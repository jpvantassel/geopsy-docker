<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ParamMinMaxWidget</name>
    <message>
        <location filename="../src/ParamMinMaxWidget.ui" line="30"/>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamMinMaxWidget.ui" line="42"/>
        <source>ParamName:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamMinMaxWidget.ui" line="68"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamMinMaxWidget.ui" line="91"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamMinMaxWidget.ui" line="117"/>
        <source>Fixed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamSpaceEditor</name>
    <message>
        <location filename="../src/ParamSpaceEditor.ui" line="13"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamSpaceEditor.ui" line="50"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Results are displayed in log message window&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamSpaceEditor.ui" line="56"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
