#ifndef DINVERGUI_HEADERS
#define DINVERGUI_HEADERS

// All headers of DinverGui library

#include "DinverGui/DinverGuiDLLExport.h"
#include "DinverGui/ParamMinMaxWidget.h"
#include "DinverGui/ParamSpaceEditor.h"

#ifndef GP_EXPLICIT_LIBRARY_NAMESPACE
using namespace DinverGui;
#endif

#endif // DINVERGUI_HEADERS
