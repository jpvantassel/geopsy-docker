/***************************************************************************
**
**  This file is part of DinverGui.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-31
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include "ParamMinMaxWidget.h"

namespace DinverGui {

/*
 *  Constructs a ParamMinMaxWidget as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
ParamMinMaxWidget::ParamMinMaxWidget( QWidget* parent, Qt::WFlags fl )
    : QWidget( parent, fl )
{
  TRACE;
  setupUi( this );

  // signals and slots connections
  connect( pMin, SIGNAL( textChanged( const QString& ) ), this, SLOT( adjustEditSize() ) );
  connect( pMax, SIGNAL( textChanged( const QString& ) ), this, SLOT( adjustEditSize() ) );
  connect( pMin, SIGNAL( textEdited( const QString& ) ), this, SIGNAL( rangeEdited() ) );
  connect( pMax, SIGNAL( textEdited( const QString& ) ), this, SIGNAL( rangeEdited() ) );

  adjustEditSize( pMin );
  adjustEditSize( pMax );
  on_pFixed_stateChanged( 0 );
}

/*
 *  Destroys the object and frees any allocated resources
 */
ParamMinMaxWidget::~ParamMinMaxWidget()
{
  TRACE;
  // no need to delete child widgets, Qt does it all for us
}

void ParamMinMaxWidget::on_pFixed_stateChanged( int )
{
  TRACE;
  if ( pFixed->isChecked() ) {
    pToLabel->hide();
    pMax->hide();
  } else {
    pToLabel->show();
    pMax->show();
  }
}

void ParamMinMaxWidget::adjustEditSize(NumericalLineEdit * obj)
{
  TRACE;
  if (!obj && sender()) {
    obj=qobject_cast<NumericalLineEdit *>(sender());
    if(!obj) return;
  }
  QString t = obj->text(0);
  QFontMetrics f( font() );
  QRect r;
  r = f.boundingRect( 0, 0, MAX_INT, MAX_INT, Qt::AlignHCenter | Qt::AlignTop, t );
  int w = r.width() + 7;
  obj->setMinimumWidth( w );
  obj->setMaximumWidth( w );
}


} // namespace DinverGui
