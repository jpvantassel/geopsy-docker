#ifndef DINVERGUIDLLEXPORT_H
#define DINVERGUIDLLEXPORT_H

/* *_STATIC and MAKE_*_DLL are defined by the capitalization of
  the package name, included in the compiler options (only for Windows).
  Use directly WIN32 to allow transparent usage with or without Qt.
  DinverGuiInstallPath.h may contain DINVERGUI_STATIC macro definition.
  This define was introduced there to mark this library as static for
  all projects that link to this library.
*/

#include "DinverGuiInstallPath.h"

#if defined(WIN32) && !defined(DINVERGUI_STATIC)
#ifdef MAKE_DINVERGUI_DLL
# define DINVERGUI_EXPORT __declspec(dllexport)
#else
# define DINVERGUI_EXPORT __declspec(dllimport)
#endif
#else
# define DINVERGUI_EXPORT
#endif

#endif  // DINVERGUIDLLEXPORT_H

