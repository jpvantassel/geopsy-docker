/***************************************************************************
**
**  This file is part of DinverGui.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-04-10
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverCore.h>
#include "ParamSpaceEditor.h"

namespace DinverGui {

/*!
  \class ParamSpaceEditor qtbparamspaceeditor.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
ParamSpaceEditor::ParamSpaceEditor( QWidget * parent )
    : QWidget(parent)
{
  TRACE;
  setupUi(this);
  connect(checkBut, SIGNAL(clicked()), this, SIGNAL(check()));

  codeEdit->setText( "// This is just an example\n"
                     "// It defines parameters, their range, their maximum precision\n"
                     "// (relative for log scale and absolute for linear scale), and\n"
                     "// the scale type\n/"
                     "parameter(\"v0\",\"m/s\",100,1000, \"log\", 0.05);\n"
                     "parameter(\"v1\",\"m/s\",500,1500, \"linear\", 50);\n"
                     "// Define conditions\n"
                     "//  A simple one: v0<1*v1+0\n"
                     "linear(\"v0\",\"<\",1,\"v1\",0);\n"
                     "// If there is a need for more complex conditions, send your request to bug@geopsy.org" );

  RealSpace sp;
  ParamExpressionContext context(&sp);
  codeEdit->setContext(context);
}

ParamSpaceScript * ParamSpaceEditor::script()
{
  TRACE;
  ParamSpaceScript * s = new ParamSpaceScript;
  s->setText( codeEdit->text() );
  return s;
}

QString ParamSpaceEditor::text()
{
  TRACE;
  return codeEdit->text();
}

void ParamSpaceEditor::setFrom( const ParamSpaceScript * script )
{
  TRACE;
  codeEdit->setText( script->text() );
}

void ParamSpaceEditor::setFrom( QString script )
{
  TRACE;
  codeEdit->setText( script );
}

void ParamSpaceEditor::setEditable( bool e )
{
  TRACE;
  codeEdit->setReadOnly( !e );
}

} // namespace DinverGui
