#ifndef GPREFRA_VERSION
#define GPREFRA_VERSION "0.1.1"
#define GPREFRA_VERSION_TIME "201101031552"
#define GPREFRA_VERSION_TYPE "testing"
#define GPREFRA_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)"
#endif // GPREFRA_VERSION
