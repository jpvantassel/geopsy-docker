<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbShReader</name>
    <message>
        <location filename="../src/qtbshreader.cpp" line="67"/>
        <source>gpsh: negative or null number of samples (option -n)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbshreader.cpp" line="71"/>
        <source>gpsh: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
