#ifndef GPSH_VERSION
#define GPSH_VERSION "0.1.3"
#define GPSH_VERSION_TIME "201212061413"
#define GPSH_VERSION_TYPE "testing"
#define GPSH_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)"
#endif // GPSH_VERSION
