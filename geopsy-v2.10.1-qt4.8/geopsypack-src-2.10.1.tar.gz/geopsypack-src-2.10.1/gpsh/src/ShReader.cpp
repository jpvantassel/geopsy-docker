/***************************************************************************
**
**  This file is part of gpsh.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-15
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include <QGpCoreWave.h>
#include "ShReader.h"

/*!
  \class ShReader qtbshreader.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
ShReader::ShReader()
    : ArgumentStdinReader()
{
  TRACE;
  _nSamples = 100;
  _samplingType = LogScale;
  _nSamples = 100;
  _minRange = 0.2;
  _maxRange = 20.0;
  _qp=0.0;
  _qs=0.0;
}

bool ShReader::setOptions( int& argc, char ** argv )
{
  TRACE;
  // Check arguments
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-s") {
        CoreApplication::checkOptionArg(i, argc, argv);
        if (strcmp(argv[i],"period")==0) {
          _samplingType = InversedScale;
        } else if (strcmp(argv[i],"frequency")==0) {
          _samplingType = LinearScale;
        } else {
          _samplingType = LogScale;
        }
      } else if (arg=="-min") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _minRange = atof(argv[i]);
        if (_minRange<=0) {
          App::stream() << tr("gpsh: negative or null value for -min") << endl;
          return false;
        }
      } else if (arg=="-max") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _maxRange = atof(argv[i]);
        if (_maxRange<=0) {
          App::stream() << tr("gpsh: negative or null value for -max") << endl;
          return false;
        }
      } else if (arg=="-qp") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _qp = atoi(argv[i]);
        if (_qp<0) {
          App::stream() << tr("gpsh: negative Qp (option -qp)") << endl;
          return false;
        }
      } else if (arg=="-qs") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _qs = atoi(argv[i]);
        if (_qs<0) {
          App::stream() << tr("gpsh: negative Qs (option -qs)") << endl;
          return false;
        }
      } else if (arg=="-n") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _nSamples = atoi(argv[i]);
        if (_nSamples<2) {
          App::stream() << tr("gpsh: number of samples less than 2 (option -n)") << endl;
          return false;
        }
      } else {
        App::stream() << tr("gpsh: bad option %1, see -help").arg(argv[i]) << endl;
        return false;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  // Compute common sampling scale
  Curve<Point1D> c;
  c.line( _minRange, 0.0, _maxRange, 0.0 );
  c.resample( _nSamples, _minRange, _maxRange, _samplingType | Function );
  _x = c.xVector();
  // SH is primarily computed on a linear scale. Get the minimum spacing between two samples
  // to adjust the number of samples for the fortran call.
  double minStep;
  switch(_samplingType) {
  case InversedScale:
    minStep=_x[_x.count()-1]-_x[_x.count()-2];
    break;
  default:
    minStep=_x[1]-_x[0];
    break;
  }
  _nRawSamples=(int)ceil(_maxRange/minStep);
  if(_nRawSamples>4096) {
    App::stream() << tr("gpsh: maximum number of samples reached (max=4096, value=%1). Either "
                        "increase minimum frequency, reduce the number of sample or "
                        "switch to 'frequency' scale (option '-s').").arg(_nRawSamples) << endl;
    return false;
  }
  // Round to next power of 2
  int n2=2;
  while(n2<_nRawSamples) n2=n2 << 1;
  _nRawSamples=n2;
  return true;
}

extern "C" int psv1d_(int * nf, float * fmax, int * ln, float * thickness,
                      float * alpha0, float * beta0, float * dens, float * qp,
                      float * qs, float * transferFonction, int * nTransferFonction);

bool ShReader::parse( QTextStream& s )
{
  TRACE;
  QTextStream sOut(stdout);
  LayeredModel m;
  QString comments;
  if (!m.fromStream(s, &comments)) {
    return false;
  }
  if(m.layerCount()>0) {
    int nf=_nRawSamples;
    float fmax=_maxRange;
    int ln=m.layerCount();
    int nTransferFonction=2*nf+1;
    float * thickness=new float[ln];
    float * alpha0=new float[ln];
    float * beta0=new float[ln];
    float * dens=new float[ln];
    float * qp=new float[ln];
    float * qs=new float[ln];
    float * transferFonction=new float[nTransferFonction];
    for(int i=0;i<ln; i++) {
      thickness[i]=i<ln-1 ? m.h(i) : 0;
      alpha0[i]=1.0/m.slowP(i);
      beta0[i]=1.0/m.slowS(i);
      dens[i]=m.rho(i);
      if(_qp>0.0) {
        qp[i]=_qp;
      } else {
        qp[i]=m.qp(i);
        if(qp[i]<=0) {
          App::stream() << tr("gpsh: negative or null value for Qp at layer %1").arg(i) << endl;
          delete [] thickness;
          delete [] alpha0;
          delete [] beta0;
          delete [] dens;
          delete [] qp;
          delete [] qs;
          delete [] transferFonction;
          return false;
        }
      }
      if(_qs>0.0) {
        qs[i]=_qs;
      } else {
        qs[i]=m.qs(i);
        if(qs[i]<=0) {
          App::stream() << tr("gpsh: negative or null value for Qs at layer %1").arg(i) << endl;
          delete [] thickness;
          delete [] alpha0;
          delete [] beta0;
          delete [] dens;
          delete [] qp;
          delete [] qs;
          delete [] transferFonction;
          return false;
        }
      }
    }
    psv1d_(&nf, &fmax, &ln, thickness, alpha0, beta0, dens, qp, qs, transferFonction, &nTransferFonction);
    Curve<Point2D> c;
    double df=(double)fmax/(nTransferFonction-1);
    for(int i=0;i<nTransferFonction;i++) {
      c.append(Point2D(df*i, 0.5*transferFonction[i]));
    }
    c.resample(_x, Function);
    c.cut(_x[0], _x[_x.count()-1], Function);
    sOut << QString("# SH transfer function\n");
    sOut << comments;
    c.toStream(sOut);
    delete [] thickness;
    delete [] alpha0;
    delete [] beta0;
    delete [] dens;
    delete [] qp;
    delete [] qs;
    delete [] transferFonction;
  }
  return true;
}
