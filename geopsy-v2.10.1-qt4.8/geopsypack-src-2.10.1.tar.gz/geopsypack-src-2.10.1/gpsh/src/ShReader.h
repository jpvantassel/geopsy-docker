/***************************************************************************
**
**  This file is part of gpsh.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-15
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef SHREADER_H
#define SHREADER_H

#include <QGpCoreTools.h>

class ShReader : public ArgumentStdinReader
{
  TRANSLATIONS("ShReader");
public:
  ShReader();

  bool setOptions( int& argc, char ** argv );
protected:
  virtual bool parse( QTextStream& s );
private:  
  SamplingOption _samplingType;
  int _nSamples;
  double _minRange;
  double _maxRange;
  double _qp, _qs;
  int _nRawSamples;

  QVector<double> _x;
};

#endif // SHREADER_H
