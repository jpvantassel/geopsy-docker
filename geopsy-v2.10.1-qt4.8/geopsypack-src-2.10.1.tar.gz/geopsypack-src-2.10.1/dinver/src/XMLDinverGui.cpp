/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-08
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverCore.h>
#include "XMLDinverGui.h"
#include "DinverGui.h"

/*!
  \class XMLDinverGui qtbxmldinvergui.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

void XMLDinverGui::xml_writeChildren( XML_WRITECHILDREN_ARGS ) const
{
  TRACE;
  XMLDinver::xml_writeChildren(s, context);
  XMLDinverContext * dinverContext=static_cast<XMLDinverContext *>(context);
  if(dinverContext->all()) {
    ThreadList ts=dinverGui->threads();
    for (ThreadList::const_iterator it=ts.begin();it!=ts.end();++it) {
      (*it)->xml_save(s, context);
    }
  }
}

XMLMember XMLDinverGui::xml_member( XML_MEMBER_ARGS )
{
  TRACE;
  Q_UNUSED(attributes)
  XMLDinverContext * dinverContext=static_cast<XMLDinverContext *>(context);
  if (tag == "InversionThread") {
    if(dinverContext->all()) {
      InversionThread * t = new InversionThread;
      dinverGui->addThread(t);
      StreamRedirection sr(&App::stream(t));
      AbstractForward * f=dinverGui->plugin()->createForward();
      if(f) {
        t->setForward(f);
        return XMLMember( t );
      } else {
        App::stream() << tr("Error creating a new forward object, skipping run") << endl;
        return XMLMember(XMLMember::Skip);
      }
    } else {
      return XMLMember(XMLMember::Skip);
    }
  } else return XMLDinver::xml_member(tag, attributes, context);
}
