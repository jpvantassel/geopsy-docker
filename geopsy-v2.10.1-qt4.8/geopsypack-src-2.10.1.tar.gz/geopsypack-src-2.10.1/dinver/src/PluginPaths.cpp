/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-11-06
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QSettings>

#include <QGpCoreTools.h>
#include "PluginPaths.h"

PluginPaths::PluginPaths( QWidget * parent )
    : Dialog( parent )
{
  TRACE;
  setupUi( this );

  QSettings reg;
  reg.beginGroup( "Plugins" );
  QStringList paths = reg.value( "Paths" ).toStringList();
  pathList->addItems( paths );
}

PluginPaths::~PluginPaths()
{
  TRACE;}

void PluginPaths::on_addPath_clicked()
{
  TRACE;
#if defined (Q_WS_X11)
  QString path = Message::getExistingDirectory( tr( "Add plugin search path" ), tr("Dinver plugin (*.so)") );
#elif defined (Q_WS_WIN)
  QString path = Message::getExistingDirectory( tr( "Add plugin search path" ), tr("Dinver plugin (*.dll)") );
#elif defined (Q_WS_MAC)
  QString path = Message::getExistingDirectory( tr( "Add plugin search path" ), tr("Dinver plugin (*.dylib)") );
#endif
  if ( !path.isEmpty() ) pathList->addItem( path );
}

void PluginPaths::on_removePath_clicked()
{
  TRACE;
  delete pathList->takeItem( pathList->currentRow() );
}

QStringList PluginPaths::getPaths()
{
  TRACE;
  QStringList paths;
  int n = pathList->count();
  for ( int i = 0;i < n;i++ ) {
    paths << pathList->item( i ) ->text();
  }
  QSettings reg;
  reg.beginGroup( "Plugins" );
  reg.setValue( "Paths", paths );
  return paths;
}
