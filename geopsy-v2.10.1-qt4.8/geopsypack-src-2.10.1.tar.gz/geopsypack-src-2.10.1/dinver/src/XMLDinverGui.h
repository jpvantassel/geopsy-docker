/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-08
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef XMLDINVERGUI_H
#define XMLDINVERGUI_H

#include <DinverCore.h>

class XMLDinverGui : public XMLDinver
{
  TRANSLATIONS("XMLDinverGui")
protected:
  void xml_writeChildren( XML_WRITECHILDREN_ARGS ) const;
  XMLMember xml_member( XML_MEMBER_ARGS );
};

#endif // XMLDINVERGUI_H
