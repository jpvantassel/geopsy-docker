/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-31
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QWorkspace>
#include <QCloseEvent>
#include <QToolBar>
#include <QMenuBar>
#include <QStatusBar>
#include <QWhatsThis>
#include <QPluginLoader>
#include <QSettings>
#include <QUrl>
#include <QDesktopServices>

#include <DinverCore.h>
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include "DinverGui.h"
#include "ThreadLauncher.h" 
#include "ProcessStatus.h"
#include "InversionThread.h"
#include "PluginSelector.h"
#include "SelectPSViewer.h"
#include "dinverInstallPath.h"
#include "dinverVersion.h"
#include "XMLDinverGui.h"

DinverGui::DinverGui( QWidget* parent, Qt::WFlags fl )
    : QMainWindow( parent, fl )
{
  TRACE;
  setWindowTitle( tr( "dinver" ) );
  setIconSize( QSize( 24, 24 ) );
  resize( QSize( 778, 533 ).expandedTo( minimumSizeHint() ) );
  setAttribute( Qt::WA_DeleteOnClose, true );

  _ws = new QWorkspace( this );
  _ws->setScrollBarsEnabled( true );
  setWidgetColor( _ws, QColor( 220, 220, 220 ) );
  connect( _ws, SIGNAL( windowActivated( QWidget * ) ),
           this, SLOT( activeWindowChanged( QWidget * ) ) );
  connect( this, SIGNAL(pluginsReady()), this, SLOT(setToolsMenuState()), Qt::QueuedConnection);

  setCentralWidget(_ws);

  UpdateIcon * liveUpdate=new UpdateIcon(statusBar());
  liveUpdate->setName("dinver");
  liveUpdate->setVersion(DINVER_VERSION);
  liveUpdate->setVersionType(DINVER_VERSION_TYPE);
  QSettings reg;
  reg.beginGroup("Plugins");
  liveUpdate->addPlugins(reg.value("pluginList").toStringList());
  statusBar()->addPermanentWidget(liveUpdate, 0);

  // Progress and status bar
  _progressBar = new ProgressBar(statusBar());
  _progressBar->setMaximumWidth(100);
  _progressBar->setMaximumHeight(20);
  _progressBar->setMaximum(100);
  _progressBar->setValue(0);
  statusBar()->addPermanentWidget(_progressBar, 0);
  statusBar()->setSizeGripEnabled(true);
  statusBar()->showMessage(tr("Ready"), 2000);

  _logs = 0;
  _runs = 0;
  _status = 0;
  _targetDock = 0;
  _paramDock = 0;
}

DinverGui::~DinverGui()
{
  TRACE;
  for ( ThreadList::iterator it = _threads.begin();it != _threads.end();++it ) {
    delete *it;
  }
  if (plugin()) {
    QSettings reg;
    reg.beginGroup("Workspace");
    reg.setValue(plugin()->tag(),saveState(0));
  }
}

void DinverGui::closeEvent ( QCloseEvent * e )
{
  TRACE;
  if (stopAll() && warnBeforeClose() ) {
    Settings::setRect( this, "dinver Root" );
    e->accept();
    _ws->closeAllWindows();
    QApplication::processEvents(QEventLoop::DeferredDeletion);
  } else {
    e->ignore();
  }
}

bool DinverGui::stopAll()
{
  TRACE;
  int runningProcess=0;
  for ( ThreadList::iterator it = _threads.begin();it != _threads.end();++it ) {
    if((*it)->isRunning()) runningProcess++;
  }
  if (runningProcess>0 || _runs->isQueued()) {
    if (Message::warning( MSG_ID, tr("Closing dinver"),
                            tr("There are still %1 running or queued processes. "
                               "Do you want to stop them?").arg(runningProcess),
                               Message::no(), Message::yes())==Message::Answer0) {
      return false;
    }
    // Dequeue all runs
    _runs->dequeueAll();
    for ( ThreadList::iterator it = _threads.begin();it != _threads.end();++it ) {
      if((*it)->isRunning()) (*it)->terminate();
    }
  }
  return true;
}

bool DinverGui::warnBeforeClose()
{
  TRACE;
  TRACE_BUG;
  if (isModified() && plugin()->xmlSupport()) {
    TRACE_BUG_N(10);
    switch (Message::warning(MSG_ID, tr("Closing dinver"),
                             tr( "Do you want to save the changes to the current environment?"),
                             Message::yes(), Message::no(), Message::cancel())) {
    case Message::Answer0: {
        TRACE_BUG_N(1);
        save();
        TRACE_BUG_N(2);
        if (isModified()) {
          return false;
        }
      }
      break;
    case Message::Answer1:
      break;
    default:
      return false;
    }
  } else if (Message::question(MSG_ID, tr("Closing dinver"), tr("Are you sure?"), Message::no(), Message::yes())==Message::Answer0) {
    TRACE_BUG_N(3);
    return false;
  }
  return true;
}

QString DinverGui::pluginSelector( QString tag, bool debug )
{
  TRACE;
  QString plugin;
  if ( tag.isEmpty() ) {
    // Init of _plugin to load the correct one
    PluginSelector * d=new PluginSelector(0, debug);
    Settings::getWidget(d);
    if (d->exec()==QDialog::Accepted) {
      Settings::setWidget(d);
      plugin=d->file();
    }
    delete d;
  } else {
    plugin = pluginFile(tag, debug);
  }
  return plugin;
}

bool DinverGui::setPlugin(QString pluginFile)
{
  TRACE;
  if (pluginFile.isEmpty()) return false;
  if(!DinverCoreObject::setPlugin(pluginFile,false)) {
    return false;
  }

  QWidget * target=plugin()->createTargetWidget();
  if (target) {
    _targetDock = new DockWidget( this );
    connect(_targetDock, SIGNAL(hidden()), this, SLOT(setToolsMenuState()), Qt::QueuedConnection);
    _targetDock->setObjectName( "Targets" );
    _targetDock->setWindowTitle( tr("Targets") );
    _targetDock->setFeatures ( QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetClosable );
    _targetDock->setAllowedAreas( Qt::AllDockWidgetAreas );
    _targetDock->setWidget( target );
    addDockWidget( Qt::LeftDockWidgetArea, _targetDock );
  }

  QWidget * param=plugin()->createParamWidget();
  if (param) {
    _paramDock = new DockWidget( this );
    connect(_paramDock, SIGNAL(hidden()), this, SLOT(setToolsMenuState()), Qt::QueuedConnection);
    _paramDock->setObjectName( "Parameters" );
    _paramDock->setWindowTitle( tr("Parameters") );
    _paramDock->setFeatures ( QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetClosable );
    _paramDock->setAllowedAreas( Qt::AllDockWidgetAreas );
    _paramDock->setWidget( param );
    addDockWidget( Qt::BottomDockWidgetArea, _paramDock );
  }

  addDocks( _targetDock, _paramDock);
  addActions();
  QSettings reg;
  reg.beginGroup("Workspace");
  restoreState(reg.value(plugin()->tag()).toByteArray(),0);
  setToolsMenuState();
  Settings::getRect( this, "dinver Root" );
  emit pluginsReady();
  return true;
}

void DinverGui::addDocks( DockWidget * leftDock, DockWidget * bottomDock )
{
  TRACE;
  DockWidget * logDock = new DockWidget( this );
  connect(logDock, SIGNAL(hidden()), this, SLOT(setToolsMenuState()), Qt::QueuedConnection);
  logDock->setObjectName( "Log" );
  logDock->setWindowTitle( tr("Log") );
  logDock->setFeatures ( QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetClosable );
  logDock->setAllowedAreas( Qt::AllDockWidgetAreas );
  _logs = new LogWidget ( logDock );
  logDock->setWidget( _logs );
  addDockWidget ( Qt::LeftDockWidgetArea, logDock );
  if ( leftDock )
    tabifyDockWidget( leftDock, logDock );

  DockWidget * runDock = new DockWidget( this );
  connect(runDock, SIGNAL(hidden()), this, SLOT(setToolsMenuState()), Qt::QueuedConnection);
  runDock->setObjectName( "Runs" );
  runDock->setWindowTitle( tr("Runs") );
  runDock->setFeatures ( QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetClosable );
  runDock->setAllowedAreas( Qt::AllDockWidgetAreas );
  _runs = new ThreadLauncher ( runDock );
  runDock->setWidget( _runs );
  addDockWidget ( Qt::LeftDockWidgetArea, runDock );
  connect( _runs, SIGNAL( setCurrentRuns( ThreadList ) ), this, SLOT( setCurrentRuns( ThreadList ) ) );
  tabifyDockWidget( logDock, runDock );

  DockWidget * statusDock = new DockWidget( this );
  connect(statusDock, SIGNAL(hidden()), this, SLOT(setToolsMenuState()), Qt::QueuedConnection);
  statusDock->setObjectName( "Status" );
  statusDock->setWindowTitle( tr("Status") );
  statusDock->setFeatures ( QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetClosable );
  statusDock->setAllowedAreas( Qt::AllDockWidgetAreas );
  _status = new ProcessStatus ( statusDock );
  statusDock->setWidget( _status );
  addDockWidget ( Qt::BottomDockWidgetArea, statusDock );
  if ( bottomDock )
    tabifyDockWidget( bottomDock, statusDock );
  connect( &_bigBen, SIGNAL( synchroTimeout() ), _status, SLOT( synchronize() ) );
}

void DinverGui::addActions()
{
  TRACE;
  addFileActions();
  addViewActions();
  addRunsActions();
  addToolsActions();
  addWindowsActions();
  addHelpActions();
}

void DinverGui::addFileActions()
{
  TRACE;
  QAction * a;
  QMenu * m;

  m = menuBar() ->addMenu( tr( "&File" ) );
  m->setTearOffEnabled ( true );

  if(plugin()->xmlSupport()) {
    a = new QAction( QIcon( ":/images/filenew.png" ), tr( "New" ), this );
    a->setStatusTip( tr( "Close current environment (if any) and clean everything" ) );
    connect( a, SIGNAL( triggered() ), this, SLOT( clear() ) );
    m->addAction( a );

    a = new QAction( QIcon( ":/images/fileopen.png" ), tr( "Open" ), this );
    a->setStatusTip( tr( "Open an environment (targets, parameters and runs)" ) );
    connect( a, SIGNAL( triggered() ), this, SLOT( open() ) );
    m->addAction( a );

    a = new QAction( QIcon( ":/images/filesave.png" ), tr( "Save" ), this );
    a->setStatusTip( tr( "Save current environment (targets, parameters and runs)" ) );
    connect( a, SIGNAL( triggered() ), this, SLOT( save() ) );
    m->addAction( a );

    a = new QAction( tr( "Save as ..." ), this );
    a->setStatusTip( tr( "Save current environment (targets, parameters and runs)" ) );
    connect( a, SIGNAL( triggered() ), this, SLOT( saveAs() ) );
    m->addAction( a );
  }

  if(_targetDock || _paramDock) {
    m->addSeparator();

    if(_targetDock) {
      a = new QAction( tr( "Import targets" ), m );
      a->setStatusTip( tr( "Import current targets" ) );
      connect( a, SIGNAL( triggered() ), this, SLOT( importTargets() ) );
      m->addAction( a );
      _importTargetsAction = a;

      a = new QAction( tr( "Export targets" ), m );
      a->setStatusTip( tr( "Export current targets" ) );
      connect( a, SIGNAL( triggered() ), this, SLOT( exportTargets() ) );
      m->addAction( a );
    }
    if(_paramDock) {
      a = new QAction( tr( "Import parameterization" ), m );
      a->setStatusTip( tr( "Import current parameterization" ) );
      connect( a, SIGNAL( triggered() ), this, SLOT( importParameters() ) );
      m->addAction( a );
      _importParamsAction = a;

      a = new QAction( tr( "Export parameterization" ), m );
      a->setStatusTip( tr( "Export current parameterization" ) );
      connect( a, SIGNAL( triggered() ), this, SLOT( exportParameters() ) );
      m->addAction( a );
    }
  }

  m->addSeparator();

  a = new QAction( tr( "&Quit" ), this );
  a->setShortcut( tr( "Ctrl+Q" ) );
  a->setStatusTip( tr( "Quit Geopsy" ) );
  connect( a, SIGNAL( triggered() ), this, SLOT( close() ) );
  m->addAction( a );
}

void DinverGui::addViewActions()
{
  TRACE;
  QAction * a;
  QMenu * m;

  m = menuBar() ->addMenu( tr( "&View" ) );
  m->setTearOffEnabled ( true );

  a = new QAction( tr( "&Parameter Space" ), this );
  a->setStatusTip( tr( "Create a new sheet with customizable projections of multidimensional parameter spaces." ) );
  connect( a, SIGNAL( triggered() ), this, SLOT( viewPS() ) );
  m->addAction( a );

  m->addSeparator();
  plugin()->addViewMenu(m);
}

void DinverGui::addRunsActions()
{
  TRACE;
  QAction * a;
  QMenu * m;

  m = menuBar() ->addMenu( tr( "&Runs" ) );
  m->setTearOffEnabled ( true );

  a = new QAction( tr( "&Add" ), this );
  a->setStatusTip( tr( "Add a new process with the current parameterization and a new random seed." ) );
  connect( a, SIGNAL( triggered() ), _runs, SLOT( newThread() ) );
  m->addAction( a );

  a=new QAction(tr("&Remove"), this);
  a->setStatusTip( tr( "Remove selected run from the current environment" ) );
  connect( a, SIGNAL( triggered() ), _runs, SLOT( remove() ) );
  m->addAction(a);

  m->addSeparator();

  a = new QAction( tr( "Star&t" ), this );
  a->setStatusTip( tr( "Start selected runs." ) );
  connect( a, SIGNAL( triggered() ), _runs, SLOT( start() ) );
  m->addAction( a );

  a = new QAction( tr( "&Stop" ), this );
  a->setStatusTip( tr( "Stop currently selected runs (no effect if no process is running)." ) );
  connect( a, SIGNAL( triggered() ), _runs, SLOT( stop() ) );
  m->addAction( a );

  a=new QAction(tr("&Clear"), this);
  a->setStatusTip( tr( "Remove all generated models from selected runs, remove .report file if any." ) );
  connect( a, SIGNAL( triggered() ), _runs, SLOT( clear() ) );
  m->addAction(a);

  a=new QAction(tr("&Show"), this);
  a->setStatusTip( tr( "In this mode, the target and the parameterization of each run can be viewed (export/import)." ) );
  a->setCheckable( true );
  a->setChecked( false );
  connect( a, SIGNAL( toggled(bool) ), _runs, SLOT( show(bool) ) );
  m->addAction(a);
  _showRunAction = a;

  m->addSeparator();

  a=new QAction(tr("&Import models"), this);
  a->setStatusTip( tr( "Populate the parameter space of selected run with models saved in .report file "
                       "(generated by another run)" ) );
  connect( a, SIGNAL( triggered() ), _runs, SLOT( importModels() ) );
  m->addAction(a);
}

void DinverGui::addToolsActions()
{
  TRACE;
  QAction * a;
  QMenu * m;

  m = menuBar() ->addMenu( tr( "&Tools" ) );
  m->setTearOffEnabled ( true );
  _toolsMenu = m;

  QList<DockWidget *> dockwidgetList = findChildren<DockWidget *>();
  for ( QList<DockWidget *>::iterator it = dockwidgetList.begin();it != dockwidgetList.end();++it ) {
    a = new QAction( ( *it ) ->windowTitle(), this );
    QByteArray wPtr( ( const char * ) & ( *it ), sizeof( DockWidget * ) );
    a->setData( wPtr );
    a->setCheckable( true );
    connect( a, SIGNAL( toggled( bool ) ), *it, SLOT( setVisible( bool ) ) );
    m->addAction( a );
  }

  m->addSeparator();

  QList<QToolBar *> toolBarList = findChildren<QToolBar *>();
  for ( QList<QToolBar *>::iterator it = toolBarList.begin();it != toolBarList.end();++it ) {
    a = new QAction( ( *it ) ->windowTitle(), this );
    QByteArray wPtr( ( const char * ) & ( *it ), sizeof( QToolBar * ) );
    a->setData( wPtr );
    a->setCheckable( true );
    connect( a, SIGNAL( toggled( bool ) ), *it, SLOT( setVisible( bool ) ) );
    m->addAction( a );
  }
}

void DinverGui::addWindowsActions()
{
  TRACE;
  QAction * a;
  QMenu * m;

  m = menuBar() ->addMenu( tr( "&Windows" ) );
  m->setTearOffEnabled ( true );
  _windowsMenu = m;

  a = new QAction( tr( "&Cascade" ), this );
  a->setEnabled( false );
  connect( a, SIGNAL( triggered() ), _ws, SLOT( cascade() ) );
  m->addAction( a );
  _windowsCascadeAction = a;

  a = new QAction( tr( "Tile &Vertically" ), this );
  a->setEnabled( false );
  connect( a, SIGNAL( triggered() ), _ws, SLOT( tile() ) );
  m->addAction( a );
  _windowsTileVAction = a;

  a = new QAction( tr( "Tile &Horizontally" ), this );
  a->setEnabled( false );
  connect( a, SIGNAL( triggered() ), this, SLOT( tileHorizontal() ) );
  m->addAction( a );
  _windowsTileHAction = a;

  a = new QAction( tr( "Close &all" ), this );
  a->setEnabled( false );
  connect( a, SIGNAL( triggered() ), this, SLOT( closeAllWindows() ) );
  m->addAction( a );
  _windowsCloseAllAction = a;

  a = new QAction( tr( "&Minimize" ), this );
  a->setEnabled( false );
  connect( a, SIGNAL( triggered() ), this, SLOT( windowsMinimize() ) );
  m->addAction( a );
  _windowsMinimizeAction = a;

  m->addSeparator();
}

void DinverGui::addHelpActions()
{
  TRACE;
  QAction * a;
  QMenu * m;

  m = menuBar() ->addMenu( tr( "&Help" ) );
  m->setTearOffEnabled ( true );

  a = new QAction( tr( "Online dinver &Documentation" ), this );
  a->setShortcut( tr( "F1" ) );
  a->setStatusTip( tr( "Access to online html documentation" ) );
  connect( a, SIGNAL( triggered() ), this, SLOT( helpDocumentation() ) );
  m->addAction( a );

  a = QWhatsThis::createAction( this );
  m->addAction( a );

  m->addSeparator();

  a = new QAction( tr( "&About" ), this );
  a->setStatusTip( tr( "Show dinver's About box" ) );
  connect( a, SIGNAL( triggered() ), this, SLOT( helpAbout() ) );
  m->addAction( a );

  a = new QAction( tr( "About &Qt" ), this );
  a->setStatusTip( tr( "Show the Qt library's About box" ) );
  connect( a, SIGNAL( triggered() ), qApp, SLOT( aboutQt() ) );
  m->addAction( a );
}

bool DinverGui::clear()
{
  TRACE;
  if (!stopAll()) return false;
  if (!closeAllPSViewers()) return false;
  qDeleteAll(_threads);
  _threads.clear();
  emit newThread(0);
  _status->clear();
  plugin()->clear();
  _currentFile="";
  setWindowTitle( "dinver" );
  return true;
}

void DinverGui::open( QString fileName )
{
  TRACE;
  if ( fileName.isEmpty() ) {
    fileName = Message::getOpenFileName( tr( "Open an existing environment" ),
                                         tr( "Dinver environment (*.dinver)" ) );
  } else {
    QFileInfo fi(fileName);
    fileName = fi.absoluteFilePath();
  }
  if ( fileName.length() > 0 ) {
    if (!clear()) return;
    MessageContext mc;
    XMLDinverContext dinverContext(XMLDinverContext::All);
    XMLDinverGui dinver;
    XMLDinverHeader hdr(&dinver);
    if (hdr.xml_restoreFile(fileName, &dinverContext)==XMLClass::NoError) {
      _currentFile = fileName;
      setWindowTitle( "dinver - " + _currentFile );
      QApplication::processEvents(QEventLoop::ExcludeUserInputEvents);
      // Load the models
      int n = _threads.count();
      setProgressMaximum(n-1);
      for (int i = 0;i<n; i++) {
        InversionThread * t = _threads.at(i);
        t->importModels();
        if (!t->hasReportFile()) {
          t->setReportDir(currentReportDir());
        }
        setProgressValue(i);
        QApplication::processEvents(QEventLoop::ExcludeUserInputEvents);
      }
    } else {
      _currentFile = QString::null;
      setWindowTitle( "dinver" );
      Message::warning( MSG_ID, tr("Opening environment"), tr("Encountered error(s) while opening your environment. "
                                                             "It is partially loaded. See log for details."));
    }
    _status->synchronize();
  }
}

void DinverGui::saveAs( QString fileName )
{
  TRACE;
  if ( fileName.isEmpty() ) {
    fileName = Message::getSaveFileName( tr( "Save current environment" ),
                                            tr( "Dinver environment (*.dinver)" ) );
  }
  if ( fileName.length() > 0 ) {
    _currentFile = fileName;
    save();
    setWindowTitle( "dinver - " + _currentFile );
  }
}

/*!
  Save parameters, target and all runs. If reports are stored in temp directory, save them in the same directory as
  the environment file.
*/
void DinverGui::save()
{
  TRACE;
  if ( _currentFile.isEmpty() ) {
    saveAs ();
    return ;
  }
  if ( _currentFile.length() > 0 ) {
    // Tranfer report files to the directory of dinver environment file
    QDir d=currentReportDir();
    bool unsavedInTempDir = false;  // check meanwhile if there are still reports in the temp file
    int n = _threads.count();
    setProgressMaximum(n-1);
    for (int i = 0;i<n; i++) {
      InversionThread * t = _threads.at(i);
      if (t->setReportDir(d)) {
        if ( t->reportDir().absolutePath() == _tempDir.absolutePath() ) {
          // Clean temp directory
          d.setPath( _tempDir.absolutePath() );
          d.remove(t->objectName());
        }
      } else {
        unsavedInTempDir = true;
      }
      setProgressValue(i);
      QApplication::processEvents(QEventLoop::ExcludeUserInputEvents);
    }
    XMLDinverContext dinverContext(XMLDinverContext::All);
    XMLDinverGui dinver;
    XMLDinverHeader hdr(&dinver);
    if (hdr.xml_saveFile(_currentFile, &dinverContext)==XMLClass::NoError) {
      if (unsavedInTempDir) {
        Message::warning( MSG_ID, tr("Saving environment"), tr("Some inversion process are still running and their models are stored "
                                                              "in temporary directory. Stop these processes or wait for their " 
                                                              "completion before saving again. When quitting, the temporary "
                                                              "directory is cleaned and models (directly stored in .report file) " 
                                                              "will be lost. See log for details."));
      } else {
        setModified(false);
      }
    } else {
      Message::warning( MSG_ID, "Saving environment",
                           "Cannot open file for writing", Message::cancel() );
    }
  }
}

void DinverGui::importTargets(QString fileName)
{
  if ( fileName.isEmpty() ) {
    fileName = Message::getOpenFileName( tr( "Import targets" ),
                                            tr( "Dinver targets (*.target);;"
                                                "Dinver environment (*.dinver)" ) );
  }
  if ( !fileName.isEmpty() ) {
    XMLDinverContext dinverContext(XMLDinverContext::Targets);
    XMLDinver dinver;
    XMLDinverHeader hdr(&dinver);
    if (hdr.xml_restoreFile(fileName, &dinverContext) != XMLClass::NoError) {
      Message::warning( MSG_ID, tr("Import targets"), tr("Error parsing file"), Message::cancel() );
    }
  }
}
void DinverGui::exportTargets(QString fileName)
{
  if ( fileName.isEmpty() ) {
    fileName = Message::getSaveFileName(tr( "Export targets" ),
                                           tr( "Dinver targets (*.target)" ),
                                           QString::null);
  }
  if ( !fileName.isEmpty() ) {
    XMLDinverContext dinverContext(XMLDinverContext::Targets);
    XMLDinver dinver;
    XMLDinverHeader hdr(&dinver);
    if (hdr.xml_saveFile(fileName, &dinverContext) == XMLClass::ErrorFileNotOpen) {
      Message::warning( MSG_ID, tr("Export targets"), tr("Cannot open file for writing"), Message::cancel() );
    }
  }
}

void DinverGui::importParameters(QString fileName)
{
  if ( fileName.isEmpty() ) {
    fileName = Message::getOpenFileName( tr( "Import paramters" ),
                                            tr( "Dinver parameters (*.param);;"
                                                "Dinver environment (*.dinver)" ) );
  }
  if ( !fileName.isEmpty() ) {
    XMLDinverContext dinverContext(XMLDinverContext::Parameters);
    XMLDinver dinver;
    XMLDinverHeader hdr(&dinver);
    if (hdr.xml_restoreFile(fileName, &dinverContext) != XMLClass::NoError) {
      Message::warning( MSG_ID, tr("Import parameters"), tr("Error parsing file"), Message::cancel() );
    }
  }
}

void DinverGui::exportParameters(QString fileName)
{
  if ( fileName.isEmpty() ) {
    fileName = Message::getSaveFileName(tr( "Export parameters" ),
                                           tr( "Dinver parameters (*.param)"),
                                           QString::null);
  }
  if ( !fileName.isEmpty() ) {
    XMLDinverContext dinverContext(XMLDinverContext::Parameters);
    XMLDinver dinver;
    XMLDinverHeader hdr(&dinver);
    if (hdr.xml_saveFile(fileName, &dinverContext) == XMLClass::ErrorFileNotOpen) {
      Message::warning( MSG_ID, tr("Export parameters"), tr("Cannot open file for writing"), Message::cancel() );
    }
  }
}

QDir DinverGui::currentReportDir() const
{
  TRACE;
  if (_currentFile.isEmpty()) {
    return _tempDir.absolutePath();
  } else {
    QFileInfo fi(_currentFile);
    QDir d=fi.absoluteDir();
    if (!d.exists()) {
      d.mkpath(d.absolutePath());
    }
    QString reportDir=fi.baseName()+"_reports";
    if (!d.exists(reportDir)) {
      d.mkdir(reportDir);
    }
    d.cd(reportDir);
    return d;
  }
}

/*!
  Add window w to MDI window system.
  
  To close the window, you must call removeWindow() before deleting the window.
*/
void DinverGui::addWindow ( QWidget * w )
{
  TRACE;
  _ws->addWindow( w );
  windowsMenuAdd( w );
}

/*!
  Remove window w from MDI window system.
  
  Window w is not deleted. It must be done after calling this function.
*/
void DinverGui::removeWindow ( QWidget * w )
{
  TRACE;
  windowsMenuRemove( w );
}

/*!
  Do not call QWidget::show() directly. Use this function instead.
*/
void DinverGui::showWindow ( QWidget * w )
{
  TRACE;
  if ( _ws->activeWindow() && _ws->activeWindow() ->isMaximized() )
    w->showMaximized();
  else w->show();
}

/*!
  Call this function whenever the title of the window change. A usual place for this function is inside a
  re-implementation of QWidget::setWindowTitle().
*/
void DinverGui::updateWindowTitle( QWidget * w )
{
  TRACE;
  QAction * a = windowsMenuAction( w );
  if ( a && w ) {
    QString title = w->windowTitle();
    if ( title.length() > 35 ) title = title.left( 35 ) + "...";
    a->setText( title );
  }
}

void DinverGui::windowsMenuAdd( QWidget * w )
{
  TRACE;
  if ( _windowsMenu->actions().count() == 6 ) setWindowsMenuEnabled( true );
  const QIcon icon = w->windowIcon();
  QString title = w->windowTitle();
  if ( title.length() > 35 ) title = title.left( 35 ) + "...";
  QAction * a = new QAction( title, this );
  if ( !icon.isNull() ) a->setIcon( icon );
  connect( a, SIGNAL( triggered() ), this, SLOT( windowsMenuTriggered() ) );
  QByteArray windowPtr( ( const char * ) & w, sizeof( QWidget * ) );
  a->setData( windowPtr );
  a->setCheckable( true );
  _windowsMenu->addAction( a );
}

QAction * DinverGui::windowsMenuAction( QWidget * w )
{
  TRACE;
  QList<QAction *> aList = _windowsMenu->actions();
  for ( int i = 6;i < aList.count();i++ ) {
    QAction * a = aList.at( i );
    if ( *reinterpret_cast<QWidget **>( a->data().toByteArray().data() ) == w ) return a;
  }
  return 0;
}

void DinverGui::windowsMenuRemove( QWidget * w )
{
  TRACE;
  QAction * a = windowsMenuAction( w );
  if ( a ) _windowsMenu->removeAction( a );
  if ( _windowsMenu->actions().count() == 6 ) setWindowsMenuEnabled( false );
}

void DinverGui::windowsMenuSetCurrent( QWidget * w )
{
  TRACE;
  QList<QAction *> aList = _windowsMenu->actions();
  for ( int i = 6;i < aList.count();i++ ) {
    QAction * a = aList.at( i );
    a->setChecked( *( QWidget ** ) a->data().toByteArray().data() == w );
  }
}

void DinverGui::windowsMenuTriggered()
{
  TRACE;
  QAction * a = qobject_cast<QAction *>( sender() );
  if ( a ) {
    QWidget * w = *( QWidget ** ) a->data().toByteArray().data();
    if ( w ) {
      qApp->setActiveWindow( this );
      showWindow( w );
      w->setFocus();
      windowsMenuSetCurrent( w );
    }
  }
}

void DinverGui::tileHorizontal()
{
  TRACE;
  // primitive horizontal tiling
  QWidgetList windows = _ws->windowList( QWorkspace::CreationOrder );
  if ( !windows.count() ) return ;

  int heightForEach = _ws->height() / windows.count();
  int y = 0;
  for ( int i = 0; i < windows.count(); ++i ) {
    QWidget *window = windows.at( i );
    if ( window->windowState() & Qt::WindowMaximized ) {
      // prevent flicker
      window->hide();
      window->showNormal();
    }
    int preferredHeight = window->minimumHeight() + window->parentWidget() ->baseSize().height();
    int actHeight = ( preferredHeight > heightForEach ) ? preferredHeight : heightForEach;

    window->parentWidget() ->setGeometry( 0, y, _ws->width(), actHeight );
    y += actHeight;
  }
}

void DinverGui::windowsMinimize()
{
  TRACE;
  _ws->activeWindow() ->showMinimized();
}

void DinverGui::activeWindowChanged( QWidget * )
{
  TRACE;
  windowsMenuSetCurrent( _ws->activeWindow() );
}

void DinverGui::setWindowsMenuEnabled( bool b )
{
  TRACE;
  _windowsCascadeAction->setEnabled( b );
  _windowsTileVAction->setEnabled( b );
  _windowsTileHAction->setEnabled( b );
  _windowsCloseAllAction->setEnabled( b );
  _windowsMinimizeAction->setEnabled( b );
}

void DinverGui::helpDocumentation()
{
  TRACE;
  QDesktopServices::openUrl(QUrl("http://www.geopsy.org/wiki/index.php/Dinver"));
}

void DinverGui::helpAbout()
{
  TRACE;
  QString version("Version: ");
  version+=DINVER_VERSION;
  if(strlen(DINVER_DISTRIBUTION)>0) {
    version+=" (";
    version+=DINVER_DISTRIBUTION;
    version+=")";
  }
  Dialog * d=new Dialog(this);
  d->setWindowTitle(tr("About dinver"));
  d->setMinimumSize(500,300);
  QLabel * text=new QLabel;
  text->setTextFormat(Qt::RichText);
  text->setWordWrap(true);
  text->setOpenExternalLinks(true);
  text->setText(tr("<p>%1</p>"
                   "<p>Dinver is a framework for inversion problems. The core engine is a "
                   "Neighbourhood Algorithm originally proposed by Sambridge (1999), implemented in C++ "
                   "and improved by <a href=\"http://www.geopsy.org/#References\">Wathelet (2008)</a>.</p>"
                   "<p>Each specific inversion problem can be coded with a simple API and packaged in a "
                   "dynamic library (plugin).</p>"
                   "<p>Using, Copying and Modifying this program is granted to everyone under the terms "
                   "of the GNU Public License version 2. <b>However, we would appreciate that you properly "
                   "reference this work, released for free, in all your publications or reports achieved "
                   "with this software.</b></p>"
                   "<p>This program is provided AS IS with NO WARRANTY OF ANY KIND, "
                   "INCLUDING THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS "
                   "FOR A PARTICULAR PURPOSE.</p>").arg(version));
  d->setMainWidget(text, Dialog::Close);
  d->exec();
  delete d;
}

void DinverGui::addThread( InversionThread * t )
{
  TRACE;
  _threads.append( t );
  connect( t, SIGNAL( started() ), &_bigBen, SLOT( threadStarted() ) );
  connect( t, SIGNAL( stopped() ), &_bigBen, SLOT( threadStopped() ) );
  connect( t, SIGNAL(stopped()), _runs, SLOT(processFinished()) );
  emit newThread(t);
}

void DinverGui::setCurrentRuns( ThreadList tList )
{
  if ( !_showRunAction->isChecked() ) {
    tList.clear();
  }
  if( tList.count()==1 ) {
    InversionThread * t = tList.first();
    plugin()->setCurrentForward( t->forward(), t->objectName() );
    if (_paramDock) {
      _importParamsAction->setEnabled( false );
      _paramDock->setWindowTitle(tr("Parameters of %1").arg(t->objectName()));
    }
    if (_targetDock) {
      _importTargetsAction->setEnabled( false );
      _targetDock->setWindowTitle(tr("Targets of %1").arg(t->objectName()));
    }
  } else {
    plugin()->setCurrentForward( 0, QString::null );
    if (_paramDock) {
      _paramDock->setWindowTitle(tr("Parameters"));
      _importParamsAction->setEnabled(true);
    }
    if (_targetDock) {
      _importTargetsAction->setEnabled(true);
      _targetDock->setWindowTitle(tr("Targets"));
    }
  }
}

void DinverGui::viewPS()
{
  TRACE;
  bool allOfTheSameType;
  ThreadList selThreads=selectedThreads(allOfTheSameType);
  if ( selThreads.isEmpty() ) return ;
  if ( allOfTheSameType ) {
    SelectPSViewer * d = new SelectPSViewer ( this );
    d->init( psViewerList(), selThreads.first() );
    d->setWindowTitle( tr( "View all selected runs" ) );
    if ( d->exec() == QDialog::Accepted ) {
      PSViewer * psViewer = d->result();
      for (ThreadList::iterator it=selThreads.begin();it!=selThreads.end();++it) {
        psViewer->addThreadData( *it );
      }
      psViewer->synchronize();
      psViewer->setLimits();
    }
  } else {
    for (ThreadList::iterator it=selThreads.begin();it!=selThreads.end();++it) {
      SelectPSViewer * d = new SelectPSViewer ( this );
      d->init( psViewerList(), *it );
      d->setWindowTitle( tr( "View run %1" ).arg( ( *it ) ->objectName() ) );
      if ( d->exec() == QDialog::Accepted ) {
        PSViewer * psViewer = d->result();
        psViewer->addThreadData( *it );
        psViewer->synchronize();
        psViewer->setLimits();
      }
    }
  }
}

ThreadList DinverGui::selectedThreads(bool& allOfTheSameType) const
{
  TRACE;
 return _runs->threadTable->selectedThreads(allOfTheSameType);
}

ThreadList DinverGui::threads( QString t ) const
{
  TRACE;
  ThreadList l;
  QRegExp trexp(t, Qt::CaseSensitive, QRegExp::Wildcard);
  for (ThreadList::const_iterator it = _threads.begin(); it<_threads.end(); it++ ) {
    if (trexp.exactMatch( (*it)->objectName() ) ) {
      l.append( *it );
    }
  }
  return l;
}

QStringList DinverGui::selectedReports( const QString& title ) const
{
  TRACE;
  QStringList reportList;
  bool allOfTheSameType;
  ThreadList selThreads = selectedThreads(allOfTheSameType);
  if ( selThreads.isEmpty() ) {
    if ( Message::question( MSG_ID, title,
                               tr( "No run selected, do you want to select all of them?" ),
                               Message::yes(), Message::cancel() ) == Message::Answer1 ) {
      return reportList;
    }
    selThreads = threads();
  }
  for (ThreadList::iterator it=selThreads.begin();it!=selThreads.end();++it) {
    reportList.append((*it)->reportFileName());
  }
  return reportList;
}

void DinverGui::setProgressMaximum( int value )
{
  TRACE;
 if (value>0) _progressBar->setMaximum( value );
}

int DinverGui::progressMaximum()
{
  TRACE;
  return _progressBar->maximum();
}

void DinverGui::setProgressValue( int value )
{
  TRACE;
  _progressBar->setValue( value );
}

void DinverGui::showMessage( QString message )
{
  TRACE;
  statusBar() ->showMessage( message );
}

QList<PSViewer *> DinverGui::psViewers()
{
  QWidgetList wList=_ws->windowList();
  QList<PSViewer *> psViewers;
  for (QWidgetList::iterator it=wList.begin();it!=wList.end();++it) {
    if ((*it)->inherits("PSViewer")) {
      psViewers << qobject_cast<PSViewer *>(*it);
    }
  }
  return psViewers;
}

bool DinverGui::closeAllPSViewers()
{
  TRACE;
  QList<PSViewer *> list = psViewers();
  if (!list.isEmpty()) {
    if ( Message::warning( MSG_ID, tr("Closing all PS viewers"), tr("This operation requires all PS viewers to be closed. Do you want to continue?"), Message::no(), Message::yes())
        == Message::Answer0 ) return false;
    for (QList<PSViewer *>::iterator it=list.begin();it!=list.end();++it) {
      delete *it;
    }
    return true;
  } else return true;
}

void DinverGui::clearThread( InversionThread * t )
{
  TRACE;
  QList<PSViewer *> list = psViewers();
  for (QList<PSViewer *>::iterator it=list.begin();it!=list.end();++it) {
    (*it)->lockPlots();
  }
  t->clear();
  _status->clearThread( t );
  for (QList<PSViewer *>::iterator it=list.begin();it!=list.end();++it) {
    (*it)->unlockPlots();
  }
}

void DinverGui::removeThread( InversionThread * t )
{
  TRACE;
  int i=_threads.indexOf(t);
  _threads.removeAt(i);
  if (t->hasReportFile()) t->removeReport();
  delete t;
  _status->removeThread( t );
  emit newThread(0);
}

/*!
  Set the state of one particular tool if the sender is a DockWidget. DockWidget emit a signal every time the user click on the
  close box. If the function is called without signal/slot, all states are checked.
*/
void DinverGui::setToolsMenuState()
{
  TRACE;
  DockWidget * w = qobject_cast<DockWidget *>(sender());
  QList<QAction *> aList = _toolsMenu->actions();
  int n=aList.count();
  if (w) {
    for ( int i = 0;i < n;i++ ) {
      QAction * a = aList.at( i );
      if ( w == *reinterpret_cast<DockWidget **>( a->data().toByteArray().data())) {
        a->setChecked( w->isVisible() );
      }
    }
  } else {
    for ( int i = 0;i < n;i++ ) {
      QAction * a = aList.at( i );
      if (!a->isSeparator()) {
        w = *reinterpret_cast<DockWidget **>( a->data().toByteArray().data());
        a->setChecked( w->isVisible() );
      }
    }
  }
}
