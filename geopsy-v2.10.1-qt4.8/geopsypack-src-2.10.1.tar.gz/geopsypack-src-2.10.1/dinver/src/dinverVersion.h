#ifndef DINVER_VERSION
#define DINVER_VERSION "0.5.6"
#define DINVER_VERSION_TIME "201506151358"
#define DINVER_VERSION_TYPE "testing"
#define DINVER_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)\nMarc Wathelet (ULg, Liège, Belgium)"
#endif // DINVER_VERSION
