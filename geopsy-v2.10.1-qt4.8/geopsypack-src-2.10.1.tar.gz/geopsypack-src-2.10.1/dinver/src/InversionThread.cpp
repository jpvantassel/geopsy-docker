/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-10-19
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QDateTime>

#include <DinverCore.h>
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include "InversionThread.h"
#include "DinverGui.h"
#include "ModelThreadInfo.h"

const QString InversionThread::xmlInversionThreadTag="InversionThread";

/*!
  \class InversionThread qtbinversionthread.h
  \brief Inversion thread with Neighbourhood tuning parameters


*/

InversionThread::InversionThread( QObject * parent )
   : Thread(parent)
{
  TRACE;
  // Create log stream for this thread
  dinverGui->logs()->addView(this, "unamed");

  _itmax=50;
  _ns0=50;
  _ns=50;
  _nr=50;
  _nw=2;
  _giveUp = 0.9;
  _seed=rand();
  _hasReportFile=false;
  _expectedModelCount = 0;
}

InversionThread::~InversionThread()
{
  // Remove log stream for this thread
  dinverGui->logs()->removeView(this);
  delete _na.forward();
}

/*!
  Remove report file from disk if a report exists. First check if this thread owns the report file (hasReportFile())
  unless you have good reasons to remove the report file
*/
void InversionThread::removeReport()
{
  TRACE;
  if (isReportExists() ) {
    App::stream() << tr("Removing %1").arg(reportFileName()) << endl;
    QDir d(reportFileName());
    d.remove(reportFileName());
  }
}

void InversionThread::start()
{
  TRACE;
  _expectedModelCount = _na.validModelCount()+_ns0+_itmax*_ns;
  App::stream(this) << tr("\n---------------------- Starting at ")
                    << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss") << "\n\n"
                    << tr(" Max number of iterations             = %1\n").arg( _itmax )
                    << tr(" Num samples 1st iteration            = %1\n").arg( _ns0 )
                    << tr(" Num samples per iteration            = %1\n").arg( _ns )
                    << tr(" Num cells to resample                = %1\n").arg( _nr )
                    << tr(" Num of walks before accepting model  = %1\n").arg( _nw )
                    << tr(" Max reject ratio before cell give up = %1\n").arg( _giveUp )
                    << tr(" Random seed                          = %1\n\n").arg( _seed )
                    << tr(" Dimension of parameter space         = %1\n").arg( _na.variableParameterCount() )
                    << tr(" Parameterization checksum            = %1\n").arg( _na.checksum() )
                    << tr(" Total number of models               = %1\n").arg( _expectedModelCount )
                    << tr(" Model file                           = %1\n").arg( _reportFileName ) << endl;
  if ( _na.variableParameterCount()==0 ) {
    App::stream(this) << tr("Number of variable parameters is null, nothing to optimize, aborting.") << endl;
    emit stopped();
    return;
  }
  _na.setSeed( _seed );
  _na.setGiveUp( _giveUp );
  _na.terminate( false );
  _na.wake();
  QThread::start();
  //run();
}

void InversionThread::setForward( AbstractForward * forward )
{
  _na.setForward( forward );
}

void InversionThread::setStorage()
{
  _na.setStorage();
}

void InversionThread::setObjectName(QString name)
{
  TRACE;
  if (name==objectName()) return;
  // Check if name is unique
  const ThreadList threads = dinverGui->threads();
  for (ThreadList::const_iterator it = threads.begin(); it<threads.end(); it++ ) {
    if ((*it)->objectName()==name) {
      App::stream() << tr("The new name for run %1 is not unique, nothing changed.").arg(objectName()) << endl;
      return;
    }
  }
  QObject::setObjectName(name);
  QFileInfo fi(_reportFileName);
  QDir d(fi.path());
  QString oldReportFileName = _reportFileName;
  bool oldReportExist = isReportExists();
  _reportFileName = d.absoluteFilePath(name+".report");
  if ( isRunning() ) {
    App::stream() << tr("run %1 is runnning: still writing models to old file name. New name will be use for next 'start'.")
                .arg(objectName()) << endl;
  } else if (oldReportExist && hasReportFile()) {
    App::stream() << tr("Renaming %1 to %2").arg(oldReportFileName).arg(reportFileName()) << endl;
    QDir d(reportFileName());
    d.rename(oldReportFileName, reportFileName());
  }
}

bool InversionThread::setReportDir( const QDir& d )
{
  TRACE;
  if ( isRunning() ) {
    App::stream() << tr("run %1 is runnnig cannot copy report to %2.")
                .arg(objectName()).arg(d.absolutePath()) << endl;
    return false;
  } else {
    QString newFileName = d.absoluteFilePath(objectName()+".report");
    if (!_reportFileName.isEmpty()) {
      QFileInfo fi(_reportFileName);
      if (fi.exists()) {
        QDir oldDir(fi.path());
        if (oldDir!=d) {
          QFile::copy(_reportFileName, newFileName);
        }
      }
    }
    _reportFileName = newFileName;
    return true;
  }
}

QDir InversionThread::reportDir() const
{
  TRACE;
  QFileInfo fi (_reportFileName);
  return fi.absoluteDir();
}

void InversionThread::setTuningParameters(InversionThread * t)
{
  TRACE;
  setItmax(t->itmax());
  setNs0(t->ns0());
  setNs(t->ns());
  setNr(t->nr());
  setNw(t->nw());
  setGiveUp(t->giveUp());
}

void InversionThread::terminate()
{
  TRACE;
  if (isRunning()) {
    _na.terminate();
    while (!wait(0)); // synchroneous terminate
    App::stream(this) << tr("Thread manually stopped.") << endl;
  } else App::stream(this) << tr("WARNING: Trying to stop it but thread is not running") << endl;
}

void InversionThread::clear()
{
  TRACE;
  if (isRunning()) terminate();
  if (_hasReportFile) removeReport();
  _hasReportFile=false;
  _expectedModelCount = 0;
  _na.clear();
  App::stream(this) << tr("Thread cleared.") << endl;
}

void InversionThread::run()
{
  TRACE;
  emit started();
  MessageContext();
  if ( ! _reportFileName.isEmpty() ) {
    if ( !_na.openReport( _reportFileName ) ) {
      _na.sleep();
      emit stopped();
      return;
    }
    _hasReportFile = true; // Take ownership of the report file
  }
  Application::instance()->setStreamPrefix( QString::null );
  App::stream() << tr("Initialization of parameter space...") << endl;
  if(!_na.setThreadCount(Thread::idealThreadCount())) {
    _na.sleep();
    emit stopped();
    return;
  }
  _na.setNr( _nr );
  if ( _ns0 > 0 ) {
    if ( !_na.random( _ns0, _nw ) ) {
      _na.sleep();
      emit stopped();
      return;
    }
  }
  if ( _itmax>0 && _ns>0 ) {
    Application::instance()->setStreamPrefix( QString::null );
    //App::stream() << tr("Model checksum = %1").arg(modelChecksum()) << endl;
    //printBestModels();
    App::stream() << tr("Starting %1 iterations...").arg(_itmax) << endl;
    int i;
    for (i=1;i<=_itmax;i++) {
      Application::instance()->setStreamPrefix( QString::null );
      App::stream() << tr("iteration %1").arg(i) << endl;
      if ( ! _na.optimization( _ns, _nw ) ) {
        _na.sleep();
        emit stopped();
        return;
      }
      //App::stream() << tr("Model checksum = %1").arg(modelChecksum()) << endl;
      // printBestModels();
    }
    Application::instance()->setStreamPrefix( QString::null );
    App::stream() << tr("Finished %1 iterations").arg(i-1) << endl;
  }
  Application::instance()->setStreamPrefix( QString::null );
  //printBestModels();
  emit stopped();
  _na.timeReport();
  _na.sleep();
}

void InversionThread::importModels()
{
  StreamRedirection sr(&App::stream(this));
  QFileInfo fi(_reportFileName);
  if (_hasReportFile) {
    if ( !fi.exists() ) {
      // Try to translate the path
      QString fn =  Application::instance()->translatePath( _reportFileName, tr("Loading reports ..."),
                                                            tr( "Report file (%1)" ) );
      fi.setFile( fn );
      if ( !fn.isEmpty() && fi.exists() ) {
        _reportFileName = fn;
        _na.importModels(_reportFileName, false);
      } else {
        _hasReportFile = false;
      }
    } else importModels(_reportFileName, false);
  } else if ( fi.exists() ) { // Detected a report file with the same name...
    _na.importModels(_reportFileName, true);
    // Take ownership only if models are compatible
    if (_na.validModelCount()>0) _hasReportFile = true;
  }
}


/*!
  \fn bool InversionThread::isReportExists()
  Check whether or not the report file exist.
*/

void InversionThread::xml_writeProperties( XML_WRITEPROPERTIES_ARGS ) const
{
  TRACE;
  writeProperty(s, "itmax",_itmax);
  writeProperty(s, "ns0",_ns0);
  writeProperty(s, "ns",_ns);
  writeProperty(s, "nr",_nr);
  writeProperty(s, "nw",_nw);
  writeProperty(s, "giveUp",_giveUp);
  writeProperty(s, "seed",_seed);
  writeProperty(s, "report",reportFileName());
  writeProperty(s, "checksum",(int)_na.checksum());
  writeProperty(s, "hasReportFile",_hasReportFile);
  _na.forward()->xml_writeProperties(s, context);
}

void InversionThread::xml_writeChildren( XML_WRITECHILDREN_ARGS ) const
{
  TRACE;
  _na.forward()->xml_writeChildren(s, context);
}

XMLMember InversionThread::xml_member(XML_MEMBER_ARGS)
{
  TRACE;
  if ( tag == "itmax" ) return XMLMember(0);
  else if ( tag == "ns0" ) return XMLMember(1);
  else if ( tag == "ns" ) return XMLMember(2);
  else if ( tag == "nr" ) return XMLMember(3);
  else if ( tag == "nw" ) return XMLMember(4);
  else if ( tag == "giveUp" ) return XMLMember(5);
  else if ( tag == "seed" ) return XMLMember(6);
  else if ( tag == "report" ) return XMLMember(7);
  else if ( tag == "checksum" ) return XMLMember(9);
  else if ( tag == "hasReportFile" ) return XMLMember(10);
  else if ( tag == "runType" ) return XMLMember(8);          // Kept for compatibility
  else if ( tag == "jointRun" ) return XMLMember(8);         // Kept for compatibility
  else if ( tag == "acceptableMisfit" ) return XMLMember(8); // Kept for compatibility
  else if ( tag == "scaling" ) return XMLMember(8);          // Kept for compatibility
  else if ( tag == "dynScale" ) return XMLMember(8);         // Kept for compatibility
  else if ( tag == "cellDist" ) return XMLMember(8);         // Kept for compatibility
  else return _na.forward()->xml_member(tag, attributes, context)+15;
}

bool InversionThread::xml_setProperty( XML_SETPROPERTY_ARGS )
{
  TRACE;
  switch (memberID) {
  case 0:
    _itmax=content.toInt();
    return true;
  case 1:
    _ns0=content.toInt();
    return true;
  case 2:
    _ns=content.toInt();
    return true;
  case 3:
    _nr=content.toInt();
    return true;
  case 4:
    _nw=content.toInt();
    return true;
  case 5:
    _giveUp=content.toDouble();
    return true;
  case 6:
    _seed=content.toInt();
    return true;
  case 7: {
      _reportFileName = content.toString();
      QFileInfo fi(_reportFileName);
      QObject::setObjectName(fi.baseName());
      dinverGui->logs()->setViewName(this, fi.baseName());
      _hasReportFile = true; // set a default value (compatibility)
    }
    return true;
  case 8:   // Kept for compatibility
    return true;
  case 9:
    // Checksum not read from file
    return true;
  case 10:
    _hasReportFile = content.toBool();
    return true;
  default:
    return _na.forward()->xml_setProperty( memberID-15, attributes, content, context);
  }
}

void InversionThread::xml_polish( XML_POLISH_ARGS )
{
  TRACE;
  StreamRedirection sr(&App::stream(this));
  _na.forward()->xml_polish(context);
  _na.setStorage();
}
