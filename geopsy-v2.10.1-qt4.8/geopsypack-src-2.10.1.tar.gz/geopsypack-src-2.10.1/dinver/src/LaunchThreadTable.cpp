/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2006-04-01
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QAction>
#include <QContextMenuEvent>
#include <QMenu>

#include <QGpCoreTools.h>
#include "LaunchThreadTable.h"
#include "DinverGui.h"

LaunchThreadTable::LaunchThreadTable(QWidget * parent)
    : QTableView(parent)
{
  TRACE;
}

void LaunchThreadTable::refresh()
{
  TRACE;
}

ThreadList LaunchThreadTable::selectedThreads(bool& allOfTheSameType)
{
  TRACE;
  ThreadList selThreads;
  int n = dinverGui->threads().count();
  InversionThread * tRef = 0;
  allOfTheSameType = true;

  for ( int i = 0;i < n;i++ ) {
    if ( isThreadSelected( i ) ) {
      InversionThread * t=dinverGui->threads().at(i);
      if ( tRef == 0 ) tRef = t;
      else if ( *t != *tRef ) allOfTheSameType = false;
      selThreads << t;
    }
  }
  return selThreads;
}

InversionThread * LaunchThreadTable::currentEditableThread()
{
  TRACE;
  QModelIndex index=currentIndex();
  if (index.isValid()) {
    InversionThread * t = static_cast<InversionThread *>(index.internalPointer());
    if (t->isRunning()) {
      Message::warning( MSG_ID,tr("Editing thread"),
                          tr("Cannot edit a running process"), Message::cancel());
      return 0;
    } else {
      return t;
    }
  } else return 0;
}
