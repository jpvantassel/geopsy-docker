/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-31
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef DINVERGUI_H
#define DINVERGUI_H

#include <QtGui>
#include <QGpGuiTools.h>
#include <DinverCore.h>

#include "PSViewer.h"

class ThreadLauncher;
class ProcessStatus;

class DinverGui : public QMainWindow, public DinverCoreObject
{
  Q_OBJECT
public:
  DinverGui( QWidget* parent = 0, Qt::WFlags fl = 0  );
  ~DinverGui();

  static QString pluginSelector( QString tag, bool debug );
  bool setPlugin(QString pluginFile);

  ThreadTimer& bigBen() {return _bigBen;}

  ProcessStatus * status() const {return _status;}
  LogWidget * logs() const {return _logs;}
  ThreadLauncher * runs() const {return _runs;}

  PSViewerList psViewerList() { return findChildren<PSViewer *>(); }
  void addThread( InversionThread * t );
  void removeThread( InversionThread * t );
  void clearThread( InversionThread * t );
  virtual QStringList selectedReports( const QString& title ) const;
  ThreadList threads() const { return _threads; }
  ThreadList threads( QString t ) const;
  ThreadList selectedThreads( bool& allOfTheSameType ) const;

  virtual bool useProgress() { return true; }
  virtual AbstractProgress * progress() { return _progressBar; }
  bool closeAllPSViewers();

  QDir currentReportDir() const;
public slots:
  void activeWindowChanged( QWidget * w );
  void setToolsMenuState();
  // File menu
  bool clear();
  void open(QString fileName=QString::null);
  void save();
  void saveAs(QString fileName=QString::null);
  void importTargets(QString fileName=QString::null);
  void exportTargets(QString fileName=QString::null);
  void importParameters(QString fileName=QString::null);
  void exportParameters(QString fileName=QString::null);
  // View menu
  void viewPS();
  // Window menu
  virtual void addWindow(QWidget * w);
  virtual void showWindow(QWidget * w);
  void removeWindow ( QWidget * w );
  void updateWindowTitle ( QWidget * w );
  void windowsMenuAdd( QWidget * w );
  void windowsMenuRemove( QWidget * w );
  void windowsMenuSetCurrent( QWidget * w );
  void windowsMenuTriggered();
  Q_SCRIPTABLE void windowsMinimize();
  Q_SCRIPTABLE void tileHorizontal();
  Q_SCRIPTABLE void closeAllWindows() {_ws->closeAllWindows();}
  // Help menu
  Q_SCRIPTABLE void helpDocumentation();
  Q_SCRIPTABLE void helpAbout();

  virtual void setProgressMaximum(int);
  virtual int progressMaximum();
  virtual void setProgressValue(int);
  virtual void showMessage(QString);
private slots:
  void setCurrentRuns( ThreadList tList );
signals:
  void newThread( InversionThread * );
  void pluginsReady();
protected:
  void setTempDir(const QDir& d);
  void cleanTempDir();
  bool stopAll ();
  bool warnBeforeClose();
  virtual void closeEvent ( QCloseEvent * e );
  void addDocks( DockWidget * leftDock, DockWidget * bottomDock );
  void addActions();
  void setWindowsMenuEnabled( bool b );
  void addFileActions();
  void addViewActions();
  void addRunsActions();
  void addToolsActions();
  void addWindowsActions();
  void addHelpActions();
  QAction * windowsMenuAction( QWidget * w );
  QList<PSViewer *> psViewers();

  ThreadTimer _bigBen;
  ThreadList _threads;

  ThreadLauncher * _runs;
  QWorkspace * _ws;
  LogWidget * _logs;
  ProcessStatus * _status;
  ProgressBar * _progressBar;

  QString _currentFile;
  TemporaryDirectory _tempDir;

  QMenu * _toolsMenu;
  QMenu * _windowsMenu;
  QAction * _importTargetsAction;
  QAction * _importParamsAction;
  QAction * _showRunAction;
  QAction * _windowsCascadeAction;
  QAction * _windowsTileVAction;
  QAction * _windowsTileHAction;
  QAction * _windowsCloseAllAction;
  QAction * _windowsMinimizeAction;
  DockWidget * _targetDock;
  DockWidget * _paramDock;
};

#define dinverGui static_cast<DinverGui *>(dinverCore)

#endif // DINVERGUI_H
