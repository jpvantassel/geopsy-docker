/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-10-28
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef ModelThreadInfo_H
#define ModelThreadInfo_H

#include <QList>
#include <QVector>
#include <QAbstractItemModel>

class InversionThread;
class PSViewer;

class ModelThreadInfo
{
public:
  inline ModelThreadInfo( const InversionThread * t, int index );

  bool operator<(const ModelThreadInfo& o) const;
  const InversionThread * thread() const { return _thread; }
  int index() const { return _index; }
private:
  const InversionThread * _thread;
  int _index;
};

typedef QList<InversionThread *> ThreadList;
typedef QList<ModelThreadInfo> ModelThreadList;
typedef QVector<PSViewer*> PSViewerVector;
typedef QList<PSViewer*> PSViewerList;

inline ModelThreadInfo::ModelThreadInfo( const InversionThread * t, int index )
{
  _thread = t;
  _index = index;
}

#endif
