/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-11-06
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef PLUGINSELECTOR_H
#define PLUGINSELECTOR_H

#include <QGpGuiTools.h>
#include <DinverCore.h>

#include "ui_PluginSelector.h"

class PluginSelector : public Dialog, public Ui::PluginSelector
{
  Q_OBJECT
public:
  PluginSelector(QWidget * parent=0, bool debug=false);
  ~PluginSelector();

  QString file() const;
public slots:
  void on_searchPaths_clicked();
  void on_pluginList_itemChanged (QListWidgetItem * selItem);
protected:
  bool setLibList( QStringList libs );
  QStringList _pluginFileList;
  static const char * _noticeContents;
  bool _wrongBuildKey;
  bool _debug;
};

#endif // PLUGINSELECTOR_H
