/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-18
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <time.h>

#include <QSettings>

#include <DinverCore.h>
#include <QGpGuiTools.h>
#include "DinverGui.h"
#include "dinverInstallPath.h"
#include "dinverVersion.h"
#include "PluginSelector.h"

PACKAGE_INFO( dinver, DINVER );

ApplicationHelp * help();
int modeGui( int argc, char ** argv );
int modeOptimization( int argc, char ** argv );
int modeImportanceSampling( int argc, char ** argv, const QString& baseFileName);
bool checkRemainingArguments( int argc, char ** argv );

QString pluginTag;
bool debugStream = false;

int main( int argc, char ** argv )
{
  // initialize system random generator (not used for direct computation)
  srand( time( NULL ) );

  // Basic options: selection of the main modes and plugin
  enum Mode {Gui, Optimization, ImportanceSampling};
  Mode mode=Gui;
  QString baseFileName;
  // Check arguments
  int j = 1;
  for (int i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-debug-stream") {
        debugStream= true;
      } else if (arg=="-clear-plugins") {
        QSettings reg;
        reg.remove( "Plugins" );
      } else if (arg=="-plugin-list") {
        CoreApplication a(argc, argv,help);
        DinverGui::printPluginList();
        return 0;
     } else if (arg=="-i") {
        CoreApplication::checkOptionArg(i, argc, argv);
        pluginTag = argv[i];
      } else if (arg=="-optimization") {
        mode=Optimization;
      } else if (arg=="-importance-sampling") {
        CoreApplication::checkOptionArg(i, argc, argv);
        baseFileName=argv[i];
        mode=ImportanceSampling;
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }

  switch(mode) {
  case Gui:
    return modeGui(argc, argv);
  case Optimization:
    return modeOptimization(argc, argv);
  case ImportanceSampling:
    return modeImportanceSampling(argc, argv, baseFileName);
  };
  return 0;
}

int modeGui( int argc, char ** argv)
{
  Application a(argc, argv, help);
  a.setStream(new StandardStream(stderr));
  a.setConsoleMessage();

  // Options
  QString dinverFile;
  // Check arguments
  int j = 1;
  for (int i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-env") {
        Application::checkOptionArg(i, argc, argv);
        dinverFile = argv[i];
      } else {
        App::stream() << tr("dinver: bad option %1, see --help").arg(argv[i]) << endl;
        return 2;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  if (!checkRemainingArguments(argc,argv)) {
    return 2;
  }

  SciFigsGlobal s;
  Application::instance()->setGuiMessage();

  QString pluginFile = DinverGui::pluginSelector(pluginTag, debugStream);
  if (pluginFile.isEmpty()) {
    App::stream() << tr("No plugin selected") << endl;
    return 2;
  }

  DinverGui * w = new DinverGui;
  w->setObjectName("dinver");
  if (!w->setPlugin(pluginFile)) {
    delete w;
    App::stream() << tr("Cannot load plugin %1").arg(pluginFile) << endl;
    return 2;
  }
  w->logs()->setDebugMode(debugStream);
  // Add main message board (after debug mode switch)
  w->logs()->addView( QThread::currentThread(), tr("Messages") );
  w->show();
  if ( !dinverFile.isEmpty() ) w->open( dinverFile );
  return qApp->exec();
}

int modeOptimization( int argc, char ** argv )
{
  CoreApplication a(argc, argv, help);
  a.setStream(new StandardStream(stderr));

  if (pluginTag.isEmpty()) {
    App::stream() << tr("dinver: no plugin selected (option -i)") << endl;
    return 2;
  }

  DinverCoreObject dinverCore;
  QString pluginFile=dinverCore.pluginFile(pluginTag, debugStream);
  if (!dinverCore.setPlugin(pluginFile, debugStream)) {
    App::stream() << tr("dinver: cannot set plugin with tag %1").arg(pluginTag) << endl;
    return 2;
  }

  // Options
  QString paramFile;
  QString targetFile;
  int itmax = 50;
  int ns0 = 50;
  int ns = 50;
  int nr = 50;
  int seed = 0;
  ReportWriter::Action reportAction=ReportWriter::Ask;
  QString outputFileName="run.report";
  // Check arguments
  int j = 1;
  for (int i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-itmax") {
        CoreApplication::checkOptionArg(i, argc, argv);
        itmax = atoi(argv[i]);
      } else if (arg=="-param") {
        Application::checkOptionArg(i, argc, argv);
        paramFile = argv[i];
      } else if (arg=="-target") {
        Application::checkOptionArg(i, argc, argv);
        targetFile = argv[i];
      } else if (arg=="-ns0") {
        CoreApplication::checkOptionArg(i, argc, argv);
        ns0 = atoi(argv[i]);
      } else if (arg=="-ns") {
        CoreApplication::checkOptionArg(i, argc, argv);
        ns = atoi(argv[i]);
      } else if (arg=="-nr") {
        CoreApplication::checkOptionArg(i, argc, argv);
        nr = atoi(argv[i]);
      } else if (arg=="-seed") {
        CoreApplication::checkOptionArg(i, argc, argv);
        seed = atoi(argv[i]);
      } else if (arg=="-o") {
        CoreApplication::checkOptionArg(i, argc, argv);
        outputFileName = argv[i];
      } else if (arg=="-f") {
        reportAction=ReportWriter::Overwrite;
      } else if (arg=="-resume") {
        reportAction=ReportWriter::Append;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(paramFile.isEmpty()) {
    App::stream() << tr("dinver: missing parameters, option '-param'") << endl;
    return 2;
  }
  if(targetFile.isEmpty()) {
    App::stream() << tr("dinver: missing targets, option '-target'") << endl;
    return 2;
  }
  BatchRun r;
  if (!r.setParameters(paramFile)) {
    App::stream() << tr("dinver: error reading parameters from file %1").arg(paramFile) << endl;
    return 2;
  }
  if (!r.setTargets(targetFile)) {
    App::stream() << tr("dinver: error reading targets from file %1").arg(targetFile) << endl;
    return 2;
  }
  if ( ! r.optimization(itmax, ns0, ns, nr, seed, outputFileName, reportAction) ) {
    return 2;
  }
  return 0;
}

int modeImportanceSampling(int argc, char ** argv, const QString& baseFileName)
{
  CoreApplication a(argc, argv, help);
  a.setStream(new StandardStream(stderr));

  if (pluginTag.isEmpty()) {
    App::stream() << tr("dinver: no plugin selected (option -i)") << endl;
    return 2;
  }

  DinverCoreObject dinverCore;
  QString pluginFile=dinverCore.pluginFile(pluginTag, debugStream);
  if (!dinverCore.setPlugin(pluginFile, debugStream)) {
    App::stream() << tr("dinver: cannot set plugin with tag %1").arg(pluginTag) << endl;
    return 2;
  }

  // Options
  QString paramFile;
  int ns = 5000;
  int seed = 0;
  QString outputFileName="run.report";
  ReportWriter::Action reportAction=ReportWriter::Ask;
  // Check arguments
  int j = 1;
  for (int i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-param") {
        Application::checkOptionArg(i, argc, argv);
        paramFile = argv[i];
      } else if (arg=="-ns") {
        CoreApplication::checkOptionArg(i, argc, argv);
        ns = atoi(argv[i]);
      } else if (arg=="-seed") {
        CoreApplication::checkOptionArg(i, argc, argv);
        seed = atoi(argv[i]);
      } else if (arg=="-o") {
        CoreApplication::checkOptionArg(i, argc, argv);
        outputFileName = argv[i];
      } else if (arg=="-f") {
        reportAction=ReportWriter::Overwrite;
      } else if (arg=="-resume") {
        reportAction=ReportWriter::Append;
      } else if (arg=="-dof") {
        CoreApplication::checkOptionArg(i, argc, argv);
        PdfPoint::setDegreesOfFreedom(atof(argv[i]));
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(paramFile.isEmpty()) {
    App::stream() << tr("dinver: missing parameters, option '-param'") << endl;
    return 2;
  }
  BatchRun r;
  if (!r.setParameters(paramFile)) {
    App::stream() << tr("dinver: error reading parameters from file %1").arg(paramFile) << endl;
    return 2;
  }
  if (!r.importanceSampling(ns, seed, baseFileName, outputFileName, reportAction) ) {
    return 2;
  }
  return 0;
}

bool checkRemainingArguments( int argc, char ** argv )
{
  if (argc>1) {
    for (int i=1; i<argc; i++) {
      App::stream() << tr("dinver: bad option '%1', see -h").arg(argv[i]) << endl;
    }
    return false;
  } else {
    return true;
  }
}

ApplicationHelp * help()
{
  ApplicationHelp * h = new ApplicationHelp;
  h->setOptionSummary( "[OPTIONS]" );
  h->setComments( "Graphical user interface for Conditional Neighbourhood Algorithm (Inversion/Optimization)." );
  h->addGroup("Dinver","dinver");
  h->addOption("-i <PLUGIN_TAG>","Select inversion plugin with tag PLUGIN_TAG, skip first dialog box. See option '-plugin-list', to get the "
                                 "list of available plugins and their tags.");
  h->addOption("-env <FILE>","Load Dinver environment file .dinver. "
                             "With option '-run', only the current target and parameterization are "
                             "considered, the run description is ignored. It replaces former options "
                             "'-target' and '-param'.");
  h->addOption("-optimization","Starts one inversion run with target and parameterization specified by options '-param' and '-target'. "
                               "No graphical user interface is started. See '-h optimization' for all options.");
  h->addOption("-importance-sampling <REPORT>","Starts one resampling run with parameterization specified by options '-param'. REPORT is "
                                               "an inversion report produced by option '-optimization' or by graphical interface. "
                                               "No graphical user interface is started. See '-h importanceSampling' for all options.");
  h->addGroup("Optimization","optimization");
  h->addOption("-target <TARGET>","Set targets from file TARGET. It can be a .target or a .dinver file. A .dinver file contains both parameters and "
                                  "targets. Provide it to both options '-param' and '-target'.");
  h->addOption("-param <PARAM>","Set parameters from file PARAM. It can be a .param or a .dinver file. A .dinver file contains both parameters and "
                                  "targets. Provide it to both options '-param' and '-target'.");
  h->addOption("-itmax <ITMAX>","Number of iterations started by option -run (default=50).");
  h->addOption("-ns0 <NS0>","Number of initial models (default=50).");
  h->addOption("-ns <NS>","Number of models generated (default=50).");
  h->addOption("-nr <NR>","Number of best cells (default=50).");
  h->addOption("-seed <SEED>","Set random seed to SEED. This option is for debug only.");
  h->addOption("-o <REPORT>","Ouput report (default='run.report'). To suppress output to .report file, set option '-o' to \"\".");
  h->addOption("-f","Force overwrite if output report already exists.");
  h->addOption("-resume","If the output report file already exists, it is imported into the parameter space before starting "
                         "the inversion. Better to set NS0 to zero in this case. This way, it is possible to continue an "
                         "existing inversion adding new iterations.");
  h->addGroup("Importance sampling","importanceSampling");
  h->addOption("-dof <DOF>","Set degrees of freedom for conversion from misfit to posteriori probability function.");
  h->addOption("-param <PARAM>","Set parameters from file PARAM. It can be a .param or a .dinver file. A .dinver file contains both parameters and "
                                  "targets. Provide it to both options '-param' and '-target'.");
  h->addOption("-ns <NS>","Number of models generated (default=5000).");
  h->addOption("-seed <SEED>","Set random seed to SEED. This option is for debug only.");
  h->addOption("-o <REPORT>","Ouput report (default='run.report'). To suppress output to .report file, set option '-o' to \"\".");
  h->addOption("-f","Force overwrite if output report already exists.");
  h->addOption("-resume","If the output report file already exists, add generated models without warning.");
  h->addGroup( "Debug","debug" );
  h->addOption("-debug-stream","Debug mode (redirect all logs to stdout)");
  h->addOption("-plugin-list","Print the list of a available plugins");
  h->addOption("-clear-plugins","Reset the list of a available plugins");
  return h;
}
