/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-10-26
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef PSViewer_H
#define PSViewer_H

#include <SciFigs.h>

#include "ModelThreadInfo.h"
#include "InversionThread.h"

class ViewerThreadInfo
{
public:
  ViewerThreadInfo() {
    alreadyLoaded=0;
  }
  int alreadyLoaded;
};

typedef QMap<const InversionThread *, ViewerThreadInfo *> ViewerThreadMap;

class PSViewer : public QWidget
{
  Q_OBJECT
public:
  PSViewer(QWidget * parent=0);
  ~PSViewer();

  void lockPlots();
  void unlockPlots();
  void addThreadData(InversionThread * models);
  const ModelThreadList& modelList() const {return _models;}
  void lockDataModels();
  void unlockDataModels();
  const ColorPalette * palette() const {return &_palette->palette();}
  bool saveParameters() const {return _saveParameters;}
  const InversionThread * parameterList() const {
    if (_threads.isEmpty()) return 0; else return _threads.begin().key();
  }
public slots:
  void synchronize();
  void setLimits();
  void addPlot();
  void fileOpenPS();
  void fileSavePS();
  void fileSaveAsPS();
  AxisWindow * addPlot(int paramX, int paramY);
private:
  GraphicSheet _sheet;
  ColorPaletteWidget * _palette;
  QVBoxLayout* _childLayout;
#ifndef Q_WS_MAC
  QMenuBar * _menuBar;
#endif

  ViewerThreadMap _threads;
  ModelThreadList _models;

  bool _saveParameters;

  void addActions();
};

#endif
