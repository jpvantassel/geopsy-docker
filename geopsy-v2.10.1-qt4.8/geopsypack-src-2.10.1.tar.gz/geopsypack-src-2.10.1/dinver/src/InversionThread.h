/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-10-19
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef InversionThread_H
#define InversionThread_H

#include <QObject>

#include <DinverCore.h>
#include <QGpCoreTools.h>

class InversionThread : public Thread, public XMLClass
{
  Q_OBJECT
public:
  InversionThread( QObject * parent = 0 );
  ~InversionThread();

  virtual const QString& xml_tagName() const {return xmlInversionThreadTag;}
  static const QString xmlInversionThreadTag;

  bool operator==( const InversionThread& o ) const { return _na==o._na; }
  bool operator!=( const InversionThread& o ) const { return !(_na==o._na); }

  void setForward( AbstractForward * forward );
  void setStorage();
  void setObjectName(QString name);
  bool setReportDir( const QDir& d );
  QDir reportDir() const;
  bool isReportExists() const { QFileInfo fi(_reportFileName); return fi.exists(); }
  bool hasReportFile() const { return _hasReportFile; }
  void importModels();
  void importModels(QString fileName, bool strict = true ) { _na.importModels( fileName, strict ); }
  QString reportFileName() const {return _reportFileName;}
  void removeReport();

  void start();
  void terminate();
  void clear();

  void setSeed(int seed) { _seed=seed; }
  void setItmax(int itmax) {_itmax=itmax; }
  void setNs0(int ns0) { _ns0=ns0; }
  void setNs(int ns) { _ns=ns; }
  void setNr(int nr) { _nr=nr; }
  void setNw(int nw) { _nw=nw; }
  void setGiveUp(double giveUp) { _giveUp=giveUp; }

  int seed() const { return _seed; }
  int itmax() const { return _itmax; }
  int ns0() const { return _ns0; }
  int ns() const { return _ns; }
  int nr() const { return _nr; }
  int nw() const { return _nw; }
  double giveUp() const { return _giveUp; }
  void setTuningParameters( InversionThread * t );

  void lock() const { _na.lock(); }
  void unlock() const { _na.unlock(); }

  int expectedModelCount() const { return _expectedModelCount; }
  int visitedModelCount() const { return _na.visitedModelCount(); }
  int validModelCount() const { return _na.validModelCount(); }
  int activeModelCount() const { return _na.activeModelCount(); }
  int rejectedCount() const { return _na.rejectedCount(); }
  int giveUpCount() const { return _na.giveUpCount(); }
  int bestModelCount() const { return _na.bestModelCount(); }
  int variableParameterCount() const { return _na.variableParameterCount(); }

  double misfit( int modelIndex ) const { return _na.misfit( modelIndex ); }
  AbstractForward * forward() { return _na.forward(); }
  const Parameter * variableParameter( int paramIndex ) const { return _na.variableParameter( paramIndex ); }
  double variableParameterValue( int modelIndex, int paramIndex ) const { return _na.variableParameterValue( modelIndex, paramIndex ); }
signals:
  void started();
  void stopped();
protected:
  virtual void run();

  virtual void xml_writeProperties( XML_WRITEPROPERTIES_ARGS ) const;
  virtual void xml_writeChildren( XML_WRITECHILDREN_ARGS ) const;
  virtual XMLMember xml_member(XML_MEMBER_ARGS);
  virtual bool xml_setProperty( XML_SETPROPERTY_ARGS );
  virtual void xml_polish( XML_POLISH_ARGS );
private:
  void importModelsFromAscii(QString fileName);
  void importModelsFromReport(QString fileName, bool strict);

  int _itmax, _ns0, _ns, _nr, _nw, _seed;
  double _giveUp;
  QString _reportFileName;
  bool _hasReportFile;
  int _expectedModelCount;

  Neighborhood _na;
};

#endif
