/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-31
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QWorkspace>

#include "SelectPSViewer.h"
#include "PSViewer.h"
#include "DinverGui.h"

/*
 *  Constructs a SelectPSViewer as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  true to construct a modal dialog.
 */
SelectPSViewer::SelectPSViewer(QWidget* parent, Qt::WFlags fl)
    : Dialog( parent, fl )
{
  TRACE;
    setupUi(this);
}

/*
 *  Destroys the object and frees any allocated resources
 */
SelectPSViewer::~SelectPSViewer()
{
  TRACE;
    // no need to delete child widgets, Qt does it all for us
}


void SelectPSViewer::on_isNewViewer_toggled( bool )
{
  TRACE;
  newViewCaption->setEnabled(isNewViewer->isChecked());
}

void SelectPSViewer::on_isAddToViewer_toggled( bool )
{
  TRACE;
  psViewerList->setEnabled(isAddToViewer->isChecked());
}

void SelectPSViewer::init(PSViewerList psViewerPtrList, InversionThread * models)
{
  TRACE;
  newViewCaption->setText(models->objectName());
  PSViewerList::iterator it;
  for (it=psViewerPtrList.begin();it!=psViewerPtrList.end();++it) {
    if (*((*it)->parameterList())==*models) {
      psViewerList->addItem((*it)->windowTitle());
      _selectedViewers.append(*it);
    }
  }
  if (_selectedViewers.size()==0) {
    psViewerList->setEnabled(false);
    isAddToViewer->setEnabled(false);
    isNewViewer->setChecked(true);
  }
  else {
    isAddToViewer->setChecked(true);
    psViewerList->setItemSelected(psViewerList->item(0),true);
  }
}

void SelectPSViewer::on_isNewViewer_clicked()
{
  TRACE;
  isNewViewer->setChecked(true);
  isAddToViewer->setChecked(false);
}

void SelectPSViewer::on_isAddToViewer_clicked()
{
  TRACE;
  isNewViewer->setChecked(false);
  isAddToViewer->setChecked(true);
}

PSViewer * SelectPSViewer::result()
{
  TRACE;
  if (isNewViewer->isChecked()) {
    PSViewer * w=new PSViewer;
    w->setWindowTitle(newViewCaption->text());
    connect(&dinverGui->bigBen(),SIGNAL(synchroTimeout()),w,SLOT(synchronize()));
    dinverCore->addWindow(w);
    dinverCore->showWindow(w);
    return w;
  }
  else {
    int sel=0;
    for (int i=psViewerList->count()-1;i>=0;i--) {
      if (psViewerList->item(i)->isSelected()) sel=i;
    }
    return _selectedViewers[sel];
  }
}

