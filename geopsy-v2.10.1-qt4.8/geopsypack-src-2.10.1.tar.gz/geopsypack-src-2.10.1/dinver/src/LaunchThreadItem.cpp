/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2006-04-01
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include "LaunchThreadItem.h"
#include "DinverGui.h"
#include "InversionThread.h"

LaunchThreadItem::LaunchThreadItem( QObject * parent )
    : QAbstractItemModel( parent )
{
  TRACE;
  connect( dinverGui, SIGNAL( newThread( InversionThread * ) ), this, SLOT( refresh() ) );
}

LaunchThreadItem::~LaunchThreadItem()
{
  TRACE;}

void LaunchThreadItem::refresh()
{
  TRACE;
  reset();
}

int LaunchThreadItem::rowCount( const QModelIndex &parent ) const
{
  TRACE;
  if ( !parent.isValid() )
    return dinverGui->threads().count();
  return 0;
}

int LaunchThreadItem::columnCount( const QModelIndex & ) const
{
  TRACE;
  return 8;
}

QVariant LaunchThreadItem::data( const QModelIndex &index, int role ) const
{
  TRACE;
  // Bug 1120, need more documentation
  TRACE_BUG;
  TRACE_BUG_POINTER(dinverGui);
  if(index.isValid()) {
    TRACE_BUG_INT(index.row());
  }
  TRACE_BUG_INT(dinverGui->threads().count());
  if ( !index.isValid() || index.row() >= dinverGui->threads().count() ) return QVariant();
  InversionThread * t = dinverGui->threads().at( index.row() );
  TRACE_BUG_N(1);
  TRACE_BUG_POINTER(t);
  TRACE_BUG_INT(t->itmax());
  switch ( role ) {
  case Qt::DisplayRole:
    switch ( index.column() ) {
    case 0: return t->objectName();
    case 1: return t->itmax();
    case 2: return t->ns0();
    case 3: return t->ns();
    case 4: return t->nr();
    case 5: return t->seed();
    case 6: return 100.0*t->giveUp();
    case 7: return t->nw();
    default: return QVariant();
    }
  default:
    return QVariant();
  }
}

bool LaunchThreadItem::setData ( const QModelIndex & index, const QVariant & value, int role )
{
  TRACE;
  if ( !index.isValid() || index.row() >= dinverGui->threads().count() ) return false;
  InversionThread * t = static_cast<InversionThread *>(index.internalPointer());
  switch ( role ) {
  case Qt::EditRole:
    switch ( index.column() ) {
    case 0:
      t->setObjectName(value.toString());
      dinverGui->logs()->setViewName(t, value.toString());
      App::stream(t) << tr("Renaming to %1").arg(value.toString()) << endl;
      emit dataChanged(index, index);
      return true;
    case 1:
      t->setItmax(value.toInt());
      emit dataChanged(index, index);
      return true;
    case 2:
      t->setNs0(value.toInt());
      emit dataChanged(index, index);
      return true;
    case 3:
      t->setNs(value.toInt());
      emit dataChanged(index, index);
      return true;
    case 4:
      t->setNr(value.toInt());
      emit dataChanged(index, index);
      return true;
    case 5:
      t->setSeed(value.toInt());
      emit dataChanged(index, index);
      return true;
    case 6:
      t->setGiveUp(value.toInt()/100.0);
      emit dataChanged(index, index);
      return true;
    case 7:
      t->setNw(value.toInt());
      emit dataChanged(index, index);
      return true;
    default:
      return false;
    }
  default:
    return false;
  }
}

QVariant LaunchThreadItem::headerData( int section, Qt::Orientation orientation, int role ) const
{
  TRACE;
  switch ( role ) {
  case Qt::DisplayRole:
    if ( orientation == Qt::Horizontal ) {
      switch ( section ) {
      case 0: return tr( "Run name" );
      case 1: return tr( "Itmax" );
      case 2: return tr( "Ns0" );
      case 3: return tr( "Ns" );
      case 4: return tr( "Nr" );
      case 5: return tr( "Seed" );
      case 6: return tr( "GiveUp" );
      case 7: return tr( "Nw" );
      default: return QVariant();
      }
    } else {
      return section + 1;
    }
  case Qt::ToolTipRole:
    if ( orientation == Qt::Horizontal ) {
      switch ( section ) {
      case 0: return tr( "A user name, must be unique inside an environment." );
      case 1: return tr( "Maximum number of iteration, each iteration generated ns new samples. It can be 0 for pure Monte Carlo." );
      case 2: return tr( "Number of model generated randomly before first iteration." );
      case 3: return tr( "Number of models generated at each iteration" );
      case 4: return tr( "Number of best solution models to consider when resampling (higher is more explorative)." );
      case 5: return tr( "Any positive number used to initialize the random sequence." );
      case 6: return tr( "When it is difficult to generate new models (misfit computation fails), it is possible to discard "
                         "some cells after un certain number of fails relative to the number of success." );
      case 7: return tr( "Number of Markov-chain walks to generate one model (1 or 2 is ok)." );
      default: return QVariant();
      }
    } else {
      return QVariant();
    }
  default:
    return QVariant();
  }
}

QModelIndex LaunchThreadItem::parent ( const QModelIndex & ) const
{
  TRACE;
  return QModelIndex();
}

QModelIndex LaunchThreadItem::index ( int row, int column, const QModelIndex & parent ) const
{
  TRACE;
  if ( column < 0 || row < 0 || row >= rowCount( parent ) ) return QModelIndex();
  InversionThread * t = dinverGui->threads().at( row );
  return createIndex( row, column, t );
}

Qt::ItemFlags LaunchThreadItem::flags ( const QModelIndex & ) const
{
  return Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
}
