/***************************************************************************
**
**  This file is part of dinver.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-31
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef THREADLAUNCHER_H
#define THREADLAUNCHER_H

#include <QQueue>

#include "ui_ThreadLauncher.h"

class ThreadLauncher : public QWidget, public Ui::ThreadLauncher
{
  Q_OBJECT
public:
  ThreadLauncher( QWidget* parent = 0 );
  ~ThreadLauncher();

  QString processBaseName( QString str );
  int processNameRank( QString str );
  QString processCompleteName( QString str, int num );
  bool isAnySelected();
  bool isQueued() const { return !_processToStart.isEmpty(); }
  bool assumeAllSelected( QString title, QString action );
  void wait();
public slots:
  void start();
  void stop();
  void clear();
  void show( bool s );
  void remove();
  void importModels();
  void dequeueAll() { _processToStart.clear(); }
  InversionThread * newThread();
  void processFinished();
  void applyAllSelected();
signals:
  void setCurrentRuns( ThreadList tList );
private slots:
  void selectionChanged();
private:
  void start(InversionThread * t);
  void startQueued();
  QQueue<InversionThread *> _processToStart;
  int _runningProcess;
};

#endif // QTBTHREADLAUNCHER_H
