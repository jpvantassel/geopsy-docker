<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbAddPlotParam</name>
    <message>
        <location filename="../src/qtbaddplotparam.ui" line="16"/>
        <source>Which parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbaddplotparam.ui" line="58"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbaddplotparam.ui" line="74"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbDinverGui</name>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="60"/>
        <source>dinver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="91"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="135"/>
        <source>There are still %1 running or queued processes. Do you want to stop them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="154"/>
        <source>Do you want to save the changes to the current environment?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="203"/>
        <location filename="../src/qtbdinvergui.cpp" line="946"/>
        <source>Targets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="215"/>
        <location filename="../src/qtbdinvergui.cpp" line="941"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="240"/>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="252"/>
        <source>Runs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="264"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="293"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="297"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="302"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="307"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="349"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="350"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="351"/>
        <source>Quit Geopsy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="362"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="365"/>
        <source>&amp;Parameter Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="366"/>
        <source>Create a new sheet with customizable projections of multidimensional parameter spaces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="380"/>
        <source>&amp;Runs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="384"/>
        <source>Add a new process with the current parameterization and a new random seed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="395"/>
        <source>Star&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="400"/>
        <source>&amp;Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="298"/>
        <source>Close current environment (if any) and clean everything</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="303"/>
        <source>Open an environment (targets, parameters and runs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="308"/>
        <location filename="../src/qtbdinvergui.cpp" line="313"/>
        <source>Save current environment (targets, parameters and runs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="322"/>
        <location filename="../src/qtbdinvergui.cpp" line="659"/>
        <location filename="../src/qtbdinvergui.cpp" line="668"/>
        <source>Import targets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="323"/>
        <source>Import current targets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="328"/>
        <location filename="../src/qtbdinvergui.cpp" line="675"/>
        <location filename="../src/qtbdinvergui.cpp" line="684"/>
        <source>Export targets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="329"/>
        <source>Export current targets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="334"/>
        <source>Import parameterization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="335"/>
        <source>Import current parameterization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="340"/>
        <source>Export parameterization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="341"/>
        <source>Export current parameterization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="383"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="389"/>
        <source>Remove selected run from the current environment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="396"/>
        <source>Start selected runs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="401"/>
        <source>Stop currently selected runs (no effect if no process is running).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="406"/>
        <source>Remove all generated models from selected runs, remove .report file if any.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="410"/>
        <source>&amp;Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="411"/>
        <source>In this mode, the target and the parameterization of each run can be viewed (export/import).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="420"/>
        <source>&amp;Import models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="421"/>
        <source>Populate the parameter space of selected run with models saved in .report file (generated by another run)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="433"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="466"/>
        <source>&amp;Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="470"/>
        <source>&amp;Cascade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="476"/>
        <source>Tile &amp;Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="482"/>
        <source>Tile &amp;Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="488"/>
        <source>Close &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="494"/>
        <source>&amp;Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="509"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="512"/>
        <source>Online Dinver &amp;Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="513"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="514"/>
        <source>Access to online html documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="523"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="524"/>
        <source>Show dinver&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="528"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="529"/>
        <source>Show the Qt library&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="553"/>
        <source>Open an existing environment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="554"/>
        <location filename="../src/qtbdinvergui.cpp" line="596"/>
        <source>Dinver environment (*.dinver)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="584"/>
        <source>Opening environment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="584"/>
        <source>Encountered error(s) while opening your environment. It is partially loaded. See log for details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="595"/>
        <source>Save current environment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="641"/>
        <source>Saving environment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="660"/>
        <source>Dinver targets (*.target);;Dinver environment (*.dinver)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="668"/>
        <location filename="../src/qtbdinvergui.cpp" line="701"/>
        <source>Error parsing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="676"/>
        <source>Dinver targets (*.target)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="684"/>
        <location filename="../src/qtbdinvergui.cpp" line="718"/>
        <source>Cannot open file for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="692"/>
        <source>Import paramters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="693"/>
        <source>Dinver parameters (*.param);;Dinver environment (*.dinver)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="701"/>
        <source>Import parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="709"/>
        <location filename="../src/qtbdinvergui.cpp" line="718"/>
        <source>Export parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="710"/>
        <source>Dinver parameters (*.param)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="932"/>
        <source>Parameters of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="936"/>
        <source>Targets of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="960"/>
        <source>View all selected runs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="973"/>
        <source>View run %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="1011"/>
        <source>No run selected, do you want to select all of them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="1064"/>
        <source>Closing all PS viewers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="1064"/>
        <source>This operation requires all PS viewers to be closed. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="388"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="134"/>
        <location filename="../src/qtbdinvergui.cpp" line="153"/>
        <location filename="../src/qtbdinvergui.cpp" line="165"/>
        <source>Closing dinver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="165"/>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="312"/>
        <source>Save as ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="641"/>
        <source>Some inversion process are still running and their models are stored in temporary directory. Stop these processes or wait for their completion before saving again. When quitting, the temporary directory is cleaned and models (directly stored in .report file) will be lost. See log for details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdinvergui.cpp" line="405"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbInversionThread</name>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="82"/>
        <source>Removing %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="93"/>
        <source>
---------------------- Starting at </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="95"/>
        <source> Max number of iterations             = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="96"/>
        <source> Num samples 1st iteration            = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="97"/>
        <source> Num samples per iteration            = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="98"/>
        <source> Num cells to resample                = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="99"/>
        <source> Num of walks before accepting model  = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="100"/>
        <source> Max reject ratio before cell give up = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="101"/>
        <source> Random seed                          = %1

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="102"/>
        <source> Dimension of parameter space         = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="103"/>
        <source> Parameterization checksum            = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="104"/>
        <source> Total number of models               = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="105"/>
        <source> Model file                           = %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="107"/>
        <source>Number of variable parameters is null, nothing to optimize, aborting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="137"/>
        <source>The new name for run %1 is not unique, nothing changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="148"/>
        <source>run %1 is runnning: still writing models to old file name. New name will be use for next &apos;start&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="151"/>
        <source>Renaming %1 to %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="161"/>
        <source>run %1 is runnnig cannot copy report to %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="204"/>
        <source>Thread manually stopped.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="205"/>
        <source>WARNING: Trying to stop it but thread is not running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="216"/>
        <source>Thread cleared.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="233"/>
        <source>Initialization of parameter space...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="251"/>
        <source>Starting %1 iterations...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="255"/>
        <source>iteration %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="265"/>
        <source>Finished %1 iterations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="281"/>
        <source>Loading reports ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbinversionthread.cpp" line="281"/>
        <source>Signal file (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbLaunchThreadDelegate</name>
    <message>
        <location filename="../src/qtblaunchthreaddelegate.cpp" line="55"/>
        <source>Importance sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaddelegate.cpp" line="56"/>
        <source>Contouring</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaddelegate.cpp" line="85"/>
        <source>Dynamic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaddelegate.cpp" line="86"/>
        <source>Static</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaddelegate.cpp" line="87"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaddelegate.cpp" line="54"/>
        <source>Optimization</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbLaunchThreadItem</name>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="141"/>
        <source>Run name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="146"/>
        <source>Seed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="95"/>
        <source>Renaming to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="142"/>
        <source>Itmax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="143"/>
        <source>Ns0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="144"/>
        <source>Ns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="145"/>
        <source>Nr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="148"/>
        <source>Nw</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="157"/>
        <source>A user name, must be unique inside an environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="147"/>
        <source>GiveUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="162"/>
        <source>Any positive number used to initialize the random sequence.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="158"/>
        <source>Maximum number of iteration, each iteration generated ns new samples. It can be 0 for pure Monte Carlo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="159"/>
        <source>Number of model generated randomly before first iteration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="160"/>
        <source>Number of models generated at each iteration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="161"/>
        <source>Number of best solution models to consider when resampling (higher is more explorative).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="165"/>
        <source>Number of Markov-chain walks to generate one model (1 or 2 is ok).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreaditem.cpp" line="163"/>
        <source>When it is difficult to generate new models (misfit computation fails), it is possible to discard some cells after un certain number of fails relative to the number of success.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbLaunchThreadTable</name>
    <message>
        <location filename="../src/qtblaunchthreadtable.cpp" line="69"/>
        <source>Editing thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblaunchthreadtable.cpp" line="70"/>
        <source>Cannot edit a running process</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbMaxNumProcess</name>
    <message>
        <location filename="../src/qtbmaxnumprocess.ui" line="22"/>
        <source>Start mixed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmaxnumprocess.ui" line="42"/>
        <source>Maximum number of simultaneous processes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmaxnumprocess.ui" line="64"/>
        <source>Typically, for a single processor architecture, a value of 2 offers better performances than running only one process at a time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmaxnumprocess.ui" line="95"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmaxnumprocess.ui" line="102"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbNAModelsPlot</name>
    <message>
        <location filename="../src/qtbnamodelsplot.cpp" line="175"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbNAModelsPlotProperties</name>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.cpp" line="48"/>
        <source>%1 (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="16"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="36"/>
        <source>Dot diameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="43"/>
        <source>1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="53"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="70"/>
        <source>Parameter X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="78"/>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="104"/>
        <source>Misfit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbnamodelsplotproperties.ui" line="96"/>
        <source>Parameter Y</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbPSViewer</name>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="96"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="104"/>
        <source>Open PS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="105"/>
        <source>Open an existing Parameter Space sheet (*.page files)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="109"/>
        <source>Save PS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="110"/>
        <location filename="../src/qtbpsviewer.cpp" line="115"/>
        <source>Save the current Parameter Space sheet (*.page files)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="114"/>
        <source>Save PS As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="121"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="127"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="137"/>
        <source>&amp;Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="142"/>
        <source>&amp;Parameter plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="143"/>
        <source>Add a new plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="154"/>
        <source>&amp;Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="159"/>
        <source>Set &amp;limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpsviewer.cpp" line="160"/>
        <source>Adjust limits of plots automatically</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbParamEditor</name>
    <message>
        <location filename="../src/qtbparameditor.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbparameditor.ui" line="41"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbparameditor.ui" line="61"/>
        <source>Conditions between parameters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbPluginPaths</name>
    <message>
        <location filename="../src/qtbpluginpaths.cpp" line="49"/>
        <location filename="../src/qtbpluginpaths.cpp" line="51"/>
        <location filename="../src/qtbpluginpaths.cpp" line="53"/>
        <source>Add plugin search path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.ui" line="16"/>
        <source>Search paths for plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.ui" line="47"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.ui" line="54"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.ui" line="99"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.ui" line="106"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.cpp" line="49"/>
        <source>Dinver plugin (*.so)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.cpp" line="51"/>
        <source>Dinver plugin (*.dll)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginpaths.cpp" line="53"/>
        <source>Dinver plugin (*.dylib)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbPluginSelector</name>
    <message>
        <location filename="../src/qtbpluginselector.ui" line="19"/>
        <source>Dinver plugin selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginselector.ui" line="74"/>
        <source>Available plugins:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginselector.ui" line="137"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginselector.ui" line="171"/>
        <source>Search ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginselector.ui" line="210"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginselector.ui" line="223"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginselector.cpp" line="41"/>
        <source>&lt;p&gt;Dinver is a framework for inversion problems. The core engine is a Neighbourhood Algorithm originally proposed by Sambridge (1999), implemented in C++ and improved by &lt;a href=&quot;http://www.geopsy.org/#References&quot;&gt;Wathelet(2008)&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Each specific inversion problem can be coded with a simple API and packaged in a dynamic library (plugin).&lt;/p&gt;&lt;p&gt;Using, Copying and Modifying this program is granted to everyone under the terms of the GNU Public License version 2. &lt;b&gt;However, we would appreciate that you properly reference this work, released for free, in all your publications or reports achieved with this software.&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbpluginselector.cpp" line="125"/>
        <source>%1 has not a correct build key.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbProcessStatus</name>
    <message>
        <location filename="../src/qtbprocessstatus.ui" line="13"/>
        <source>Thread status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.ui" line="58"/>
        <source>Legend</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbSelectPSViewer</name>
    <message>
        <location filename="../src/qtbselectpsviewer.ui" line="16"/>
        <source>Select model viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbselectpsviewer.ui" line="39"/>
        <source>New PS viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbselectpsviewer.ui" line="51"/>
        <source>Add to an existing PS viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbselectpsviewer.ui" line="85"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbselectpsviewer.ui" line="101"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbStatusThreadItem</name>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="321"/>
        <source>%1/%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="318"/>
        <location filename="../src/qtbprocessstatus.cpp" line="323"/>
        <location filename="../src/qtbprocessstatus.cpp" line="328"/>
        <location filename="../src/qtbprocessstatus.cpp" line="333"/>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="326"/>
        <location filename="../src/qtbprocessstatus.cpp" line="331"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="336"/>
        <source>%1 m/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="338"/>
        <source>? m/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="346"/>
        <source>%1 m/m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="372"/>
        <source>Valid models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="373"/>
        <source>Active models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="374"/>
        <source>Visited models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="341"/>
        <location filename="../src/qtbprocessstatus.cpp" line="348"/>
        <location filename="../src/qtbprocessstatus.cpp" line="353"/>
        <source>%1 m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="350"/>
        <location filename="../src/qtbprocessstatus.cpp" line="355"/>
        <source>? m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="369"/>
        <source>Pen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="370"/>
        <source>Run name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="375"/>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="376"/>
        <source>Eff. Nr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="377"/>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="378"/>
        <source>Give up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbprocessstatus.cpp" line="371"/>
        <source>Min misfit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbThreadLauncher</name>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="196"/>
        <source>No run selected, do you want to %1 all of them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="228"/>
        <location filename="../src/qtbthreadlauncher.cpp" line="251"/>
        <location filename="../src/qtbthreadlauncher.cpp" line="265"/>
        <source>Starting inversion run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="228"/>
        <source>start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="91"/>
        <location filename="../src/qtbthreadlauncher.cpp" line="103"/>
        <location filename="../src/qtbthreadlauncher.cpp" line="111"/>
        <source>New thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="91"/>
        <location filename="../src/qtbthreadlauncher.cpp" line="111"/>
        <source>Error creating a new inversion thread.

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="103"/>
        <source>No variable parameters, check parameterization.

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="252"/>
        <source>A report file already exists for run %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="253"/>
        <source>Append</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="253"/>
        <location filename="../src/qtbthreadlauncher.cpp" line="267"/>
        <source>Overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="255"/>
        <location filename="../src/qtbthreadlauncher.cpp" line="269"/>
        <source>Run %1 not started because report file already exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="266"/>
        <source>A report file already exist for run %1, but it has not a report format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="287"/>
        <source>:-p Starting process %1, %2 are running, %3 are queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="295"/>
        <source>:-( process %1 is already running, hence removed from queue, %2 are running, %3 are queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="311"/>
        <source>:-) Process %1 finished, %2 are running, %3 are queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="325"/>
        <source>Stoping inversion run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="325"/>
        <source>stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="353"/>
        <source>Clearing inversion run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="353"/>
        <source>clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="379"/>
        <source>Removing inversion run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="379"/>
        <source>remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="406"/>
        <source>Importing models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="407"/>
        <source>Inversion report file (*.report)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.ui" line="21"/>
        <source>Inversion thread launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="210"/>
        <source>Run parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbthreadlauncher.cpp" line="211"/>
        <source>Do you want to set the same value to all selected runs?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbXMLDinverGui</name>
    <message>
        <location filename="../src/qtbxmldinvergui.cpp" line="68"/>
        <source>Error creating a new forward object, skipping run</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="128"/>
        <source>dinver: bad option %1, see --help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="149"/>
        <source>No plugin selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="157"/>
        <source>Cannot load plugin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="162"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="176"/>
        <location filename="../src/main.cpp" line="271"/>
        <source>dinver: no plugin selected (option -i)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="183"/>
        <location filename="../src/main.cpp" line="278"/>
        <source>dinver: cannot set plugin with tag %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="241"/>
        <location filename="../src/main.cpp" line="320"/>
        <source>dinver: missing parameters, option &apos;-param&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="245"/>
        <source>dinver: missing targets, option &apos;-target&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="250"/>
        <location filename="../src/main.cpp" line="325"/>
        <source>dinver: error reading parameters from file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="254"/>
        <source>dinver: error reading targets from file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="338"/>
        <source>dinver: bad option &apos;%1&apos;, see -h</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
