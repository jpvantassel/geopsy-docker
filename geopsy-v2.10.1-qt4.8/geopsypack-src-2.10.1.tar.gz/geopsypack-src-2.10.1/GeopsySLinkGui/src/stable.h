#if defined __cplusplus
#include <QtGui>
#ifndef Q_WS_MAC
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include <SciFigs.h>
#include <GeopsyCore.h>
#include <GeopsySLink.h>
#include <GeopsyGui.h>
#include <slink.h>
#endif // Q_WS_MAC
#endif // __cplusplus
