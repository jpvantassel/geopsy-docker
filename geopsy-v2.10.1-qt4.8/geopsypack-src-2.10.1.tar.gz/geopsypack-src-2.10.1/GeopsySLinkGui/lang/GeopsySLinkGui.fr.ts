<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>SeedLinkLoader</name>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="149"/>
        <source>Parameters info and info_trusted in seedlink.ini can be used to limit access to information obtained via INFO command. If the connecting IP matches the value of trusted (by default 127.0.0.0/8, eg., localhost), the parameter with trusted suffix is used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="155"/>
        <location filename="../src/SeedLinkLoader.cpp" line="161"/>
        <source>Requesting stream list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="156"/>
        <source>Server returned an error after requesting stream list. It is probably linked to permission restrictions on the server side.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="162"/>
        <source>Server returned an error after requesting station list. It is probably linked to permission restrictions on the server side.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="174"/>
        <source>%1
%2
Started at %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="327"/>
        <source>Active SeedLink signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="350"/>
        <source>Expand all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="351"/>
        <source>Collapse all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.cpp" line="352"/>
        <source>Select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="13"/>
        <source>Seed link signal loader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="36"/>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="56"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="73"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="103"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;List of stations and streams to select (slinktool format or regular expression, see &apos;What&apos;s this&apos;)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="109"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;There are two ways to specify stations and streams: conventional seedlink format (same as in slinktool) or regular expressions (more flexible).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;1. Conventional way&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;SL:NW_STAT1:BH?.D,NW_STAT2,NW_STAT3:?,NW_STAT4:BHE BHN&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-style:italic;&quot;&gt;&lt;span style=&quot; font-style:normal;&quot;&gt;Select channels starting with &apos;BH&apos; and of type &apos;D&apos; for station STAT1 of network NW, all channels of stations STAT2 and STAT3, and horizontal channels of STAT4.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;2. Regular expressions&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;RX:STAT_REGEXP1:CHAN_REGEXP1,STAT_REGEXP2:CHAN_REGEXP2&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Examples:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;&quot;RX:WA_WAU[0-9]{2}:(HHE|HHN)&quot;&lt;/span&gt; stands for all HH horizontal channels of all stations with name starting with WAU of network WA&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;&quot;RX:.*&quot;&lt;/span&gt; stands for all channels of all stations.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;&quot;RX:.*:..Z\.D&quot;&lt;/span&gt; stands for all vertical channels (HH, BH,...) of type &apos;D&apos; of all stations.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="130"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="156"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;View selected streams (works only for active streams)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="162"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="169"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="192"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Stop listening to selected streams&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="198"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="208"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Start listening to selected streams&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoader.ui" line="214"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeedLinkLoaderOptions</name>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.cpp" line="122"/>
        <source> day(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.cpp" line="125"/>
        <source> h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.cpp" line="128"/>
        <source> min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.cpp" line="131"/>
        <source> s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="14"/>
        <source>SeedLink loader options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="26"/>
        <source>Start listening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="38"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="48"/>
        <source>From now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="61"/>
        <source>Buffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="73"/>
        <source>Maximum duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="81"/>
        <source>Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="86"/>
        <source>Minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="91"/>
        <source>Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="96"/>
        <source>Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="120"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When the maximum duration is reached, a new signal is created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="126"/>
        <source>Create new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="133"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When the maximum duration is reached, the buffer starts to rotate, loosing older samples.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="139"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="146"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Limited only by the memory you allowed for Geopsy in preferences.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkLoaderOptions.ui" line="152"/>
        <source>Unlimited</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeedLinkStreamItem</name>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="126"/>
        <source>Stream name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="127"/>
        <location filename="../src/SeedLinkStreamItem.cpp" line="166"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="145"/>
        <source>Station name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="146"/>
        <source>Stream check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="147"/>
        <source>Station description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="165"/>
        <source>Seed name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="167"/>
        <source>Begin time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="168"/>
        <source>End time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="169"/>
        <source>Begin recno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="170"/>
        <source>End recno</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="171"/>
        <source>Gap check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLinkStreamItem.cpp" line="172"/>
        <source>Gap treshold</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
