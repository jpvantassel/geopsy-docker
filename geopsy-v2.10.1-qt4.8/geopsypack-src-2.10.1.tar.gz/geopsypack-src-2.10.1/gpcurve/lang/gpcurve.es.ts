<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbCurveReader</name>
    <message>
        <location filename="../src/qtbcurvereader.cpp" line="155"/>
        <source>gpcurve: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcurvereader.cpp" line="197"/>
        <source>At least 2 samples are required to define a curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcurvereader.cpp" line="283"/>
        <source>At least 3 samples per curve are required to calculate derivative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcurvereader.cpp" line="356"/>
        <source>gpcurve: missing reference file, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcurvereader.cpp" line="361"/>
        <source>gpcurve: cannot open reference file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcurvereader.cpp" line="380"/>
        <source>gpcurve: reference curve is empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcurvereader.cpp" line="395"/>
        <source>gpcurve: no function defined</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
