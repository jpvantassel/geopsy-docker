/***************************************************************************
**
**  This file is part of gpcurve.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-06-26
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include "CurveReader.h"
#include "gpcurveVersion.h"
#include "gpcurveInstallPath.h"

PACKAGE_INFO( gpcurve, GPCURVE );

ApplicationHelp * help();

int main( int argc, char ** argv )
{
  CoreApplication a( argc, argv, help );
  // stdout is used for output of results, redirect main application log to stderr
  a.setStream(new StandardStream(stderr));

  // Options
  CurveReader reader;
  if ( reader.setOptions( argc, argv ) ) {
    if ( reader.isFunctionMode() ) {
      reader.generateFunction();
      return 0;
    } else if ( reader.read( argc, argv ) ) {
      return 0;
    } else {
      return 2;
    }
  } else {
    return 2;
  }
}

ApplicationHelp * help()
{
  TRACE;
  ApplicationHelp * h = new ApplicationHelp;
  h->setOptionSummary( "[OPTIONS]" );
  h->setComments( "Manipulation of curve given through stdin. The same operations are applied to all curves. "
                  "Various curves are separated by blank lines or comments('#'). There can be as many column as "
                  "given by option '-columns'. Other columns are ignored." );
  h->addGroup("Gpcurve", "gpcurve");
  h->addOption("-resample <N>", "Resample curves. N is the number of output samples. If MIN is -1e99, the minimum "
               "X of curve are kept (same for MAX).");
  h->addOption("-resample-ext <N>", "Same as -resample except that limits of curves are extrapolated");
  h->addOption("-set <REF>", "Output the curve contains in REF with values ");
  h->addOption("-cut", "Cut curves, remove all sample outside MIN and MAX. It does not interpole values at both ends "
               "if MIN and MAX does not fit with a sample");
  h->addOption("-cut-int", "Same as -cut except that it interpoles values at both ends if MIN and MAX does not fit "
               "with a sample");
  h->addOption("-swap", "Swap x and y. It works only on x,y curves (with only one column).");
  h->addOption("-value <X>", "Return the interpolated value at X");
  h->addOption("-max-index <COL>", "Return sample index of maximum value for column COL. COL is not mandatory (default=1).");
  h->addOption("-max-value <COL>", "Return maximum value for column COL. COL is not mandatory (default=1).");
  h->addOption("-merge-replace <REF>", "Output curves. For all matching x in curve found in REF, the values of REF are output instead.");
  h->addOption("-merge-interpolate <REF>", "Output curves together with the interpolated values of a reference curve in file REF");
  h->addOption("-misfit <REF>", "Calculate misfit between curves and a reference curve in file REF. "
                                "Curve are supposed to have 1 or 2 columns: mean and an optional stddev. "
                                "The type of misift computation can be set with option '-misfit-type'.");
  h->addOption("-derivative", "Output first derivative of input curves");
  h->addOption("-multiply <FACTOR>", "Multiplies all Y values by FACTOR.");
  h->addOption("-pow <BASE>", "Takes power of all Y values with base BASE.");
  h->addOption("-log <BASE>", "Takes log of all Y values with base BASE.");
  h->addOption("-function <FUNC>", "Output values of expression FUNC from MIN to MAX, x must be the variable parameter. "
               "FUNC must the format 'y=...'.");
  h->addGroup("Resample mode", "resample");
  h->addOption("-min <MIN>", "Minimum X value (default=-1e99)");
  h->addOption("-max <MAX>", "Maximum X value (default=1e99)");
  h->addOption("-sampling <TYPE>","Defines the sampling type:\n"
                              "  inversed   regular sampling in 1/X\n"
                              "  linear     regular sampling in linear(X) (default)\n"
                              "  log        regular sampling in log(X)");
  h->addGroup("Cut mode", "cut");
  h->addOption("-min <MIN>", "Minimum X value (default=-1e99)");
  h->addOption("-max <MAX>", "Maximum X value (default=1e99)");
  h->addGroup("Function mode", "function");
  h->addOption("-min <MIN>", "Minimum X value (default=-1e99)");
  h->addOption("-max <MAX>", "Maximum X value (default=1e99)");
  h->addOption("-dx <DX>", "Sample function with DX step, starting from MIN to MAX.");
  h->addGroup("Misfit mode", "misfit");
  h->addOption("-misfit-type <TYPE>", "TYPE can take the following values:\n"
                                      "  L1                        L1 norm.\n"
                                      "  L1_Normalized             L1 norm normalized by mean value or stddev if available.\n"
                                      "  L1_LogNormalized          L1 norm normalized by log(mean value) or log(stddev) if available.\n"
                                      "  L1_NormalizedBySigmaOnly  L1 norm normalized by stddev if available (if not, no normalization).\n"
                                      "  L2                        L2 norm.\n"
                                      "  L2_Normalized             L2 norm normalized by mean value or stddev if available.\n"
                                      "  L2_LogNormalized          L2 norm normalized by log(mean value) or log(stddev) if available.\n"
                                      "  L2_NormalizedBySigmaOnly  L2 norm normalized by stddev if available (if not, no normalization).\n"
                                      "  Akaike                    Akaike for least square estimation with normally distributed errors. "
                                                                  "Option '-misfit-dof' is required.\n"
                                      "  Akaike_Few     Akaike for least square estimation with normally distributed errors "
                                                       "and few samples compared to the degrees of freedom. "
                                                       "Option '-misfit-dof' is required.");
  h->addOption("-misfit-min <MIN>", "Minimum misfit value of misfit (on a per sample basis).");
  h->addOption("-misfit-dof <DOF>", "Number of degrees of freedom for Akaike misfits.");
  return h;
}
