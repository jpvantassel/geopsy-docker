#ifndef GPCURVE_VERSION
#define GPCURVE_VERSION "0.1.0"
#define GPCURVE_VERSION_TIME "201101031552"
#define GPCURVE_VERSION_TYPE "testing"
#define GPCURVE_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)"
#endif // GPCURVE_VERSION
