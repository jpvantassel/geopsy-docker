/***************************************************************************
**
**  This file is part of gpcurve.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-11
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include "CurveReader.h"

/*!
  \class CurveReader qtbcurvereader.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
CurveReader::CurveReader()
    : ArgumentStdinReader()
{
  TRACE;
  _mode = None;
  _nResample = 100;
  _minX = -1e99;
  _maxX = 1e99;
  _dx = 1;
  _xValue = 0.0;
  _columnIndex = 1;
  _samplingType = LinearScale;
  _misfitType = StatValue::L2_Normalized;
  _misfitMin = 0.0;
  _misfitDof = 1;
  _multiplyFactor=1.0;
  _logBase=10.0;
}

bool CurveReader::setOptions( int& argc, char ** argv )
{
  TRACE;
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-resample") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = Resample;
        _nResample = atoi(argv[i]);
      } else if (arg=="-resample-ext") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = ResampleExtrapole;
        _nResample = atoi(argv[i]);
      } else if (arg=="-cut") {
        _mode = Cut;
      } else if (arg=="-cut-int") {
        _mode = CutInterpole;
      } else if (arg=="-swap") {
        if ( CoreApplication::checkOptionArg(i, argc, argv, false) ) {
          _columnIndex = atoi(argv[i]);
        }
        _mode = Swap;
      } else if (arg=="-max-index") {
        if ( CoreApplication::checkOptionArg(i, argc, argv, false) ) {
          _columnIndex = atoi(argv[i]);
        }
        _mode = MaxIndex;
      } else if (arg=="-max-value") {
        if ( CoreApplication::checkOptionArg(i, argc, argv, false) ) {
          _columnIndex = atoi(argv[i]);
        }
        _mode = MaxValue;
      } else if (arg=="-value") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = FunctionValue;
        _xValue = atof(argv[i]);
      } else if (arg=="-merge-replace") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = MergeReplace;
        _referenceFile = argv[i];
      } else if (arg=="-merge-interpolate") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = MergeInterpolate;
        _referenceFile = argv[i];
      } else if (arg=="-misfit") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = Misfit;
        _referenceFile = argv[i];
      } else if (arg=="-derivative") {
        _mode = Derivative;
      } else if (arg=="-pow") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = Power;
        _logBase=atof(argv[i]);
      } else if (arg=="-log") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = Log;
        _logBase=atof(argv[i]);
      } else if (arg=="-multiply") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = Multiply;
        _multiplyFactor=atof(argv[i]);
      } else if (arg=="-function") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode = ParseFunction;
        _functionText=argv[i];
      } else if (arg=="-misfit-type") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _misfitType = StatValue::misfitType( argv[i] );
      } else if (arg=="-misfit-min") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _misfitMin = atof( argv[i] );
      } else if (arg=="-misfit-dof") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _misfitDof = atoi( argv[i] );
      } else if (arg=="-min") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _minX = atof(argv[i]);
      } else if (arg=="-max") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _maxX = atof(argv[i]);
      } else if (arg=="-dx") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _dx = atof(argv[i]);
      } else if (arg=="-sampling") {
        CoreApplication::checkOptionArg(i, argc, argv);
        if (strcmp(argv[i],"inversed")==0) {
          _samplingType = InversedScale;
        } else if (strcmp(argv[i],"linear")==0) {
          _samplingType = LinearScale;
        } else {
          _samplingType = LogScale;
        }
      } else {
        App::stream() << tr("gpcurve: bad option %1, see -help").arg(argv[i]) << endl;
        return false;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  return true;
}

bool CurveReader::parse( QTextStream& s )
{
  TRACE;
  QTextStream sOut( stdout );
  Curve<PointND> curve;
  PointND p;
  QString buf;
  while (!s.atEnd()) {
    buf = s.readLine();
    if (buf.isEmpty() || buf[0]=='\n' || buf[0]=='#') {
      if (!exec(curve)) {
        return false;
      }
      curve.clear();
      if (buf[0]=='#') sOut << buf << endl;
    } else {
      p.fromString( buf );
      curve.append( p );
    }
  }
  return exec(curve);
}

bool CurveReader::exec( Curve<PointND>& curve )
{
  if (curve.isEmpty()) return true;
  QTextStream sOut(stdout);
  if (curve.count()<2) {
    App::stream() << tr("At least 2 samples are required to define a curve") << endl;
    return false;
  }
  switch(_mode) {
  case Multiply:
  case Log:
  case Power:
    break;
  default:
    curve.setFunction();
    if (_minX==-1e99) {
      _minX = curve.first().x();
    }
    if (_maxX==1e99) {
      _maxX = curve.last().x();
    }
    break;
  }
  switch(_mode) {
  case None:
  case ParseFunction:
    break;
  case ResampleExtrapole:
    curve.resample( _nResample, _minX, _maxX, _samplingType | Function );
    curve.toStream(sOut);
    break;
  case Resample: {
      double minOriginalX = curve.first().x();
      double maxOriginalX = curve.last().x();
      curve.resample( _nResample, _minX, _maxX, _samplingType | Function );
      curve.cut( minOriginalX, maxOriginalX, Function );
      curve.toStream(sOut);
    }
    break;
  case Cut:
    curve.cut( _minX, _maxX, Function );
    curve.toStream(sOut);
    break;
  case CutInterpole:
    curve.cut( _minX, _maxX, Function | Interpole );
    curve.toStream(sOut);
    break;
  case Swap: {
      Curve<Point2D> c2 = curve2D( curve );
      c2.swapXY();
      c2.toStream(sOut);
    }
    break;
  case MaxIndex: {
      Curve<Point2D> c2 = curve2D( curve );
      sOut << c2.maximumY() << "\n";
    }
    break;
  case MaxValue: {
      Curve<Point2D> c2 = curve2D( curve );
      int i = c2.maximumY();
      ASSERT(i>-1);
      sOut << curve.at(i).toString(20) << "\n";
    }
    break;
  case FunctionValue:
    sOut << curve.at( _xValue ).toString(20) << "\n";
    break;
  case MergeReplace: {
      loadReference();
      for (int i=0;i<curve.count();i++) {
        const PointND& p = curve.at(i);
        int index = _referenceCurve.indexAfter( p.x() );
        if(index<_referenceCurve.count() && _referenceCurve.at(index).x()==p.x()) {
          sOut << _referenceCurve.at( index ).toString(20) << "\n";
        } else {
          sOut << p.toString(20) << "\n";
        }
      }
    }
    break;
  case MergeInterpolate: {
      loadReference();
      for (int i=0;i<curve.count();i++) {
        const PointND& p = curve.at(i);
        sOut << p.toString(20) << " " << _referenceCurve.at( p.x() ).toString(20) << "\n";
      }
    }
    break;
  case Derivative:
    if ( curve.count() < 3 ) {
      App::stream() << tr("At least 3 samples per curve are required to calculate derivative") << endl;
      return false;
    } else {
      Curve<Point2D> c2 = curve2D( curve );
      c2.derivative().toStream(sOut);
    }
    break;
  case Misfit: {
      loadReference();
      double sum = 0.0;
      int nData = 0, nValues =0;
      for (int i=0;i<curve.count();i++) {
        const PointND& p = curve.at(i);
        PointND r = _referenceCurve.at( p.x() );
        StatValue sv( r.y(0), r.y(1) );
        Value v( p.y(0) );
        sum += sv.misfit( nValues, nData, v, _misfitType, _misfitMin );
      }
      switch(_misfitType) {
      case StatValue::L1:
      case StatValue::L1_Normalized:
      case StatValue::L1_LogNormalized:
      case StatValue::L1_NormalizedBySigmaOnly:
      case StatValue::L2:
      case StatValue::L2_Normalized:
      case StatValue::L2_LogNormalized:
      case StatValue::L2_NormalizedBySigmaOnly:
        sOut << sqrt( sum/curve.count() ) << "\n";
        break;
      case StatValue::Akaike:
        sOut << curve.count() * log10( sqrt( sum/curve.count() ) )+2.0*_misfitDof << "\n";
        break;
      case StatValue::AkaikeFewSamples:
        sOut << curve.count() * log10( sqrt( sum/curve.count() ) )
               +2.0*_misfitDof+(2.0*_misfitDof*(_misfitDof+1.0))/(curve.count()-_misfitDof-1.0) << "\n";
        break;
      }
    }
    break;
  case Multiply:
    curve.yMultiply(_multiplyFactor);
    curve.toStream(sOut);
    break;
  case Log:
    curve.yLog10();
    if(_logBase!=10.0) {
      curve.yMultiply(1.0/log10(_logBase));
    }
    curve.toStream(sOut);
    break;
  case Power:
    if(_logBase!=10.0) {
      curve.yMultiply(log10(_logBase));
    }
    curve.yExp10();
    curve.toStream(sOut);
    break;
  }
  sOut << flush;
  return true;
}

Curve<Point2D> CurveReader::curve2D( Curve<PointND>& cn )
{
  int n = cn.count();
  Curve<Point2D> c2;
  c2.resize(n);
  for(int i = 0; i<n; i++) {
    c2[i].setX( cn[i].x() );
    c2[i].setY( cn[i].y( _columnIndex-1 ) );
  }
  return c2;
}

bool CurveReader::loadReference()
{
  if (_referenceFile.isEmpty()) {
    App::stream() << tr("gpcurve: missing reference file, see -help") << endl;
    return false;
  } else {
    QFile f( _referenceFile );
    if ( !f.open(QIODevice::ReadOnly) ) {
      App::stream() << tr("gpcurve: cannot open reference file %1").arg(_referenceFile) << endl;
      return false;
    }
    QTextStream s(&f);
    // Read file for first curve and set it as the reference curve
    QString buf;
    PointND p;
    while (!s.atEnd()) {
      buf = s.readLine();
      if (buf[0]=='\n' || buf[0]=='#') {
        if (!_referenceCurve.isEmpty()) break;
      } else {
        StringSection bufFields(buf);
        p.fromString( bufFields );
        _referenceCurve.append( p );
      }
    }
  }
  if (_referenceCurve.isEmpty()) {
    App::stream() << tr("gpcurve: reference curve is empty") << endl;
    return false;
  }
  _referenceCurve.setFunction();
  return true;
}

void CurveReader::generateFunction() const
{
  TRACE;
  QTextStream sOut(stdout);
  ExpressionParser pEngine;
  ExpressionContext context;
  ExpressionActions actions=pEngine.parse(_functionText, &context);
  if (actions.isEmpty()) {
    App::stream() << tr("gpcurve: no function defined") << endl;
  } else {
    sOut << "# Function " << _functionText << endl;
    for(double x=_minX;x<=_maxX;x+=_dx) {
      context.addVariable("x", x);
      for (ExpressionActions::iterator ita=actions.begin();ita!=actions.end();++ita) {
        (*ita)->value();
      }
      sOut << QString("%1 %2\n").arg( x, 0, 'g', 16 ).arg( context.variableValue( "y" ).toDouble(), 0, 'g', 16 );
    }
    sOut << flush;
  }
  qDeleteAll( actions );
}
