/***************************************************************************
**
**  This file is part of gpcurve.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-11
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef CURVEREADER_H
#define CURVEREADER_H

#include <QGpCoreTools.h>

class CurveReader : public ArgumentStdinReader
{
  TRANSLATIONS("ArgumentStdinReader")
public:
  CurveReader();

  bool setOptions( int& argc, char ** argv );
  bool isFunctionMode() const { return _mode == ParseFunction; }
  void generateFunction() const;
protected:
  virtual bool parse( QTextStream& s );
private:
  bool exec( Curve<PointND>& curve );
  Curve<Point2D> curve2D( Curve<PointND>& cn );
  bool loadReference();

  enum Mode { None, Resample, ResampleExtrapole, Cut, CutInterpole, Swap, FunctionValue, MaxIndex, MaxValue,
              Misfit, MergeReplace, MergeInterpolate, ParseFunction, Derivative, Multiply, Log, Power };
  Mode _mode;
  int _nResample;
  double _minX;
  double _maxX;
  double _dx;
  double _xValue;
  int _columnIndex;
  SamplingOption _samplingType;
  QString _referenceFile;
  Curve<PointND> _referenceCurve;
  StatValue::MisfitType _misfitType;
  double _misfitMin;
  int _misfitDof;
  QString _functionText;
  double _logBase;
  double _multiplyFactor;
};

#endif // CURVEREADER_H
