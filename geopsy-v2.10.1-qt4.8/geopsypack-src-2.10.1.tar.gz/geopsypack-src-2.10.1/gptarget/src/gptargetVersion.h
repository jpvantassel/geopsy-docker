#ifndef GPTARGET_VERSION
#define GPTARGET_VERSION "0.1.1"
#define GPTARGET_VERSION_TIME "201105121055"
#define GPTARGET_VERSION_TYPE "testing"
#define GPTARGET_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)"
#endif // GPTARGET_VERSION
