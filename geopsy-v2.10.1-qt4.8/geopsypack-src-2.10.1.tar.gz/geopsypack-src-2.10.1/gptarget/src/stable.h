#if defined __cplusplus
#include <QtCore>
#ifndef Q_WS_MAC
#include <QGpCoreTools.h>
#include <QGpCoreWave.h>
#include <DinverCore.h>
#include <DinverDCCore.h>
#include <QGpCompatibility.h>
#endif // Q_WS_MAC
#endif // __cplusplus
