/***************************************************************************
**
**  This file is part of gptarget.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-05-28
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>

#include "gptargetVersion.h"
#include "gptargetInstallPath.h"
#include "TargetAdd.h"
#include "TargetExtract.h"

PACKAGE_INFO( gptarget, GPTARGET );

ApplicationHelp * help();

int main( int argc, char ** argv )
{
  enum Mode { Undefined, Add, Delete, Extract };
  Mode mode = Undefined;

  if(argc>1) {
    switch (argv[1][0]) {
    case 'A':
      mode = Add;
      break;
    case 'D':
      mode = Delete;
      break;
    case 'E':
      mode = Extract;
      break;
    default:
      break;
    }
  }
  if (mode!=Undefined) {
    for (int i=2; i<argc; i++) {
      argv[i-1] = argv[i];
    }
    argc--;
  }

  CoreApplication a( argc, argv, help );
  // stdout is used for output of results, redirect main application log to stderr
  a.setStream(new StandardStream(stderr));

  AbstractTarget * t = 0;

  switch(mode) {
  case Add:
    t = new TargetAdd();
    break;
  case Delete:
    // Temporary message
    App::stream() << tr("gptarget: mode 'Delete' currently not supported. Request it to the developers if needed.") << endl;
    return 2;
  case Extract:
    t = new TargetExtract();
    break;
  case Undefined:
    App::stream() << tr("gptarget: mode not specified, see -help") << endl;
    return 2;
  }
  t->setOptions( argc, argv );
  if(argc != 2) {
    App::stream() << tr("gptarget: missing target file, see -help") << endl;
    return 2;
  }
  t->setFileName( argv[1] );
  return t->execute();
}

ApplicationHelp * help()
{
  TRACE;
  ApplicationHelp * h = new ApplicationHelp;
  h->setOptionSummary( "MODE [OPTIONS] <FILE.target>" );
  h->setComments( "Manipulation of dinver targets through command line. This tool "
                  "can add, delete, or extract curves to or from FILE.target files. "
                  "If FILE.target does not exist, it is created. This tool currently "
                  "support only dispersion curves but can be extended to other "
                  "target types upon request." );
  h->addGroup("Mode", "mode");
  h->addOption("A","Add information to FILE.target (see '-h add')");
  h->addOption("D","Delete information from FILE.target (see '-h delete')");
  h->addOption("E","Extract information from FILE.target (see '-h extract')");
  h->addGroup("Add", "add");
  h->addOption("-R <INDEX>","Adds dispersion curves read from stdin as Rayleigh with "
                           "mode INDEX (0 is fundamental). Format: frequency, slowness, stddev. Blanks or lines starting with '#' "
                           "delimit various curves.");
  h->addOption("-L <INDEX>","Adds dispersion curves read from stdin as Love with mode "
                           "INDEX (0 is fundamental). Format: frequency, "
                           "slowness, stddev. Blanks or lines starting with '#' "
                           "delimit various curves.");
  h->addOption("-group","Set Group slowness (default is Phase).");
  h->addOption("-weight <WEIGHT>","Set misfit weight for dispersion curves (default=1).");
  h->addOption("-min-misfit <WEIGHT>","Set minimum misfit for dispersion curves (default=0).");
  h->addGroup("Delete", "delete");
  h->addOption("-disp <INDEX>","Deletes dispersion curve with INDEX.");
  h->addGroup("Extract", "extract");
  h->addOption("-disp <INDEX>","Extracts dispersion curve with INDEX.");
  h->addExample("gptarget E -disp 0 my.target","Extracts the dispersion curve of fundamental mode contained in target file 'my.target'.");
  return h;
}
