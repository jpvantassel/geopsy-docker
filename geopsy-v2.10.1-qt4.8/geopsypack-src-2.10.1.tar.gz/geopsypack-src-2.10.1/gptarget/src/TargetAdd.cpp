/***************************************************************************
**
**  This file is part of gptarget.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-05-28
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverCore.h>
#include <DinverDCCore.h>
#include <QGpCoreTools.h>
#include <QGpCoreWave.h>

#include "TargetAdd.h"

/*!
  \class TargetAdd qtbtargetadd.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

TargetAdd::TargetAdd()
{
  _dispersionWeight=1.0;
  _dispersionMinimumMisfit=0.0;
}

/*!
  Description still missing
*/
bool TargetAdd::setOptions( int& argc, char ** argv )
{
  int j = 1;
  for (int i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-R") {
        _mode.setPolarisation( Mode::Rayleigh );
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode.setIndex( atoi(argv[i]) );
      } else if (arg=="-L") {
        _mode.setPolarisation( Mode::Love );
        CoreApplication::checkOptionArg(i, argc, argv);
        _mode.setIndex( atoi(argv[i]) );
      } else if (arg=="-group") {
        _mode.setSlowness( Mode::Group );
      } else if (arg=="-weight") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _dispersionWeight=atof(argv[i]);
      } else if (arg=="-min-misfit") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _dispersionMinimumMisfit=atof(argv[i]);
      } else {
        App::stream() << tr("gptarget: bad option %1, see -help").arg(argv[i]) << endl;
        return false;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  return true;
}

/*!
  Description still missing
*/
int TargetAdd::execute()
{
  TargetList tl;
  QFileInfo fi(fileName());
  if ( fi.exists() ) {
    XMLDinverDC dinverdc(&tl);
    XMLDinverHeader hdr(&dinverdc);
    if (hdr.xml_restoreFile( fileName() ) != XMLClass::NoError ) {
      App::stream() << tr("gptarget: error reading file %1").arg(fileName()) << endl;
      return 2;
    }
  }
  QList<ModalCurve> curves = tl.dispersionTarget().curves();
  tl.dispersionTarget().setMisfitWeight(_dispersionWeight);
  tl.dispersionTarget().setMinimumMisfit(_dispersionMinimumMisfit);
  QTextStream sIn( stdin );
  readCurves( curves, sIn );
  tl.dispersionTarget().setCurves( curves );
  XMLDinverDC dinverdc(&tl);
  XMLDinverHeader hdr(&dinverdc);
  if (hdr.xml_saveFile(fileName())!=XMLClass::NoError) {
    App::stream() << tr("gptarget: error writing to file %1").arg(fileName()) << endl;
    return 2;
  }
  return 0;
}

void TargetAdd::readCurves(QList<ModalCurve>& curves, QTextStream& s)
{
  ModalCurve curve;
  curve.addMode(_mode);
  FactoryPoint p;
  QString buf;
  CoreApplication::instance()->debugUserInterrupts(false);
  while (!s.atEnd()) {
    buf = s.readLine();
    if (buf[0]=='\n' || buf[0]=='#') {
      if (!curve.isEmpty()) {
        curves.append( curve );
        curve.clear();
      }
    } else {
      p.fromString( buf );
      curve.append( p );
    }
  }
  if (!curve.isEmpty()) {
    curves.append( curve );
  }
  CoreApplication::instance()->debugUserInterrupts(true);
}
