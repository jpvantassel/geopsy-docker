/***************************************************************************
**
**  This file is part of gptarget.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-05-28
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverCore.h>
#include <DinverDCCore.h>
#include <QGpCoreTools.h>
#include <QGpCoreWave.h>
#include "TargetExtract.h"

/*!
  \class TargetExtract qtbtargetextract.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

TargetExtract::TargetExtract()
{
  _curveIndex = 0;
}

/*!
  Description still missing
*/
bool TargetExtract::setOptions( int& argc, char ** argv )
{
  int j = 1;
  for (int i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-disp") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _curveIndex = atoi( argv[i] );
        if (_curveIndex<0) {
          App::stream() << tr("gptarget: curve index must be positive, see -help") << endl;
          return false;
        }
      } else {
        App::stream() << tr("gptarget: bad option %1, see -help").arg(argv[i]) << endl;
        return false;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  return true;
}

/*!
  Description still missing
*/
int TargetExtract::execute()
{
  TargetList tl;
  XMLDinverDC dinverdc(&tl);
  XMLDinverHeader hdr(&dinverdc);
  if (hdr.xml_restoreFile( fileName() ) != XMLClass::NoError ) {
    App::stream() << tr("gptarget: error reading file %1").arg(fileName()) << endl;
    return 2;
  }
  if (_curveIndex<tl.dispersionTarget().curves().count()) {
    QTextStream sOut( stdout );
    const ModalCurve& c = tl.dispersionTarget().curves().at(_curveIndex);
    sOut << "# index " << _curveIndex << ": " << c.modes().first().toString() << endl;
    c.toStream( sOut );
  } else {
    App::stream() << tr("gptarget: curve index out of bounds (%1)").arg(tl.dispersionTarget().curves().count()-1) << endl;
    return 2;
  }
  return 0;
}
