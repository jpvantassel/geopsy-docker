<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbTargetAdd</name>
    <message>
        <location filename="../src/qtbtargetadd.cpp" line="66"/>
        <source>gptarget: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtargetadd.cpp" line="91"/>
        <source>gptarget: error reading file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtargetadd.cpp" line="102"/>
        <source>gptarget: error writing to file %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbTargetExtract</name>
    <message>
        <location filename="../src/qtbtargetextract.cpp" line="60"/>
        <source>gptarget: curve index must be positive, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtargetextract.cpp" line="64"/>
        <source>gptarget: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtargetextract.cpp" line="87"/>
        <source>gptarget: error reading file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtargetextract.cpp" line="96"/>
        <source>gptarget: curve index out of bounds (%1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="77"/>
        <source>gptarget: mode &apos;Delete&apos; currently not supported. Request it to the developers if needed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <source>gptarget: mode not specified, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>gptarget: missing target file, see -help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
