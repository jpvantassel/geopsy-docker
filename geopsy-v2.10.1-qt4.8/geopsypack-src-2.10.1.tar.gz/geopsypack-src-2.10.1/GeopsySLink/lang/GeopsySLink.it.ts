<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>SeedLink</name>
    <message>
        <location filename="../src/SeedLink.cpp" line="118"/>
        <source>Listening to stream %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="134"/>
        <source>Stop listening to stream %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="148"/>
        <source>Active SeedLink signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="197"/>
        <source>Requesting list of streams...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="204"/>
        <source>Requesting list of stations...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="247"/>
        <source>Resolved %1:%2 into %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="291"/>
        <source>List of streams downloaded successfully: %1 stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="294"/>
        <source>Error parsing xml info received from %1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="327"/>
        <source>Error parsing packet from stream %1, no data downloaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="333"/>
        <source>Keep alive packet received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="336"/>
        <source>Received unknown packet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
