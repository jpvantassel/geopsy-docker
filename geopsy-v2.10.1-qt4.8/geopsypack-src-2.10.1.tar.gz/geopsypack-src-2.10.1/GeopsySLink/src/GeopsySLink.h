#ifndef GEOPSYSLINK_HEADERS
#define GEOPSYSLINK_HEADERS

// All headers of GeopsySLink library

#include "GeopsySLink/GeopsySLinkDLLExport.h"
#include "GeopsySLink/SeedLink.h"
#include "GeopsySLink/SeedLinkServer.h"
#include "GeopsySLink/SeedLinkStation.h"
#include "GeopsySLink/SeedLinkStream.h"

#ifndef GP_EXPLICIT_LIBRARY_NAMESPACE
using namespace GeopsySLink;
#endif

#endif // GEOPSYSLINK_HEADERS
