/***************************************************************************
**
**  This file is part of GeopsySLink.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-04-23
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QtNetwork>
#include <GeopsyCore.h>
#include <QGpCoreTools.h>
#include <slink.h>

#include "SeedLink.h"
#include "SeedLinkStation.h"

namespace GeopsySLink {

class SeedLinkPrivate
{
public:
  static QByteArray streamTag(LibSLink::MSrecord * msr);
  LibSLink::SLCD * slconn;
  LibSLink::SLpacket * slpack;
};

QByteArray SeedLinkPrivate::streamTag( LibSLink::MSrecord * msr )
{
  QByteArray tag(msr->fsdh.network,2);
  tag+="_";
  tag+=QByteArray(msr->fsdh.station,5);
  tag+=QByteArray(msr->fsdh.location,2);
  tag+=QByteArray(msr->fsdh.channel,3);
  return tag;
}

/*!
  \class SeedLink qtbseedlink.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

SeedLink * SeedLink::_instance = 0;

/*!
  Description of constructor still missing
*/
SeedLink::SeedLink( QObject * parent ) : QThread(parent)
{
  TRACE;
  _serverPort = 18000;
  _internals=new SeedLinkPrivate;
  _internals->slconn=0;
  _bufferType = SeedLinkStream::Unlimited;
  _maximumDuration = 0.0;
  if (_instance) {
    qWarning("Only one instance of Seedlink allowed!");
  } else {
    _instance = this;
  }
  _error = NoError;
  qRegisterMetaType<Error>();
}

/*!
  Description of destructor still missing
*/
SeedLink::~SeedLink()
{
  TRACE;
  if (_internals->slconn) sl_freeslcd (_internals->slconn);
  delete _internals;
  _instance = 0;
}

/*!

*/
void SeedLink::setServer( QByteArray address, qint16 port )
{
  TRACE;
  stop();
  _serverName = address.trimmed();
  _serverPort = port;
  _request = Dns;
  start();
}

void SeedLink::stop()
{
  TRACE;
  if (_internals->slconn) sl_terminate( _internals->slconn );
  wait();
  ASSERT(_internals->slconn == 0);
}

void SeedLink::streams()
{
  TRACE;
  stop();
  _request = Streams;
  _serverInfo.clear();
  _listeningStreams.clear();
  start();
}

void SeedLink::stations()
{
  TRACE;
  stop();
  _request = Stations;
  _serverInfo.clear();
  _listeningStreams.clear();
  start();
}

bool SeedLink::addStream( SeedLinkStream * str )
{
  TRACE;
  QMutexLocker m(&_mutex);
  _request = Data;
  printf("AddStream: _listeningStreams.count=%i %s\n", _listeningStreams.count(), str->tag().data());
  if (!_listeningStreams.contains(str->tag())) {
    _listeningStreams.insert(str->tag(),str);
    str->setListening(true);
    App::stream() << tr("Listening to stream %1").arg(str->tag().data()) << endl;
    return true;
  } else {
    return false;
  }
}

bool SeedLink::removeStream( SeedLinkStream * str )
{
  TRACE;
  QMutexLocker m(&_mutex);
  _request = Data;
  if (_listeningStreams.contains(str->tag())) {
    _listeningStreams.remove(str->tag());
    str->detachSignal();
    str->setListening(false);
    App::stream() << tr("Stop listening to stream %1").arg(str->tag().data()) << endl;
    return true;
  } else {
    return false;
  }
}

SubSignalPool SeedLink::subPool() const
{
  TRACE;
  SubSignalPool s;
  for( QMap<QByteArray,SeedLinkStream *>::const_iterator it = _listeningStreams.begin(); it != _listeningStreams.end();it++) {
    s.addSignal( it.value()->signal() );
  }
  s.setName(tr("Active SeedLink signals"));
  return s;
}

/*!
  Forward seedlink errors to application log system
*/
void SeedLink::log( const char * msg )
{
  TRACE;
  App::stream() << msg << endl;
  QByteArray str(msg);
  if (str.contains("DATA/FETCH/TIME command is not accepted")) {
    _instance->setError( FromTimeNotAvailable );
  }
}

void SeedLink::setError( Error e )
{
  TRACE;
  _error = e;
  for( QMap<QByteArray,SeedLinkStream *>::iterator it = _listeningStreams.begin(); it != _listeningStreams.end();it++) {
    SeedLinkStream& str = *it.value();
    str.detachSignal();
    str.setListening(false);
  }
  _listeningStreams.clear();
  sl_terminate (_internals->slconn);
  emit error( _error );
}

void SeedLink::start()
{
  TRACE;
  if (isRunning()) stop();
  LibSLink::sl_loginit (0, log, NULL, log, NULL);
  QThread::start();
}

void SeedLink::run()
{
  TRACE;
  _error = NoError;
  switch (_request) {
  case Streams:
    _xmlInfos.clear();
    _internals->slconn = LibSLink::sl_newslcd();
    sl_request_info( _internals->slconn, "STREAMS" );
    sl_setuniparams (_internals->slconn, 0, -1, 0);
    App::stream() << tr("Requesting list of streams...") << endl;
    break;
  case Stations:
    _xmlInfos.clear();
    _internals->slconn = LibSLink::sl_newslcd();
    LibSLink::sl_request_info( _internals->slconn, "STATIONS" );
    LibSLink::sl_setuniparams (_internals->slconn, 0, -1, 0);
    App::stream() << tr("Requesting list of stations...") << endl;
    break;
  case Data: {
      _internals->slconn = LibSLink::sl_newslcd();
      _mutex.lock();
      // Set fromTime to _fromTime if not all active signals are already initialized
      QDateTime fromTime;
      for( QMap<QByteArray,SeedLinkStream *>::iterator it = _listeningStreams.begin(); it != _listeningStreams.end();it++) {
        SeedLinkStream& str = *it.value();
        if ( !str.signal() ) {
          fromTime = _fromTime;
          break;
        }
      }
      QMap<SeedLinkStation *,QList<SeedLinkStream *> > newStreams;
      for( QMap<QByteArray,SeedLinkStream *>::iterator it = _listeningStreams.begin(); it != _listeningStreams.end();it++) {
        SeedLinkStream * str = it.value();
        SeedLinkStation * sta = str->station();
        QMap<SeedLinkStation *,QList<SeedLinkStream *> >::iterator its;
        its=newStreams.find(sta);
        if(its!=newStreams.end()) {
          its.value().append(str);
        } else {
          QList<SeedLinkStream *> list;
          list.append(str);
          newStreams.insert(sta, list);
        }
      }
      for( QMap<SeedLinkStation *,QList<SeedLinkStream *> >::iterator it = newStreams.begin(); it != newStreams.end();it++) {
        SeedLinkStation * sta = it.key();
        QList<SeedLinkStream *>& list=it.value();
        QString selectors;
        for(QList<SeedLinkStream *>::iterator its=list.begin();its!=list.end();its++) {
          SeedLinkStream * str = *its;
          if ( str->signal() ) {
            QDateTime endTime = str->signal()->timeReference();
            endTime = endTime.addSecs( (int) floor( str->signal()->endTime() ) );
            if (!fromTime.isValid() || endTime<fromTime) fromTime = endTime;
          }
          selectors+=" "+str->location()+str->seedName()+"."+str->type();
        }
        App::stream() << tr("Requesting streams %1_%2:%3").arg(sta->network()).arg(sta->name()).arg(selectors) << endl;
        LibSLink::sl_addstream(_internals->slconn, sta->network().toAscii().data(),
                               sta->name().toAscii().data(),
                               selectors.toAscii().data(), -1, 0);
      }
      if (fromTime.isValid()) {
        _internals->slconn->begin_time = strdup(fromTime.toString("yyyy,MM,dd,hh,mm,ss").toAscii().data());
      }
      _mutex.unlock();
    }
    break;
  case Dns: {
      // Check if serverName is a numerical address or not
      QRegExp ipExp("[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]*");
      if (ipExp.exactMatch( _serverName ) ) {
        _serverAddress = _serverName+":"+QString::number(_serverPort).toAscii();
      } else {
        QHostInfo info = QHostInfo::fromName( _serverName );
        if (info.addresses().isEmpty()) {
          return;
        }
        _serverAddress = info.addresses().first().toString().toAscii()+":"+QString::number(_serverPort).toAscii();
        App::stream() << tr("Resolved %1:%2 into %3").arg(_serverName.data()).arg(_serverPort).arg(_serverAddress.data()) << endl;
      }
    }
    return;
  }

  _internals->slconn->sladdr = (char *) malloc( _serverAddress.length()+1 );
  strcpy( _internals->slconn->sladdr, _serverAddress.data() );
  _internals->slconn->resume = 0;

  while ( sl_collect(_internals->slconn, &_internals->slpack) != 0 ) {
    //App::stream() << tr("collect packet") << endl;
    packetReceived();
  }
  /* Make sure everything is shut down*/
  if (_internals->slconn->link != -1) sl_disconnect (_internals->slconn);
  sl_freeslcd (_internals->slconn);
  _internals->slconn = 0;
}

void SeedLink::packetReceived()
{
  TRACE;
  int ptype  = sl_packettype (_internals->slpack);
  static LibSLink::MSrecord * msr = NULL;
  switch(ptype) {
  case SLINF:
  case SLINFT:
    LibSLink::sl_msr_parse (_internals->slconn->log, _internals->slpack->msrecord, &msr, 0, 0);
    if ( strncmp(msr->fsdh.channel, "ERR", 3)==0 ) {
      switch (_request ) {
      case Streams:
        setError( StreamsNotAvailable );
        break;
      case Stations:
        setError( StationsNotAvailable );
      default:
        break;
      }
    }
    _xmlInfos+=QByteArray((char *) msr->msrecord + msr->fsdh.begin_data, msr->fsdh.num_samples);
    if (ptype == SLINFT) {
      XMLHeader hdr(&_serverInfo);
      if ( hdr.xml_restoreString(_xmlInfos)==XMLClass::NoError ) {
        App::stream() << tr("List of streams downloaded successfully: %1 stations").arg(_serverInfo.count()) << endl;
        emit infoAvailable();
      } else {
        App::stream() << tr("Error parsing xml info received from %1:").arg(_serverAddress.data()) << endl;
        App::stream() << _xmlInfos << endl;
      }
    }
    break;
  case SLDATA: {
      if ( sl_msr_parse(_internals->slconn->log, _internals->slpack->msrecord, &msr, 1, 1) ) {
        QByteArray tag = SeedLinkPrivate::streamTag(msr); // msr structure is populated by sl_msr_parse
        QMap<QByteArray,SeedLinkStream *>::iterator it = _listeningStreams.find(tag);
        if ( it!=_listeningStreams.end() ) {
          SeedLinkStream * str = it.value();
          if ( str && str->listening() ) {
            double t = LibSLink::sl_msr_depochstime(msr);
            /*App::stream() << tr("Received packet %1 from %2 to %3 for stream %4")
                         .arg(sl_sequence (slpack))
                         .arg(t,0,'f',4)
                         .arg(t+(double)msr->numsamples/(double)sl_msr_dnomsamprate(msr),0,'f',4)
                         .arg(tag.data()) << endl;*/
            double t0Packet;
            if (!str->signal()) {
              str->initSignal(t, LibSLink::sl_msr_dnomsamprate(msr));
              t0Packet = str->signal()->t0();
            } else {
              t0Packet = str->localTime( t );
            }
            //App::stream() << tr("  Time of packet = %1").arg( t0Packet ) << endl;
            str->set( t0Packet, msr->datasamples, msr->numsamples, _bufferType, _maximumDuration );
            emit dataChanged( str->signal(),
                              TimeRange( t0Packet, t0Packet+msr->numsamples*str->signal()->deltaT() ) );
          }
        }
      } else {
        // msr structure might be partially initialized in case of error, we display what we can.
        App::stream() << tr("Error parsing packet from stream %1, no data downloaded.")
                  .arg(SeedLinkPrivate::streamTag(msr).data()) << endl;
      }
    }
    break;
  case SLKEEP:
    App::stream() << tr("Keep alive packet received") << endl;
    break;
  default:
    App::stream() << tr("Received unknown packet") << endl;
    break;
  }
}

} // namespace GeopsySLink
