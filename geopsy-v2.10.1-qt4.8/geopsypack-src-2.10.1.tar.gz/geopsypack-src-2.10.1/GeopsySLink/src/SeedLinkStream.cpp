/***************************************************************************
**
**  This file is part of GeopsySLink.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-04-24
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyCore.h>
#include "SeedLinkStream.h"
#include "SeedLinkStation.h"

namespace GeopsySLink {

/*!
  \class SeedLinkStream qtbseedlinkstream.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

const QString SeedLinkStream::xmlSeedLinkStreamTag = "stream";

SeedLinkStream::SeedLinkStream( SeedLinkStation * station )
{
  TRACE;
  _station = station;
  _location="00";
  _signal = 0;
  _listening = false;
}

void SeedLinkStream::xml_attributes(XML_ATTRIBUTES_ARGS) const
{
  TRACE;
  Q_UNUSED(context);
  static const QString keys[]={ "location", "seedname", "type", "begin_time", "end_time", "begin_recno", "end_recno", "gap_check", "gap_threshold" };
  attributes.add( keys[0], _location );
  attributes.add( keys[1], _seedName );
  attributes.add( keys[2], _type );
  attributes.add( keys[3], _beginTime );
  attributes.add( keys[4], _endTime );
  attributes.add( keys[5], QString::number( _beginRecNo ) );
  attributes.add( keys[6], QString::number( _endRecNo ) );
  attributes.add( keys[7], _gapCheck ? "enabled" : "disabled" );
  attributes.add( keys[8], QString::number( _gapThreshold ) );
}

bool SeedLinkStream::xml_setAttributes( XML_SETATTRIBUTES_ARGS )
{
  TRACE;
  Q_UNUSED(context);
  for (XMLRestoreAttributeIterator it = attributes.begin(); it!= attributes.end(); it++ ) {
    const StringSection& att = it.key();
    if (att.size()<1) return false;
    switch ( att[0].unicode() ) {
    case 'l':
      if ( att == "location" ) _location = it.value().toString(); else return false;
      break;
    case 's':
      if ( att == "seedname" ) _seedName = it.value().toString(); else return false;
      break;
    case 't':
      if ( att == "type" ) _type = it.value().toString(); else return false;
      break;
    case 'b':
      if ( att == "begin_time" ) _beginTime = it.value().toString();
      else if ( att == "begin_recno" ) _beginRecNo = it.value().toInt(); else return false;
      break;
    case 'e':
      if ( att == "end_time" ) _endTime = it.value().toString();
      else if ( att == "end_recno" ) _endRecNo = it.value().toInt(); else return false;
      break;
    case 'g':
      if ( att == "gap_check" ) _gapCheck = it.value() == "enabled";
      else if ( att == "gap_treshold" ) _gapThreshold = it.value().toInt(); else return false;
      break;
    default:
      return false;
    }
  }
  setTag();
  return true;
}

void SeedLinkStream::setTag()
{
  TRACE;
  _tag=_station->network().left(2).toAscii();
  _tag+="_";
  _tag+=_station->name().leftJustified(5,' ',true).toAscii();
  _tag+=_location.left(2).leftJustified(2,' ',true).toAscii();
  _tag+=_seedName.left(3).leftJustified(3,' ',true).toAscii();
}

/*!
  Transform \a t expressed in seconds from January 1970 into number of seconds since time reference
  of internal dynamic signal.
*/
double SeedLinkStream::localTime( double t ) const
{
  TRACE;
  uint sec = (uint) floor( t );
  double msec = t - (double) sec;
  QDateTime tPacket;
  tPacket.setTime_t(sec);

  QDateTime tRef = _signal->timeReference();
  return tRef.secsTo(tPacket)+msec;
}

/*!
  Initialize internal signal starting at \a t (expressed in seconds from January 1970).
*/
void SeedLinkStream::initSignal( double t, double samplingFrequency )
{
  TRACE;
  uint sec = (uint) floor( t );
  double msec = t - (double) sec;
  QDateTime tPacket;
  tPacket.setTimeSpec( Qt::UTC );
  tPacket.setTime_t(sec);  // 

  QDateTime tRef = tPacket;
  tRef.setTime( QTime( 0, 0 ) ); // Set reference at midnight

  createSignal();
  _signal->setDeltaT( 1.0/samplingFrequency );
  _signal->setT0( tRef.secsTo(tPacket)+msec );
  _signal->setTimeReference( tRef );
}

void SeedLinkStream::createSignal()
{
  TRACE;
  _signal = new DynamicSignal( geopsyCore->currentDB() );
  _signal->setName( _station->network() + "_" + _station->name() );
  if ( seedName().endsWith( "Z" ) )
    _signal->setComponent( Signal::Vertical );
  else if ( seedName().endsWith( "E" ) )
    _signal->setComponent( Signal::East );
  else if ( seedName().endsWith( "N" ) )
    _signal->setComponent( Signal::North );
  else
    _signal->setComponent( Signal::UndefinedComponent );
  _signal->setType(Signal::Waveform);
  _signal->setHeaderModified( true );
  _signal->setReadOnlySamples(true);
}

/*!
  \a t is the number of seconds counted from time reference.
*/
void SeedLinkStream::set( double t, int * samples, int nSamples, BufferType bt, double maxTime )
{
  TRACE;
  switch (bt) {
  case Unlimited:
    _signal->set( t, samples, nSamples );
    break;
  case CreateNew: {
      if (maxTime==0.0) return;
      double availableTime = maxTime - ( t - _signal->t0() );
      if ( ( nSamples*_signal->deltaT() ) > availableTime ) {
        int nSamplesOld = (int) floor ( availableTime / _signal->deltaT() );
        _signal->set( t, samples, nSamplesOld );
        DynamicSignal * oldSignal = _signal;
        createSignal();
        _signal->setT0( oldSignal->endTime() );
        _signal->setDeltaT( oldSignal->deltaT() );
        _signal->setTimeReference( oldSignal->timeReference() );
        _signal->set( _signal->t0(), samples+nSamplesOld, nSamples-nSamplesOld );
      } else {
        _signal->set( t, samples, nSamples );
      }
    }
    break;
  case Rotate: {
      if (maxTime==0.0) return;
      double availableTime = maxTime - ( t - _signal->t0() );
      if ( ( nSamples*_signal->deltaT() ) > availableTime ) {
        int n = nSamples - (int) floor ( availableTime / _signal->deltaT() );
        _signal->shiftT0( n );
      }
      _signal->set( t, samples, nSamples );
    }
    break;
  }
}

} // namespace GeopsySLink
