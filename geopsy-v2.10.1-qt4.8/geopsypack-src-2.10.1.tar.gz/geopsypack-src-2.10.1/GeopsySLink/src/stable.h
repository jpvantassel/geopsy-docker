#if defined __cplusplus
#include <QtCore>
#include <QtNetwork>
#ifndef Q_WS_MAC
#include <QGpCoreTools.h>
#include <GeopsyCore.h>
#include <slink.h>
#endif // Q_WS_MAC
#endif // __cplusplus
