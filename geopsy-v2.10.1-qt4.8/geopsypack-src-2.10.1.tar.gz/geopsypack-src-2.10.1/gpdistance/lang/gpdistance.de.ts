<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="54"/>
        <source>gpdistance: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <source>gpdistance: missing coordinate file (option -c).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="72"/>
        <source>gpdistance: cannot read file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>gpdistance: error reading file %1 at line %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>gpdistance: error reading station_name_1 station_name_2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <location filename="../src/main.cpp" line="119"/>
        <source>gpdistance: unknown station name: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
