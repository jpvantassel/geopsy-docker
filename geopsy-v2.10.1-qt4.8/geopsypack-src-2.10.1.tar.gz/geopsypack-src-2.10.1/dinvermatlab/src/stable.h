#if defined __cplusplus
#include <QtGui>
#ifndef Q_WS_MAC
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include <DinverCore.h>
#include <DinverGui.h>
#endif // Q_WS_MAC
#endif // __cplusplus
