/***************************************************************************
**
**  This file is part of dinvermatlab.
**
**  This file is distributed under the terms of the Geopsy.org Commercial
**  License appearing in the file LICENSE.COMMERCIAL included in the packaging
**  of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See Geopsy.org Commercial License for
**  more details.
**
**  You should have received a copy of the Geopsy.org Commercial License
**  along with this program. If not, see <http://www.geopsy.org>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-11-23
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef MATLABTARGETWIDGET_H
#define MATLABTARGETWIDGET_H

#include <QWidget>

#include "ui_MatlabTargetWidget.h"

class MatlabTarget;

class MatlabTargetWidget : public QWidget, public Ui::MatlabTargetWidget
{
  Q_OBJECT
public:
  MatlabTargetWidget( QWidget * parent=0 );
  ~MatlabTargetWidget();

  MatlabTarget * target();
  void setFrom(MatlabTarget * target);

  void setEditable( bool e );
};

#endif // MATLABTARGETWIDGET_H
