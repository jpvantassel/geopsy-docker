<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbForward</name>
    <message>
        <source>Empty target, skipping matlab testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initialize Matlab engine...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matlab engine not available, check your configuration.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbMatlabPlugin</name>
    <message>
        <source>Matlab forward computation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;With this plugin you can build your own parameterization&lt;br/&gt;within the graphical interface and use a Matlab script&lt;br/&gt;to calculate the misfit function.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error building parameter space, see above messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error setting target, see above messages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbMatlabTarget</name>
    <message>
        <source>Testing scripts ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error starting Matlab engine.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error adding path &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error running initialization script &apos;%1&apos; in Matlab environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error setting variable dinverModel in Matlab environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error setting variable dinverOk in Matlab environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error running forward script &apos;%1&apos; in Matlab environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error retreiving variable &apos;dinverMisfit&apos; from Matlab environment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error variable &apos;dinverMisfit&apos; is not a scalar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matlab engine not available, check your configuration.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbMatlabTargetWidget</name>
    <message>
        <source>Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matlab startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To run it on another host enter hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>matlab -nosplash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Script path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Init script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dinverInit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dinverForward</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
