/***************************************************************************
**
**  This file is part of gpell.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2006-09-03
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include <QGpCoreWave.h>

#include "EllipticityReader.h"
#include "gpellVersion.h"
#include "gpellInstallPath.h"

PACKAGE_INFO( gpell, GPELL );

ApplicationHelp * help();

int main( int argc, char ** argv )
{
  CoreApplication a( argc, argv, help );
  // stdout is used for output of results, redirect main application log to stderr
  a.setStream(new StandardStream(stderr));

  // Options
  EllipticityReader reader;
  if ( reader.setOptions( argc, argv ) && reader.read( argc, argv ) ) {
    return 0;
  } else {
    return 2;
  }
}

ApplicationHelp * help()
{
  ApplicationHelp * h = new ApplicationHelp;
  h->setOptionSummary( "[OPTIONS] [FILE]" );
  h->setComments( "Compute ellipticity curve for layered models given through stdin or FILE.\n\n"
                 "Format for layered models:\n"
                 + LayeredModel::formatHelp() +
                 "\n\n"
                 "Quality factors are not mandatory. If not specified, pure elastic computation is performed. Any number of models "
                 "can be given as input.");
  h->addGroup("Gpell","gpell");
  h->addOption("-n <count>","Number of samples (default=100)");
  h->addOption("-R <n modes>","Number of Rayleigh modes (default=1)");
  h->addOption("-one-mode","Instead of outputting all modes (see option '-R'), output only the highest one.");
  h->addOption("-signed","Outputs signed ellipticities (default=absolute value)");
  h->addOption("-s <sampling>","Defines the sampling type:\n"
                              "  period     regular sampling in period\n"
                              "  frequency  regular sampling in frequency\n"
                              "  log        regular sampling in log(frequency) (default)");
  h->addOption("-min <min>","Minimum of range for ellipticity curve (default=0.2)");
  h->addOption("-max <max>","Maximum of range for ellipticity curve (default=20)");
  h->addOption("-n <count>","Number of samples (default=100)");
  h->addOption("-p","Output frequency peaks only");
  h->addOption("-c","Output curves only");
  h->addOption("-pc","Output curves only with peak refinements");
  h->addExample("gpell < test.model", "Calculate fundamental ellipticity curve from 0.2 Hz to 20 Hz for model 'test.model'.");
  h->addExample("gpell < test.model | figue -c", "Calculate the same ellipticity curve and plot it.");
  h->addExample("gpell < test.model | figue -c -m ell.mkup", "Show the same ellipticity curve on a log-log plot. 'ell.mkup' is a tar.gz file containing an xml description of the graphic format, it can be generated from figue's interface.");
  return h;
}
