#ifndef GPELL_VERSION
#define GPELL_VERSION "0.3.0"
#define GPELL_VERSION_TIME "201212060929"
#define GPELL_VERSION_TYPE "testing"
#define GPELL_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)"
#endif // GPELL_VERSION
