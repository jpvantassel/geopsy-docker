/***************************************************************************
**
**  This file is part of gpell.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-15
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include <QGpCoreWave.h>
#include "EllipticityReader.h"

/*!
  \class EllipticityReader qtbellipticityreader.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
EllipticityReader::EllipticityReader()
    : ArgumentStdinReader()
{
  TRACE;
  _nRayleigh = 1;
  _samplingType = LogScale;
  _nSamples = 100;
  _minRange = 0.2;
  _maxRange = 20.0;
  _outputCurves = true;
  _calculatePeaks = false;
  _signed=false;
  _oneMode=false;
}

bool EllipticityReader::setOptions( int& argc, char ** argv )
{
  TRACE;
  // Check arguments
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-R") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _nRayleigh = atoi(argv[i]);
      } else if (arg=="-one-mode") {
        _oneMode=true;
      } else if (arg=="-signed") {
        _signed=true;
      } else if (arg=="-s") {
        CoreApplication::checkOptionArg(i, argc, argv);
        if (strcmp(argv[i],"period")==0) {
          _samplingType = InversedScale;
        } else if (strcmp(argv[i],"frequency")==0) {
          _samplingType = LinearScale;
        } else {
          _samplingType = LogScale;
        }
      } else if (arg=="-min") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _minRange = atof(argv[i]);
      } else if (arg=="-max") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _maxRange = atof(argv[i]);
      } else if (arg=="-n") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _nSamples = atoi(argv[i]);
        if (_nSamples<=0) {
          App::stream() << tr("gpell: negative or null number of samples (option -n)") << endl;
          return false;
        }
      } else if (arg=="-p") {
        _calculatePeaks = true;
        _outputCurves = false;
      } else if (arg=="-c") {
        _calculatePeaks = false;
        _outputCurves = true;
      } else if (arg=="-pc") {
        _calculatePeaks = true;
        _outputCurves = true;
      } else {
        App::stream() << tr("gpell: bad option %1, see -help").arg(argv[i]) << endl;
        return false;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  // Compute common sampling scale
  Curve<Point1D> c;
  c.line( _minRange, 0.0, _maxRange, 0.0 );
  c.resample( _nSamples, _minRange, _maxRange, _samplingType | Function );
  c.xMultiply( 2*M_PI ); // convert to angular frequency
  _x = c.xVector();
  return true;
}

bool EllipticityReader::parse( QTextStream& s )
{
  TRACE;
  QTextStream sOut(stdout);
  LayeredModel m;
  QString comments;
  if (!m.fromStream(s, &comments)) {
    return false;
  }
  if(m.layerCount()>0) {
    if (_nRayleigh>0) {
      Rayleigh rayleigh( &m );
      Dispersion dispersion (_nRayleigh, &_x);
      dispersion.setPrecision(1e-12); // Highest precision with double
      Ellipticity ell(_nRayleigh, &_x);
      // TODO: take errors into consideration
      dispersion.calculate(&rayleigh, &ell);
      QList<double> peaks[_nRayleigh];
      if (_calculatePeaks) {
        for (int im=0; im<_nRayleigh; im++) {
          peaks[im]=ell.peaks (im, dispersion, &rayleigh);
        }
      }
      if(!_signed) {
        ell.abs();
      }
      sOut << comments;
      if (_outputCurves) {
        sOut << QString("# %1 Rayleigh ellipticity mode(s)\n").arg(_nRayleigh);
        ell.toStream(sOut, _oneMode ? _nRayleigh-1 : -1);
      } else {
        for ( int im = 0; im < _nRayleigh; im++ ) {
          sOut << "# Mode " << im << "\n";
          for ( int ip = 0; ip < peaks[im].count(); ip++ ) {
            sOut << peaks[im][ip] << "\n";
          }
        }
      }
    }
  }
  return true;
}
