<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbEllipticityReader</name>
    <message>
        <location filename="../src/qtbellipticityreader.cpp" line="83"/>
        <source>gpell: negative or null number of samples (option -n)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbellipticityreader.cpp" line="96"/>
        <source>gpell: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
