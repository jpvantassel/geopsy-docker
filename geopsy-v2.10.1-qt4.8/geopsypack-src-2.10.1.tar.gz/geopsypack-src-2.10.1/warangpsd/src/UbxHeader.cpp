/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-26
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <stdio.h>

#include "UbxHeader.h"
#include "UbxChecksum.h"

/*!
  \class UbxHeader qtbubxheader.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

char UbxHeader::_syncHex[5];

const char * UbxHeader::syncChars() const
{
  sprintf(_syncHex,"%02hhX%02hhX", _syncChar1, _syncChar2);
  return _syncHex;
}

void UbxHeader::print() const
{
  printf("%4s %02hhX %02hhX %hu\n", syncChars(), _class, _id, length());
}

bool UbxHeader::checksum(const UbxChecksum& cksum, const char * payload) const
{
  unsigned char a=0, b=0;
  a+=_class;
  b+=a;
  a+=_id;
  b+=a;
  a+=_length.bytes[0];
  b+=a;
  a+=_length.bytes[1];
  b+=a;
  if(payload) {
    for(int i=0;i<length();i++) {
      a+=payload[i];
      b+=a;
    }
  }
  if(a!=cksum.a()) {
    //printf("--- ck_A not correct: %02hhX instead of %02hhX\n",a,cksum.a());
    return false;
  }
  if(b!=cksum.b()) {
    //printf("--- ck_B not correct: %02hhX instead of %02hhX\n",b,cksum.b());
    return false;
  }
  return true;
}
