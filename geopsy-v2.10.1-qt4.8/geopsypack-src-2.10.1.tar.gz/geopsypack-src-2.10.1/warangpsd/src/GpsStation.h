/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-09-10
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef GPSSTATION_H
#define GPSSTATION_H

#include <GpCoreTools.h>
#include <WaranCore.h>

class GpsStation
{
public:
  GpsStation();
  ~GpsStation();

  const Address& address() const {return _address;}
  void setAddress(const Address& a) {_address=a;}

  uint16_t port() const { return _port; }
  void setPort( uint16_t p ) { _port = p; }

  int fixCount() const {return _fixCount;}
  const std::string& info() const {return _info;}
  const Statistics& longitude() const {return _longitude;}
  const Statistics& latitude() const {return _latitude;}
  const Statistics& altitude() const {return _altitude;}
  double horizontalAccuracy() const {return _fix.horizontalAccuracy()*1e-3;}
  double horizontalDop() const {return _fix.horizontalDop()*1e-2;}
  double northingDop() const {return _fix.northingDop()*1e-2;}
  double eastingDop() const {return _fix.eastingDop()*1e-2;}
  int sateliteCount() const {return _fix.sateliteCount();}

  bool isAvailable();

  void startBroadcast();
  void stopBroadcast();
  void powerOn();
  void powerOff();
  void requestInfo();

  enum Mode {Off, Track, Stack};
  void setMode(Mode m);
  Mode mode() const {return _mode;}
private:
  int parseFix(const char * data, int bytesAvailable);
  int parseInfo(const char * data, int bytesAvailable);

  Address _address;
  uint16_t _port;

  Mode _mode;
  int _fixCount;
  Statistics _longitude;
  Statistics _latitude;
  Statistics _altitude;
  GpsFix _fix;
  std::string _info;
};

#endif // GPSSTATION_H
