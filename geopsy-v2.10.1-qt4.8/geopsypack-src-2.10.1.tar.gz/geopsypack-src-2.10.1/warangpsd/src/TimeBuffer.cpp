/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2010-04-08
**  Authors:
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <signal.h>

#include "TimeBuffer.h"
#include "TimeStream.h"

/*!
  \class TimeBuffer TimeBuffer.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

double TimeBuffer::_lastDelay=1e99;
double TimeBuffer::_adjustCount=0;

/*!
  Description of constructor still missing
*/
TimeBuffer::TimeBuffer(int fileDescriptor, TimeStream * stream)
    : DynamicBuffer(fileDescriptor)
{
  _stream=stream;
}

/*!
  Description of destructor still missing
*/
TimeBuffer::~TimeBuffer()
{
}

/*!
  Communication protocol:

  't' is sent to all neighbors, they reply by their current time whit this format

  sizeof(timeval)       peer time
  sizeof(timeval)       send time
*/
int TimeBuffer::bytesAvailable(const char * buffer, int byteCount)
{
  TRACE;
  if(byteCount<(int)(4+2*sizeof(timeval))) {
    return 0;
  }
  while(strncmp(buffer, "WAUT", 4)!=0) {
    Log::write(2, "bad data block\n");
    buffer++;
    byteCount--;
    if(byteCount<(int)(4+2*sizeof(timeval))) {
      return 0;
    }
  }
  const timeval& sendTime=*reinterpret_cast<const timeval *>(buffer+4);
  const timeval& peerTime=*reinterpret_cast<const timeval *>(buffer+4+sizeof(timeval));
  // Get time delay of response, assume that transfer time is symetric
  timeval sysTime;
  gettimeofday(&sysTime, 0);
  timeval deltaTime;
  deltaTime.tv_sec=sysTime.tv_sec-sendTime.tv_sec;
  deltaTime.tv_usec=sysTime.tv_usec-sendTime.tv_usec;
  double dt=deltaTime.tv_sec;
  dt+=deltaTime.tv_usec*1e-6;
  dt*=0.5;
  // Correct peer time
  double dtsec=floor(dt);
  timeval realTime=peerTime;
  realTime.tv_sec+=(int)dtsec;
  realTime.tv_usec+=(int)((dt-dtsec)*1e6);
  if(realTime.tv_usec>=1000000) {
    realTime.tv_sec++;
    realTime.tv_usec-=1000000;
  }
  if(dt<_lastDelay) {
    Log::write(0, "set time to %li.%06li (from %s)\n", realTime.tv_sec, realTime.tv_usec,
               _stream->peer().toString().data());
    if(settimeofday(&realTime, 0)!=0) {
      Log::write(0, "set time: %s\n", strerror(errno));
      _lastDelay=dt;
    } else {
      Log::write(0, "time set to %li.%06li\n", realTime.tv_sec, realTime.tv_usec);
    }
  } else {
    deltaTime.tv_sec=sysTime.tv_sec-sendTime.tv_sec;
    deltaTime.tv_usec=sysTime.tv_usec-sendTime.tv_usec;
    dt=deltaTime.tv_sec;
    dt+=deltaTime.tv_usec*1e-6;
    Log::write(0, "received time %li.%06li (delay=%lf s) from %s\n", realTime.tv_sec, realTime.tv_usec, dt,
               _stream->peer().toString().data());
  }
  _adjustCount++;
  if(_adjustCount>10) {
    // Send "signal" to other process that internal clock is locked on PEERS
    FILE * f=fopen("/tmp/system_clock_set", "wb");
    if(f) {
      fwrite("PEERS", 1, 5, f);
      fclose(f);
    }
    Log::write(0, "system time set from peers\n");
    EventLoop::instance()->terminate();
  }
  _stream->close();
  return 2*sizeof(timeval);
}
