/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-09-10
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "MasterBuffer.h"

/*!
  \class MasterBuffer MasterBuffer.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
MasterBuffer::MasterBuffer(int fd, std::list<GpsStation *> * stations)
    : DynamicBuffer(fd)
{
  TRACE;
  _station=0;
  _stations=stations;
}

MasterBuffer::MasterBuffer(int fd, GpsStation * station)
    : DynamicBuffer(fd)
{
  TRACE;
  _station=station;
  _stations=0;
}

/*!
*/
int MasterBuffer::bytesAvailable(const char * buffer, int byteCount)
{
  TRACE;
  /*if(byteCount>0) {
    switch(buffer[0]) {
    case 'S':
      _device->stack();
      break;
    case 'T':
      _device->track();
      break;
    case 'P':
      _device->powerUp();
      break;
    case 'p':
      _device->powerDown();
      break;
    case 'B':
      _device->startBroadcast();
      break;
    case 'b':
      _device->stopBroadcast();
      break;
    case 'i':
      info();
      break;
    default:
      break;
    }
    int i;
    // Skip spaces, CR, LF (produced by telnet)
    for(i=1; i<byteCount && isspace(buffer[i]); i++) {}
    return i;
  } else {
   return 0;
  }*/
}
