/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-09-10
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef MASTERBUFFER_H
#define MASTERBUFFER_H

#include <GpCoreTools.h>

class GpsStation;

class MasterBuffer : public DynamicBuffer
{
public:
  MasterBuffer(int fd, std::list<GpsStation *> * stations);
  MasterBuffer(int fd, GpsStation * station);
protected:
  virtual int bytesAvailable(const char * buffer, int byteCount);
private:
  GpsStation * _station;
  std::list<GpsStation *> * _stations;
};

#endif // MASTERBUFFER_H
