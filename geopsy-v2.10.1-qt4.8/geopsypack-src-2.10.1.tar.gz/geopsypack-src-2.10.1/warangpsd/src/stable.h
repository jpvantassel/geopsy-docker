#if defined __cplusplus
#ifndef Q_WS_MAC
#include <GpCoreTools.h>
#include <WaranCore.h>
#endif // Q_WS_MAC
#endif // __cplusplus
