/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2010-04-08
**  Authors:
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef TIMESTREAM_H
#define TIMESTREAM_H

#include <GpCoreTools.h>

#include "TimeBuffer.h"

class TimeStream : public TcpClientStream
{
public:
  TimeStream(int fileDescriptor, const Address& peer);

  TimeBuffer * buffer() const {return static_cast<TimeBuffer *>(TcpClientStream::buffer());}
private:
  timeval _sendTime;
};

#endif // TIMESTREAM_H
