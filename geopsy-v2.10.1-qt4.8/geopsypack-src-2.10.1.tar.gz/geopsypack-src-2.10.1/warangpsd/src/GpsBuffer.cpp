/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-27
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GpCoreTools.h>
#include <WaranCore.h>
#include "GpsBuffer.h"
#include "UbxDevice.h"

/*!
  \class GpsBuffer qtbgpsserverbuffer.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
GpsBuffer::GpsBuffer(int fileDescriptor, UbxDevice * device)
    : DynamicBuffer(fileDescriptor)
{
  TRACE;
  _device=device;
}

/*!
  Description of destructor still missing
*/
GpsBuffer::~GpsBuffer()
{
  TRACE;
  _device->stopBroadcast();
}

/*!
  Communication protocol:

  1 byte command:
    'B'         Start broadcast
    'b'         Stop broadcast
    'r'         Reset, starts new fix and raw files
    'i'         Returns information
*/
int GpsBuffer::bytesAvailable(const char * buffer, int byteCount)
{
  TRACE;
  if(byteCount>0) {
    switch(buffer[0]) {
    case 'B':
      _device->startBroadcast();
      break;
    case 'b':
      _device->stopBroadcast();
      break;
    case 'r':
      _device->resetFiles();
      break;
    case 'i':
      info();
      break;
      break;
    default:
      break;
    }
    int i;
    // Skip spaces, CR, LF (produced by telnet)
    for(i=1; i<byteCount && isspace(buffer[i]); i++) {}
    return i;
  } else {
   return 0;
  }
}

void GpsBuffer::info()
{
  TRACE;
  std::string str=_device->info();
  TcpHeader hb(GPSBLOCK_VERSION, 2);
  send((const char *)&hb, sizeof(TcpHeader));
  int l=str.length();
  send((const char *)&l, 4);
  send(str.data(), l);
}

