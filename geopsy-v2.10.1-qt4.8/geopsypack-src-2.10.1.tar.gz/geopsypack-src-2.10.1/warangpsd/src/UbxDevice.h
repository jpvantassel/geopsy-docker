/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-26
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef UBXDEVICE_H
#define UBXDEVICE_H

#include <GpCoreTools.h>
#include <WaranCore.h>

#include "NavigationTimer.h"
#include "UbxHeader.h"
#include "UbxChecksum.h"

class GpsServer;

class UbxDevice : public PThread
{
public:
  enum Mode {Off=0, Track=1, Stack=2};

  UbxDevice(const std::string& stationName, const std::string& basePath,
            const std::string& devicePath, GpsServer * server);
  ~UbxDevice();

  void startBroadcast();
  void stopBroadcast();
  void resetFiles();
  void requestNavigation();
  std::string info();
  void setTimeLocked();
  bool timeLocked();

  FILE * lockFixStream() {pthread_mutex_lock(&_fixStreamMutex); return _fixStream; }
  void unlockFixStream() {pthread_mutex_unlock(&_fixStreamMutex);}
  FILE * lockRawStream() {pthread_mutex_lock(&_rawStreamMutex); return _rawStream; }
  void unlockRawStream() {pthread_mutex_unlock(&_rawStreamMutex);}
private:
  void connect();
  const char * timeStamp(char * buffer32);
  bool openFixFile();
  void closeFixFile();
  bool openRawFile();
  void closeRawFile();
  virtual void run();
  int lockSerial() {return pthread_mutex_lock(&_serialMutex);}
  int unlockSerial() {return pthread_mutex_unlock(&_serialMutex);}

  std::string _serialPath;
  std::string _basePath;
  std::string _stationName;
  pthread_mutex_t _fixStreamMutex;
  pthread_mutex_t _rawStreamMutex;
  std::string _fixFileName;
  std::string _rawFileName;
  FILE * _rawStream;
  FILE * _fixStream;
  pthread_mutex_t _serialMutex;
  Serial * _serial;
  GpsServer * _server;
  NavigationTimer _navigationTimer;
  pthread_mutex_t _timeLockedMutex;
  bool _timeLocked;
};

#endif // UBXDEVICE_H
