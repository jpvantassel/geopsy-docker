/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-26
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef UBXHEADER_H
#define UBXHEADER_H

class UbxChecksum;

class UbxHeader
{
public:
  UbxHeader() {_syncChar1=0;}

  bool isValid() const {return _syncChar1==0xB5 && _syncChar2==0x62;}
  const char * syncChars() const;
  unsigned char ubxClass() const {return _class;}
  unsigned char ubxId() const {return _id;}
  unsigned short length() const {return _length.value;}
  void print() const;
  bool checksum(const UbxChecksum& cksum, const char * payload=0) const;
private:
  static char _syncHex[5];
  unsigned char _syncChar1;
  unsigned char _syncChar2;
  unsigned char _class;
  unsigned char _id;
  union {
    unsigned short value;
    unsigned char bytes[2];
  } _length;
};

#endif // UBXHEADER_H
