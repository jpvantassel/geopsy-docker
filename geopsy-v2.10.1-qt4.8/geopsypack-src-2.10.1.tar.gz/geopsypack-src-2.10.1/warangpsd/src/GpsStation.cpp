/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-09-10
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "GpsStation.h"

/*!
  \class GpsStation GpsStation.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
GpsStation::GpsStation()
{
  TRACE;
  _mode=Off;
  _fix.reset();
  _fixCount=0;
  _longitude.reset();
  _latitude.reset();
  _altitude.reset();
  //connect(&_socket, SIGNAL(readyRead()), this, SLOT(bytesAvailable()));
  //connect(&_socket, SIGNAL(connected()), this, SLOT(justConnected()));
  //connect(&_socket, SIGNAL(disconnected()), this, SIGNAL(modeChanged()));
}

/*!
  Description of destructor still missing
*/
GpsStation::~GpsStation()
{
  TRACE;
}
