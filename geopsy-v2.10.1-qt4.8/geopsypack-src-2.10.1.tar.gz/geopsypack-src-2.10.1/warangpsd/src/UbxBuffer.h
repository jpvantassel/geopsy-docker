/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-28
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef UBXBUFFER_H
#define UBXBUFFER_H

#include <GpCoreTools.h>
#include <WaranCore.h>

class UbxHeader;
class GpsServer;
class UbxDevice;

class UbxBuffer : public DynamicBuffer
{
public:
  UbxBuffer(int fd, GpsServer * server, UbxDevice * device);
  ~UbxBuffer();

  void setBroadcast(bool b);
  bool isBroadcast() const {return _broadcast;}
protected:
  virtual int bytesAvailable(const char * buffer, int byteCount);
private:
  void read(const UbxHeader& hdr, const char * payload);
  void broadcast();
  void saveRaw(const UbxHeader& hdr, const char * payload);
  void saveFix();

  void readNavPosLLH(const char * payload);
  void readNavStatus(const char * payload);
  void readNavDop(const char * payload);
  void readNavSvInfo(const char * payload);
  void readNavTimeUTC(const char * payload);

  volatile bool _broadcast;
  unsigned char _index;
  GpsFix * _oldFix;
  GpsFix * _newFix;
  GpsServer * _server;
  UbxDevice * _device;

  unsigned int _nextAdjustTime;
  std::vector<double> _deltaTimes;
};


#endif // UBXBUFFER_H
