/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-26
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <assert.h>
#include <string.h>

#include "UbxDevice.h"
#include "GpsServer.h"
#include "UbxBuffer.h"

/*!
  \class UbxDevice qtbubxdevice.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
UbxDevice::UbxDevice(const std::string& stationName, const std::string& basePath,
                     const std::string& devicePath, GpsServer * server)
  : _navigationTimer(this, 60000) // Request ephemeridis after one minute
{
  _stationName=stationName;
  _basePath=basePath;
  _serialPath=devicePath;
  _serial=0;
  _server=server;
  _server->setDevice(this);
  _rawStream=0;
  _fixStream=0;
  assert(pthread_mutex_init(&_fixStreamMutex, 0)==0);
  assert(pthread_mutex_init(&_rawStreamMutex, 0)==0);
  assert(pthread_mutex_init(&_serialMutex, 0)==0);
  assert(pthread_mutex_init(&_timeLockedMutex, 0)==0);
  _timeLocked=false;
}

/*!
  Description of destructor still missing
*/
UbxDevice::~UbxDevice()
{
  if(_serial) {
    delete _serial;
  } else {
    closeFixFile();
    closeRawFile();
  }
}

const char * UbxDevice::timeStamp(char * buffer32)
{
  time_t t=time(0);
  strftime(buffer32, 32, "%Y%m%d-%H%M%S", gmtime(&t));
  return buffer32;
}

bool UbxDevice::openFixFile()
{
  char timeBuf[32];
  std::string _fixFileName=_basePath;
  _fixFileName+=_stationName;
  _fixFileName+="-fix-";
  _fixFileName+=timeStamp(timeBuf);
  _fixFileName+=".txt";
  _fixStream=fopen(_fixFileName.data(), "wt");
  if(!_fixStream) {
    Log::write(0, "failed to open fix file %s\n",_fixFileName.data());
    return false;
  } else {
    Log::write(0, "open fix file %s\n",_fixFileName.data());
    return true;
  }
}

void UbxDevice::closeFixFile()
{
  if(_fixStream) {
    Log::write(0, "close fix file %s\n", _fixFileName.data());
    fclose(_fixStream);
    _fixStream=0;
  }
}

bool UbxDevice::openRawFile()
{
  char timeBuf[32];
  std::string _rawFileName=_basePath;
  _rawFileName+=_stationName;
  _rawFileName+="-raw-";
  _rawFileName+=timeStamp(timeBuf);
  _rawFileName+=".ubx";
  _rawStream=fopen(_rawFileName.data(), "wb");
  if(!_rawStream) {
    Log::write(0, "failed to open raw file %s\n", _rawFileName.data());
    return false;
  } else {
    Log::write(0, "open raw file %s\n", _rawFileName.data());
    return true;
  }
}

void UbxDevice::closeRawFile()
{
  if(_rawStream) {
    Log::write(0, "close raw file %s\n", _rawFileName.data());
    fclose(_rawStream);
    _rawStream=0;
  }
}

void UbxDevice::connect()
{
  delete _serial;
  _serial=0;
  while(!isTerminated()) {
    _serial=new Serial(new UbxBuffer(0, _server, this));
    if(!_serial->open(_serialPath.data())) {
      delete _serial;
      _serial=0;
    } else {
      _serial->init();
      Log::write(0, "gps connected\n");
      return;
    }
    sleep(10);
  }
}

void UbxDevice::run()
{
  lockSerial();
  if(!_serial) {
    connect();
    resetFiles();
    unlockSerial();
    _navigationTimer.start();
  } else {
    unlockSerial();
  }
  Log::write(0, "start listening to gps\n");
  while(!isTerminated()) {
    _serial->exec();
    Log::write(0, "gps disconnected\n");
    if(!isTerminated()) {
      usleep(10000);
      lockSerial();
      connect();
      unlockSerial();
    }
  }
  Log::write(0, "stop listening to gps\n");
}

/*!
  Called by UbxBuffer when time is locked
*/
void UbxDevice::setTimeLocked()
{
  pthread_mutex_lock(&_timeLockedMutex);
  if(_timeLocked) {
    pthread_mutex_unlock(&_timeLockedMutex);
    return;
  }
  _timeLocked=true;
  pthread_mutex_unlock(&_timeLockedMutex);
  // Delayed opening of fix and raw files
  resetFiles();
  // Send "signal" to other process that internal clock is locked on GPS
  FILE * f=fopen("/tmp/system_clock_set", "wb");
  if(f) {
    fwrite("GPS", 1, 3, f);
    fclose(f);
  }
}

/*!
  Returns true if system time is locked to GPS
*/
bool UbxDevice::timeLocked()
{
  pthread_mutex_lock(&_timeLockedMutex);
  bool r=_timeLocked;
  pthread_mutex_unlock(&_timeLockedMutex);
  return r;
}

/*!
  Reset files
*/
void UbxDevice::resetFiles()
{
  if(_timeLocked) {
    lockFixStream();
    lockRawStream();
    closeFixFile();
    openFixFile();
    openRawFile();
    unlockFixStream();
    unlockRawStream();
  }
}

void UbxDevice::startBroadcast()
{
  lockSerial();
  if(_serial) {
    static_cast<UbxBuffer *>(_serial->buffer())->setBroadcast(true);
    Log::write(1, "broadcast fix on\n");
  }
  unlockSerial();
}

void UbxDevice::stopBroadcast()
{
  lockSerial();
  if(_serial) {
    static_cast<UbxBuffer *>(_serial->buffer())->setBroadcast(false);
    Log::write(1, "broadcast fix off\n");
  }
  unlockSerial();
}

/*
  Request almanach and ephemeris
*/
void UbxDevice::requestNavigation()
{
  /* Checksum computation (N is number of bytes from class, id to end of payload)
      CK_A = 0, CK_B = 0
      For(I=0;I<N;I++) {
        CK_A = CK_A + Buffer[I]
        CK_B = CK_B + CK_A
      }
  */
  // AID-HUI (AID-DATA is returning blocks that are not accepted by teqc)
  static unsigned char pollAid[]={0xB5, 0x62, 0x0B, 0x02, 0x00, 0x00, 0x0D, 0x32};
  // RXM-ALM
  static unsigned char pollAlm[]={0xB5, 0x62, 0x02, 0x30, 0x00, 0x00, 0x32, 0x98};
  // RXM-EPH
  static unsigned char pollEph[]={0xB5, 0x62, 0x02, 0x31, 0x00, 0x00, 0x33, 0x9B};
  lockSerial();
  if(_serial) {
    _serial->write((char *)pollAid, 8);
    _serial->write((char *)pollAlm, 8);
    _serial->write((char *)pollEph, 8);
    Log::write(1, "request almanach and ephemeris\n");
  }
  unlockSerial();
}

/*!
  Returns a string describing current state
*/
std::string UbxDevice::info()
{
  std::string str;
  str+="serial ";
  lockSerial();
  if(_serial) {
    str+="connected";
  } else {
    str+="disconnected";
  }
  unlockSerial();
  str+="\nfix ";
  if(_fixStream) {
    str+=_fixFileName;
  } else {
    str+="no stream";
  }
  str+="\nraw ";
  if(_rawStream) {
    str+=_rawFileName;
  } else {
    str+="no stream";
  }
  return str;
}
