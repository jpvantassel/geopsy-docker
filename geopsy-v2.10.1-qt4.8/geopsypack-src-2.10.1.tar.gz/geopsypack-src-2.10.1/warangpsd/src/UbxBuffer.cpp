/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-28
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <errno.h>
#include <string.h>

#include "UbxBuffer.h"
#include "UbxHeader.h"
#include "UbxDevice.h"
#include "GpsServer.h"

/*!
  \class UbxBuffer qtbubxbuffer.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
UbxBuffer::UbxBuffer(int fd, GpsServer * server, UbxDevice * device)
    : DynamicBuffer(fd)
{
  TRACE;
  _oldFix=new GpsFix;
  _newFix=new GpsFix;
  _server=server;
  _index=0;
  _broadcast=false;
  _nextAdjustTime=0;
  _device=device;
}

/*!
  Description of destructor still missing
*/
UbxBuffer::~UbxBuffer()
{
  TRACE;
  delete _oldFix;
  delete _newFix;
}

/*!
  Returns the number of accepted bytes.
*/
int UbxBuffer::bytesAvailable(const char * buffer, int byteCount)
{
  TRACE;
  int readBytes=0;
  // 8 bytes is the minimum size of an U-Blox binary packet
  // If less bytes are available, just wait for more data.
  if(byteCount<8) {
    return readBytes;
  }
  // Expects that the buffer begins with the U-Blox packet tag 0xB5 0x62
  // If there are some garbage at the beginning scan for the first
  // match of the tag (try to synchronize)
  const UbxHeader * hdr=reinterpret_cast<const UbxHeader *>(buffer);
  readBytes+=6;
  while(readBytes<byteCount && !hdr->isValid()) {
    buffer+=2;
    readBytes+=2;
    hdr=reinterpret_cast<const UbxHeader *>(buffer);
  }
  // Exits if no valid tag was found
  if(readBytes>=byteCount) {
    return byteCount;
  }
  buffer+=6;
  // The buffer contains a valid U-Blox header, continue parsing
  // Now the total lenght of the packet is known, check if it is
  // available.
  readBytes+=hdr->length()+2;
  if(readBytes>byteCount) {
    return readBytes-8-hdr->length();
  }
  const char * payload=buffer;
  buffer+=hdr->length();
  const UbxChecksum * cksum=reinterpret_cast<const UbxChecksum *>(buffer);
  if(hdr->checksum(*cksum, payload)) {
    read(*hdr, payload);
  }
  return readBytes;
}

/*!
  U-Blox gps ouputs the packet in this order every second:
    \li NavSVInfo
    \li NavStatus
    \li NavPosLLH
    \li NavDop
  The last one triggers the signal to the Tcp server to send the update
*/
void UbxBuffer::read(const UbxHeader& hdr, const char * payload)
{
  TRACE;
  switch(hdr.ubxClass()) {
  case 0x01:
    switch(hdr.ubxId()) {
    case 0x01: // NAV-POSECEF
      saveRaw(hdr, payload);
      break;
    case 0x02:
      readNavPosLLH(payload);
      saveRaw(hdr, payload);
      break;
    case 0x03:
      readNavStatus(payload);
      break;
    case 0x04:
      readNavDop(payload);
      saveFix(); // Uses _newFix altered by broadcast()
      if(_broadcast) broadcast();
      break;
    case 0x30:
      readNavSvInfo(payload);
      break;
    case 0x21:
      readNavTimeUTC(payload);
      break;
    case 0x22: // NAV-CLOCK
      saveRaw(hdr, payload);
      break;
    default:
      break;
    }
    break;
  case 0x02:
    switch(hdr.ubxId()) {
    case 0x10: // RXM-RAW
      saveRaw(hdr, payload);
      break;
    case 0x11: // RXM-SFRB
      saveRaw(hdr, payload);
      break;
    case 0x20: // RXM-SVSI
      saveRaw(hdr, payload);
      break;
    case 0x30: // RXM-ALM
      //Log::write(5, "RXM-ALM\n");
      saveRaw(hdr, payload);
      break;
    case 0x31: // RXM-EPH
      //Log::write(5, "RXM-EPH\n");
      saveRaw(hdr, payload);
      break;
    }
    break;
  case 0x0B:
    switch(hdr.ubxId()) {
    //case 0x01: // AID-INI     Not accepted by teqc
    //  saveRaw(hdr, payload);
    //  break;
    case 0x02: // AID-HUI
      //Log::write(5, "AID-HUI\n");
      saveRaw(hdr, payload);
      break;
    //case 0x30: // AID-ALM     Not accepted by teqc
    //  saveRaw(hdr, payload);
    //  break;
    //case 0x31: // AID-EPH     Not accepted by teqc
    //  saveRaw(hdr, payload);
    //  break;
    default:
      break;
    }
    break;
  case 0x0D:
    switch(hdr.ubxId()) {
    case 0x01: // TIM-TP
      saveRaw(hdr, payload);
      break;
    default:
      break;
    }
    break;
  default:
    break;
  }
}

void UbxBuffer::broadcast()
{
  TRACE;
  TcpHeader hb(GPSBLOCK_VERSION, 1);
  _server->send((const char *)&hb, sizeof(TcpHeader));
  unsigned int dataLength;
  const char * data=GpsBlock::encode(_index, *_oldFix, *_newFix, dataLength);
  _server->send(data, dataLength);
  delete data;
  GpsFix * tmpFix=_oldFix;
  _oldFix=_newFix;
  _newFix=tmpFix;
  Log::write(9, "Broadcast index %hhu size %i\n", _index, dataLength);
  _index++;
}

void UbxBuffer::saveRaw(const UbxHeader& hdr, const char * payload)
{
  TRACE;
  FILE * f=_device->lockRawStream();
  if(f) {
    fwrite((const char *)&hdr, sizeof(UbxHeader), 1, f);
    fwrite(payload, 1, hdr.length()+2, f);
    fflush(f);
  }
  _device->unlockRawStream();
}

void UbxBuffer::saveFix()
{
  TRACE;
  if(_newFix->state()==GpsFix::Fix3D) {
    FILE * f=_device->lockFixStream();
    if(f) {
      char timeBuf[32];
      Log::timeStamp(timeBuf);
      fprintf(f,"%s %.7lf %.7lf %.3lf %.3lf %.1lf %.1lf %.1lf %i\n",
              timeBuf,
              _newFix->longitude()*1e-7,
              _newFix->latitude()*1e-7,
              _newFix->altitude()*1e-3,
              _newFix->horizontalAccuracy()*1e-3,
              _newFix->horizontalDop()*1e-2,
              _newFix->northingDop()*1e-2,
              _newFix->eastingDop()*1e-2,
              _newFix->sateliteCount());
      fflush(f);
    }
    _device->unlockFixStream();
  }
}

void UbxBuffer::setBroadcast(bool b)
{
  TRACE;
  _broadcast=b;
  if(b) {
    _oldFix->reset();
    _index=0;
  }
}

struct NavPosLLH {
  unsigned int _gpsTimeOfWeek; // milliseconds
  int _longitude; // degrees*1e7
  int _latitude; // degrees*1e7
  int _heightEllipsoid; // mm
  int _heightMeanSeaLevel; // mm
  unsigned int _horizontalAccuracy; // mm
  unsigned int _verticalAccuracy; // mm
};

struct NavStatus {
  unsigned int _gpsTimeOfWeek; // milliseconds
  unsigned char _gpsFixType;
  unsigned char _flags;
  unsigned char _differentialStatus;
  unsigned char _reserved;
  unsigned int _timeFirstFix; // milliseconds
  unsigned int _timeSinceStartup; // milliseconds
};

struct NavDop {
  unsigned int _gpsTimeOfWeek; // milliseconds
  unsigned short _geometricDop; // *100
  unsigned short _positionDop; // *100
  unsigned short _timeDop; // *100
  unsigned short _verticalDop; // *100
  unsigned short _horizontalDop; // *100
  unsigned short _NorthingDop; // *100
  unsigned short _EastingDop; // *100
};

struct NavSVInfoHeader {
  unsigned int _gpsTimeOfWeek; // milliseconds
  unsigned char _numChannels;
  unsigned char _globalFlags;
  unsigned short _reserved;
};

struct NavSvInfo {
  unsigned char _channelNum;
  unsigned char _svId;
  unsigned char _flags;
  unsigned char _quality;
  unsigned char _cno;
  char _elev;
  short _azim;
  int _prRes;
};

struct NavTimeUTC {
  unsigned int _gpsTimeOfWeek; // milliseconds
  unsigned int _tAcc; // ns
  int _nano;
  unsigned short _year;
  unsigned char _month;
  unsigned char _day;
  unsigned char _hour;
  unsigned char _min;
  unsigned char _sec;
  unsigned char _valid;
};

void UbxBuffer::readNavPosLLH(const char * payload)
{
  TRACE;
  //Log::write("NavPosLLH\n");
  if(_newFix->state()==GpsFix::Fix3D) {
    const NavPosLLH * s=reinterpret_cast<const NavPosLLH *>(payload);
    _newFix->longitude()=s->_longitude;
    _newFix->latitude()=s->_latitude;
    _newFix->altitude()=s->_heightMeanSeaLevel;
    _newFix->horizontalAccuracy()=s->_horizontalAccuracy;
  }
}

void UbxBuffer::readNavStatus(const char * payload)
{
  TRACE;
  //Log::write("NavStatus\n");
  const NavStatus * s=reinterpret_cast<const NavStatus *>(payload);
  switch(s->_gpsFixType) {
  case 0x00:
  case 0x01:
    _newFix->setState(GpsFix::NoFix);
    break;
  case 0x02:
    _newFix->setState(GpsFix::Fix2D);
    break;
  case 0x03:
    _newFix->setState(GpsFix::Fix3D);
    break;
  case 0x04: // Ignored
    break;
  case 0x05:
    _newFix->setState(GpsFix::TimeFix);
    break;
  default:
    fprintf(stderr, "  Unrecognized type of gps fix %02hhX\n", s->_gpsFixType);
    break;
  }
  //printf("  %u milliseconds since startup\n",s->_timeSinceStartup);
}

void UbxBuffer::readNavDop(const char * payload)
{
  TRACE;
  //Log::write("NavDop\n");
  if(_newFix->state()==GpsFix::Fix3D) {
    const NavDop * s=reinterpret_cast<const NavDop *>(payload);
    _newFix->horizontalDop()=s->_horizontalDop;
    _newFix->northingDop()=s->_NorthingDop;
    _newFix->eastingDop()=s->_EastingDop;
  }
}

void UbxBuffer::readNavSvInfo(const char * payload)
{
  TRACE;
  //Log::write("NavSVInfo\n");
  if(_newFix->state()==GpsFix::Fix3D) {
    const NavSVInfoHeader * s=reinterpret_cast<const NavSVInfoHeader *>(payload);
    unsigned char satCount=0;
    for(int i=0;i<s->_numChannels; i++) {
      const NavSvInfo * ssv=reinterpret_cast<const NavSvInfo *>(payload+8+12*i);
      //printf("  %hhu %hhu %hhu dbHz elev %hhi\260 azim %hi\260\n",ssv->_channelNum, ssv->_svId,
      //                                                      ssv->_cno, ssv->_elev, ssv->_azim);
      if(ssv->_flags & 0x01) satCount++;
    }
    _newFix->sateliteCount()=satCount;
  }
}

/*!
  Time is used to adjust system time
*/
void UbxBuffer::readNavTimeUTC(const char * payload)
{
  TRACE;
  //Log::write(5, "NavTimeUTC\n");
  const NavTimeUTC * s=reinterpret_cast<const NavTimeUTC *>(payload);
  // valid UTC and Time of Week
  // Make a time adjustment every 5 minutes
  if(s->_gpsTimeOfWeek>_nextAdjustTime && s->_valid & 0x07 && s->_tAcc<1000) {
    timeval sysTime;
    timeval gpsTime;
    gettimeofday(&sysTime, 0);
    tm gps_tm;
    gps_tm.tm_year=s->_year-1900;
    gps_tm.tm_mon=s->_month-1;
    gps_tm.tm_mday=s->_day;
    gps_tm.tm_hour=s->_hour;
    gps_tm.tm_min=s->_min;
    gps_tm.tm_sec=s->_sec;
    gps_tm.tm_isdst=-1;
    gpsTime.tv_sec=timegm(&gps_tm);
    gpsTime.tv_usec=s->_nano/1000;
    if(gpsTime.tv_usec<0) {
      gpsTime.tv_sec--;
      gpsTime.tv_usec=1000000+gpsTime.tv_usec;
    }
    timeval deltaTime;
    deltaTime.tv_sec=gpsTime.tv_sec-sysTime.tv_sec;
    deltaTime.tv_usec=gpsTime.tv_usec-sysTime.tv_usec;
    //Log::write("    Current gps time %li.%06li\n", gpsTime.tv_sec, gpsTime.tv_usec);
    //Log::write("    Current sys time %li.%06li\n", sysTime.tv_sec, sysTime.tv_usec);
    double dt=deltaTime.tv_sec;
    dt+=deltaTime.tv_usec*1e-6;
    //Log::write("  Diff time %.6lf\n", dt);
    // A delay of more than 5 seconds?
    // force time now...
    if(fabs(dt)>5.0) {
      Log::write(0, "system and gps clocks differ by %.3lf seconds: force system time.\n", dt);
      int deltaSec=(int)floor(dt);
      sysTime.tv_sec+=deltaSec;
      sysTime.tv_usec+=(int)round((dt-deltaSec)*1000000);
      if(sysTime.tv_usec>=1000000) {
        sysTime.tv_sec++;
        sysTime.tv_usec-=1000000;
      }
      Log::write(0, "set time to %li.%06li\n", sysTime.tv_sec, sysTime.tv_usec);
      if(settimeofday(&sysTime, 0)!=0) {
        Log::write(0, "set time: %s\n", strerror(errno));
      } else {
        Log::write(0, "Time set to %li.%06li\n", sysTime.tv_sec, sysTime.tv_usec);
        _device->setTimeLocked();
      }
    } else {
      _device->setTimeLocked();
    }
    _deltaTimes.push_back(dt);
    unsigned int n=_deltaTimes.size();
    if(n==30) {
      // Get std deviation and discard any value outside three stddev
      double sum=0;
      double sum2=0;
      for(int i=0;i<30;i++) {
        double dt=_deltaTimes[i];
        sum+=dt;
        sum2+=dt*dt;
      }
      double mean=sum/n;
      double stddev3=(sum2-mean*mean*n)/(n-1);
      if(stddev3<0.0) stddev3=0.0;
      stddev3=3.0*sqrt(stddev3);
      for(int i=0;i<30;i++) {
        double dt=_deltaTimes[i];
        if(fabs(dt-mean)>stddev3) {
          //Log::write("  %lf outside [%lf,%lf]\n", dt, mean-stddev3, mean+stddev3);
          _deltaTimes[i]=_deltaTimes[29];
          _deltaTimes.resize(29);
          break;
        }
      }
      if(_deltaTimes.size()==n) {
        if(fabs(mean)<1.0) {
          deltaTime.tv_sec=(int)floor(mean);
          deltaTime.tv_usec=(int)round((mean-deltaTime.tv_sec)*1000000);
          if(adjtime(&deltaTime, 0)!=0) {
            Log::write(0, "adjust time: %s\n", strerror(errno));
          } else {
            Log::write(0, "adjust time by %.6lf seconds\n", mean);
          }
        } else {
          Log::write(0, "system and gps clocks differ by %.3lf seconds: force system time.\n", dt);
          int deltaSec=(int)floor(mean);
          sysTime.tv_sec+=deltaSec;
          sysTime.tv_usec+=(int)round((mean-deltaSec)*1000000);
          if(sysTime.tv_usec>=1000000) {
            sysTime.tv_sec++;
            sysTime.tv_usec-=1000000;
          }
          Log::write(0, "set time to %li.%06li\n", sysTime.tv_sec, sysTime.tv_usec);
          if(settimeofday(&sysTime, 0)!=0) {
            Log::write(0, "set time: %s\n", strerror(errno));
          } else {
            Log::write(0, "time set to %li.%06li\n", sysTime.tv_sec, sysTime.tv_usec);
          }
        }
        // Every 5 minutes
        _nextAdjustTime=s->_gpsTimeOfWeek+300000;
        _deltaTimes.clear();
      }
    }
  }
}
