/***************************************************************************
**
**  This file is part of warangpsd.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-06-25
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <signal.h>
#include <sys/stat.h>
#include <string.h>

#include <GpCoreTools.h>
#include "warangpsdVersion.h"
#include "warangpsdInstallPath.h"
#include "UbxDevice.h"
#include "GpsServer.h"
#include "TimeRequest.h"
#include "SlaveTimeServer.h"
#include "MasterTimeServer.h"
#include "MasterServer.h"

PACKAGE_INFO( warangpsd, WARANGPSD );
ApplicationHelp * help();

UbxDevice * ubxSerial=0;

void interrupted(int)
{
  Log::write(2, "received TERM or INTERRUPT signal\n");
  if(ubxSerial) {
    ubxSerial->stop();
  }
  EventLoop::instance()->terminate();
}

int main( int argc, char ** argv )
{
  CoreApplication a(argc, argv, help);

  // Use external leds to show status (if available)
  Leds leds;

  // Options
  std::string devicePath("/dev/ttyACM0");
  std::string basePath("/mnt/usbdrive/waran/gps");
  std::string stationName("unamed");
  std::string interface("wlan0");
  bool initTimeOnly=false;
  bool doFork=true;
  uint16_t port=2974;
  uint16_t timePort=2975;
  bool master=false;
  // Check arguments
  int i, j = 1;
  for (i=1; i<argc; i++) {
    const char * arg = argv[i];
    if (arg[0]=='-') {
      if (strcmp(arg, "-p")==0) {
        CoreApplication::checkOptionArg(i, argc, argv, true);
        port=atoi(argv[i]);
      } else if (strcmp(arg, "-tp")==0) {
          CoreApplication::checkOptionArg(i, argc, argv, true);
          timePort=atoi(argv[i]);
      } else if (strcmp(arg, "-s")==0) {
        CoreApplication::checkOptionArg(i, argc, argv, true);
        stationName=argv[i];
      } else if (strcmp(arg, "-i")==0) {
        CoreApplication::checkOptionArg(i, argc, argv, true);
        interface=argv[i];
      } else if (strcmp(arg, "-b")==0) {
        CoreApplication::checkOptionArg(i, argc, argv, true);
        basePath=argv[i];
      } else if (strcmp(arg, "-N")==0) {
        doFork=false;
      } else if (strcmp(arg, "-master")==0) {
        master=true;
      } else if (strcmp(arg, "-time")==0) {
        doFork=false;
        initTimeOnly=true;
        master=false;
      } else {
        fprintf(stderr, "%s: bad option %s, see -help\n", a.applicationName(), argv[i]);
        CoreApplication::exit(2);
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  if(argc==2) {
    devicePath=argv[1];
  }

  // Checks if basepath exists and creates directory for station if it does not exist yet.
  struct stat sInfo;
  int sErr;
  sErr=stat(basePath.data(), &sInfo);
  if(sErr==0 && S_ISDIR(sInfo.st_mode)) {
    basePath+="/";
    basePath+=stationName;
    sErr=stat(basePath.data(), &sInfo);
    if(sErr!=0) {
      if(errno==ENOENT) {
        if(mkdir(basePath.data(), S_IFDIR | S_IRWXU)!=0) {
          perror(basePath.data());
          a.exit(2);
        }
      } else {
        perror(basePath.data());
        CoreApplication::exit(2);
      }
    } else {
      if(!S_ISDIR(sInfo.st_mode)) {
        fprintf(stderr, "%s: %s already exists and is not a directory\n", a.applicationName(), basePath.data());
        CoreApplication::exit(2);
      }
    }
  }
  basePath+="/";

  // Init log file
  Log log;
  if(doFork || initTimeOnly) {
    std::string logFile=basePath;
    logFile+=stationName;
    logFile+=".log";
    log.setFile(logFile.data());
  }

  if(doFork) {
    sErr=stat("/var/run/warangpsd.pid", &sInfo);
    if(sErr==0) {
      Log::write(0, "warangpsd is already running (stop it and remove /var/run/warangpsd.pid)\n");
      CoreApplication::exit(2);
    }
    // Our process ID and Session ID
    pid_t pid, sid;
    // Fork off the parent process
    pid = fork();
    if (pid < 0) { // Error, no child is created, -1 is returned to parent
      Log::write(0, "cannot fork off the parent process: %s\n", strerror(errno));
      CoreApplication::exit(2);
    }
    // If we got a good PID, then we can exit the parent process.
    if (pid > 0) {
      // Write pid to /var/run/warangpsd.pid
      FILE * fpid=fopen("/var/run/warangpsd.pid","wt");
      if(!fpid) {
        Log::write(0, "cannot create /var/run/warangpsd.pid\n");
        CoreApplication::exit(2);
      }
      fprintf(fpid, "%u\n", pid);
      fclose(fpid);
      exit(0);
    }
    // pid is null, hence we are in the child process
    // Change the file mode mask
    umask(0);
    // Create a new SID for the child process
    sid = setsid();
    if (sid < 0) {
      Log::write(0, "Cannot create a new SID for the child process\n");
      CoreApplication::exit(2);
    }
    CoreApplication::initInternalDebugger(true);
  }

  signal(SIGTERM, interrupted);
  signal(SIGINT, interrupted);

  Log::write(0, "start new daemon with pid %i\n",getpid());

  Address::setMaskSize(24);
  Address::identifyMe(interface.data());
  if(!Address::me().isValid()) {
     Log::write(1, "cannot get host address, check interface (option -i).\n");
     return 2;
  }

  EventLoop loop;

  if(master) {
    MasterServer * server=new MasterServer;
    while(!server->listen(port, 50)) {
      Log::write(1, "cannot listen to port %hu, retry in 10 seconds\n", port);
      sleep(10);
    }
    loop.addStream(server);
    loop.exec();
    // server automatically deleted by event loop
  } else if (initTimeOnly) {
    SlaveTimeServer * server=new SlaveTimeServer;
    while(!server->listen(timePort, 50)) {
      Log::write(1, "cannot listen to port %hu, retry in 10 seconds\n", port);
      sleep(10);
    }
    loop.addStream(server);
    TimeRequest request(timePort);
    request.start();
    loop.exec();
  } else {
    GpsServer * server=new GpsServer;
    while(!server->listen(port, 50)) {
      Log::write(1, "cannot listen to port %hu, retry in 10 seconds\n", port);
      sleep(10);
    }
    loop.addStream(server);

    ubxSerial=new UbxDevice(stationName, basePath, devicePath, server);

    MasterTimeServer * timeServer=new MasterTimeServer(timePort, ubxSerial);
    while(!timeServer->listen(timePort)) {
      Log::write(1, "cannot listen to port %hu, retry in 10 seconds\n", timePort);
      sleep(10);
    }
    loop.addStream(timeServer);

    ubxSerial->start();
    loop.exec();
    ubxSerial->wait();
    delete ubxSerial;
    ubxSerial=0;
    // server automatically deleted by event loop
  }
  Log::write(0, "stop daemon with pid %i\n",getpid());
  remove("/var/run/warangpsd.pid");
  return 0;
}

ApplicationHelp * help()
{
  ApplicationHelp * h = new ApplicationHelp;
  h->setOptionSummary( "[OPTIONS] <DEVICE>" );
  h->setComments("U-blox gps daemon (UBX binary protocol). Through port specified by option '-p', "
                 "it accepts the following commands (e.g. 'telnet localhost 2974'):\n"
                 "  'B' Start broadcast\n"
                 "  'b' Stop broadcast\n"
                 "  'i' Returns information\n"
                 "If no gps is connected, use option -time to synchronize clock with other stations.");
  h->addGroup("", "main");
  h->addOption("-i <INTERFACE>", "Defines network interface (default='wlan0').");
  h->addOption("-s <STATION>", "Set station name, usually the hostname (default=unamed).");
  h->addOption("-b <PATH>", "Set base path (default=/mnt/usb/waran/gps).");
  h->addOption("-p <PORT>", "Listen on port PORT (default=2974).");
  h->addOption("-master", "Run as a gps master.");
  h->addOption("-N", "Don't go into background");
  h->addOption("-tp <PORT>", "Listen on port PORT for time exchange (default=2975).");
  h->addOption("-time", "Request time from stations inside subnet. This for the "
                        "initialization, to avoid unrealistic time in log file upon startup. "
                        "After a few minutes ntp daemon is assumed to maintain the synchronization.");
  h->addExample("warangpsd -s $(uname -n) /dev/ttyACM0", "Start daemon listening on device ttyACM0 (USB)");
  h->addExample("warangpsd -s $(uname -n) -b /mnt/usb/waran/time -time", "Get time from any station in subnet and quit.");
  return h;
}
