<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>Application</name>
    <message>
        <location filename="../src/Application.cpp" line="138"/>
        <source>
Please copy the message below to http://www.geopsy.org/bugs/backtrace.php:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="140"/>
        <source>Please copy the above message to http://www.geopsy.org/bugs/backtrace.php.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="141"/>
        <source>Only the XML content must be copied: &lt;CrashReport&gt;...&lt;/CrashReport&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="142"/>
        <source>This is the system information to copy in the first field of this online form.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="158"/>
        <source>Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="159"/>
        <source>-nograb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="159"/>
        <source>Tells Qt that it must never grab the mouse or the keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="161"/>
        <source>-dograb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="161"/>
        <source>Running under a debugger can cause an implicit -nograb, use -dograb to override</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="162"/>
        <source>-sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="162"/>
        <source>Switches to synchronous mode for debugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="164"/>
        <source>-style &lt;style&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="164"/>
        <source>Sets the application GUI style. Possible values are
  motif
  windows
  platinum
If you compiled Qt with additional styles or have additional styles as plugins these will be available to the -style command line option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="170"/>
        <source>-session &lt;session&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="170"/>
        <source>Restore the application from an earlier session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="171"/>
        <source>-reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="171"/>
        <source>Sets the application&apos;s layout direction to right to left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="173"/>
        <source>-display &lt;display&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="173"/>
        <source>Sets the X display (default is $DISPLAY)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="174"/>
        <source>-geometry &lt;geometry&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="174"/>
        <source>Sets the client geometry of the first window that is shown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="175"/>
        <source>-fn, -font &lt;font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="175"/>
        <source>Defines the application font. The font should be specified using an X logical font description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="177"/>
        <source>-bg, -background &lt;color&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="177"/>
        <source>Sets the default background color and an application palette (light and dark shades are calculated)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="179"/>
        <source>-fg, -foreground &lt;color&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="179"/>
        <source>Sets the default foreground color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="180"/>
        <source>-btn, -button &lt;color&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="180"/>
        <source>Sets the default button color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="181"/>
        <source>-name &lt;name&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="181"/>
        <source>Sets the application name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="182"/>
        <source>-title &lt;title&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="182"/>
        <source>Sets the application title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="183"/>
        <source>-visual TrueColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="183"/>
        <source>Forces the application to use a TrueColor visual on an 8-bit display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="184"/>
        <source>-ncols &lt;count&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="184"/>
        <source>Limits the number of colors allocated in the color cube on an 8-bit display, if the application is using the QApplication::ManyColor color specification. If count is 216 then a  6x6x6 color cube is used (i.e. 6 levels of red, 6 of green, and 6 of blue); for other values, a cube approximately proportional to a 2x3x1 cube is used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="188"/>
        <source>-cmap &lt;count&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="188"/>
        <source>Causes the application to install a private color map on an 8-bit display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="189"/>
        <source>-im &lt;XIM server&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="189"/>
        <source>Sets the input method server (equivalent to setting the XMODIFIERS environment variable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="190"/>
        <source>-noxim</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="190"/>
        <source>Disables the input method framework (&quot;no X input method&quot;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="191"/>
        <source>-inputstyle &lt;inputstyle&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="191"/>
        <source>Defines how the input is inserted into the given widget. Possible values are:
  onTheSpot makes the input appear directly in the widget
  offTheSpot
  overTheSpot makes the input appear in a box floating over the widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Application.cpp" line="196"/>
        <source>Generic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Attachments</name>
    <message>
        <location filename="../src/Attachments.ui" line="13"/>
        <source>Attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Attachments.ui" line="28"/>
        <source>&lt;p&gt;Add here the input files that produced the crash or or the error.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Attachments.ui" line="60"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Attachments.ui" line="76"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Attachments.ui" line="105"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Attachments.ui" line="112"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BugReport</name>
    <message>
        <location filename="../src/BugReport.cpp" line="147"/>
        <source>Sending bug report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="147"/>
        <source>Not a valid e-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="197"/>
        <source>geopsy.org host lookup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="200"/>
        <source>Connecting to geopsy.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="203"/>
        <source>Sending data to geopsy.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="206"/>
        <source>Reading data from geopsy.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="209"/>
        <source>Connected to geopsy.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="212"/>
        <location filename="../src/BugReport.ui" line="160"/>
        <source>Not connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="231"/>
        <location filename="../src/BugReport.cpp" line="243"/>
        <source>geopsy.org bug report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.cpp" line="244"/>
        <source>&lt;html&gt;&lt;body&gt;&lt;p&gt;Cannot send bug report. To help debugging, please save this report and &lt;a href=&quot;http://www.geopsy.org/bugs/backtrace.php&quot;&gt;submit it manually&lt;/a&gt;.&lt;/p&gt;
&lt;p&gt;One possible reason is that you are behind a web proxy configured with an automatic script. You can manually set the proxy parameters by right clicking on the box in the lower right corner you can find in most of the graphical applications.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="13"/>
        <source>Geopsy.org bug report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="32"/>
        <source>Environment and crash information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="55"/>
        <source>Additionnal information:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="65"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Can you reproduce the application crash?&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;How did it happen?&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Did it happen reading an input file?&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Can you attach it ( see &quot;Attachments&quot; here below)?&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Reports in French, English or Spanish are prefered.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="75"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;&quot;&gt;-- Enter here optional comments --&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;&quot;&gt;This application shouldn&apos;t crash, so don&apos;t be afraid of sending this report even if you think that you&apos;ve done something wrong, in fact, what&apos;s wrong is the developer&apos;s job. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;&quot;&gt;- Can you reproduce the application crash?&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;&quot;&gt;- How did it happen?&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;&quot;&gt;- Did it happen reading an input file? Can you attach it ( see &quot;Attachments&quot; here below)?&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="98"/>
        <source>By clicking on &apos;send&apos;, you accept to send these information to the developpers. Bug reports are automatically analyzed. Dupplicate bug reports are automatically recognized.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="110"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Enter your email address. This is useful if complementary is required to solve the bug.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="116"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="126"/>
        <source>This address will used to keep you informed of bug resolution or for any complementary information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="136"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="143"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="189"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This feature is currently not available.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/BugReport.ui" line="195"/>
        <source>Add attachments</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorPalette</name>
    <message>
        <location filename="../src/ColorPalette.cpp" line="113"/>
        <source>Restoring color palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColorPalette.cpp" line="186"/>
        <source>Error parsing color %1, incomplete line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColumnTextColumnsProperties</name>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="13"/>
        <source>Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="19"/>
        <source>Delimiters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="31"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="41"/>
        <source>Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="51"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Example: &quot;;,&quot; for semi-colon or comma&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="61"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If not checked, consecutive separators are ignored.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="67"/>
        <source>Null</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="76"/>
        <source>Fixed widths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="83"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Separate widths by &apos;,&apos;: e.g. 4,5,7,10&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextColumnsProperties.ui" line="89"/>
        <source>10, 10,10, 10</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColumnTextItem</name>
    <message>
        <location filename="../src/ColumnTextItem.cpp" line="116"/>
        <source>Associate columns to data fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextItem.cpp" line="118"/>
        <source>Factors to convert values shown below to the standard units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextItem.cpp" line="121"/>
        <source>The &apos;Regular eXpression (RX)&apos; is search in cell contents and replaced by &apos;After&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextItem.cpp" line="188"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextItem.cpp" line="190"/>
        <source>Factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextItem.cpp" line="192"/>
        <source>RX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextItem.cpp" line="194"/>
        <source>After</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColumnTextLinesProperties</name>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="13"/>
        <source>Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="19"/>
        <source>Start at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="42"/>
        <source>End at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="68"/>
        <source>Accept pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="75"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Only lines that contain this regular expression will be accepted&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="85"/>
        <source>Reject pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="98"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All lines that contain this regular expression will be rejected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextLinesProperties.ui" line="104"/>
        <source>^#</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColumnTextSectionsProperties</name>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="13"/>
        <source>Sections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="19"/>
        <source>When this pattern is encountered, a new section is started.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="22"/>
        <source>Create a new section if ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="29"/>
        <source>Pattern is encountered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="42"/>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="106"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;All lines that contain this regular expression will be rejected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="48"/>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="112"/>
        <source>^#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="55"/>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="69"/>
        <source>After reading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="62"/>
        <source> lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="76"/>
        <source> rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="83"/>
        <source>Column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextSectionsProperties.ui" line="93"/>
        <source>matches</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColumnTextWidget</name>
    <message>
        <location filename="../src/ColumnTextWidget.cpp" line="211"/>
        <source>Cannot read file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.cpp" line="307"/>
        <source>Load parser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.cpp" line="308"/>
        <location filename="../src/ColumnTextWidget.cpp" line="316"/>
        <source>Column text parser (*.ctparser)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.cpp" line="315"/>
        <source>Save parser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="13"/>
        <source>Column text parser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="24"/>
        <source>Parser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="38"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Save current settings for text parser&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="44"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="51"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Load settings for text parser from an existing file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="57"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="68"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Change definition of lines to consider.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="74"/>
        <source>Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="81"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Define columns (delimiters, fixed width,...)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="87"/>
        <source>Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextWidget.ui" line="94"/>
        <source>Sections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConnectionParam</name>
    <message>
        <location filename="../src/ConnectionParam.ui" line="19"/>
        <source>Internet connection parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConnectionParam.ui" line="40"/>
        <source>Direct connection to the Internet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConnectionParam.ui" line="50"/>
        <source>Connection through a proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConnectionParam.ui" line="74"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConnectionParam.ui" line="81"/>
        <source>www-cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConnectionParam.ui" line="88"/>
        <source>port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConnectionParam.ui" line="137"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ConnectionParam.ui" line="144"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoordinateReader</name>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="69"/>
        <source>Station name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="70"/>
        <source>X (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="71"/>
        <source>X (km)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="72"/>
        <source>Y (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="73"/>
        <source>Y (km)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="74"/>
        <source>Z (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="75"/>
        <source>Longitude (D)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="76"/>
        <source>Longitude (M)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="77"/>
        <source>Longitude (S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="78"/>
        <source>Longitude (DEG)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="79"/>
        <source>Latitude (D)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="80"/>
        <source>Latitude (M)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="81"/>
        <source>Latitude (S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="82"/>
        <source>Latitude (DEG)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="91"/>
        <source>Load coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="122"/>
        <location filename="../src/CoordinateReader.cpp" line="133"/>
        <location filename="../src/CoordinateReader.cpp" line="193"/>
        <source>Read coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="123"/>
        <location filename="../src/CoordinateReader.cpp" line="134"/>
        <source>Mix of geographical and cartesian coordinates for column %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="193"/>
        <source>Empty station name at line %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="201"/>
        <source>Converting from Geographical coordinates:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="209"/>
        <source>Reference point: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoordinateReader.cpp" line="211"/>
        <source>  %1 ---&gt; </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExpandTabWidget</name>
    <message>
        <location filename="../src/ExpandTabWidget.cpp" line="353"/>
        <source>Expand all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpandTabWidget.cpp" line="354"/>
        <source>Collapse all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExpressionEditor</name>
    <message>
        <location filename="../src/ExpressionEditor.ui" line="13"/>
        <source>Expression editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionEditor.ui" line="28"/>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionEditor.ui" line="45"/>
        <source>Operators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionEditor.ui" line="66"/>
        <source>(%1, %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionEditor.ui" line="73"/>
        <source>Functions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogWidget</name>
    <message>
        <location filename="../src/LogWidget.cpp" line="40"/>
        <source>vboxLayout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/LogWidget.cpp" line="42"/>
        <source>logTab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBox</name>
    <message>
        <location filename="../src/MessageBox.cpp" line="81"/>
        <source>Show this message again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MessageBox.ui" line="13"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MessageBox.ui" line="68"/>
        <source>iconLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MessageBox.ui" line="132"/>
        <source>Button 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MessageBox.ui" line="145"/>
        <source>Button 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MessageBox.ui" line="155"/>
        <source>Button 2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MultiDocumentWindow</name>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="84"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="86"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="93"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="94"/>
        <source>Create a new document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="100"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="101"/>
        <source>Open an existing document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="107"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="108"/>
        <location filename="../src/MultiDocumentWindow.cpp" line="117"/>
        <source>Save current document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="109"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="115"/>
        <source>Save as ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="116"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="125"/>
        <source>&amp;Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="126"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="127"/>
        <source>Print current document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="135"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="136"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="137"/>
        <source>Quit application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="150"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="152"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="159"/>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="160"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="161"/>
        <source>Undo last operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="167"/>
        <source>Re&amp;do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="168"/>
        <source>Ctrl+Shift+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="169"/>
        <source>Redo last operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="178"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="179"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="180"/>
        <source>Cut the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="186"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="187"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="188"/>
        <source>Copy the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="194"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="195"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="196"/>
        <source>Paste the clipboard&apos;s contents in the sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="211"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="213"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="227"/>
        <source>&amp;Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="232"/>
        <source>&amp;Cascade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="238"/>
        <source>Tile &amp;Vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="244"/>
        <source>Tile &amp;Horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="250"/>
        <source>Close &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="256"/>
        <source>&amp;Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="267"/>
        <source>&amp;Tool bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="280"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="283"/>
        <source>Online &amp;Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="284"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="285"/>
        <source>Access to online html documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="294"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="295"/>
        <source>Show about box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="299"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MultiDocumentWindow.cpp" line="300"/>
        <source>Show the Qt library&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialogWrapper</name>
    <message>
        <location filename="../src/PrintDialogWrapper.cpp" line="73"/>
        <source>Print to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PrintDialogWrapper.cpp" line="73"/>
        <source>Postcript files (*.ps);;PDF files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyEditor</name>
    <message>
        <location filename="../src/PropertyEditor.cpp" line="61"/>
        <source>&lt;p&gt;When you select more than one object at a time, there may be some properties marked in red, meaning that properties differs between widgets. &lt;b&gt;Touching red properties will uniformize them across all objects.&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PropertyEditor.cpp" line="141"/>
        <source>Property editor::%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyWidget</name>
    <message>
        <location filename="../src/PropertyWidget.cpp" line="139"/>
        <source>widgetType %1 unsupported, define connectCustomWidget()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PropertyWidget.cpp" line="239"/>
        <source>widgetType %1 unsupported, define setCustomWidget()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PropertyWidget.cpp" line="284"/>
        <source>widgetType %1 unsupported, define customWidgetValue()</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSA</name>
    <message>
        <location filename="../src/QSA.cpp" line="188"/>
        <location filename="../src/QSA.cpp" line="209"/>
        <source>&amp;Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="191"/>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="226"/>
        <source>&amp;Open project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="227"/>
        <source>Open a qsa project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="233"/>
        <source>S&amp;ave project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="234"/>
        <source>Save current qsa project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="244"/>
        <source>&amp;QSA Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="245"/>
        <source>Show qsa editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="253"/>
        <source>&amp;Start function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="254"/>
        <source>Execute a function of current qsa project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="310"/>
        <source>QSA is not installed, see www.trolltech.com to downloadthe latest release, if you want to execute automatic scripts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="398"/>
        <source>Open QSA project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="398"/>
        <location filename="../src/QSA.cpp" line="410"/>
        <source>QSA project (*.qsa)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="410"/>
        <source>Save QSA project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="534"/>
        <source>List of available objects:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/QSA.cpp" line="612"/>
        <source>Children %1 not found for object %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SamplingWidget</name>
    <message>
        <location filename="../src/SamplingWidget.ui" line="13"/>
        <source>Sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="33"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This is the frequency band where the calculation will be computed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="36"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="62"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="98"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;On the choosen frequency band, a number of samples are selected. Define here the frequency step between each of them, constant on a linear or on a logarythmic scale.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="101"/>
        <source>Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="109"/>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="114"/>
        <source>Linear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="122"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The frequency range is divided into a number of frequency samples (fc). The constant frequency step is automatically calculated according to the chosen type of scale.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SamplingWidget.ui" line="125"/>
        <source>Number of samples</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendMail</name>
    <message>
        <location filename="../src/SendMail.cpp" line="79"/>
        <source>Connecting to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="94"/>
        <source>Connected to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="133"/>
        <source>Sending data ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="140"/>
        <source>Message sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="149"/>
        <source>Sending mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="150"/>
        <source>Unexpected reply from smtp server:

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="168"/>
        <location filename="../src/SendMail.cpp" line="175"/>
        <location filename="../src/SendMail.cpp" line="192"/>
        <source>Sending attachments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="169"/>
        <source>Cannot read file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="176"/>
        <source>Cannot open temporary file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="180"/>
        <source>Zipping %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="188"/>
        <source>Encoding %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SendMail.cpp" line="193"/>
        <source>Cannot open temporary zipped file %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SmoothingWidget</name>
    <message>
        <location filename="../src/SmoothingWidget.ui" line="13"/>
        <source>Smoothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SmoothingWidget.ui" line="31"/>
        <source>Smoothing type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SmoothingWidget.ui" line="39"/>
        <source>Konno &amp; Ohmachi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SmoothingWidget.ui" line="44"/>
        <source>Constant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SmoothingWidget.ui" line="49"/>
        <source>Proportional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SmoothingWidget.ui" line="54"/>
        <source>No smoothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SmoothingWidget.ui" line="62"/>
        <source>Smoothing constant</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateIcon</name>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="60"/>
        <source>Live update: connecting ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="64"/>
        <source>&amp;Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="65"/>
        <source>Open your browser at download page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="69"/>
        <source>&amp;Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="70"/>
        <source>Set connection parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="207"/>
        <source>Not connected or bad proxy parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="210"/>
        <source>You are running the latest release.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="214"/>
        <source>A new snapshot (develoment release) of %1 is now available for download at %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/UpdateIcon.cpp" line="218"/>
        <source>A new release of %1 is now available for download at %2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XMLEditor</name>
    <message>
        <location filename="../src/XMLEditor.cpp" line="106"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLEditor.cpp" line="107"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XMLItem</name>
    <message>
        <location filename="../src/XMLItem.cpp" line="149"/>
        <source>Property name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLItem.cpp" line="151"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
