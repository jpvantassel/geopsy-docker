/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-09-13
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "SamplingWidget.h"

namespace QGpGuiTools {

SamplingWidget::SamplingWidget(QWidget* parent)
    : QWidget(parent)
{
  TRACE;
  setupUi(this);

  _inversed = false;
  _admissibleMin = -1e99;
  _admissibleMax = 1e99;
  // signals and slots connections
  connect(fromValue, SIGNAL(valueChanged(const QString&)), this, SIGNAL(parametersChanged()));
  connect(toValue, SIGNAL(valueChanged(const QString&)), this, SIGNAL(parametersChanged()));
  connect(sampCount, SIGNAL(valueChanged(int)), this, SIGNAL(sampleCountChanged()));
  connect(sampCount, SIGNAL(valueChanged(int)), this, SIGNAL(parametersChanged()));
}

void SamplingWidget::setRangeOnly()
{
  TRACE;
  delete stepTypeLabel;
  stepTypeLabel = 0;
  delete stepType;
  stepType = 0;
  delete sampCountLabel;
  sampCountLabel = 0;
  delete sampCount;
  sampCount = 0;
}

void SamplingWidget::setPrecision( int digit )
{
  TRACE;
  fromValue->setDecimals( digit );
  toValue->setDecimals( digit );
}

void SamplingWidget::setSingleStep( double s )
{
  TRACE;
  fromValue->setSingleStep( s );
  toValue->setSingleStep( s );
}

void SamplingWidget::setAdmissibleRange( double min, double max )
{
  TRACE;
  if (min<max) {
    _admissibleMin = min;
    _admissibleMax = max;
  } else {
    _admissibleMin = max;
    _admissibleMax = min;
  }
  fromValue->setMinimum(_admissibleMin);
  toValue->setMinimum(_admissibleMin);
  fromValue->setMaximum(_admissibleMax);
  toValue->setMaximum(_admissibleMax);
  if (stepType) {
    if (_admissibleMax<0.0) {
      stepType->setCurrentIndex(1);
      stepType->setEnabled(false);
    } else {
      stepType->setEnabled(true);
    }
    if (stepType->currentIndex()==0 && _admissibleMin<0.0) {
      fromValue->setMinimum( pow( 10, -fromValue->decimals() ) );
      toValue->setMinimum( pow( 10, -fromValue->decimals() ) );
    }
  }
}

/*!
  Take the inverse of current values
*/
void SamplingWidget::setInversed( bool inversed, bool inverseValues )
{
  TRACE;
  if ( inversed != _inversed ) {
    if (inverseValues) {
      double min = fromValue->value();
      double max = toValue->value();
      fromValue->setValue( 1.0/max );
      toValue->setValue( 1.0/min );
    }
    _inversed = inversed;
  }
}

void SamplingWidget::on_stepType_currentIndexChanged( int index )
{
  TRACE;
  if (index ==0 ) {
    if (fromValue->minimum()<=0.0)
      fromValue->setMinimum( pow( 10, -fromValue->decimals() ) );
    if (toValue->minimum()<=0.0)
      toValue->setMinimum( pow( 10, -fromValue->decimals() ) );
  } else {
    fromValue->setMinimum( _admissibleMin );
    toValue->setMinimum( _admissibleMin );
  }
  emit parametersChanged();
}

void SamplingWidget::getParameters( Sampling & param )
{
  TRACE;
  param.setRange( fromValue->value(), toValue->value() );
  if (stepType && sampCount) {
    if (stepType->currentIndex()==0) param.setType( Sampling::Log );
    else param.setType( Sampling::Linear );
    param.setCount( sampCount->value() );
  }
}

void SamplingWidget::exportParameters(QString& log, QString prefix)
{
  TRACE;
  log+=prefix+"MINIMUM "+_fileId+" = "+QString::number(fromValue->value())+"\n";
  log+=prefix+"MAXIMUM "+_fileId+" = "+QString::number(toValue->value())+"\n";
  log+=prefix+"INVERSED "+_fileId+" = "+(_inversed ? "y" : "n" )+"\n";
  if (stepType) {
    log+=prefix+QString("SAMPLES NUMBER "+_fileId+" = %1\n").arg(sampCount->value());
    log+=prefix+QString("SAMPLING TYPE "+_fileId+" (0=log, 1=linear)= %1\n").
        arg(stepType->currentIndex());
  }
}

bool SamplingWidget::loadParameters( QString keyword, QString value, QString prefix )
{
  TRACE;
  if (keyword.contains(prefix+"MINIMUM "+_fileId))
    fromValue->setValue(value.toDouble());
  else if (keyword.contains(prefix+"MAXIMUM "+_fileId))
    toValue->setValue(value.toDouble());
  else if (keyword.contains(prefix+"INVERSED "+_fileId))
    setInversed( value == "y" );
  else if (keyword.contains(prefix+"SAMPLES NUMBER")) {
    if (sampCount) sampCount->setValue(value.toInt());
  } else if (keyword.contains(prefix+"SAMPLING TYPE")) {
    if (stepType) stepType->setCurrentIndex(value.toInt());
  } else return false;
  return true;
}

} // namespace QGpGuiTools
