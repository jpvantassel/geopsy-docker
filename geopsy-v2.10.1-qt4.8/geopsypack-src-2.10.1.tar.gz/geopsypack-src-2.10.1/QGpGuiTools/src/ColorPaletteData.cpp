/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-03-02
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <math.h>

#include "ColorPaletteData.h"

namespace QGpGuiTools {

/*!
  \class ColorPaletteData qtbcolorpalettedata.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
ColorPaletteData::ColorPaletteData()
  : QSharedData()
{
  TRACE;
  _colors = 0;
  _upperValues = 0;
  _n = 0;
}

ColorPaletteData::ColorPaletteData( const ColorPaletteData& o )
  : QSharedData(o)
{
  TRACE;
  _n = o._n;
  _n2 = o._n2;
  _colors=new QColor[_n];
  int i;
  for ( i = 0;i < _n;i++ )
    _colors[ i ] = o._colors[ i ];
  int n1 = _n - 1;
  _upperValues = new double[ n1 ];
  for ( i = 0;i < n1;i++ )
    _upperValues[ i ] = o._upperValues[ i ];
}

/*!
  Description of destructor still missing
*/
ColorPaletteData::~ColorPaletteData()
{
  TRACE;
  if ( _colors ) delete [] _colors;
  if ( _upperValues ) delete [] _upperValues;
}

bool ColorPaletteData::operator==( const ColorPaletteData& o ) const
{
  TRACE;
  if ( _n != o._n ) return false;
  int i;
  for ( i = 0;i < _n;i++ ) {
    if ( _colors[ i ] != o._colors[ i ] ) return false;
  }
  int n1 = _n - 1;
  for ( i = 0;i < n1;i++ ) {
    if ( _upperValues[ i ] != o._upperValues[ i ] ) return false;
  }
  return true;
}

void ColorPaletteData::allocate( int n )
{
  TRACE;
  if ( n < 2 ) n = 2;
  if ( !_colors || n != _n ) {
    if ( _colors ) delete [] _colors;
    _colors = new QColor[ n ];
    if ( _upperValues ) delete [] _upperValues;
    _upperValues = new double[ n - 1 ];
    _n = n;
    _n2 = 1;
    while ( _n2 < _n - 1 ) _n2 = _n2 << 1; // multiply by 2
    _n2 = _n2 >> 1;
  }
}

void ColorPaletteData::defaultRGBColors( int n, int transparency )
{
  TRACE;
  allocate( n );
  int i;
  if ( _n == 2 ) {
    _colors[ 0 ] = QColor( 0, 0, 255, transparency );
    _colors[ 1 ] = QColor( 255, 0, 0, transparency );
  } else if ( _n == 3 ) {
    _colors[ 0 ] = QColor( 0, 0, 255, transparency );
    _colors[ 1 ] = QColor( 0, 255, 0, transparency );
    _colors[ 2 ] = QColor( 255, 0, 0, transparency );
  } else {
    double truc, r, g, b;

    int n1 = _n / 3;
    int n2 = n1 + ( _n - n1 ) / 2;
    for ( i = 0; i < n1; i++ ) {
      truc = ( double ) i / ( double ) n1;
      r = 0.;
      g = pow( truc, 0.3 );
      b = 1. - truc * truc;
      _colors[ i ] = QColor( ( int ) ( r * 255 ), ( int ) ( g * 255 ), ( int ) ( b * 255 ), transparency );
    }
    for ( i = n1; i < n2; i++ ) {
      truc = ( double ) ( i - n1 ) / ( double ) ( n2 - n1 );
      r = pow( truc, 0.3 );
      g = 1.;
      b = 0.;
      _colors[ i ] = QColor( ( int ) ( r * 255 ), ( int ) ( g * 255 ), ( int ) ( b * 255 ), transparency );
    }
    for ( i = n2; i < _n; i++ ) {
      truc = ( double ) ( i - n2 ) / ( double ) ( n - n2 - 1 );
      r = 1.;
      g = 1. - truc * truc;
      b = 0.;
      _colors[ i ] = QColor( ( int ) ( r * 255 ), ( int ) ( g * 255 ), ( int ) ( b * 255 ), transparency );
    }
  }
}

void ColorPaletteData::defaultHSVColors( int sat, int value, int n, int transparency )
{
  TRACE;
  allocate( n );
  for ( int i = 0; i < _n; i++ ) {
    _colors[ i ] = QColor::fromHsv( ( int ) ( ( double ) i * 330.0 / ( double ) _n ), sat, value, transparency );
  }
}

void ColorPaletteData::defaultBW( int n, int transparency )
{
  TRACE;
  allocate( n );
  double truc, g;

  for ( int i = 0; i < _n; i++ ) {
    truc = ( double ) i / ( double ) ( n - 1 );
    g = 1. - truc * truc;
    _colors[ i ] = QColor( ( int ) ( g * 255 ), ( int ) ( g * 255 ), ( int ) ( g * 255 ), transparency );
  }
}

void ColorPaletteData::colorRGBInterpole( int imin, int imax )
{
  TRACE;
  double r, r2, dr, g, g2, dg, b, b2, db, a, a2, da;
  if ( _n <= 2 ) return ;
  if ( imin < 0 ) imin = 0;
  if ( imax > _n - 1 ) imax = _n - 1;

  QColor& c1 = _colors[ imin ];
  r = c1.red();
  g = c1.green();
  b = c1.blue();
  a = c1.alpha();

  QColor& c2 = _colors[ imax ];
  r2 = c2.red();
  g2 = c2.green();
  b2 = c2.blue();
  a2 = c2.alpha();

  dr = ( r2 - r ) / ( double ) ( imax - imin + 1 );
  dg = ( g2 - g ) / ( double ) ( imax - imin + 1 );
  db = ( b2 - b ) / ( double ) ( imax - imin + 1 );
  da = ( a2 - a ) / ( double ) ( imax - imin + 1 );

  for ( int i = imin + 1; i < imax; i++ ) {
    r += dr;
    g += dg;
    b += db;
    a += da;
    _colors[ i ] = QColor( ( int ) r, ( int ) g, ( int ) b, (int) a );
  }
}

void ColorPaletteData::colorHSVInterpole( int imin, int imax )
{
  TRACE;
  double h, h2, dh, s, s2, ds, v, v2, dv, a, a2, da;
  if ( _n <= 2 ) return ;
  if ( imin < 0 ) imin = 0;
  if ( imax > _n - 1 ) imax = _n - 1;

  QColor& c1 = _colors[ imin ];
  h = c1.hue();
  s = c1.saturation();
  v = c1.value();
  a = c1.alpha();

  QColor& c2 = _colors[ imax ];
  h2 = c2.hue();
  s2 = c2.saturation();
  v2 = c2.value();
  a2 = c2.alpha();

  dh = ( h2 - h ) / ( double ) ( imax - imin + 1 );
  ds = ( s2 - s ) / ( double ) ( imax - imin + 1 );
  dv = ( v2 - v ) / ( double ) ( imax - imin + 1 );
  da = ( a2 - a ) / ( double ) ( imax - imin + 1 );

  for ( int i = imin + 1; i < imax; i++ ) {
    h += dh;
    s += ds;
    v += dv;
    a += da;
    _colors[ i ].setHsv( ( int ) h, ( int ) s, ( int ) v, ( int ) a);
  }
}

void ColorPaletteData::setVLinear( int imin, int imax, double min, double max )
{
  TRACE;
  if ( _n == 2 )
    _upperValues[ 0 ] = ( min + max ) * 0.5;
  else if ( _n < 2 ) return ;
  else {
    if (imin<0) imin = 0;
    else if (imin>=_n-1) imin = _n-2;
    if (imax<0) imax = 0;
    else if (imax>=_n-1) imax = _n-2;
    double inc = ( max - min ) / ( double ) ( imax -imin );
    _upperValues[ imin ] = min;
    for ( int i = imin+1;i <= imax; i++ ) _upperValues[ i ] = _upperValues[ i - 1 ] + inc;
  }
}


void ColorPaletteData::setVLog( int imin, int imax, double min, double max )
{
  TRACE;
  if ( _n == 2 )
    _upperValues[ 0 ] = ( min + max ) * 0.5;
  else if ( _n < 2 ) return ;
  else {
    if (imin<0) imin = 0;
    else if (imin>=_n-1) imin = _n-2;
    if (imax<0) imax = 0;
    else if (imax>=_n-1) imax = _n-2;
    double inc = pow( max / min, 1 / ( double ) ( imax - imin ) );
    _upperValues[ imin ] = min;
    for ( int i = imin+1;i <= imax; i++ ) _upperValues[ i ] = _upperValues[ i - 1 ] * inc;
  }
}

/*!
  Returns the color index of value \a val.
  The palette must at least contain two items.
*/
int ColorPaletteData::index( double val ) const
{
  TRACE;
  if ( val <= _upperValues[ 0 ] ) return 0;
  int lasti = _n - 2;
  if ( val > _upperValues[ lasti ] ) return lasti + 1;
  int i = _n2;
  int step2 = i >> 1;
  while ( step2 > 0 ) {
    if ( i > lasti ) i -= step2;
    else if ( val <= _upperValues[ i ] ) {
      if ( val > _upperValues[ i - 1 ] ) break;
      i -= step2;
    } else
      i += step2;
    step2 = step2 >> 1;
  }
  return i;
}

} // namespace QGpGuiTools
