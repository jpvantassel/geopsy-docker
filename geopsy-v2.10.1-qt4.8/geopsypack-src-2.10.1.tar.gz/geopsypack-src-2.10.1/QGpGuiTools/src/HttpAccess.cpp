/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2010-12-07
**  Authors:
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QtNetwork>

#include <QGpCoreTools.h>

#include "HttpAccess.h"
#include "HttpProxyList.h"

namespace QGpGuiTools {

  /*!
    \class HttpAccess HttpAccess.h
    \brief Brief description of class still missing

    Full description of class still missing
  */

  /*!
    Description of constructor still missing
  */
  HttpAccess::HttpAccess(const QString& testUrl, QObject * parent)
    : QObject(parent)
  {
    TRACE;
    _proxy=0;
    _proxies=new HttpProxyList(testUrl, this);
    connect(_proxies, SIGNAL(ready()), this, SLOT(testProxies()));
    _proxies->collect();
  }

  /*!
    Description of destructor still missing
  */
  HttpAccess::~HttpAccess()
  {
    TRACE;
    delete _proxy;
  }

  void HttpAccess::get(const QUrl& url)
  {
    TRACE;
    QNetworkAccessManager * manager=new QNetworkAccessManager(this);
    if(_proxy) {
      manager->setProxy(*_proxy);
    }
    QNetworkReply * reply=manager->get(QNetworkRequest(url));
    connect(reply, SIGNAL(finished()), this, SLOT(requestFinished()));
  }

  void HttpAccess::post(const QUrl& url, const QByteArray& data)
  {
    TRACE;
    QNetworkAccessManager * manager=new QNetworkAccessManager(this);
    if(_proxy) {
      manager->setProxy(*_proxy);
    }
    QNetworkReply * reply=manager->post(QNetworkRequest(url), data);
    connect(reply, SIGNAL(finished()), this, SLOT(requestFinished()));
  }

  void HttpAccess::requestFinished()
  {
    TRACE;
    QNetworkReply * reply=static_cast<QNetworkReply *>(sender());
    if(reply->error()==QNetworkReply::NoError) {
      _receivedData=reply->readAll();
      reply->manager()->deleteLater();
      emit finished(true);
    }
  }

  void HttpAccess::testProxies()
  {
    TRACE;
    for(int i=0; i<_proxies->count(); i++) {
      QNetworkAccessManager * manager=new QNetworkAccessManager(this);
      manager->setProxy(_proxies->at(i).proxy());
      QNetworkReply * reply;
      reply=manager->get(QNetworkRequest(_proxies->testUrl()));
      connect(reply, SIGNAL(finished()), this, SLOT(testFinished()));
      _testReplies.append(reply);
    }
  }


  void HttpAccess::testFinished()
  {
    TRACE;
    if(_testReplies.isEmpty()) { // Already found a good proxy
      return;
    }
    QNetworkReply * reply=static_cast<QNetworkReply *>(sender());
    int index=_testReplies.indexOf(reply);
    if(reply->error()==QNetworkReply::NoError && reply->readAll()=="ACCESS OK\n") {
      _proxy=new QNetworkProxy(reply->manager()->proxy());
      delete _proxies;
      _proxies=0;
      _testReplies.clear();
      emit ready();
    } else {
      if(index>-1) {
        _testReplies.removeAt(index);
      }
      if(_testReplies.isEmpty()) { // Unfortunately no http access
        emit ready();
      }
    }
    reply->manager()->deleteLater();
  }

} // namespace QGpGuiTools
