/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-02-23
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "SmoothingWidget.h"

namespace QGpGuiTools {

/*!
  \class SmoothingWidget qtbsmoothingwidget.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
SmoothingWidget::SmoothingWidget( QWidget * parent )
    : QWidget(parent)
{
  TRACE;
  setupUi(this);

  // signals and slots connections
  connect( constant, SIGNAL( valueChanged( const QString& ) ), this, SIGNAL( parametersChanged() ) );
}

/*!
  Description of destructor still missing
*/
SmoothingWidget::~SmoothingWidget()
{
  TRACE;
}

void SmoothingWidget::on_type_activated( int )
{
  TRACE;
  switch ( type->currentIndex() ) {
  case 0:
    constant->setEnabled( true );
    constant->setSuffix( "" );
    constantLabel->setEnabled( true );
    constantLabel->setText( "Smoothing constant" );
    break;
  case 1:
    constant->setEnabled( true );
    constant->setSuffix( "" );
    constantLabel->setEnabled( true );
    constantLabel->setText( "Smoothing width" );
    break;
  case 2:
    constant->setEnabled( true );
    constant->setSuffix( " %" );
    constantLabel->setEnabled( true );
    constantLabel->setText( "Smoothing with" );
    break;
  case 3:
    constant->setEnabled( false );
    constantLabel->setEnabled( false );
    break;
  }
  emit parametersChanged();
}

bool SmoothingWidget::loadParameters( QString& keyword, QString& value )
{
  TRACE;
  if ( keyword.contains( "SMOOTHING TYPE" ) ) {
    if ( value == "konno & ohmachi" ) type->setCurrentIndex( 0 );
    else if ( value == "constant band" ) type->setCurrentIndex( 1 );
    else if ( value == "proportional" ) type->setCurrentIndex( 2 );
    else type->setCurrentIndex( 3 );
    return true;
  } else if ( keyword.contains( "SMOOTHING CONSTANT" ) ) {
    constant->setValue( value.toDouble() );
    return true;
  }
  return false;
}

void SmoothingWidget::exportParameters( QString& log )
{
  TRACE;
  log += "SMOOTHING TYPE (konno & ohmachi/constant band/proportional/"
         "no smoothing) = " + type->currentText().toLower() + "\n";
  log += "SMOOTHING CONSTANT = " + constant->text() + "\n";
}

void SmoothingWidget::getParameters( SmoothingParameters& param ) const
{
  TRACE;
  param.set(type->currentText(), constant->value());
}

} // namespace QGpGuiTools
