/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-04-28
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "Settings.h"
#include "PrintDialogWrapper.h"
#include "Dialog.h"

namespace QGpGuiTools {

/*!
  Load the widget's rectangle from the registry
*/
void Settings::getRect( QWidget * w, QString name )
{
  TRACE;
  bool ok, allOk = true;
  QSettings reg;
  reg.beginGroup( "WidgetRect" );
  reg.beginGroup( name );
  if ( reg.contains( "x" ) ) {
    int x = reg.value( "x", w->x() ).toInt( &ok );
    if ( !ok ) allOk = false;
    int y = reg.value( "y", w->y() ).toInt( &ok );
    if ( !ok ) allOk = false;
    int width = reg.value( "width", w->width() ).toInt( &ok );
    if ( !ok ) allOk = false;
    int height = reg.value( "height", w->height() ).toInt( &ok );
    if ( !ok ) allOk = false;
    if ( allOk ) {
      if ( x < 0 ) x = 0;
#if defined(Q_WS_WIN)
      if ( y < 40 ) y = 40;
      w->move( x, y - 20 );
#elif defined(Q_WS_MACX)
      if ( y < 0 ) y = 0;
      w->move( x, y );
#elif defined(Q_WS_X11)
      if ( y < 0 ) y = 0;
      w->move( x, y );
#endif
      if (width>0 && height>0) {
        w->resize( width, height );
      }
    }
  }
}

/*!
  Save the widget's rectangle in the registry if widget is visible

  Be careful not to use QDialog if you want to save rectangles to registry, but Dialog.
*/
void Settings::setRect( QWidget * w, QString name )
{
  TRACE;
  Dialog * d=qobject_cast<Dialog *>(w);
  if (d) {
    d->setRect(name);
  } else {
    if (w->isVisible()) {
      QSettings reg;
      reg.beginGroup( "WidgetRect" );
      reg.beginGroup( name );
      reg.setValue( "x", w->x() );
      reg.setValue( "y", w->y() );
      reg.setValue( "width", w->width() );
      reg.setValue( "height", w->height() );
    }
  }
}

/*!
  Load the widget's size from the registry
*/
void Settings::getSize( QWidget * w, QString name )
{
  TRACE;
  QSettings reg;
  bool ok, allOk = true;
  reg.beginGroup( "WidgetRect" );
  reg.beginGroup( name );
  int width = reg.value( "width", w->width() ).toInt( &ok );
  if ( !ok ) allOk = false;
  int height = reg.value( "height", w->height() ).toInt( &ok );
  if ( !ok ) allOk = false;
  if ( allOk ) w->resize( width, height );
}

/*!
  Save the widget's size in the registry (not the position)
*/
void Settings::setSize( QWidget * w, QString name )
{
  TRACE;
  if (!w->isMaximized()) {
    QSettings reg;
    reg.beginGroup( "WidgetRect" );
    reg.beginGroup( name );
    reg.setValue( "width", w->width() );
    reg.setValue( "height", w->height() );
  }
}

/*!
  Load a path from the registry
*/
QString Settings::getPath( QString name )
{
  TRACE;
#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup( "CurrentDirectories" );
  if (reg.contains(name)) {
    QDir d( reg.value( name ).toString() );
    if ( d.exists() ) return d.absolutePath();
  }
  return QDir::currentPath ();
}

/*!
  Save a path in the registry
*/
void Settings::setPath( QString name, QDir dirPath )
{
  TRACE;
#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup( "CurrentDirectories" );
  QString p = dirPath.canonicalPath();
  reg.setValue( name, p );
  // Set current directory to dirPath, in case of uninitialized path
  // See getPath()
  QDir::setCurrent( p );
}

/*!
  Load current filter from the registry
*/
QString Settings::getFilter( QString name )
{
  TRACE;
#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup( "CurrentFilters" );
  return reg.value( name ).toString();
}

/*!
  Save current filter in the registry
*/
void Settings::setFilter( QString name, QString filter )
{
  TRACE;
#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup( "CurrentFilters" );
  reg.setValue( name, filter );
}

/*!
  Save current tab index
*/
void Settings::setActiveTab( QTabWidget * w, QString name )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  reg.setValue( w->objectName(), w->currentIndex() );
}

/*!
  restore current tab index
*/
void Settings::activeTab( QTabWidget * w, QString name )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  QVariant val = reg.value( w->objectName() );
  if ( !val.isValid() ) return;
  w->setCurrentIndex( val.toInt() );
}

/*!
  save splitter positions
*/
void Settings::setSplitter(QSplitter * w, QString name)
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  QStringList list;
  QList<int> intList = w->sizes();
  int val;
  foreach( val, intList ) list << QString::number(val);
  reg.setValue( w->objectName(), list );
}

/*!
  restore splitter positions
*/
void Settings::splitter(QSplitter * w, QString name)
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  QVariant val = reg.value( w->objectName() );
  if ( !val.isValid() ) return;
  QStringList list = val.toStringList();
  QList<int> intList;
  foreach( val, list ) intList << val.toInt();
  w->setSizes( intList );
}

/*!
  save columms widths
*/
void Settings::setColumnWidth( QTableView * w, QString name )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  QStringList colWidthList;
  int n = w->model()->columnCount();
  for (int i = 0; i<n; i++ ) {
    colWidthList << QString::number( w->columnWidth(i) );
  }
  reg.setValue( w->objectName(), colWidthList );
}

/*!
  restore columms widths
*/
void Settings::columnWidth( QTableView * w, QString name )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  if (reg.contains(w->objectName())) {
    QStringList colWidthList = reg.value( w->objectName() ).toStringList();
    int n = colWidthList.count();
    if (w->model()->columnCount()<n) n = w->model()->columnCount();
    for (int i = 0; i<n; i++ ) {
      w->setColumnWidth( i, colWidthList.at(i).toInt());
    }
  }
}

/*!
  save columms widths
*/
void Settings::setColumnWidth( QTreeView * w, QString name )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  QStringList colWidthList;
  int n = w->model()->columnCount();
  for (int i = 0; i<n; i++ ) {
    colWidthList << QString::number( w->columnWidth(i) );
  }
  reg.setValue( w->objectName(), colWidthList );
}

/*!
  restore columms widths
*/
void Settings::columnWidth( QTreeView * w, QString name )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  if (reg.contains(w->objectName())) {
    QStringList colWidthList = reg.value( w->objectName() ).toStringList();
    int n = colWidthList.count();
    if (w->model()->columnCount()<n) n = w->model()->columnCount();
    for (int i = 0; i<n; i++ ) {
      w->setColumnWidth( i, colWidthList.at(i).toInt());
    }
  }
}

/*!
  Load the widget's settings from the registry.

  Only the Qt common widgets are loaded.
*/
void Settings::getWidget( QWidget * d, QString name, bool rect )
{
  TRACE;
  if ( name.isEmpty() ) {
    name = d->objectName();
    ASSERT( !name.isEmpty() );
  }
  if ( rect ) getRect( d, name );
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  getWidget( reg, d->children() );
}

void Settings::getWidget( QSettings& reg, const QObjectList & list )
{
  TRACE;
  for(QObjectList::const_iterator it=list.begin();it!=list.end();++it) {
    QWidget * child = qobject_cast<QWidget *>(*it);
    if (!child) continue;
    const QObjectList & childList = child->children();
    if (!childList.isEmpty()) {
      if (child->objectName().isEmpty()) {
        getWidget( reg, childList );
      } else {
        reg.beginGroup(child->objectName());
        getWidget( reg, childList );
        reg.endGroup();
      }
    }
    bool ok = true;
    const char * className = child->metaObject() ->className();
    // Restore specific widget data
    if ( child->objectName().isEmpty() || !reg.contains(child->objectName())) continue;
    QVariant val = reg.value( child->objectName());
    if ( !val.isValid() ) continue;
    child->blockSignals( true );
    switch ( className[ 1 ] ) {
    case 'C':
      if(strcmp(className, "QComboBox")==0) {
        QComboBox * w=static_cast<QComboBox *>(child);
        if(w->isEditable()) {
          w->setEditText(val.toString());
        } else {
          int index=w->findText(val.toString());
          if(index>-1) {
            w->setCurrentIndex(index);
          }
         }
        static_cast<QComboBox *>(child)->setEditText(val.toString());
      } else if(strcmp(className, "QCheckBox")==0) {
        static_cast<QCheckBox *>(child)->setChecked(val.toBool());
      }
      break;
    case 'D':
      if ( strcmp( className, "QDoubleSpinBox" ) == 0 ) {
        QDoubleSpinBox * sb = static_cast<QDoubleSpinBox*>( child );
        double spinVal = val.toDouble( &ok );
        if ( ok ) sb->setValue( spinVal );
      } else if ( strcmp( className, "QDateEdit" ) == 0 &&
          !child->parent() ->inherits( "QDateTimeEdit" ) ) {
        QString str = val.toString();
        if ( !str.isEmpty() ) {
          QDate td;
          td.setYMD( str.section( "/", 2, 2 ).toInt(),
                    str.section( "/", 1, 1 ).toInt(),
                    str.section( "/", 0, 0 ).toInt() );
          if ( td.isValid() ) ( ( QDateEdit* ) child ) ->setDate( td );
        }
      } else if ( strcmp( className, "QDateTimeEdit" ) == 0 ) {
        QString str = val.toString();
        if ( !str.isEmpty() ) {
          QTime tt;
          QDate td;
          QString d = str.section( " ", 0, 0 );
          td.setYMD( d.section( "/", 2, 2 ).toInt(),
                    d.section( "/", 1, 1 ).toInt(),
                    d.section( "/", 0, 0 ).toInt() );
          QString t = str.section( " ", 1, 1 );
          tt.setHMS( t.section( ":", 0, 0 ).toInt(),
                    t.section( ":", 1, 1 ).toInt(),
                    t.section( ":", 2, 2 ).toInt() );
          if ( tt.isValid() && td.isValid() ) ( ( QDateTimeEdit* ) child ) ->setDateTime( QDateTime( td, tt ) );
        }
      }
      break;
    case 'G':
      if ( strcmp( className, "QGpGuiTools::DoubleSpinBox" ) == 0 ) {
        QStringList propList = val.toStringList();
        QDoubleSpinBox * sb = static_cast<QDoubleSpinBox*>( child );
        if (propList.count() == 3) {
          sb->setDecimals( propList[0].toInt() );
          sb->setSingleStep( propList[1].toDouble() );
          sb->setValue( propList[2].toDouble() );
        }
      } else if ( strcmp( className, "QGroupBox" ) == 0 ) {
        QGroupBox * w = ( ( QGroupBox* ) child );
        if (w->isCheckable())
          w->setChecked( val.toBool() );
      }
      break;
    case 'L':
      if ( strcmp( className, "QLineEdit" ) == 0 ) {
        if (child->objectName()!="qt_spinbox_lineedit")
          ( ( QLineEdit* ) child ) ->setText( val.toString() );
      } else if ( strcmp( className, "QListWidget" ) == 0 &&
                  child->objectName() != "in-combo" ) {
        QListWidget * list = ( QListWidget * ) child;
        if ( list->selectionMode() == QAbstractItemView::MultiSelection ||
            list->selectionMode() == QAbstractItemView::ExtendedSelection ) {
          QStringList selList = val.toStringList();
          QString str;
          QListWidgetItem * item;
          foreach( str, selList ) {
            item=list->item( str.toInt());
            if (item) list->setItemSelected( item, true );
          }
        } else {
          int index = val.toInt( &ok );
          if ( ok ) list->setCurrentRow( index );
        }
      }
      break;
    case 'P':
      if ( strcmp( className, "QPlainTextEdit" ) == 0 ) {
        static_cast<QPlainTextEdit* >(child)->setPlainText( val.toString() );
      }
      break;
    case 'R':
      if ( strcmp( className, "QRadioButton" ) == 0 ) {
        ( ( QCheckBox* ) child ) ->setChecked( val.toBool() );
      }
      break;
    case 'S':
      if ( strcmp( className, "QSpinBox" ) == 0 ) {
        int spinVal = val.toInt( &ok );
        if ( ok ) ( ( QSpinBox* ) child ) ->setValue( spinVal );
      } else if ( strcmp( className, "QSplitter" ) == 0 ) {
        QStringList sizesList = val.toStringList();
        QList<int> intSizesList;
        QString str;
        foreach( str, sizesList ) {
          int s = str.toInt();
          if (s==0) s = 100; // Forbid total disappearing of widgets
          intSizesList << s;
        }
        ( ( QSplitter* ) child ) ->setSizes( intSizesList );
      }
      break;
    case 'T':
      if ( strcmp( className, "QTabWidget" ) == 0 ) {
        int index = val.toInt( &ok );
        if ( ok && index < ( ( QTabWidget* ) child ) ->count() )
          ( ( QTabWidget* ) child ) ->setCurrentIndex( index );
      } else if ( strcmp( className, "QTextEdit" ) == 0 ) {
        ( ( QTextEdit* ) child ) ->setPlainText( val.toString() );
      } else if ( strcmp( className, "QTimeEdit" ) == 0 &&
                  !child->parent() ->inherits( "QDateTimeEdit" ) ) {
        QString str = val.toString();
        if ( !str.isEmpty() ) {
          QTime tt;
          tt.setHMS( str.section( ":", 0, 0 ).toInt(),
                    str.section( ":", 1, 1 ).toInt(),
                    str.section( ":", 2, 2 ).toInt() );
          if ( tt.isValid() ) ( ( QTimeEdit* ) child ) ->setTime( tt );
        }
      }
      break;
    default:
      break;
    }
    child->blockSignals( false );
  }
}

/*!
  Save widget's settings into the registry

  Be careful not to use QDialog if you want to save rectangles to registry, but Dialog.
*/
void Settings::setWidget( QWidget * d, QString name, bool rect )
{
  TRACE;
  if ( name.isEmpty() ) {
    name = d->objectName();
    ASSERT( !name.isEmpty() );
  }
  if ( rect ) setRect( d, name );
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  reg.beginGroup( name );
  setWidget( reg, d->children() );
}

void Settings::setWidget(QSettings& reg, const QObjectList & list)
{
  TRACE;
  for(QObjectList::const_iterator it=list.begin();it!=list.end();++it) {
    QWidget * child = qobject_cast<QWidget *>(*it);
    if (!child) continue;
    const QObjectList & childList = child->children();
    if (!childList.isEmpty()) {
      if (child->objectName().isEmpty()) {
        setWidget( reg, childList );
      } else {
        reg.beginGroup(child->objectName());
        setWidget( reg, childList );
        reg.endGroup();
      }
    }
    if ( child->objectName().isEmpty() ) continue;
    const char * className = child->metaObject() ->className();
    switch ( className[ 1 ] ) {
    case 'C':
      if (strcmp(className, "QComboBox")==0) {
        reg.setValue(child->objectName(), static_cast<QComboBox*>(child)->currentText());
      } else if ( strcmp( className, "QCheckBox" ) == 0 ) {
        reg.setValue(child->objectName(), static_cast<QCheckBox*>(child)->isChecked());
      }
      break;
    case 'D':
      if ( strcmp( className, "QDoubleSpinBox" ) == 0 ) {
        QDoubleSpinBox * sb = static_cast<QDoubleSpinBox*>( child );
        reg.setValue( child->objectName(), sb->value() );
      } else if ( strcmp( className, "QDateEdit" ) == 0 &&
           !child->parent() ->inherits( "QDateTimeEdit" ) ) {
        QDate d( ( ( QDateEdit* ) child ) ->date() );
        reg.setValue( child->objectName(), d.toString( "dd/MM/yyyy" ) );
      } else if ( strcmp( className, "QDateTimeEdit" ) == 0 ) {
        QDateTime dt( ( ( QDateTimeEdit* ) child ) ->dateTime() );
        reg.setValue( child->objectName(), dt.toString( "dd/MM/yyyy hh:mm:ss" ) );
      }
      break;
    case 'G':
      if ( strcmp( className, "QGpGuiTools::DoubleSpinBox" ) == 0 ) {
        QDoubleSpinBox * sb = static_cast<QDoubleSpinBox*>( child );
        QStringList propList;
        propList << QString::number(sb->decimals());
        propList << QString::number(sb->singleStep());
        propList << QString::number(sb->value());
        reg.setValue( child->objectName(), propList );
      } else if ( strcmp( className, "QGroupBox" ) == 0 ) {
        QGroupBox * w = ( ( QGroupBox* ) child );
        if (w->isCheckable())
          reg.setValue( child->objectName(), w->isChecked() );
      }
      break;
    case 'L':
      if ( strcmp( className, "QLineEdit" ) == 0 ) {
        reg.setValue( child->objectName(), ( ( QLineEdit* ) child ) ->text() );
      } else if ( strcmp( className, "QListWidget" ) == 0 &&
                  child->objectName() != "in-combo" ) {
        QListWidget * list = ( QListWidget * ) child;
        if ( list->selectionMode() == QAbstractItemView::MultiSelection ||
             list->selectionMode() == QAbstractItemView::ExtendedSelection ) {
          QStringList selList;
          for ( int i = 0;i < list->count();i++ ) {
            if ( list->item( i )->isSelected() ) selList << QString::number( i );
          }
          reg.setValue( child->objectName(), selList );
        } else reg.setValue( child->objectName(), list->currentRow() );
      }
      break;
    case 'P':
      if ( strcmp( className, "QPlainTextEdit" ) == 0 ) {
        reg.setValue( child->objectName(),static_cast<QPlainTextEdit* >(child)->toPlainText() );
      }
      break;
    case 'R':
      if ( strcmp( className, "QRadioButton" ) == 0 ) {
        reg.setValue( child->objectName(), ( ( QRadioButton* ) child ) ->isChecked() );
      }
      break;
    case 'S':
      if ( strcmp( className, "QSpinBox" ) == 0 ) {
        reg.setValue( child->objectName(), ( ( QSpinBox* ) child ) ->value() );
      } else if ( strcmp( className, "QSplitter" ) == 0 ) {
        QStringList sizesList;
        QList<int> intSizeList = ( ( QSplitter* ) child ) ->sizes();
        int val;
        foreach( val, intSizeList ) sizesList << QString::number( val );
        reg.setValue( child->objectName(), sizesList );
      }
      break;
    case 'T':
      if ( strcmp( className, "QTabWidget" ) == 0 ) {
        reg.setValue( child->objectName(), ( ( QTabWidget* ) child ) ->currentIndex() );
      } else if ( strcmp( className, "QTextEdit" ) == 0 ) {
        reg.setValue( child->objectName(), ( ( QTextEdit* ) child ) ->toPlainText() );
      } else if ( strcmp( className, "QTimeEdit" ) == 0 &&
                  !child->parent() ->inherits( "QDateTimeEdit" ) ) {
        QTime t( ( ( QTimeEdit* ) child ) ->time() );
        reg.setValue( child->objectName(), t.toString( "hh:mm:ss" ) );
      }
      break;
    default:
      break;
    }
  }
}

/*!
  QInputDialog::getText with save-retore mechanism
*/
QString Settings::getText( QWidget * parent, const QString & caption,
                              const QString & label, QLineEdit::EchoMode mode,
                              const QString & text, bool * ok )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "DialogOptions" );
  QString t = reg.value( caption ).toString();
  if ( !text.isEmpty() ) t = text;
  QString res = QInputDialog::getText( parent, caption, label, mode, t, ok );
  if ( *ok ) reg.setValue( caption, res );
  return res;
}

/*!
  Set printer information from settings and/or user dialog
*/
bool Settings::printSetup( QPrinter& p )
{
  TRACE;
  QSettings reg;
  reg.beginGroup( "PrintOptions" );
  if ( reg.contains( "printerName" ) ) {
    p.setPrinterName( reg.value( "printerName" ).toString() );
  }
  if ( reg.contains( "outputFileName" ) ) {
    p.setOutputFileName( reg.value( "outputFileName" ).toString() );
  }
  if ( reg.contains( "orientation" ) ) {
    p.setOrientation( ( QPrinter::Orientation ) reg.value( "orientation" ).toInt() );
  }
  if ( reg.contains( "pageSize" ) ) {
    p.setPaperSize( ( QPrinter::PaperSize ) reg.value( "pageSize" ).toInt() );
  }
  if ( reg.contains( "pageOrder" ) ) {
    p.setPageOrder( ( QPrinter::PageOrder ) reg.value( "pageOrder" ).toInt() );
  }
  if ( reg.contains( "paperSource" ) ) {
    p.setPaperSource( ( QPrinter::PaperSource ) reg.value( "paperSource" ).toInt() );
  }
  if ( reg.contains( "numCopies" ) ) {
    p.setNumCopies( reg.value( "numCopies" ).toInt() );
  }
  if ( reg.contains( "outputFormat" ) ) {
    p.setOutputFormat( ( QPrinter::OutputFormat ) reg.value( "outputFormat" ).toInt() );
  }
  if ( reg.contains( "colorMode" ) ) {
    p.setColorMode( ( QPrinter::ColorMode ) reg.value( "colorMode" ).toInt() );
  }
  if ( reg.contains( "printRange" ) ) {
    p.setPrintRange( ( QPrinter::PrintRange ) reg.value( "printRange" ).toInt() );
  }
  if ( reg.contains( "toPage" ) && reg.contains( "fromPage") ) {
    p.setFromTo( reg.value( "fromPage" ).toInt(), reg.value( "toPage" ).toInt() );
  }
  if ( reg.contains( "collateCopies" ) ) {
    p.setCollateCopies( reg.value( "collateCopies" ).toBool() );
  }

  p.setCreator( QApplication::applicationName() );
  QPrintDialog pd( &p );
  PrintDialogWrapper pdWrap( &pd );

  if ( pd.exec() == QDialog::Accepted ) {
    reg.setValue( "printerName", p.printerName() );
    reg.setValue( "outputFileName", p.outputFileName() );
    reg.setValue( "orientation", p.orientation() );
    reg.setValue( "pageSize", p.pageSize() );
    reg.setValue( "pageOrder", p.pageOrder() );
    reg.setValue( "paperSource", p.paperSource() );
    reg.setValue( "numCopies", p.numCopies() );
    reg.setValue( "outputFormat", p.outputFormat() );
    reg.setValue( "colorMode", p.colorMode() );
    reg.setValue( "printRange", p.printRange() );
    reg.setValue( "fromPage", p.fromPage() );
    reg.setValue( "toPage", p.toPage() );
    reg.setValue( "collateCopies", p.collateCopies() );
    return true;
  } else return false;
}

/*!
  Restores history from registry
*/
QStringList Settings::getHistory(QSettings& reg, const QString & name)
{
  TRACE;
  return reg.value(name).toStringList();
}

/*!
  Saves the directory history to registry
*/
void Settings::setHistory(QSettings& reg, const QString & name, QString newString, int maxCount)
{
  TRACE;
  QStringList list=reg.value(name).toStringList();
  int i=list.indexOf(newString);
  if (i>-1) {
    list.removeAt(i);
  }
  list.prepend(newString);
  while (list.count()>maxCount) list.removeLast();
  reg.setValue(name, list);
}

/*!
  Restores the directory history from registry
*/
QStringList Settings::getDirHistory( const QString & caption )
{
  TRACE;
#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup( "DirectoryHistories" );
  QStringList l=getHistory( reg, "common" );
  l+=getHistory(reg, caption);
  // Check that all items exit
  for (int i = l.count()-1;i>=0;i--) {
    QDir d(l.at(i));
    if (!d.exists()) l.removeAt(i);
  }
  // Add current directory
  QDir d;
  l.prepend(d.absolutePath());
  return l;
}

/*!
  Saves the directory history to registry
*/
void Settings::setDirHistory(const QString & caption, QDir newPath)
{
  TRACE;
#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup("DirectoryHistories");
  setHistory(reg, caption, newPath.canonicalPath(), 17);
  setHistory(reg, "common", newPath.canonicalPath(), 3);
}

/*!
  Restores history from registry
*/
QStringList Settings::getHistory(const QString & name)
{
  QSettings reg;
  return Settings::getHistory(reg, name);
}

/*!
  Saves the directory history to registry
*/
void Settings::setHistory(const QString & name, QString newString, int maxCount)
{
  QSettings reg;
  Settings::setHistory(reg, name, newString, maxCount);
}

} // namespace QGpGuiTools
