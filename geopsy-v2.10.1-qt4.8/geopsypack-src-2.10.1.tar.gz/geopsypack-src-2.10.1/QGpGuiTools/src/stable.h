#if defined __cplusplus
#include <QtGui>
#include <QtNetwork>
#include <QtScript>
#ifndef Q_WS_MAC
#include <QGpCoreTools.h>
#endif // Q_WS_MAC
#endif // __cplusplus
