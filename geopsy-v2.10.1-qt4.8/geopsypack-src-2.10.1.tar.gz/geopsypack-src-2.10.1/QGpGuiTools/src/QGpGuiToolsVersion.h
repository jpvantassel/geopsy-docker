#ifndef QGPGUITOOLS_VERSION
#define QGPGUITOOLS_VERSION "1.14.0"
#define QGPGUITOOLS_VERSION_TIME "201605121341"
#define QGPGUITOOLS_VERSION_TYPE "testing"
#define QGPGUITOOLS_AUTHORS "Marc Wathelet\nMarc Wathelet (ISTerre, Grenoble, France)\nMarc Wathelet (LGIT, Grenoble, France)\nMarc Wathelet (ULg, Liège, Belgium)"
#endif // QGPGUITOOLS_VERSION
