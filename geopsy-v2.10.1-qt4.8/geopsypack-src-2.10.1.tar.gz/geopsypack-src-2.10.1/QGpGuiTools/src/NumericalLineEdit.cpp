/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2010-02-28
**  Authors :

**
***************************************************************************/

#include "NumericalLineEdit.h"

namespace QGpGuiTools {

/*!
  \class NumericalLineEdit NumericalLineEdit.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
NumericalLineEdit::NumericalLineEdit(QWidget * parent)
    : QLineEdit(parent)
{
  TRACE;
  setValidator(new QDoubleValidator(this));
}

/*!
  Set current value to \a v. Negative precisions are considered as maximum precision.
*/
void NumericalLineEdit::setValue(double v, Number::Type type, int precision)
{
  TRACE;
  // Eventually set automatic precision
  if(precision<0) {
    precision=-precision;
    double vr=floor(v);
    double vf=v;
    int i;
    for(i=0;i<precision && vr!=vf;i++) {
      vf*=10.0;
      vr=floor(vf);
    }
    precision=i;
  }
  QLocale dl;
  dl.setNumberOptions(QLocale::OmitGroupSeparator);
  QLineEdit::setText(dl.toString(v, Number::type(type), precision));
}

/*!
  Returns current value
*/
double NumericalLineEdit::value(bool * ok) const
{
  TRACE;
  return QLineEdit::text().toDouble(ok);
}

} // namespace QGpGuiTools
