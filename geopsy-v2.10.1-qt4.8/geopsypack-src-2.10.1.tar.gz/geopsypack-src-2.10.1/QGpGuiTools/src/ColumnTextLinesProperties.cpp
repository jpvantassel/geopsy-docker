/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-07-12
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "ColumnTextLinesProperties.h"

namespace QGpGuiTools {

/*!
  \class ColumnTextLinesProperties qtbcolumntextlinesproperties.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
ColumnTextLinesProperties::ColumnTextLinesProperties( QWidget * parent )
    : Dialog(parent)
{
  setupUi(this);
}

/*!
  Description of destructor still missing
*/
ColumnTextLinesProperties::~ColumnTextLinesProperties()
{
}

void ColumnTextLinesProperties::updateWidgets()
{
  on_isStartLine_toggled();
  on_isEndLine_toggled();
}

void ColumnTextLinesProperties::on_isStartLine_toggled()
{
  startLine->setEnabled( isStartLine->isChecked() );
}

void ColumnTextLinesProperties::on_isEndLine_toggled()
{
  endLine->setEnabled( isEndLine->isChecked() );
}

} // namespace QGpGuiTools
