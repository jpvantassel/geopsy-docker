/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-04-01
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "PropertyWidget.h"
#include "ColorButton.h"

namespace QGpGuiTools {

/*!
  \class PropertyWidget qtbpropertywidget.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
PropertyWidget::PropertyWidget( QWidget * parent )
    : QWidget(parent)
{
  TRACE;
  _wid = 0;
}

PropertyWidget::~PropertyWidget()
{
  TRACE;
  QHash<int, PropertyValue *>::Iterator it;
  for ( it = _list.begin();it != _list.end();it++ ) delete it.value();
}

void PropertyWidget::touched(PropertyValue * p, QVariant val)
{
  TRACE;
  // Commit property value and force re-read of all properties except this one (p), because frozen.
  p->freeze(true);
  emit setProperty( p->id(), val );
  emit refreshValues();
  p->freeze(false);
  // Force re-read of all properties from linked widgets
  emit touched();
}

void PropertyWidget::linkTo( PropertyWidget * w )
{
  // First make sure it is not already connected
  disconnect(this, SIGNAL(touched()), w, SIGNAL(refreshValues()));
  connect(this, SIGNAL(touched()), w, SIGNAL(refreshValues()));
}

inline int PropertyWidget::determineWidgetType( int pid, QWidget * w, QWidget * label )
{
  TRACE;
  if ( ! w ) return 0;
  // First consider special custom types
  int t = determineCustomWidgetType(pid, w, label);
  // If not handled consider standard types
  if (t==0) {
    if ( w->inherits( "QGpGuiTools::ColorButton" ) ) t = 9;
    else if ( w->inherits( "QAbstractButton" ) ) t = 1;
    else if ( w->inherits( "QLineEdit" ) ) t = 2;
    else if ( w->inherits( "QComboBox" ) ) t = 3;
    else if ( w->inherits( "QSpinBox" ) ) t = 4;
    else if ( w->inherits( "QAbstractSlider" ) ) t = 5;
    else if ( w->inherits( "QTextEdit" ) ) t = 6;
    else if ( w->inherits( "QGroupBox" ) ) t = 7;
    else if ( w->inherits( "QDoubleSpinBox" ) ) t = 8;
  }
  return t;
}

inline void PropertyWidget::connectWidget( PropertyValue & p )
{
  TRACE;
  switch ( p.widgetType() ) {
  case 0:
    break;
  case 1:
    QObject::connect( p.widget(), SIGNAL( toggled( bool ) ), &p, SLOT( touched() ) );
    break;
  case 2:
    QObject::connect( p.widget(), SIGNAL( textChanged( const QString& ) ), &p, SLOT( touched() ) );
    break;
  case 3:
    QObject::connect( p.widget(), SIGNAL( activated( int ) ), &p, SLOT( touched() ) );
    break;
  case 4:
  case 5:
    QObject::connect( p.widget(), SIGNAL( valueChanged( int ) ), &p, SLOT( touched() ) );
    break;
  case 6:
    QObject::connect( p.widget(), SIGNAL( textChanged() ), &p, SLOT( touched() ) );
    break;
  case 7:
    if (( ( QGroupBox * ) p.widget() ) ->isCheckable()) {
      QObject::connect( p.widget(), SIGNAL( toggled( bool ) ), &p, SLOT( touched() ) );
    }
    break;
  case 8:
    QObject::connect( p.widget(), SIGNAL( valueChanged( double ) ), &p, SLOT( touched() ) );
    break;
  case 9:
    QObject::connect( p.widget(), SIGNAL( colorChanged( QColor ) ), &p, SLOT( touched() ) );
    break;
  default:
    if (!connectCustomWidget(p)) {
      App::stream() << tr( "widgetType %1 unsupported, define connectCustomWidget()" )
                .arg( p.widgetType() ) << endl;
    }
    break;
  }
}

/*!
  If \a pid does not exist, a new value is created
*/
void PropertyWidget::setValue(int pid, QVariant val)
{
  TRACE;
  QHash<int, PropertyValue *>::iterator it = _list.find(pid);
  if (it!=_list.end()) {
    it.value()->setValue(val);
  } else {
    PropertyValue * p = addProperty( pid, 0, 0 );
    p->setValue(val);
  }
}

PropertyValue * PropertyWidget::addProperty( int pid, QWidget * w, QWidget * label )
{
  TRACE;
  PropertyValue * p = new PropertyValue( pid, w, label, determineWidgetType( pid, w, label ) );
  _list.insert( pid, p );
  connectWidget( *p );
  connect( p, SIGNAL(touched(PropertyValue *)), this, SLOT(touched(PropertyValue *)));
  return p;
}

void PropertyWidget::setWidgets()
{
  TRACE;
  QHash<int, PropertyValue *>::Iterator it;
  for ( it = _list.begin();it != _list.end();it++ ) {
    PropertyValue & p = **it;
    if (!p.isFrozen()) { // The property is already frozen by someone else, do not set widget.
      p.freeze(true);
      setWidget( p );
      p.freeze(false);
    }
  }
}

void PropertyWidget::reset()
{
  TRACE;
  QHash<int, PropertyValue *>::Iterator it;
  for ( it = _list.begin();it != _list.end();it++ ) (*it)->reset();
}

void PropertyWidget::setWidget( PropertyValue & p )
{
  TRACE;
  switch ( p.widgetType() ) {
  case 0:
    break;
  case 1:
    static_cast<QAbstractButton *>( p.widget() )->setChecked( p.value().toBool() );
    break;
  case 2: {
      QLineEdit * w = static_cast<QLineEdit * >( p.widget() );
      QString s = p.value().toString();
      w->setText( s );
      bool ok;
      s.toDouble( &ok );
      if ( ok ) {
        w->setCursorPosition( 0 );
      }
    }
    break;
  case 3:
    static_cast<QComboBox *>( p.widget() )->setCurrentIndex( p.value().toInt() );
    break;
  case 4:
    static_cast<QSpinBox *>( p.widget() )->setValue( p.value().toInt() );
    break;
  case 5:
    static_cast<QAbstractSlider *>( p.widget() )->setValue( p.value().toInt() );
    break;
  case 6:
    static_cast<QTextEdit *>( p.widget() )->setPlainText( p.value().toString() );
    break;
  case 7: {
      QGroupBox * w = static_cast<QGroupBox *>( p.widget() );
      if ( w->isCheckable() ) {
        w->setChecked( p.value().toBool() );
      }
    }
    break;
  case 8:
    static_cast<QDoubleSpinBox *>( p.widget() )->setValue( p.value().toDouble() );
    break;
  case 9:
    static_cast<ColorButton *>( p.widget() )->setColor( p.value().value<QColor>() );
    break;
  default:
    if (!setCustomWidget(p)) {
      App::stream() << tr( "widgetType %1 unsupported, define setCustomWidget()" )
                .arg( p.widgetType() ) << endl;
    }
    break;
  }
}

QVariant PropertyWidget::widgetValue( PropertyValue & p )
{
  QVariant val;
  switch ( p.widgetType() ) {
  case 0:
    break;
  case 1:
     val = static_cast<QAbstractButton *>( p.widget() )->isChecked();
    break;
  case 2:
    val = static_cast<QLineEdit *>( p.widget() )->text();
    break;
  case 3:
    val = static_cast<QComboBox *>( p.widget() )->currentIndex();
    break;
  case 4:
    val = static_cast<QSpinBox *>( p.widget() )->value();
    break;
  case 5:
    val = static_cast<QAbstractSlider *>( p.widget() )->value();
    break;
  case 6:
    val = static_cast<QTextEdit *>( p.widget() )->toPlainText();
    break;
  case 7:
    if ( static_cast<QGroupBox *>( p.widget() )->isCheckable() ) {
      val = static_cast<QGroupBox *>( p.widget() )->isChecked();
    }
    break;
  case 8:
    val = static_cast<QDoubleSpinBox *>( p.widget() )->value();
    break;
  case 9:
    val = static_cast<ColorButton *>( p.widget() )->color();
    break;
  default:
    val = customWidgetValue(p);
    if (!val.isValid()) {
      App::stream() << tr( "widgetType %1 unsupported, define customWidgetValue()" )
                .arg( p.widgetType() ) << endl;
    }
    break;
  }
  return val;
}

} // namespace QGpGuiTools
