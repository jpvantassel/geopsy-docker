/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2011-01-05
**  Authors:
**    Marc Wathelet (ISTerre, Grenoble, France)
**
***************************************************************************/

#ifndef HTTPPROXYSCRIPT_H
#define HTTPPROXYSCRIPT_H

#include <QGpCoreTools.h>

#include "QGpGuiToolsDLLExport.h"
#include "HttpProxy.h"

class QScriptEngine;
class QScriptContext;
class QScriptEngine;
class QScriptValue;

namespace QGpGuiTools {

  class QGPGUITOOLS_EXPORT HttpProxyScript
  {
  public:
    HttpProxyScript(const QString& content);
    ~HttpProxyScript();

    QList<HttpProxy> proxies(const QUrl& url);
  private:
    static QScriptValue isPlainHostName(QScriptContext *context, QScriptEngine *);
    static QScriptValue dnsDomainIs(QScriptContext *context, QScriptEngine *);
    static QScriptValue localHostOrDomainIs(QScriptContext *context, QScriptEngine *);
    static QScriptValue isResolvable(QScriptContext *context, QScriptEngine *);
    static QScriptValue isInNet(QScriptContext *context, QScriptEngine *);
    static QScriptValue dnsResolve(QScriptContext *context, QScriptEngine *);
    static QScriptValue myIpAddress(QScriptContext *context, QScriptEngine *);
    static QScriptValue dnsDomainLevels(QScriptContext *context, QScriptEngine *);
    static QScriptValue shExpMatch(QScriptContext *context, QScriptEngine *);
    static QScriptValue weekdayRange(QScriptContext *context, QScriptEngine *);
    static QScriptValue dateRange(QScriptContext *context, QScriptEngine *);
    static QScriptValue timeRange(QScriptContext *context, QScriptEngine *);
  private:
    QString _script;
    QScriptEngine * _engine;
  };

} // namespace QGpGuiTools

#endif // HTTPPROXYSCRIPT_H
