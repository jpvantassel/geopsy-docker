/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2011-03-11
**  Authors:
**    Marc Wathelet (ISTerre, Grenoble, France)
**
***************************************************************************/

#include "GeographicalReference.h"
#include "Settings.h"

namespace QGpGuiTools {

  /*!
    \class GeographicalReference GeographicalReference.h
    \brief Brief description of class still missing

    Full description of class still missing
  */

  /*!
    Description of constructor still missing
  */
  GeographicalReference::GeographicalReference(QWidget * parent)
    : QWidget(parent)
  {
    TRACE;
    setupUi(this);

    refName->addItem(QString::null);
    QSettings * reg=settings();
    QStringList list=reg->childKeys();
    qSort(list);
    NamedPoint p;
    for(QStringList::iterator it=list.begin(); it!=list.end(); it++) {
      if(p.fromString(reg->value(*it).toString())) {
        p.setName(*it);
        _references.append(p);
        refName->addItem(p.name());
      }
    }
    delete reg;
  }

  /*!
    Description of destructor still missing
  */
  GeographicalReference::~GeographicalReference()
  {
    TRACE;
  }

  QSettings * GeographicalReference::settings() const
  {
#ifdef Q_WS_MAC
    QSettings * reg=new QSettings(qApp->organizationDomain());
#else
    QSettings * reg=new QSettings(qApp->organizationName());
#endif
    reg->beginGroup("GeographicalReferences");
    return reg;
  }

  Point2D GeographicalReference::reference() const
  {
    Point2D p;
    p.setX(refLongitude->text().toDouble());
    p.setY(refLatitude->text().toDouble());
    if(!refName->currentText().isEmpty()) {
      QSettings * reg=settings();
      reg->setValue(refName->currentText(), p.toString(20));
      delete reg;
    }
    return p;
  }

  void GeographicalReference::on_refName_currentIndexChanged(int index)
  {
    if(index>0) {
      const NamedPoint& p=_references.at(index-1);
      refLongitude->setText(QString::number(p.x(), 'f', 10));
      refLatitude->setText(QString::number(p.y(), 'f', 10));
    }
  }

} // namespace QGpGuiTools
