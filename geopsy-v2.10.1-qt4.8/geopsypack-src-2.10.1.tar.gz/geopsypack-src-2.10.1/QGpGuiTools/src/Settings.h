/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-04-28
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef SETTINGS_H
#define SETTINGS_H

#include <QtGui>
#include <QGpCoreTools.h>

#include "QGpGuiToolsDLLExport.h"

namespace QGpGuiTools {

class PrintRange;

class QGPGUITOOLS_EXPORT Settings
{
public:
  static QString getPath(QString name);
  static void setPath(QString name, QDir dirPath);

  static QStringList getDirHistory(const QString & caption);
  static void setDirHistory(const QString & caption, QDir newPath);

  static QStringList getHistory(const QString & name);
  static void setHistory(const QString & name, QString newString, int maxCount=20);

  static QString getFilter(QString name);
  static void setFilter(QString name, QString filter);

  static void getRect(QWidget * w, QString name);
  static void setRect(QWidget * w, QString name);

  static void getSize(QWidget * w, QString name);
  static void setSize(QWidget * w, QString name);

  static void setActiveTab(QTabWidget * w, QString name);
  static void activeTab(QTabWidget * w, QString name);

  static void setSplitter(QSplitter * w, QString name);
  static void splitter(QSplitter * w, QString name);

  static void setColumnWidth(QTableView * w, QString name);
  static void columnWidth(QTableView * w, QString name);

  static void setColumnWidth(QTreeView * w, QString name);
  static void columnWidth(QTreeView * w, QString name);

  static void getWidget(QWidget * d, QString name=QString::null, bool rect=true);
  static void setWidget( QWidget *d, QString name=QString::null, bool rect=true);

  static QString getText(QWidget * parent, const QString & caption,
                         const QString & label, QLineEdit::EchoMode mode=QLineEdit::Normal,
                         const QString & text=QString::null, bool * ok=0);

  static bool printSetup(QPrinter& p);
private:
  static void getWidget(QSettings& reg, const QObjectList& list);
  static void setWidget(QSettings& reg, const QObjectList& list);

  static QStringList getHistory(QSettings& reg, const QString & name);
  static void setHistory(QSettings& reg, const QString & name, QString newString, int maxCount);
};

} // namespace QGpGuiTools

#endif // SETTINGS_H
