/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-09-14
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "MultiDocumentWindow.h"
#include "MultiDocumentTabWidget.h"
#include "MultiDocumentTab.h"
#include "MultiDocumentSubWindow.h"
#include "MultiDocumentEnvironment.h"
#include "Application.h"

namespace QGpGuiTools {

/*!
  \class MultiDocumentWindow qtbmultidocumentwindow.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
MultiDocumentWindow::MultiDocumentWindow(QWidget * parent, Qt::WindowFlags f)
    : QMainWindow(parent, f)
{
  TRACE;
  setAttribute(Qt::WA_DeleteOnClose, true);

  _tabs=new MultiDocumentTabWidget(this);
  connect(_tabs, SIGNAL(newTabRequested(int)), this, SLOT(insertTab(int)));
  connect(_tabs, SIGNAL(closeTabRequested(int)), this, SLOT(closeTab(int)));
  setCentralWidget(_tabs);
  createWindowsActions();
}

/*!
  Description of destructor still missing
*/
MultiDocumentWindow::~MultiDocumentWindow()
{
  TRACE;
}

void MultiDocumentWindow::addFileActions()
{
  TRACE;

  QMenu * m;
  QToolBar * tb;

  m=menuBar()->addMenu(tr("&File"));
  m->setTearOffEnabled (true);
  tb=addToolBar(tr("File"));
  tb->setObjectName("FileBar");
  tb->setIconSize(QSize(24, 24));

  _fileMenu=m;
  _fileBar=tb;

  MultiDocumentEnvironment::instance()->addFileActions(m, tb);
}

void MultiDocumentWindow::addEditActions()
{
  TRACE;

  QMenu * m;
  QToolBar * tb;

  m=menuBar()->addMenu(tr("&Edit"));
  m->setTearOffEnabled (true);
  tb=addToolBar(tr("Edit"));
  tb->setObjectName("EditBar");
  tb->setIconSize(QSize(24, 24));

  _editMenu=m;
  _editBar=tb;

  MultiDocumentEnvironment::instance()->addEditActions(m, tb);
}

void MultiDocumentWindow::addViewActions()
{
  TRACE;

  QMenu * m;
  QToolBar * tb;

  m=menuBar()->addMenu(tr("&View"));
  m->setTearOffEnabled (true);
  tb=addToolBar(tr("View"));
  tb->setObjectName("ViewBar");
  tb->setIconSize(QSize(24, 24));

  _viewMenu=m;
  _viewBar=tb;

  MultiDocumentEnvironment::instance()->addViewActions(m, tb);
}

void MultiDocumentWindow::addWindowsActions()
{
  TRACE;

  QMenu * m;

  m=menuBar()->addMenu(tr("&Windows"));
  m->setTearOffEnabled (true);

  _windowsMenu=m;

  MultiDocumentEnvironment::instance()->addWindowsActions(m);
  addWindowsActions(m);
  m->addSeparator();
}

void MultiDocumentWindow::addHelpActions()
{
  TRACE;

  QMenu * m;

  m=menuBar()->addMenu(tr("&Help"));
  m->setTearOffEnabled (true);

  _helpMenu=m;

  MultiDocumentEnvironment::instance()->addHelpActions(m);
}

void MultiDocumentWindow::createWindowsActions()
{
  TRACE;
  QAction * a;

  a=new QAction(tr("New &tab"), this);
  a->setToolTip(tr("Add a new tab"));
  connect(a, SIGNAL(triggered()), this, SLOT(addTab()));
  _windowsNewTabAction=a;

  a=new QAction(tr("Close win&dow"), this);
  a->setToolTip(tr("Close current sub window"));
  a->setEnabled(false);
  connect(a, SIGNAL(triggered()), this, SLOT(closeSubWindow()));
  _windowsCloseAction=a;

  a=new QAction(tr("Close all w&indows"), this);
  a->setToolTip(tr("Close all sub windows of the current tab"));
  a->setEnabled(false);
  connect(a, SIGNAL(triggered()), this, SLOT(closeAllSubWindows()));
  _windowsCloseAllSubWindowsAction=a;

  a=new QAction(tr("Close t&ab"), this);
  a->setToolTip(tr("Close current tab"));
  connect(a, SIGNAL(triggered()), this, SLOT(closeTab()));
  _windowsCloseTabAction=a;

  a=new QAction(tr("Close all ta&bs"), this);
  a->setToolTip(tr("Close all tabs"));
  connect(a, SIGNAL(triggered()), this, SLOT(closeAllTabs()));
  _windowsCloseAllTabsAction=a;

  a=new QAction(tr("&Cascade"), this);
  a->setToolTip(tr("Organize sub windows in cascade"));
  a->setEnabled(false);
  connect(a, SIGNAL(triggered()), this, SLOT(cascadeSubWindows()));
  _windowsCascadeAction=a;

  a=new QAction(tr("Ti&le"), this);
  a->setToolTip(tr("Organize sub windows in tiles"));
  a->setEnabled(false);
  connect(a, SIGNAL(triggered()), this, SLOT(tileSubWindows()));
  _windowsTileAction=a;

  _toolBarsMenu=new QMenu;
  connect(_toolBarsMenu, SIGNAL(aboutToShow()), this, SLOT(showToolBarMenu()));

  a=new QAction(tr("T&ool bars"), this);
  a->setMenu(_toolBarsMenu);
  _windowsToolBarsAction=a;
}

void MultiDocumentWindow::addWindowsActions(QMenu * m)
{
  TRACE;
  if(m) {
    m->addAction(_windowsNewTabAction);
    m->addSeparator();
    m->addAction(_windowsCloseAction);
    m->addAction(_windowsCloseAllSubWindowsAction);
    m->addAction(_windowsCloseTabAction);
    m->addAction(_windowsCloseAllTabsAction);
    m->addSeparator();
    m->addAction(_windowsCascadeAction);
    m->addAction(_windowsTileAction);
    m->addSeparator();
    m->addAction(_windowsToolBarsAction);
  }
}

void MultiDocumentWindow::setWindowsMenuEnabled(bool b)
{
  TRACE;
  _windowsCloseAction->setEnabled(b);
  _windowsCloseAllSubWindowsAction->setEnabled(b);
  _windowsCascadeAction->setEnabled(b);
  _windowsTileAction->setEnabled(b);
}

void MultiDocumentWindow::addTab()
{
  TRACE;
  MultiDocumentTab * t=new MultiDocumentTab;
  connect(t, SIGNAL(subWindowActivated(QMdiSubWindow *)),
          this, SLOT(setCurrentSubWindow(QMdiSubWindow *)));
  _tabs->addTab(t);
  _windowsMenu->addAction(t->windowMenuAction());
}

void MultiDocumentWindow::insertTab(int at)
{
  TRACE;
  MultiDocumentTab * t=new MultiDocumentTab;
  connect(t, SIGNAL(subWindowActivated(QMdiSubWindow *)),
          this, SLOT(setCurrentSubWindow(QMdiSubWindow *)));
  _tabs->insertTab(at, t);
  _windowsMenu->addAction(t->windowMenuAction());
}

MultiDocumentTab * MultiDocumentWindow::tab(int index) const
{
  TRACE;
  ASSERT(index>=0 && index<_tabs->count());
  return qobject_cast<MultiDocumentTab *>(_tabs->widget(index));
}

/*!
  Add window w to window system.
*/
void MultiDocumentWindow::addWindow(MultiDocumentSubWindow * w)
{
  TRACE;
  MultiDocumentTab * t=tab(_tabs->currentIndex());
  t->addSubWindow(w);
  connect(w, SIGNAL(clearCloseMarks()), this, SIGNAL(clearCloseMarks()));
  connect(w, SIGNAL(askForClose(bool&)), this, SIGNAL(askForClose(bool&)));
  w->show();
  t->windowMenuAction()->menu()->addAction(w->windowMenuAction());
}

void MultiDocumentWindow::setCurrentSubWindow(QMdiSubWindow * w)
{
  TRACE;
  MultiDocumentSubWindow * mdw=qobject_cast<MultiDocumentSubWindow *>(w);
  if(!mdw) return;
  MultiDocumentTab * t=mdw->tab();
  QList<QMdiSubWindow *>	wList=t->subWindowList(QMdiArea::CreationOrder);
  if(t==tab(_tabs->currentIndex())) { // Enable or not menu only if a is the current tab
    setWindowsMenuEnabled(!wList.isEmpty());
  }
  foreach(QMdiSubWindow * subw, wList) {
    MultiDocumentSubWindow * mywin=qobject_cast<MultiDocumentSubWindow *>(subw);
    if(mywin) {
      QAction * a=mywin->windowMenuAction();
      if(subw==w) {
        a->setChecked(true);
        emit activeWindowChanged(mywin);
      } else {
        a->setChecked(false);
      }
    }
  } 
}

void MultiDocumentWindow::setCloseMarks(bool c)
{
  TRACE;
  for(int i=0; i<_tabs->count(); i++) {
    MultiDocumentTab * t=_tabs->tab(i);
    t->setCloseMarks(c);
  }
}

void MultiDocumentWindow::closeSubWindow()
{
  TRACE;
  MultiDocumentTab * t=tab(_tabs->currentIndex());
  MultiDocumentSubWindow * w=t->currentSubWindow();
  if(w) {
    emit clearCloseMarks();
    w->setCloseMark();
    bool ok;
    emit askForClose(ok);
    if(ok) {
      w->close();
    }
  }
}

void MultiDocumentWindow::closeAllSubWindows()
{
  TRACE;
  MultiDocumentTab * t=tab(_tabs->currentIndex());
  emit clearCloseMarks();
  t->setCloseMarks();
  bool ok;
  emit askForClose(ok);
  if(ok) {
    t->closeAllSubWindows();
  }
}

void MultiDocumentWindow::closeTab(int at)
{
  TRACE;
  if(at<0) {
    at=_tabs->currentIndex();
  }
  MultiDocumentTab * t=_tabs->tab(at);
  emit clearCloseMarks();
  t->setCloseMarks();
  bool ok;
  emit askForClose(ok);
  if(ok) {
    _tabs->removeTab(at);
    delete t;
    if(_tabs->count()==0) {
      addTab();
    }
  }
}

void MultiDocumentWindow::closeAllTabs()
{
  TRACE;
  emit clearCloseMarks();
  setCloseMarks();
  bool ok;
  emit askForClose(ok);
  if(ok) {
    for(int i=_tabs->count()-1; i>=0; i--) {
      MultiDocumentTab * t=_tabs->tab(i);
      _tabs->removeTab(i);
      delete t;
    }
    addTab();
  }
}

void MultiDocumentWindow::cascadeSubWindows()
{
  TRACE;
  MultiDocumentTab * t=tab(_tabs->currentIndex());
  t->cascadeSubWindows();
}

void MultiDocumentWindow::tileSubWindows()
{
  TRACE;
  MultiDocumentTab * t=tab(_tabs->currentIndex());
  t->tileSubWindows();
}

void MultiDocumentWindow::showToolBarMenu()
{
  TRACE;
  _toolBarsMenu->clear();
  QList<QDockWidget *> dockwidgetList=findChildren<QDockWidget *>();
  QAction * a;
  for (QList<QDockWidget *>::iterator it=dockwidgetList.begin();it != dockwidgetList.end();++it) {
    a=new QAction((*it) ->windowTitle(), this);
    a->setCheckable(true);
    if ((*it) ->isVisible())
      a->setChecked(true);
    connect(a, SIGNAL(toggled(bool)), *it, SLOT(setVisible(bool)));
    _toolBarsMenu->addAction(a);
  }
  _toolBarsMenu->addSeparator();
  QList<QToolBar *> toolBarList=findChildren<QToolBar *>();
  for (QList<QToolBar *>::iterator it=toolBarList.begin();it != toolBarList.end();++it) {
    a=new QAction((*it) ->windowTitle(), this);
    a->setCheckable(true);
    if ((*it) ->isVisible())
      a->setChecked(true);
    connect(a, SIGNAL(toggled(bool)), *it, SLOT(setVisible(bool)));
    _toolBarsMenu->addAction(a);
  }
}

void MultiDocumentWindow::closeEvent(QCloseEvent * e)
{
  TRACE;
  emit clearCloseMarks();
  setCloseMarks();
  bool ok;
  emit askForClose(ok);
  if(ok) {
    e->accept();
  } else {
    e->ignore();
  }
}

} // namespace QGpGuiTools
