/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2002-05-24
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "ColorPalette.h"

namespace QGpGuiTools {

/*!
  \class ColorPalette qtbcolorpalette.h
  \brief A ColorPalette links a color palette with a vector of values

  ColorPalette are defined by a QColor vector of n elements and a vector
  of double of n-1 elements. Each value at i corresponds to the interface between
  the two colors at positions i and i+1. 
*/

const QString ColorPalette::xmlColorPaletteTag = "ColorPalette";

// Automatic registration of ColorPalette upon loading of the library
class ColorPaletteInitMetaType
{
public:
  ColorPaletteInitMetaType();
};

ColorPaletteInitMetaType::ColorPaletteInitMetaType()
{
  qRegisterMetaType<ColorPalette>("ColorPalette");
}
ColorPaletteInitMetaType qtbColorPaletteInitMetaTypeInstance;

QTextStream& operator<<( QTextStream& s, const ColorPalette& p )
{
  TRACE;
  int n = p.count();
  s << n << " elements\n";
  s << "upper   red    green    blue\n";
  for ( int i = 0; i < ( n - 1 ); i++ ) {
    s << p.upperValue( i ) << " ";
    s << p.color( i ).red() << " ";
    s << p.color( i ).green() << " ";
    s << p.color( i ).blue() << "\n";
  }
  // for compatibility reasons (with Sardine), store a last value
  s << 0 << " ";
  s << p.color( n - 1 ).red() << " ";
  s << p.color( n - 1 ).green() << " ";
  s << p.color( n - 1 ).blue() << "\n";
  // for compatibility reasons (with Sardine), store as a C printf format
  s << "%g0.6\n";
  return s;
}

QTextStream& operator>>( QTextStream& s, ColorPalette& p )
{
  TRACE;
  QString str;
  int r, g, b;
  bool ok;

  str = s.readLine();
  int n = str.section( " ", 0, 0 ).toInt( &ok );
  if ( !ok || !n ) goto error;
  p.allocate( n );
  s.readLine();
  for ( int i = 0; i < n - 1; i++ ) {
    str = s.readLine();
    p.setUpperValue( i, str.section( " ", 0, 0 ).toDouble( &ok ));
    if ( !ok ) goto error;
    r = str.section( " ", 1, 1 ).toInt( &ok );
    if ( !ok ) goto error;
    g = str.section( " ", 2, 2 ).toInt( &ok );
    if ( !ok ) goto error;
    b = str.section( " ", 3, 3 ).toInt( &ok );
    if ( !ok ) goto error;
    p.setColor( i, QColor( r, g, b ) );
  }
  str = s.readLine();
  // first value is ignored for compatibility reasons (with Sardine)
  r = str.section( " ", 1, 1 ).toInt( &ok );
  if ( !ok ) goto error;
  g = str.section( " ", 2, 2 ).toInt( &ok );
  if ( !ok ) goto error;
  b = str.section( " ", 3, 3 ).toInt( &ok );
  if ( !ok ) goto error;
  p.setColor( n - 1, QColor( r, g, b ) );
  str = s.readLine(); // Read precision and number type for compatibility (no longer part of ColorPalette 20080326)
  return s;
error:
  Message::wrongTextFormat( s, ColorPalette::tr("Restoring color palette"));
  return s;
}

void ColorPalette::xml_writeProperties( XML_WRITEPROPERTIES_ARGS ) const
{
  TRACE;
  Q_UNUSED(context);
  writeProperty( s, "nColors", count() );
  QString tmp;
  tmp += s.indent();
  tmp += "<palette>\n";
  for ( int i = 0; i < count(); i++ ) {
    tmp += s.indent();
    tmp += color( i ).name();
    if ( i < count() - 1 ) {
      tmp += " ";
      tmp += QString::number( upperValue( i ) );
    }
    tmp += "\n";
  }
  tmp += s.indent();
  tmp += "</palette>\n";
  s << tmp;
}

XMLMember ColorPalette::xml_member( XML_MEMBER_ARGS )
{
  TRACE;
  Q_UNUSED(attributes)
  Q_UNUSED(context);
  if ( tag == "nColors" ) return XMLMember( 0 );
  else if ( tag == "numberType" ) return XMLMember( 1 );       // Compatibility
  else if ( tag == "numberPrecision" ) return XMLMember( 2 );  // Compatibility
  else if ( tag == "palette" ) return XMLMember( 3 );
  else if ( tag == "numType" ) return XMLMember( 1 );          // Compatibility
  else if ( tag == "numPrec" ) return XMLMember( 2 );          // Compatibility
  else return XMLMember(XMLMember::Unknown);
}

bool ColorPalette::xml_setProperty( XML_SETPROPERTY_ARGS )
{
  TRACE;
  Q_UNUSED(attributes)
  Q_UNUSED(context);
  switch ( memberID ) {
  case 0: {
      int n = content.toInt();
      if ( n > 0 ) {
        allocate( n );
        return true;
      } else return false;
    }
  case 1:
  case 2:
    return true;
  case 3: {
      if ( count() == 0 ) return false;
      const QChar * ptr = 0;
      content.nextLine(ptr);
      StringSection f;
      int i;
      QColor c;
      for ( i = 0;i < count();i++ ) {
        f = content.nextField(ptr);
        c.setNamedColor( f.toString() );
        if ( f.isValid() ) setColor( i, c ); else break;
        if ( i < count() - 1 ) {
          f = content.nextField(ptr);
          if ( f.isValid() ) setUpperValue( i, f.toDouble() ); else break;
        }
        content.nextLine(ptr);
      }
      if ( i == count() ) return true;
      else {
        App::stream() << tr( "Error parsing color %1, incomplete line" ).arg( i ) << endl;
        return false;
      }
    }
  default:
    break;
  }
  return false;
}


} // namespace QGpGuiTools
