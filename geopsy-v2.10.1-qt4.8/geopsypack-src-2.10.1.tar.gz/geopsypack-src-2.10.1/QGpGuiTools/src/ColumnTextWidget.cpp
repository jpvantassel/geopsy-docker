/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-07-11
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "ColumnTextWidget.h"
#include "ColumnTextItem.h"
#include "Settings.h"
#include "ColumnTextLinesProperties.h"
#include "ColumnTextColumnsProperties.h"
#include "ColumnTextSectionsProperties.h"

namespace QGpGuiTools {

class ColumnTextDelegate : public QItemDelegate
{
public:
  ColumnTextDelegate( QObject *parent = 0 ) : QItemDelegate(parent) {}

  void setTypes( QStringList t ) { _types = t; }
  const QStringList& types() const { return _types; }

  QWidget *createEditor( QWidget *parent, const QStyleOptionViewItem &option,
                         const QModelIndex &index ) const;
  void setEditorData( QWidget *editor, const QModelIndex &index ) const;
  void setModelData( QWidget *editor, QAbstractItemModel *model,
                     const QModelIndex &index ) const;
private:
  QStringList _types;
};

QWidget * ColumnTextDelegate::createEditor( QWidget * parent, const QStyleOptionViewItem &,
                                               const QModelIndex & index ) const
{
  TRACE;
  switch ( index.row() ) {
  case 0: {
      QComboBox * w = new QComboBox( parent );
      w->addItems( _types );
      return w;
    }
  case 1:
  case 2:
  case 3: {
      QLineEdit * w = new QLineEdit( parent );
      return w;
    }
  default:
    return 0;
  }
  return 0;
}

void ColumnTextDelegate::setEditorData( QWidget *editor, const QModelIndex &index ) const
{
  TRACE;
  switch ( index.row() ) {
  case 0: {
      QComboBox * w = qobject_cast<QComboBox *>( editor );
      ASSERT( w );
      int i=w->findText(index.model() ->data( index ).toString());
      w->setCurrentIndex( i );
      break;
    }
  case 1:
  case 2:
  case 3: {
      QLineEdit * w = qobject_cast<QLineEdit *>( editor );
      ASSERT( w );
      w->setText( index.model() ->data( index ).toString() );
      w->selectAll();
      break;
    }
  default:
    break;
  }
}

void ColumnTextDelegate::setModelData( QWidget *editor, QAbstractItemModel *model,
                                          const QModelIndex &index ) const
{
  TRACE;
  switch ( index.row() ) {
  case 0: {
      QComboBox * w = qobject_cast<QComboBox *>( editor );
      ASSERT( w );
      if (model->data(index)!=w->currentText()) {
        model->setData( index, w->currentText() );
      }
      break;
    }
  case 1:
  case 2:
  case 3: {
      QLineEdit * w = qobject_cast<QLineEdit *>( editor );
      ASSERT( w );
      if (model->data(index)!=w->text()) {
        model->setData( index, w->text() );
      }
      break;
    }
  default:
    break;
  }
}

/*!
  \class ColumnTextWidget ColumnFileWidget.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
ColumnTextWidget::ColumnTextWidget( QWidget * parent )
    : QWidget(parent)
{
  TRACE;
  setupUi(this);

  _parser=new ColumnTextParser(this);
  _file=0;
  _buffer=0;

  ColumnTextItem * itemModel = new ColumnTextItem(this);
  itemModel->setParser( _parser );
  fileView->setModel( itemModel );
  ColumnTextDelegate * itemDelegate = new ColumnTextDelegate(this);
  itemDelegate->setTypes( _parser->standardTypes() );
  fileView->setItemDelegate( itemDelegate );
  fileView->setSelectionMode( QAbstractItemView::SingleSelection );
  fileView->setEditTriggers( QAbstractItemView::AllEditTriggers );

  connect(_parser, SIGNAL(dataAvailable()), this, SLOT(restoreColumnWidths()));
}

/*!
  Description of destructor still missing
*/
ColumnTextWidget::~ColumnTextWidget()
{
  TRACE;
  delete _file;
  delete _buffer;
  if (!_parserFile.isEmpty()) {
    QFileInfo fi(_parserFile);
    Settings::setColumnWidth(fileView, "ColumnTextParsers/"+fi.baseName());
  }
}

void ColumnTextWidget::restoreColumnWidths()
{
  TRACE;
  if (!_restoreColumnWidth.isEmpty()) {
    Settings::columnWidth(fileView, _restoreColumnWidth);
    _restoreColumnWidth = "";
  }
}

void ColumnTextWidget::setStandardTypes(const QStringList& t)
{
  TRACE;
  _parser->setStandardTypes(t);
  static_cast<ColumnTextDelegate *>(fileView->itemDelegate())->setTypes(_parser->standardTypes());
}

void ColumnTextWidget::setTypes(const QVector<int>& t)
{
  TRACE;
  int n = t.count();
  for(int i=0;i<n;i++) {
    _parser->setType( i, t[i] );
  }
}

/*!
  Sets file to parse.

  \sa setBuffer()
*/
bool ColumnTextWidget::setFile(const QString& fileName)
{
  TRACE;
  delete _file;
  _file=new QFile(fileName);
  if ( !_file->open(QIODevice::ReadOnly)) {
    App::stream() << tr("Cannot read file %1").arg(fileName) << endl;
    delete _file;
    _file=0;
    return false;
  }
  _parser->setText(new QTextStream(_file));
  return true;
}

/*!
  Sets buffer to parse.

  \sa setFile()
*/
bool ColumnTextWidget::setBuffer(const QString& str)
{
  TRACE;
  delete _buffer;
  _buffer=new QString(str);
  _parser->setText(new QTextStream(_buffer));
  return true;
}

void ColumnTextWidget::on_linesBut_clicked()
{
  TRACE;
  ColumnTextLinesProperties * d = new ColumnTextLinesProperties(this);
  Settings::getRect( d, "ColumnTextLinesProperties" );
  d->isStartLine->setChecked( _parser->startLine()>0 );
  d->isEndLine->setChecked( _parser->endLine()>0 );
  d->startLine->setValue( _parser->startLine() );
  d->endLine->setValue( _parser->endLine() );
  d->acceptPattern->setText( _parser->acceptPattern() );
  d->rejectPattern->setText( _parser->rejectPattern() );
  d->hasComments->setChecked(_parser->hasComments());
  d->updateWidgets();
  if( d->exec() == QDialog::Accepted ) {
    Settings::setRect( d, "ColumnTextLinesProperties" );
    _parser->stopUpdates();
    _parser->setStartLine( d->isStartLine->isChecked() ? d->startLine->value() : 0 );
    _parser->setEndLine( d->isEndLine->isChecked() ? d->endLine->value() : 0 );
    _parser->setAcceptPattern( d->acceptPattern->text() );
    _parser->setRejectPattern( d->rejectPattern->text() );
    _parser->setHasComments(d->hasComments->isChecked());
    _parser->startUpdates();
  }
  delete d;
}

void ColumnTextWidget::on_parserName_editTextChanged(const QString& text)
{
  TRACE;
  setParserFile(text);
}

void ColumnTextWidget::on_columnsBut_clicked()
{
  TRACE;
  ColumnTextColumnsProperties * d = new ColumnTextColumnsProperties(this);
  Settings::getRect( d, "ColumnTextColumnsProperties" );
  if (_parser->isFixedWidth())
    d->fixedWidthsOption->setChecked(true);
  else
    d->delimitersOption->setChecked(true);
  d->tabDelimiter->setChecked(_parser->delimiters().contains("\t"));
  d->spaceDelimiter->setChecked(_parser->delimiters().contains(" "));
  d->otherDelimiters->setText(_parser->delimiters().replace(QRegExp("[ \t]"),""));
  d->acceptNullColumns->setChecked(_parser->acceptNullColumns() );
  d->maximumColumnCount->setValue(_parser->maximumColumnCount());
  d->columnWidths->setText(_parser->columnWidths());
  d->updateWidgets();
  if(d->exec()==QDialog::Accepted) {
    Settings::setRect(d, "ColumnTextColumnsProperties");
    _parser->stopUpdates();
    _parser->setFixedWidth(d->fixedWidthsOption->isChecked());
    _parser->setDelimiters(d->delimiters());
    _parser->setAcceptNullColumns(d->acceptNullColumns->isChecked());
    _parser->setMaximumColumnCount(d->maximumColumnCount->value());
    _parser->setColumnWidths(d->columnWidths->text());
    _parser->startUpdates();
  }
  delete d;
}

void ColumnTextWidget::on_sectionsBut_clicked()
{
  TRACE;
  ColumnTextSectionsProperties * d = new ColumnTextSectionsProperties(this);
  Settings::getRect( d, "ColumnTextSectionsProperties" );
  d->isLinePattern->setChecked( _parser->isSectionLinePattern() );
  d->linePattern->setText( _parser->sectionLinePattern() );
  d->isLineCount->setChecked( _parser->isSectionLineCount() );
  d->lineCount->setValue( _parser->sectionLineCount() );
  d->isRowCount->setChecked( _parser->isSectionRowCount() );
  d->rowCount->setValue( _parser->sectionRowCount() );
  d->isCellPattern->setChecked( _parser->isSectionCellPattern() );
  d->cellColumn->setValue( _parser->sectionCellColumn() );
  d->cellPattern->setText( _parser->sectionCellPattern() );
  d->updateWidgets();
  if( d->exec() == QDialog::Accepted ) {
    Settings::setRect( d, "ColumnTextSectionsProperties" );
    _parser->stopUpdates();
    _parser->setSectionLinePattern( d->isLinePattern->isChecked() );
    _parser->setSectionLinePattern( d->linePattern->text() );
    _parser->setSectionLineCount( d->isLineCount->isChecked() );
    _parser->setSectionLineCount( d->lineCount->value() );
    _parser->setSectionRowCount( d->isRowCount->isChecked() );
    _parser->setSectionRowCount( d->rowCount->value() );
    _parser->setSectionCellPattern( d->isCellPattern->isChecked() );
    _parser->setSectionCellColumn( d->cellColumn->value() );
    _parser->setSectionCellPattern( d->cellPattern->text() );
    _parser->startUpdates();
  }
  delete d;
}

void ColumnTextWidget::on_loadBut_clicked()
{
  TRACE;
  QString str = Message::getOpenFileName(tr("Load parser"),
                                         tr("Column text parser (*.ctparser)") );
  setParserFile(str);
}

void ColumnTextWidget::on_saveBut_clicked()
{
  TRACE;
  QString str=Message::getSaveFileName(tr("Save parser"), tr("Column text parser (*.ctparser)"));
  if (!str.isEmpty()) {
    XMLHeader hdr(_parser);
    hdr.xml_saveFile(str);
    _parserFile=str;
    parserName->setEditText(_parserFile);
  }
}

void ColumnTextWidget::restoreParserSettings(QString keyName)
{
  parserName->addItem(QString::null);
  parserName->addItems(Settings::getHistory("ColumnTextParsers/"+keyName));
}

void ColumnTextWidget::saveParserSettings(QString keyName)
{
  Settings::setHistory("ColumnTextParsers/"+keyName, _parserFile);
}

void ColumnTextWidget::setParserFile(const QString& p)
{
  TRACE;
  if (!p.isEmpty()) {
    _parser->stopUpdates();
    XMLHeader hdr(_parser);
    if (hdr.xml_restoreFile(p)==XMLClass::NoError) {
      if (_parserFile!=p) {
        _parserFile=p;
        QFileInfo fi(_parserFile);
        _restoreColumnWidth = "ColumnTextParsers/"+fi.baseName();
        parserName->setEditText(_parserFile);
        Settings::setHistory("ColumnTextWidget/parserName", _parserFile);
      }
    }
    _parser->startUpdates();
  }
}

/*!
  Forces file parsing. Must be called before first show and after setting all
  parameters.
*/
void ColumnTextWidget::parse()
{
  TRACE;
  QString pn=parserName->currentText();
  if(pn.isEmpty()) {
    _parser->stopUpdates();
    _parser->startUpdates();
  } else {
    setParserFile(pn);
  }
}

} // namespace QGpGuiTools
