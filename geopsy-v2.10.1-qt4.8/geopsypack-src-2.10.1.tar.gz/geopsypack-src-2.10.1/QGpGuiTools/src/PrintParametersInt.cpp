/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2003-08-22
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "PrintParametersInt.h"

namespace QGpGuiTools {

PrintParametersInt::PrintParametersInt(QObject * parent)
 : QObject(parent)
{
  TRACE;
  _orientation=QPrinter::Portrait;
  _pageSize=QPrinter::A4;
  _colorMode=QPrinter::Color;
  _from=0;
  _to=0;
  _numCopies=1;
}

QString PrintParametersInt::orientation() const
{
  TRACE;
  switch (_orientation) {
  case QPrinter::Portrait:
    return "Portrait";
  case QPrinter::Landscape:
    return "Landscape";
  }
  return "Undefined";
}

QString PrintParametersInt::pageSize() const
{
  TRACE;
  switch (_pageSize) {
  case QPrinter::A4:
    return "A4";
  case QPrinter::B5:
    return "B5";
  case QPrinter::Letter:
    return "Letter";
  case QPrinter::Legal:
    return "Legal";
  case QPrinter::Executive:
    return "Executive";
  case QPrinter::A0:
    return "A0";
  case QPrinter::A1:
    return "A1";
  case QPrinter::A2:
    return "A2";
  case QPrinter::A3:
    return "A3";
  case QPrinter::A5:
    return "A5";
  case QPrinter::A6:
    return "A6";
  case QPrinter::A7:
    return "A7";
  case QPrinter::A8:
    return "A8";
  case QPrinter::A9:
    return "A9";
  case QPrinter::B0:
    return "B0";
  case QPrinter::B1:
    return "B1";
  case QPrinter::B2:
    return "B2";
  case QPrinter::B3:
    return "B3";
  case QPrinter::B4:
    return "B4";
  case QPrinter::B6:
    return "B6";
  case QPrinter::B7:
    return "B7";
  case QPrinter::B8:
    return "B8";
  case QPrinter::B9:
    return "B9";
  case QPrinter::B10:
    return "B10";
  case QPrinter::C5E:
    return "C5E";
  case QPrinter::Comm10E:
    return "Comm10E";
  case QPrinter::DLE:
    return "DLE";
  case QPrinter::Folio:
    return "Folio";
  case QPrinter::Ledger:
    return "Ledger";
  case QPrinter::Tabloid:
    return "Tabloid";
  case QPrinter::Custom:
    return "Custom";
  }
  return "Undefined";
}

QString PrintParametersInt::colorMode() const
{
  TRACE;
  switch (_colorMode) {
  case QPrinter::Color:
    return "Color";
  case QPrinter::GrayScale:
    return "GrayScale";
  }
  return "Undefined";
}

QString PrintParametersInt::pageOrder() const
{
  TRACE;
  switch (_pageOrder) {
  case QPrinter::FirstPageFirst:
    return "FirstPageFirst";
  case QPrinter::LastPageFirst:
    return "LastPageFirst";
  }
  return "Undefined";
}

void PrintParametersInt::setOrientation(QString val)
{
  TRACE;
  val=val.toLower();
  if (val=="portrait") _orientation=QPrinter::Portrait;
  else if (val=="landscape") _orientation=QPrinter::Landscape;
}

void PrintParametersInt::setPageSize(QString val)
{
  TRACE;
  val=val.toLower();
  if (val=="a4") _pageSize=QPrinter::A4;
  else if (val=="b5") _pageSize=QPrinter::B5;
  else if (val=="letter") _pageSize=QPrinter::Letter;
  else if (val=="legal") _pageSize=QPrinter::Legal;
  else if (val=="executive") _pageSize=QPrinter::Executive;
  else if (val=="a1") _pageSize=QPrinter::A1;
  else if (val=="a2") _pageSize=QPrinter::A2;
  else if (val=="a3") _pageSize=QPrinter::A3;
  else if (val=="a5") _pageSize=QPrinter::A5;
}

void PrintParametersInt::setPageOrder(QString val)
{
  TRACE;
  val=val.toLower();
  if (val=="firstpagefirst") _pageOrder=QPrinter::FirstPageFirst;
  else if (val=="lastpagefirst") _pageOrder=QPrinter::LastPageFirst;
}

void PrintParametersInt::setColorMode(QString val)
{
  TRACE;
  val=val.toLower();
  if (val=="color") _colorMode=QPrinter::Color;
  else if (val=="grayscale") _colorMode=QPrinter::GrayScale;
}

QString PrintParametersInt::currentSettings() const
{
  TRACE;
  QString ret;
  ret="Orientation = ";
  ret+=orientation();
  ret+=", PageSize = ";
  ret+=pageSize();
  ret+=", PageOrder = ";
  ret+=pageOrder();
  ret+=", ColorMode = ";
  ret+=colorMode();
  ret+=QString(", FromPage = %1").arg(_from);
  ret+=QString(", ToPage = %1").arg(_to);
  ret+=QString(", NumCopies = %1").arg(_numCopies);
  return ret;
}

} // namespace QGpGuiTools
