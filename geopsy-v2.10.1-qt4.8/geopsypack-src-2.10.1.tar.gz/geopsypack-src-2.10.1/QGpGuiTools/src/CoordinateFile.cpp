/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-09-16
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "CoordinateFile.h"
#include "CoordinateConvert.h"
#include "Dialog.h"
#include "ColumnTextWidget.h"

namespace QGpGuiTools {

  /*!
    \class CoordinateFile CoordinateFile.h
    \brief Brief description of class still missing

    Full description of class still missing
  */

  const QString CoordinateFile::fileFilter=
      QT_TRANSLATE_NOOP("CoordinateFile", "Coordinate file (*);;Coordinate file (*.coord);;"
                                            "Google Earth KML (*.kml)");

  /*!
  Description of constructor still missing
  */
  CoordinateFile::CoordinateFile()
  {
    TRACE;
  }

  /*!
    Description of destructor still missing
  */
  CoordinateFile::~CoordinateFile()
  {
    TRACE;
  }

  bool CoordinateFile::read (QString fileName, QString format)
  {
    TRACE;
    if(fileName.isEmpty()) {
      fileName=Message::getOpenFileName(tr("Load coordinates"), CoordinateFile::fileFilter);
      if(fileName.isEmpty()) {
        return false;
      }
    }
    bool res;
    Dialog * d=new Dialog;
    ColumnTextWidget * dg=new ColumnTextWidget;
    static QStringList types;
    if (types.isEmpty()) {
      // Order here is quite important, see parse() in case of modification
      // 2 to 5: cartesian, 7 to 14: geographical
      types << tr("Station name")    // 1
            << tr("X (m)")           // 2
            << tr("X (km)")          // 3
            << tr("Y (m)")           // 4
            << tr("Y (km)")          // 5
            << tr("Z (m)")           // 6
            << tr("Longitude (D)")   // 7
            << tr("Longitude (M)")   // 8
            << tr("Longitude (S)")   // 9
            << tr("Longitude (DEG)") // 10
            << tr("Latitude (D)")    // 11
            << tr("Latitude (M)")    // 12
            << tr("Latitude (S)")    // 13
            << tr("Latitude (DEG)");  // 14
    }
    dg->setStandardTypes( types );
    QVector<int> defaultTypes;
    if(fileName.endsWith(".kml")) {
      GoogleEarthKML kml;
      XMLHeader hdr(&kml);
      if(hdr.xml_restoreFile(fileName, 0, XMLClass::XmlFile)!=XMLClass::NoError) {
        Message::warning(MSG_ID, tr("Loading Google Earth KML ..."),
                         tr("Error while reading file %1").arg(fileName), Message::cancel());
        return false;
      }
      QList<NamedPoint> list=kml.document().points();
      QString str;
      for(QList<NamedPoint>::iterator it=list.begin(); it!=list.end(); it++) {
        str+=it->toString(20)+"\n";
      }
      defaultTypes << 10 << 14 << 6 << 1;
      dg->parser()->setMaximumColumnCount(4);
      dg->setBuffer(str);
    } else {
      defaultTypes << 1 << 2 << 4 << 6;
      dg->setFile(fileName);
    }
    dg->setTypes(defaultTypes);
    if(!format.isEmpty()) {
      dg->setParserFile(format);
    }
    dg->restoreParserSettings("coordinateReader");
    d->addWidget(dg);
    CoordinateConvert * cc=new CoordinateConvert;
    d->addWidget(cc);
    d->addButtons();
    d->setWindowTitle(tr("Load coordinates"));
    Settings::getRect(d, "coordinateReader");
    Settings::getWidget(dg, "coordinateReader");
    Settings::getWidget(cc, "coordinateReader");
    dg->parse();
    while(d->exec()==QDialog::Accepted) {
      res=true;
      dg->saveParserSettings("coordinateReader");
      Settings::setWidget(dg, "coordinateReader");
      Settings::setWidget(cc, "coordinateReader");
      Settings::setRect(d, "coordinateReader");
      if(parse(dg->parser(), cc->localProjection->isChecked(), cc->ref->reference())) break;
      res=false;
    }
    delete d;
    return res;
  }

  bool CoordinateFile::parse(const ColumnTextParser * parser, bool localProjection, const Point2D& reference)
  {
    TRACE;
    int nColumns = parser->columnCount();
    int nRows = parser->rowCount();
    // Check whether we are in cartesian or geographical coordinates
    enum CoordinateType { Undefined, Cartesian, Geographical };
    CoordinateType coordType = Undefined;
    for(int i=0;i<nColumns;i++) {
      int type = parser->type(i);
      if (type>=2 && type<=5) {
        switch(coordType) {
        case Undefined:
          coordType = Cartesian;
        case Cartesian:
          break;
        case Geographical:
          Message::warning( MSG_ID, tr("Read coordinates"),
                               tr("Mix of geographical and cartesian coordinates for column %1.").arg(i) );
          return false;
        }
      } else if (type>=7 && type<=14) {
        switch(coordType) {
        case Undefined:
          coordType = Geographical;
        case Geographical:
          break;
        case Cartesian:
          Message::warning( MSG_ID, tr("Read coordinates"),
                               tr("Mix of geographical and cartesian coordinates for column %1.").arg(i) );
          return false;
        }
      }
    }
    // Load coordinates
    _points.clear();
    for(int iRow=0;iRow<nRows;iRow++) {
      Point p;
      QString name;
      for(int iCol=0;iCol<nColumns;iCol++) {
        switch( parser->type(iCol) ) {
        case 1:
          name = parser->text( iRow, iCol );
          break;
        case 2:
          p.setX( parser->text( iRow, iCol ).toDouble() );
          break;
        case 3:
          p.setX( parser->text( iRow, iCol ).toDouble() * 1000.0 );
          break;
        case 4:
          p.setY( parser->text( iRow, iCol ).toDouble() );
          break;
        case 5:
          p.setY( parser->text( iRow, iCol ).toDouble() * 1000.0 );
          break;
        case 6:
          p.setZ( parser->text( iRow, iCol ).toDouble() );
          break;
        case 7:
          p.setX( p.x() + parser->text( iRow, iCol ).toDouble() );
          break;
        case 8:
          p.setX( p.x() + parser->text( iRow, iCol ).toDouble() / 60.0 );
          break;
        case 9:
          p.setX( p.x() + parser->text( iRow, iCol ).toDouble() / 3600.0 );
          break;
        case 10:
          p.setX( parser->text( iRow, iCol ).toDouble() );
          break;
        case 11:
          p.setY( p.y() + parser->text( iRow, iCol ).toDouble() );
          break;
        case 12:
          p.setY( p.y() + parser->text( iRow, iCol ).toDouble() / 60.0 );
          break;
        case 13:
          p.setY( p.y() + parser->text( iRow, iCol ).toDouble() / 3600.0 );
          break;
        case 14:
          p.setY( parser->text( iRow, iCol ).toDouble() );
          break;
        default:
          break;
        }
      }
      if (name.isEmpty()) {
        name=QString("p_%1").arg(iRow+1, 3, 10, QChar('0'));
        Message::warning(MSG_ID, tr("Read coordinates"), tr("Empty station name at line %1, using '%2' instead.")
                            .arg(parser->lineNumber(iRow)).arg(name), true);
      }
      _points.append( NamedPoint(name,p) );
    }
    // Convert to cartesian with the center of array as the reference
    if (coordType==Geographical) {
      App::stream() << tr("Converting from Geographical coordinates:") << endl;
      QList<NamedPoint>::iterator it;
      for (it=_points.begin(); it!=_points.end(); ++it) {
        App::stream() << tr("  %1 ---> ").arg(it->toString(10));
        if(localProjection) {
          it->geographicalToRectangular(reference);
          App::stream() << it->toString(10) << endl;
        } else {
          QString zone;
          it->geographicalToUTM(&zone);
          App::stream() << zone << " " << it->toString(10) << endl;
        }
      }
    }
    return true;
  }

  bool CoordinateFile::write(const QList<NamedPoint>& points, QString fileName)
  {
    TRACE;
    if(fileName.isEmpty()) {
      fileName=Message::getSaveFileName( tr("Save coordinates"), CoordinateFile::fileFilter);
      if(fileName.isEmpty()) {
        return false;
      }
    }
    if(fileName.endsWith(".kml")) {
      Dialog * d=new Dialog;
      GeographicalReference * dg=new GeographicalReference;
      d->setMainWidget(dg);
      d->setWindowTitle("Google Earth KML export");
      Settings::getWidget(dg, "CoordinateWriteKML");
      Settings::getRect(d, "CoordinateWriteKML");
      NamedPoint reference;
      if(d->exec()==QDialog::Accepted) {
        Settings::setWidget(dg, "CoordinateWriteKML");
        Settings::setRect(d, "CoordinateWriteKML");
        reference=dg->reference();
        delete d;
      } else {
        delete d;
        return false;
      }

      GoogleEarthKML kml;
      GoogleEarthKML::Document& doc=kml.document();
      QFileInfo fi(fileName);
      doc.setName(fi.baseName());
      GoogleEarthKML::Folder * f=doc.mainFolder();
      f->setName(fi.baseName());
      Point point;
      for(QList<NamedPoint>::const_iterator it=points.begin(); it!=points.end(); it++) {
        GoogleEarthKML::Placemark * p=new GoogleEarthKML::Placemark;
        p->setName(it->name());
        point=*it;
        point.rectangularToGeographical(reference);
        p->setCoordinates(point);
        f->addPlacemark(p);
      }
      return kml.save(fileName);
    } else {
      QFile f(fileName);
      if(!f.open(QIODevice::WriteOnly)) {
        Message::warning(MSG_ID, tr("Saving coordinates ..."),
                         tr("Error while writing to file %1").arg(fileName), Message::cancel());
        return false;
      }
      QTextStream s(&f);
      for(QList<NamedPoint>::const_iterator it=points.begin(); it!=points.end(); it++) {
        s << it->toString(20) << "\n";
      }
    }
    return true;
  }

} // namespace QGpGuiTools
