/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2010-06-23
**  Authors:
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "MultiDocumentTabBar.h"

namespace QGpGuiTools {

/*!
  \class MultiDocumentTabBar MultiDocumentTabBar.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
MultiDocumentTabBar::MultiDocumentTabBar(QWidget * parent)
    : QTabBar(parent)
{
  TRACE;
  setContextMenuPolicy(Qt::CustomContextMenu);
  connect(this, SIGNAL(customContextMenuRequested(const QPoint&)),
          this, SLOT(showContextMenu(const QPoint&)));

  QAction * a;

  a=new QAction(tr("New tab"), this);
  a->setToolTip(tr("Insert a new tab after this one (or before if it is the first tab)"));
  connect(a, SIGNAL(triggered()), this, SLOT(newTab()));
  addAction(a);

  a=new QAction(tr("Rename"), this);
  a->setToolTip(tr("Rename this tab"));
  connect(a, SIGNAL(triggered()), this, SLOT(renameTab()));
  addAction(a);

  a=new QAction(tr("Close"), this);
  a->setToolTip(tr("Close this tab"));
  connect(a, SIGNAL(triggered()), this, SLOT(closeTab()));
  addAction(a);
}

/*!
  Description of destructor still missing
*/
MultiDocumentTabBar::~MultiDocumentTabBar()
{
  TRACE;
}

void MultiDocumentTabBar::showContextMenu(const QPoint& pos)
{
  TRACE;
  int index=tabAt(pos);
  if(index>-1) {
    setCurrentIndex(index);
    QMenu::exec(actions(), mapToGlobal(pos), 0, this);
  }
}

void MultiDocumentTabBar::mouseDoubleClickEvent(QMouseEvent * event)
{
  TRACE;
  int index=tabAt(event->pos());
  if(index>-1) {
    emit renameTabRequested(index);
  }
}

void MultiDocumentTabBar::newTab()
{
  TRACE;
  emit newTabRequested(currentIndex());
}

void MultiDocumentTabBar::renameTab()
{
  TRACE;
  emit renameTabRequested(currentIndex());
}

void MultiDocumentTabBar::closeTab()
{
  TRACE;
  emit closeTabRequested(currentIndex());
}

} // namespace QGpGuiTools
