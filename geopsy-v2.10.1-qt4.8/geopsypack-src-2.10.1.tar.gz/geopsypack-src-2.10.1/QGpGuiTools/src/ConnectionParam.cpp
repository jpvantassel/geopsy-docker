/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2006-11-03
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "ConnectionParam.h"

namespace QGpGuiTools {

/*!
  \class ConnectionParam qtbconnectionparam.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
ConnectionParam::ConnectionParam( QWidget * parent )
    : Dialog(parent)
{
  TRACE;
  setupUi(this);

#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup( "connection" );
  if ( reg.value( "direct", false ).toBool() ) {
    directConnection->setChecked(true);
  } else  {
    proxyConnection->setChecked(true);
  }
  proxyServer->setText( reg.value("httpProxy", "www-cache").toString() );
  proxyPort->setValue( reg.value("httpProxyPort", 3128).toInt() );
  on_proxyConnection_toggled( proxyConnection->isChecked() );
}

/*!
  Description of destructor still missing
*/
ConnectionParam::~ConnectionParam()
{
  TRACE;
}

void ConnectionParam::on_proxyConnection_toggled( bool b )
{
  TRACE;
  proxyServerLabel->setEnabled( b);
  proxyServer->setEnabled( b);
  proxyPortLabel->setEnabled( b);
  proxyPort->setEnabled( b);
}

void ConnectionParam::saveParam()
{
  TRACE;
#ifdef Q_WS_MAC
  QSettings reg(qApp->organizationDomain());
#else
  QSettings reg(qApp->organizationName());
#endif
  reg.beginGroup( "connection" );
  reg.setValue( "direct", directConnection->isChecked() );
  reg.setValue( "httpProxy", proxyServer->text() );
  reg.setValue( "httpProxyPort", proxyPort->value() );
}


} // namespace QGpGuiTools
