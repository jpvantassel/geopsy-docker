/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2010-06-23
**  Authors:
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "MultiDocumentTab.h"
#include "MultiDocumentSubWindow.h"

namespace QGpGuiTools {

/*!
  \class MultiDocumentTab MultiDocumentTab.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
MultiDocumentTab::MultiDocumentTab(QWidget * parent)
    : QMdiArea(parent)
{
  TRACE;
  setAttribute(Qt::WA_DeleteOnClose);
  setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
  setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

  QMenu * m=new QMenu(this);
  _windowMenuAction=new QAction(tr("Unamed"), this);
  _windowMenuAction->setMenu(m);
  connect(_windowMenuAction, SIGNAL(triggered()), this, SLOT(activate()));
}

/*!
  Description of destructor still missing
*/
MultiDocumentTab::~MultiDocumentTab()
{
  TRACE;
}

void MultiDocumentTab::activate()
{
  TRACE;
  emit activateRequested(this);
}

void MultiDocumentTab::setName(const QString& n)
{
  TRACE;
  _windowMenuAction->setText(n);
}

QString MultiDocumentTab::name() const
{
  TRACE;
  return _windowMenuAction->text();
}

void MultiDocumentTab::setCloseMarks(bool c)
{
  TRACE;
  QList<QMdiSubWindow *>	wList=subWindowList();
  foreach(QMdiSubWindow * subw, wList) {
    MultiDocumentSubWindow * mywin=qobject_cast<MultiDocumentSubWindow *>(subw);
    ASSERT(mywin);
    mywin->setCloseMark(c);
  }
}

} // namespace QGpGuiTools
