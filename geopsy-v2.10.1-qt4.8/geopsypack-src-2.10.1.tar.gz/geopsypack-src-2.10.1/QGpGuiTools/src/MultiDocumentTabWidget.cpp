/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2010-06-23
**  Authors:
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "MultiDocumentTabWidget.h"
#include "MultiDocumentTab.h"
#include "MultiDocumentTabBar.h"
#include "Settings.h"

namespace QGpGuiTools {

/*!
  \class MultiDocumentTabWidget MultiDocumentTabWidget.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
MultiDocumentTabWidget::MultiDocumentTabWidget(QWidget * parent)
    : QTabWidget(parent)
{
  TRACE;
  connect(this, SIGNAL(tabCloseRequested(int)), this, SIGNAL(closeTabRequested(int)));
  MultiDocumentTabBar * tb=new MultiDocumentTabBar(this);
  connect(tb, SIGNAL(newTabRequested(int)), this, SIGNAL(newTabRequested(int)));
  connect(tb, SIGNAL(renameTabRequested(int)), this, SLOT(renameTab(int)));
  connect(tb, SIGNAL(closeTabRequested(int)), this, SIGNAL(closeTabRequested(int)));
  setTabBar(tb);
  setTabsClosable(true);
  setMovable(true);
  setDocumentMode(true);
}

/*!
  Description of destructor still missing
*/
MultiDocumentTabWidget::~MultiDocumentTabWidget()
{
  TRACE;
}

void MultiDocumentTabWidget::addTab(MultiDocumentTab * t)
{
  TRACE;
  connect(t, SIGNAL(activateRequested(QWidget *)), this, SLOT(setCurrentWidget(QWidget *)));
  QTabWidget::addTab(t, t->name());
}

void MultiDocumentTabWidget::insertTab(int at, MultiDocumentTab * t)
{
  TRACE;
  connect(t, SIGNAL(activateRequested(QWidget *)), this, SLOT(setCurrentWidget(QWidget *)));
  if(at==0 && count()>1) {
    QTabWidget::insertTab(at, t, t->name());
  } else {
    QTabWidget::insertTab(at+1, t, t->name());
  }
}

MultiDocumentTab * MultiDocumentTabWidget::tab(int index)
{
  TRACE;
  return qobject_cast<MultiDocumentTab *>(widget(index));
}

void MultiDocumentTabWidget::renameTab(int at)
{
  TRACE;
  MultiDocumentTab * t=tab(at);
  bool ok;
  QString text = Settings::getText(QApplication::activeWindow(),
                                   tr("Rename tab"),
                                   tr("Tab's name:"),
                                   QLineEdit::Normal, t->name(), &ok);
  if (ok) {
    t->setName(text);
    setTabText(at, text);
  }
}

} // namespace QGpGuiTools
