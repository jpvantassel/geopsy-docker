/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2006-01-11
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "Dialog.h"

namespace QGpGuiTools {

/*!
  \class Dialog Dialog.h
  \brief Dialog class for saving current rect in registry
  When a dialog box is not visible on the screen, it is not possible to retrieve its correct rectangle and
  state (maximized, minimized,...). This class dynamically store the rectangle while the dialog box is visible
  and save it to registry upon request, usually after Settings::setWidget().
*/

Dialog::Dialog(QWidget * parent, Qt::WFlags f)
  : QDialog(parent, f)
{
  TRACE;
  _vboxLayout=0;
}

void Dialog::resizeEvent(QResizeEvent * e)
{
  TRACE;
  setFrame(this);
  QDialog::resizeEvent(e);
}

void Dialog::moveEvent(QMoveEvent * e)
{
  TRACE;
  setFrame(this);
  QDialog::moveEvent(e);
}

/*!
  Shows any number of widgets (vertical layout) in a modal dialog box with bottom buttons.

  \sa addButtons(), setMainWidget()
*/
void Dialog::addWidget(QWidget * w)
{
  TRACE;
  if(!_vboxLayout) {
    _vboxLayout=new QVBoxLayout(this);
    _vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
  }
  _vboxLayout->addWidget(w);

  if(windowTitle().isEmpty()) setWindowTitle(w->windowTitle());
}

/*!
  Shows any number of widgets (vertical layout) in a modal dialog box with bottom buttons.
  At least one call to addWidget is required by calling this function.

  \sa addWidget(), setMainWidget()
*/
void Dialog::addButtons(Buttons b)
{
  TRACE;
  ASSERT(_vboxLayout);

  QDialogButtonBox * buttonBox=new QDialogButtonBox(this);
  switch(b) {
  case OkCancel:
    buttonBox->addButton(QDialogButtonBox::Ok);
    buttonBox->addButton(QDialogButtonBox::Cancel);
    connect (buttonBox, SIGNAL(accepted()), this, SLOT(accept()));
    connect (buttonBox, SIGNAL(rejected()), this, SLOT(reject()));
    break;
  case Close:
    buttonBox->addButton(QDialogButtonBox::Close);
    connect (buttonBox, SIGNAL(rejected()), this, SLOT(accept()));
    break;
  }
  _vboxLayout->addWidget(buttonBox);

  resize(minimumSizeHint());
}

/*!
  Shows any widget in a modal dialog box with bottom buttons.
  Convenient function for dialogs containing only one widget.
*/
void Dialog::setMainWidget(QWidget * w, Buttons b)
{
  TRACE;
  addWidget(w);
  addButtons(b);
}

void FileDialog::resizeEvent(QResizeEvent * e)
{
  TRACE;
  setFrame(this);
  QFileDialog::resizeEvent(e);
}

void FileDialog::moveEvent(QMoveEvent * e)
{
  TRACE;
  setFrame(this);
  QFileDialog::moveEvent(e);
}

void FrameGrabber::setRect( QWidget * w, QString name )
{
  TRACE;
  if (_valid) {
    QSettings reg;
    reg.beginGroup( "WidgetRect" );
    reg.beginGroup( name );
    reg.setValue( "x", _x );
    reg.setValue( "y", _y );
    if (w->isMaximized()) {
      reg.setValue( "width", -1 );
      reg.setValue( "height", -1 );
    } else {
      reg.setValue( "width", _width );
      reg.setValue( "height", _height );
    }
  }
}

} // namespace QGpGuiTools
