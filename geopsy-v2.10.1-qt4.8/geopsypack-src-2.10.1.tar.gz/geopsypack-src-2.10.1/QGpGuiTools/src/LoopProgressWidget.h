/***************************************************************************
**
**  This file is part of QGpGuiTools.
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Lesser General Public
**  License as published by the Free Software Foundation; either
**  version 2.1 of the License, or (at your option) any later version.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
**  License for more details.
**
**  You should have received a copy of the GNU Lesser General Public
**  License along with this library; if not, write to the Free Software
**  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-09-18
**  Authors :
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef LOOPPROGRESSWIDGET_H
#define LOOPPROGRESSWIDGET_H

#include <QtGui>
#include <QGpCoreTools.h>
#include "QGpGuiToolsDLLExport.h"

namespace QGpGuiTools {

class QGPGUITOOLS_EXPORT LoopProgressWidget : public QScrollArea
{
  Q_OBJECT
public:
  LoopProgressWidget( QWidget *parent = 0 );
  ~LoopProgressWidget();

  void setLoop( ParallelLoop * loop );
private slots:
  void setStatus(int processIndex, QString msg);
  void setProgress(int processIndex, int value);
  void initProgress(int processIndex, int maximumValue);
private:
  QList<QLabel *> _labelList;
  QList<QProgressBar *> _progressList;
};

} // namespace QGpGuiTools

#endif // LOOPPROGRESSWIDGET_H
