/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef TOOLARRAYBASE_H
#define TOOLARRAYBASE_H

#include <GeopsyGui.h>
#include <ArrayCore.h>

class ToolArrayBase :  public ToolBase
{
  Q_OBJECT
public:
  ToolArrayBase(QWidget * parent, int nChildren);

  void setTimeWindowLayer(TimeWindowList * winList);
protected:
  virtual const char * toolName()=0;
  // General initialization function
  bool initStations(SubSignalPool * subPool, WindowingParamWidget * winParam);
  // Painting time windows
  StationSignals * belongsTo(Signal * sig);
  // Log management
  void resetLogs();
  void writeParameterLogs(QString outputFile);
  void writeProcessLogs(QString outputFile);
protected:
  ArrayStations _array;
  QString _log;
  QString _initLog;
  QString _paramLog;
};

#endif // TOOLARRAYBASE_H
