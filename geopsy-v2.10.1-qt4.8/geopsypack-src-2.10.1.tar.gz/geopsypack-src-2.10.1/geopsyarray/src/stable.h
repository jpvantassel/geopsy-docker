#if defined __cplusplus
#include <QtGui>
#ifndef Q_WS_MAC
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include <SciFigs.h>
#include <GeopsyCore.h>
#include <GeopsyGui.h>
#include <QGpCoreWave.h>
#include <ArrayCore.h>
#include <ArrayGui.h>
#include <QGpGuiWave.h>
#include <DinverCore.h>
#include <DinverGui.h>
#include <DinverDCCore.h>
#include <QGpCompatibility.h>
#endif // Q_WS_MAC
#endif // __cplusplus
