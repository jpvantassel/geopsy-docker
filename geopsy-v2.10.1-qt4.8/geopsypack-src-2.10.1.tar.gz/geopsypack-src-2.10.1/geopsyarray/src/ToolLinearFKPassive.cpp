/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-11-06
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <ArrayCore.h>
#include <QGpGuiTools.h>
#include "ToolLinearFKPassive.h"
#include "LinearFKPassiveLoop.h"
#include "ToolFKd.h"

/*!
  \class ToolLinearFKPassive qtbtoollinearfkpassive.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

#define _fkBrowser static_cast<FKTimeWindows*>(_childrenList[0])

const char * ToolLinearFKPassive::toolName()
{
  return "Linear FK Array analysis for passive sources";
}

/*!
  Description of constructor still missing
*/
ToolLinearFKPassive::ToolLinearFKPassive(QWidget * parent)
    : ToolFK(parent)
{
  TRACE;
  setWindowTitle( "Linear FK for passive measurements Toolbox" );
  setObjectName("ToolLinearFKPassive");
}

bool ToolLinearFKPassive::initStations( SubSignalPool * subPool )
{
  if (!ToolFK::initStations( subPool )) return false;
  if (_array.components() != StationSignals::VerticalComponent) {
    Message::warning( MSG_ID, windowTitle(), tr( "Only vertical component are accepted for "
                         "pssive recording with linear arrays." ) );
    return false;
  }
  return true;
}

/*!
  Calculate the best fitting cross section
*/
double ToolLinearFKPassive::averageAzimuth() const
{
  TRACE;
  // Calculate the best fitting cross section
  Curve<Point> statList;
  for ( ArrayStations::const_iterator it = _array.begin();it != _array.end();++it ) {
    StationSignals * stat = *it;
    statList.append(stat->coordinates());
  }
  return statList.azimuth();
}

void ToolLinearFKPassive::start()
{
  TRACE;
  if (subPoolLocked()) return;
  resetLogs();
  // Get parameters from dialog box
  FKParameters * param = static_cast<FKParameters *>(parameters());
  if (!param) return;
  param->outputFile = _d->outputFile();
  param->setExportAllFKGrids( false );
  double azimuth = averageAzimuth();
  // Prepare loop
  LinearFKPassiveLoop * loop = new LinearFKPassiveLoop;
  loop->setArray( &_array );
  loop->setLog( &_log );
  if ( !loop->setParameters( param ) ) {
    delete loop;
    return;
  }
  loop->setAzimuth( azimuth );
  connect( loop, SIGNAL(finished()), this, SLOT(finishPositive()));
  startLoop(loop, param, tr("Running forwards..."));
}

void ToolLinearFKPassive::finishPositive()
{
  // Scan in azimuth opposite direction
  _d->mainStatus->setText(tr("Running backwards..."));
  LinearFKPassiveLoop * loop = static_cast<LinearFKPassiveLoop *>(_loop);
  loop->setAzimuth( loop->azimuth()-M_PI );
  disconnect( _loop, SIGNAL(finished()), this, SLOT(finishPositive()));
  connect( _loop, SIGNAL(finished()), this, SLOT(finish()));
  _loop->start(0, _param->frequencySampling.count());
}
