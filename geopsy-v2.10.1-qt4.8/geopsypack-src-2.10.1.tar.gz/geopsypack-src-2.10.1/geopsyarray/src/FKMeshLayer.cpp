/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-02-05
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <math.h>

#include <SciFigs.h>
#include "FKMeshLayer.h"

/*!
  \class FKMeshLayer qtbfkmeshlayer.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
FKMeshLayer::FKMeshLayer( AxisWindow * parent )
    : GraphContentLayer(parent)
{
  TRACE;
  _size = 0.03; // cm
  _kmin = 0.1;
  _kmax = 1.0;
  setOpacity(0.1);
}

/*!
  Description of destructor still missing
*/
FKMeshLayer::~FKMeshLayer()
{
  TRACE;
}

Rect FKMeshLayer::boundingRect() const
{
  TRACE;
  return Rect( -_kmax, -_kmax, _kmax, _kmax );
}

/*!
*/
void FKMeshLayer::paintData( const LayerPainterRequest& lp, QPainter& p, double dotpercm ) const
{
  TRACE;
  const GraphContentOptions& gc = lp.options();
  int pointSize, halfSize;
  double pointSizeF=_size * dotpercm;
  if (pointSizeF<=2.0) {
    pointSize = 2;
    halfSize = 1;
  } else {
    pointSize = ( int ) floor( pointSizeF + 0.5 );
    halfSize = ( int ) floor( 0.5 * pointSizeF+0.5 );
  }
  double invKmin = 1.0/_kmin;
  double kmax2 = _kmax*_kmax;
  int nNodes=(int)floor(2.0*_kmax*invKmin+0.5)+1;
  int ixMin, iyMin, ixMax, iyMax;
  ixMin = (int) floor( (gc.xVisMin() + _kmax)*invKmin );
  if (ixMin<0) ixMin=0;
  ixMax = (int) ceil( (gc.xVisMax() + _kmax)*invKmin );
  if (ixMax>nNodes) ixMax=nNodes;
  iyMin = (int) floor( (gc.yVisMin() + _kmax)*invKmin );
  if (iyMin<0) iyMin=0;
  iyMax = (int) ceil( (gc.yVisMax() + _kmax)*invKmin );
  if (iyMax>nNodes) iyMax=nNodes;

  p.setPen(QPen( Qt::black, 1 ));
  p.setBrush( QBrush( Qt::black, Qt::SolidPattern ) );
  if ( fabs(gc.ys2r( pointSize+2 )-gc.ys2r( 0 ) ) > _kmin ||
       fabs(gc.xs2r( pointSize+2 )-gc.xs2r( 0 ) ) > _kmin ) {
    int x1 = gc.xr2s( -_kmax );
    int y1 = gc.yr2s( -_kmax );
    int x2 = gc.xr2s( _kmax );
    int y2 = gc.yr2s( _kmax );
    if (x1>x2) std::swap( x1, x2 );
    if (y1>y2) std::swap( y1, y2 );
    p.drawEllipse( x1, y1, x2-x1, y2-y1 );
  } else {
    for ( int iy = iyMin;iy < iyMax;iy++ ) {
      if (lp.terminated()) return;
      double ky2 = (double)iy * _kmin - _kmax;
      int ory = gc.yr2s( ky2 ) - halfSize;
      ky2*=ky2;
      for ( int ix = ixMin;ix < ixMax;ix++ ) {
        double kx = (double)ix * _kmin - _kmax;
        if (kx*kx+ky2<kmax2) {
          int orx = gc.xr2s( kx ) - halfSize;
          p.drawEllipse( orx, ory, pointSize, pointSize );
        }
      }
    }
  }
}
