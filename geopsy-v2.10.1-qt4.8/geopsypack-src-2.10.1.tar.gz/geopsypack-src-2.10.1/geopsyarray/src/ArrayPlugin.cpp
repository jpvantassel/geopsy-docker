/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-11-14
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QAction>
#include <QApplication>
#include <qplugin.h>

#include <QGpCoreTools.h>
#include "ArrayPlugin.h"
#include "geopsyarrayVersion.h"
#include "geopsyarrayInstallPath.h"
#include "ToolFK.h"
#include "ToolHRFK.h"
#include "ToolSPAC.h"
#include "ToolLinearFKActive.h"
#include "ToolLinearFKPassive.h"


/*
   To test if there are missing symbols, uncomment the following lines and swith project template to 'app'
*/

/*int main(int argc, char ** argv)
{
  QApplication a( argc, argv );
  ArrayPlugin p;
  return 0;
}*/

void ArrayPlugin::createToolActions( QObject * toolFactory )
{
  TRACE;
  QAction * a;

  a = new QAction( toolFactory );
  a->setText( tr( "F-K" ) );
  a->setIcon( QIcon( ":/images/fk-22x22.png" ) );
  connect( a, SIGNAL( triggered() ), toolFactory, SLOT( showTool() ) );
  addAction( a );

  a = new QAction( toolFactory );
  a->setText( tr( "High resolution F-K" ) );
  a->setIcon( QIcon( ":/images/hrfk-22x22.png" ) );
  connect( a, SIGNAL( triggered() ), toolFactory, SLOT( showTool() ) );
  addAction( a );

  a = new QAction( toolFactory );
  a->setText( tr( "SPAC" ) );
  a->setIcon( QIcon( ":/images/spac-22x22.png" ) );
  connect( a, SIGNAL( triggered() ), toolFactory, SLOT( showTool() ) );
  addAction( a );

  a = new QAction( toolFactory );
  a->setText( tr( "Linear F-K for active experiments" ) );
  a->setIcon( QIcon( ":/images/linearfkactive-22x22.png" ) );
  connect( a, SIGNAL( triggered() ), toolFactory, SLOT( showTool() ) );
  addAction( a );

  a = new QAction( toolFactory );
  a->setText( tr( "Linear F-K for passive experiments" ) );
  a->setIcon( QIcon( ":/images/linearfkpassive-22x22.png" ) );
  connect( a, SIGNAL( triggered() ), toolFactory, SLOT( showTool() ) );
  addAction( a );
}

ToolBase * ArrayPlugin::createTool( int id, QWidget * wsParent ) const
{
  TRACE;
  switch (id) {
  case 0:
    return new ToolFK(wsParent);
  case 1:
    return new ToolHRFK(wsParent);
  case 2:
    return new ToolSPAC(wsParent);
  case 3:
    return new ToolLinearFKActive(wsParent);
  case 4:
    return new ToolLinearFKPassive(wsParent);
  default:
    return 0;
  }
}

void ArrayPlugin::setHelp( ApplicationHelp * h )
{
  TRACE;
  h->addGroup( tr("FK (tag=%1, slot=0)").arg(tag()), "fk" );
  h->addOption("-param <FILE.log>","Set processing parameters as specified in FILE.log");
  h->addOption("-export-grids","Export all FK grids for all frequency bands and time windows to files fkgrid_fxxx_twxxx (be careful, "
               "need a lot of disk space)");
  h->addOption("-f","Does not ask if .max file already exists.");

  h->addGroup( tr("High resolution FK (tag=%1, slot=1)").arg(tag()), "hrfk" );
  h->addOption("-param <FILE.log>","Set processing parameters as specified in FILE.log");
  h->addOption("-export-grids","Export all FK grids for all frequency bands and time windows to files fkgrid_fxxx_twxxx (be careful, "
               "need a lot of disk space)");
  h->addOption("-f","Does not ask if .max file already exists.");

  h->addGroup( tr("SPAC (tag=%1, slot=2)").arg(tag()), "spac" );
  h->addOption("-param <FILE.log>","Set processing parameters as specified in FILE.log");
  h->addOption("-rings <FILE.rings>","Load ring file FILE.rings (mandatory option)");

  h->addGroup( tr("Linear FK Active (tag=%1, slot=3)").arg(tag()), "linearfkactive" );
  h->addOption("-param <FILE.log>","Set processing parameters as specified in FILE.log");

  h->addGroup( tr("Linear FK Passive (tag=%1, slot=4)").arg(tag()), "linearfkpassive" );
  h->addOption("-param <FILE.log>","Set processing parameters as specified in FILE.log");

  h->addExample( "geopsy -db /home/mwathele/M2/database.gpy -tool geopsyarray -slot 0 -group "
                 "\"/333 sources/Array C/Vertical\" -- -param tmp.log",
                 "Open a database and start FK processing on group of signals named \"/333 sources/Array C/Vertical\". "
                 "Parameters are defined by \"tmp.log\" (format? see log file from a previous run).");
}

PACKAGE_INFO( geopsyarray, GEOPSYARRAY );
Q_EXPORT_PLUGIN2( geopsyarray, ArrayPlugin );
