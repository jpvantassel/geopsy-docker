/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "ToolSPACd.h"

ToolSPACd::ToolSPACd( QWidget* parent, Qt::WFlags fl )
    : QWidget( parent, fl )
{
  TRACE;
  setupUi( this );

  timeLimits->removeUseFirstOnly();
  winParam->removeFilterOption();
  winParam->setLength( WindowingParameters::FreqDep, 50.0 );
  freqSamp->setFileId("FREQUENCY");
  freqSamp->setUnit(tr(" Hz"));
  freqSamp->setPrecision( 2 );
  freqSamp->setSingleStep( 0.25 );
  freqSamp->setAdmissibleRange(1e-99, 1e99);
}

/*
 *  Destroys the object and frees any allocated resources
 */
ToolSPACd::~ToolSPACd()
{
  TRACE;
  // no need to delete child widgets, Qt does it all for us
}

void ToolSPACd::on_outputFileBrowse_clicked()
{
  TRACE;
  QString str = Message::getSaveFileName( tr( "Autocorrelation output file" ),
                                             tr( "SPAC output file (*.target *.stmap *.max)" ), outputFileEdit->text() );
  if ( str.length() > 0 ) {
    removeExtension(str);
    outputFileEdit->setText( str );
  }
}

void ToolSPACd::on_freqScroll_valueChanged(int)
{
  TRACE;
  Sampling fparam;
  freqSamp->getParameters(fparam);
  testFrequency->setValue(fparam.value(freqScroll->value()));
}

void ToolSPACd::removeExtension(QString& fileName)
{
  TRACE;
  if (fileName.endsWith(".stmap")) {
    fileName.chop(6);
    if (fileName.endsWith("_vertical")) fileName.chop(9);
    else if (fileName.endsWith("_radial")) fileName.chop(7);
    else if (fileName.endsWith("_transverse")) fileName.chop(11);
  } else if (fileName.endsWith(".max")) fileName.chop(4);
  else if (fileName.endsWith(".target")) fileName.chop(7);
}

QString ToolSPACd::outputFile()
{
  TRACE;
  if (outputFileEdit->text().isEmpty()) {
    on_outputFileBrowse_clicked();
    if (outputFileEdit->text().isEmpty()) return QString::null;
  }
  QString fileName = outputFileEdit->text();
  removeExtension(fileName);
  return fileName;
}

void ToolSPACd::getParameters( SPACParameters& param )
{
  TRACE;

  timeLimits->getParameters( param.timeLimits );
  winParam->getParameters( param.windowing );
  freqSamp->getParameters( param.frequencySampling );
  param.frequencyBandWidth = 0.1;
  // Output file not set here (useless and annoying for test)
  SPACParameters::OutputTypes output = SPACParameters::NoOutput;
  if (outputTarget->isChecked()) {
    output |= SPACParameters::Target;
  }
  if (outputStmap->isChecked()) {
    output |= SPACParameters::Stmap;
  }
  if (outputMax->isChecked()) {
    output |= SPACParameters::Max;
  }
  param.setOutputTypes( output );
}

void ToolSPACd::setRunning(bool r)
{
  TRACE;
  startBut->setEnabled(!r);
  stopBut->setEnabled(r);
  if(r) {
    mainStatus->setText(tr("Running..."));
  } else {
    mainStatus->setText(tr("Not running"));
  }
}
