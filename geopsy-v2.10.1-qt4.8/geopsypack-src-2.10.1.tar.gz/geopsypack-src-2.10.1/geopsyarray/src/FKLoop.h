/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-02-07
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef FKLOOP_H
#define FKLOOP_H

#include <ArrayCore.h>

class FKLoop: public ParallelLoop
{
public:
  FKLoop();
  ~FKLoop();

  void setArray( const ArrayStations * a );
  void setLog( QString * l ) { _log = l; }
  bool setParameters( FKParameters * p );

  bool hasComponent(int iComp) const {return _dotmax[iComp];}
  QFile * output(int iComp) const {return _dotmax[iComp];}
  void lockOutput(int iComp) const {_dotmaxMutex[iComp].lock();}
  void unlockOutput(int iComp) const {_dotmaxMutex[iComp].unlock();}
  void addLog(const QString& s) const;
protected:
  virtual LoopTask * newTask();

  const ArrayStations * _array;
  const FKParameters * _param;
private:
  QFile * initMaxFile(QString suffix) const;

  mutable QMutex _dotmaxMutex[3];
  QFile * _dotmax[3];
  mutable QMutex _logMutex;
  QString * _log;
};

class FKLoopTask : public LoopTask
{
public:
  FKLoopTask();
  ~FKLoopTask();

  virtual void setArray( const ArrayStations& array );
  virtual void setGrid();
  void setParameters( const FKParameters * param );
  void setLoop( const FKLoop * l ) { _loop = l; }
protected:
  virtual void run( int index );
  virtual void initGridValues() {}
  virtual void getPower( const Point2D& pos, double& beampower, double& semblance );
  virtual void exportMax();
  void exportGrid( QString baseName, int iOmega, int iWin);
  void exportResults( const Point2D& pos );

  const FKLoop * _loop;
  FKArrayProcess * _process;
  int _nStations, _currentComponent;
  double _nStations2;
  const TimeRange * _win;
  FKGridSearch * _grid[3];
};

#endif // FKLOOP_H
