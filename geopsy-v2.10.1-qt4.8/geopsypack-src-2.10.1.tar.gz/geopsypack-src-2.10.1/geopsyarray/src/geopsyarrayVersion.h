#ifndef GEOPSYARRAY_VERSION
#define GEOPSYARRAY_VERSION "2.6.0"
#define GEOPSYARRAY_VERSION_TIME "201605121341"
#define GEOPSYARRAY_VERSION_TYPE "testing"
#define GEOPSYARRAY_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)\nMarc Wathelet (ULg, Liège, Belgium)"
#endif // GEOPSYARRAY_VERSION
