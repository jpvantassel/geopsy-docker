/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-02-05
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef FKMESHLAYER_H
#define FKMESHLAYER_H

#include <SciFigs.h>

class FKMeshLayer : public GraphContentLayer
{
  Q_OBJECT
public:
  FKMeshLayer( AxisWindow * parent );
  ~FKMeshLayer();

  void setKmin( double k ) { _kmin = k; }
  double kmin() const { return _kmin; }

  void setKmax( double k ) { _kmax = k; }
  double kmax() const { return _kmax; }

  virtual Rect boundingRect() const;
protected:
  virtual void paintData ( const LayerPainterRequest& lp, QPainter& p, double dotpercm ) const;
private:
  double _kmin, _kmax;
  double _size; // point size in cm
};

#endif // FKMESHLAYER_H
