/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyGui.h>
#include <ArrayCore.h>
#include <QGpGuiTools.h>

#include "ToolHRFK.h"
#include "ToolFKd.h"
#include "HRFKLoop.h"
#include "HRFKTimeWindows.h"

#define _fkBrowser static_cast<HRFKTimeWindows*>(_childrenList[0])

const char * ToolHRFK::toolName()
{
  return "High resolution FK Array analysis";
}

ToolHRFK::ToolHRFK( QWidget * parent ) :
    ToolFK( parent )
{
  TRACE;
  setWindowIcon( QIcon( ":/images/hrfk-22x22.png" ) );
  setObjectName("ToolHRFK");
  setWindowTitle( "High resolution FK toolbox" );

  QGroupBox * hrParamGroup = new QGroupBox(_d->processingTab);
  hrParamGroup->setObjectName(QString::fromUtf8("hrParamGroup"));
  hrParamGroup->setTitle(tr("High resolution matrix"));
  QHBoxLayout * hboxLayout = new QHBoxLayout(hrParamGroup);
  hboxLayout->setObjectName(QString::fromUtf8("hboxLayout1"));
  doDampingFactor = new QCheckBox(hrParamGroup);
  doDampingFactor->setObjectName(QString::fromUtf8("doDampingFactor"));
  doDampingFactor->setText(tr("Damping factor"));
  connect( doDampingFactor, SIGNAL(toggled(bool)), this, SLOT(on_doDampingFactor_toggled()));

  hboxLayout->addWidget(doDampingFactor);

  dampingFactorEdit = new DoubleSpinBox(hrParamGroup);
  dampingFactorEdit->setObjectName(QString::fromUtf8("dampingFactorEdit"));
  dampingFactorEdit->setEnabled(false);
  dampingFactorEdit->setDecimals(4);
  dampingFactorEdit->setMaximum(1);
  dampingFactorEdit->setSingleStep(0.0005);
  dampingFactorEdit->setValue(0.001);

  hboxLayout->addWidget(dampingFactorEdit);

  static_cast<QBoxLayout *>(_d->processingTab->layout())->insertWidget(2, hrParamGroup);

  connect( dampingFactorEdit, SIGNAL( valueChanged( const QString& ) ), this, SLOT( parametersChanged() ) );
  connect( doDampingFactor, SIGNAL( toggled(bool) ), this, SLOT( parametersChanged() ) );
}

void ToolHRFK::on_doDampingFactor_toggled()
{
  TRACE;
  dampingFactorEdit->setEnabled( doDampingFactor->isChecked() );
}

void ToolHRFK::setDefaultGridStep(double kmin)
{
  TRACE;
  kmin*=0.2; // FK is already dividing by 4, we add a factor 5
  ToolFK::setDefaultGridStep(kmin);
}

FKParameters * ToolHRFK::parameters()
{
  TRACE;
  HRFKParameters * param = new HRFKParameters;
  _d->getParameters( *param );
  if (!checkParameters(param)) {
    delete param;
    return 0;
  }
  if (doDampingFactor->isChecked()) {
    param->setDamping( dampingFactorEdit->value() );
  } else {
    param->setDamping( 0.0 );
  }
  return param;
}

void ToolHRFK::test()
{
  if ( !_fkBrowser ) {
    _childrenList[ 0 ] = new HRFKTimeWindows;
    _fkBrowser->setObjectName( "HRFKBrowser" );
    _fkBrowser->setArray(_array);
    _fkBrowser->setTimeWindowLayer(timeWindowLayer());
    setTimeWindowLayer(_fkBrowser->timeWindowList());
    geopsyGui->addWindow( _fkBrowser );
  }
  geopsyGui->showWindow( _fkBrowser );
  QApplication::processEvents();
  parametersChanged();
  geopsyCore->showMessage( tr( "Signals are ready" ) );
}

void ToolHRFK::start()
{
  TRACE;
  if (subPoolLocked()) return;
  resetLogs();
  // Get parameters from dialog box
  HRFKParameters * param = static_cast<HRFKParameters *>(parameters());
  if (!param) return;
  param->outputFile = _d->outputFile();
  param->setExportAllFKGrids( _exportAllFKGrids );
  // Prepare the common parameters
  HRFKLoop * loop = new HRFKLoop;
  loop->setArray( &_array );
  loop->setLog( &_log );
  if ( !loop->setParameters( param ) ) {
    delete loop;
    return;
  }
  connect( loop, SIGNAL(finished()), this, SLOT(finish()));
  startLoop( loop, param );
}

QString ToolHRFK::logParameters() const
{
  TRACE;
  QString log = ToolFK::logParameters();
  log += "DO DAMPING FACTOR = ";
  log += doDampingFactor->isChecked() ? "true" : "false";
  log += "\n";
  log += "DAMPING FACTOR = " + QString::number(dampingFactorEdit->value()) + "\n";
  return log;
}

bool ToolHRFK::setLogParameters( QString& keyword, QString& value )
{
  TRACE;
  if ( ToolFK::setLogParameters( keyword, value ) );
  else if ( keyword.contains( "DO DAMPING FACTOR" ) )
    doDampingFactor->setChecked( value == "true" );
  else if ( keyword.contains( "DAMPING FACTOR" ) )
    dampingFactorEdit->setValue( value.toDouble() );
  else return false;
  return true;
}
