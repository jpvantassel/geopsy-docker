/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QStatusBar>

#include <GeopsyCore.h>
#include <GeopsyGui.h>
#include <ArrayCore.h>
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include <SciFigs.h>
#include "ToolArrayBase.h"

/*!
  \class ToolArrayBase qtbtoolarraybase.h
  \brief Abstract base class for all array techniques

  Stores the list of stations and log stream.
  Call beginProcess() and endProcess() to calculate the signal processing for all frequencies and time windows
  It initializes of structure ArrayProcess with contains parameters, current frequency and keep vector (for window placement).
*/

ToolArrayBase::ToolArrayBase( QWidget * parent, int nChildren ) :
    ToolBase( parent, nChildren )
{
  TRACE;
}

bool ToolArrayBase::initStations( SubSignalPool * subPool, WindowingParamWidget * winParam )
{
  TRACE;
  _subPool = subPool;
  _initLog = QString( "*********** %1 ***********\n" ).arg( _subPool->name() );
  geopsyCore->showMessage( tr( "Loading samples ..." ) );
  StationSignals::organizeSubPool( _subPool );
  if ( !_array.addSignals( _subPool , &_initLog ) ||
       !_array.hasAllComponents( &_initLog ) ||
       !_array.hasCompatibleStations( &_initLog ) ) {
    Message::warning( MSG_ID, tr("Checking stations"), _initLog, Message::cancel());
    return false;
  }
  if (_array.count()<2) {
    Message::warning( MSG_ID, tr("Creating array"),
                          tr( "Found less than 2 stations." ),
                          Message::cancel());
    return false;
  }
  _initLog += tr( "Found %1 different stations\n" ).arg( _array.count() );
  emit updateSubPool();
  App::stream() << _initLog << endl;
  if ( winParam ) {
    // Set station names in apply list
    for (int i = 0; i<_array.nComponents();i++) {
      winParam->addComponent( Signal::userName( _array.component(i) ) );
    }
    for (ArrayStations::iterator it=_array.begin();it!=_array.end();++it) {
      winParam->addStation( (*it)->name() );
    }
  }
  return true;
}

StationSignals * ToolArrayBase::belongsTo( Signal * sig )
{
  TRACE;
  QList<StationSignals *>::iterator it;
  for ( it = _array.begin();it != _array.end();++it ) {
    if ( (*it)->contains(sig) ) return *it;
  }
  return 0;
}

void ToolArrayBase::resetLogs()
{
  TRACE;
  _log = "";
  _paramLog = logParameters();
}

void ToolArrayBase::writeParameterLogs( QString outputFile )
{
  TRACE;
  QFileInfo fi( outputFile );
  QDir d( fi.absolutePath() );
  QFile f(d.absoluteFilePath( fi.baseName() + ".log" ) );
  if ( !f.open( QIODevice::WriteOnly ) ) {
    Message::warning( MSG_ID, toolName(),
                         tr("Cannot open .log file for writing"), Message::cancel());
    return;
  }
  QTextStream s(&f);
  s << "### Init Log ###\n";
  s << _initLog;
  s << "### End Init Log ###\n";
  s << "### Parameters ###\n";
  s << _paramLog;
  s << "### End Parameters ###" << endl;
}

void ToolArrayBase::writeProcessLogs( QString outputFile )
{
  TRACE;
  QFileInfo fi( outputFile );
  QDir d( fi.absolutePath() );
  QFile f(d.absoluteFilePath( fi.baseName() + ".log" ) );
  if ( !f.open( QIODevice::Append ) ) {
    Message::warning( MSG_ID, toolName(),
                         tr("Cannot open .log file for writing"), Message::cancel());
    return;
  }
  QTextStream s(&f);
  s << "### Process Log ###\n";
  s << _log;
  s << "### End Process Log ###" << endl;
}

/*!
  Add all station to time window layer
*/
void ToolArrayBase::setTimeWindowLayer(TimeWindowList * winList)
{
  TRACE;
  if (timeWindowLayer()) {
    int nComp = _array.nComponents();
    for ( QList<StationSignals *>::iterator it = _array.begin();it != _array.end();++it ) {
      for( int iComp = 0; iComp<nComp; iComp++ ) {
        const SubSignalPool subPool = (*it)->originals(iComp);
        for (SubSignalPool::const_iterator itSig = subPool.begin();itSig!=subPool.end(); itSig++) {
          timeWindowLayer()->addTimeWindows(*itSig, winList);
        }
      }
    }
  }
}
