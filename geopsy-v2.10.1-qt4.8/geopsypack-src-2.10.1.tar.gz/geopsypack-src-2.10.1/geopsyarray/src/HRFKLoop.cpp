/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-02-11
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <ArrayCore.h>
#include <GeopsyGui.h>

#include "HRFKLoop.h"

/*!
  \class HRFKLoop qtbhrfkloop.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

LoopTask * HRFKLoop::newTask()
{
  TRACE;
  HRFKLoopTask * t = new HRFKLoopTask;
  t->setLoop(this);
  t->setArray(*_array);
  t->setParameters(_param);
  t->setGrid();
  return t;
}

void HRFKLoopTask::setArray( const ArrayStations& array )
{
  TRACE;
  _process = new HRFKArrayProcess(array);
  _process->setTimeRangeList(new TimeWindowList);
}

void HRFKLoopTask::setGrid()
{
  TRACE;
  for (int iComp = 0; iComp<3; iComp++) {
    if (_loop->hasComponent(iComp)) {
      _grid[iComp] = new HRFKGridSearch;
      _grid[iComp]->setFunction( static_cast<HRFK *>(_process->function(iComp)) );
      const FKParameters * param = _process->parameters();
      _grid[iComp]->setGrid( param->minimumWaveNumber(), param->maximumWaveNumber() );
      _grid[iComp]->function()->setMaximumSlowness( param->maximumSlowness() );
    }
  }
}

void HRFKLoopTask::getPower( const Point2D& pos, double& beampower, double& semblance )
{
  TRACE;
  const FK * fk = _grid[_currentComponent]->function();
  beampower = fk->value( pos.x(), pos.y() );
  semblance = beampower;
  // Normalizations by number of stations or band width
  const FrequencyBand& fb = _process->frequency();
  double freqBandWidth= fb.width();
  if ( freqBandWidth > 0.0 )
    beampower = 10.0 * log10( beampower / ( 0.5 * freqBandWidth * _nStations2 ) );
  else
    beampower = 10.0 * log10( beampower / ( fb.center() * _nStations2 ) );
}

void HRFKLoopTask::initGridValues()
{
  TRACE;
  const HRFKParameters * param = static_cast<const HRFKParameters *>(_process->parameters());
  HRFK * fk = static_cast<HRFK *>(_grid[_currentComponent]->function());
  fk->initOperator( fk->crossCorrelationMatrix( _currentComponent ), param->damping() );
}
