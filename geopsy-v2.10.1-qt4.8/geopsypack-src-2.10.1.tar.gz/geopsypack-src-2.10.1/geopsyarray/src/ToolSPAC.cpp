/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-09
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverDCCore.h>
#include <GeopsyGui.h>
#include <ArrayCore.h>
#include <QGpCoreWave.h>

#include "ToolSPAC.h"
#include "ToolSPACd.h"
#include "SPACLoop.h"

#define MinCol 0
#define MaxCol 1
#define PairsNumCol 2
#define ColorCol 3

#define _arrayMap static_cast<ArrayMap*>(_childrenList[0])
#define _coArrayMap static_cast<ArrayMap*>(_childrenList[1])

const char * ToolSPAC::toolName()
{
  return "SPAC Array analysis";
}

ToolSPAC::ToolSPAC( QWidget * parent ) :
    ToolArrayBase( parent, 2 )
{
  TRACE;
  setWindowIcon( QIcon( ":/images/spac-22x22.png" ) );
  setObjectName("ToolSPAC");
  QVBoxLayout * baseLayout=new QVBoxLayout(this);
  _d = new ToolSPACd(this);
  baseLayout->addWidget( _d );
  setWindowTitle( "SPAC toolbox" );

  connect( _d->startBut, SIGNAL( clicked() ), this, SLOT( start() ) );
  connect( _d->stopBut, SIGNAL( clicked() ), this, SLOT( stop() ) );
  connect( _d->testBut, SIGNAL( clicked() ), this, SLOT( parametersChanged() ) );
  connect( _d->loadParam, SIGNAL( clicked() ), this, SLOT( loadLogParameters() ) );

  connect( _d->winParam, SIGNAL( parametersChanged() ), this, SLOT( parametersChanged() ) );
  connect( _d->timeLimits, SIGNAL( parametersChanged() ), this, SLOT( parametersChanged() ) );
  connect( _d->testFrequency, SIGNAL( valueChanged( const QString& ) ), this, SLOT( parametersChanged() ) );
  _loop=0;
}

ToolSPAC::~ToolSPAC()
{
  TRACE;
}

void ToolSPAC::updateAllFields()
{
  TRACE;
  _d->winParam->updateAllFields();
  _d->timeLimits->updateAllFields();
}

bool ToolSPAC::initStations( SubSignalPool * subPool )
{
  TRACE;
  if ( !ToolArrayBase::initStations( subPool, _d->winParam ) ) return false;
  switch ( _array.components() ) {
  case StationSignals::VerticalComponent:
  case StationSignals::AllComponent:
    break;
  default:
    Message::warning( MSG_ID, tr("Creating array"),
                          tr( "Error while checking components: only vertical or 3 components allowed." ),
                          Message::cancel());
    return false;
  }
  _d->timeLimits->setPicks( _subPool );
  // Create children plots: coordinates and azimuth
  if ( !_arrayMap || !_coArrayMap ) {
    _childrenList[ 0 ] = new ArrayMap;
    _childrenList[ 1 ] = new ArrayMap;
    _arrayMap->QWidget::resize( 300, 300 ); // default size
    _arrayMap->setObjectName( "arrayMap" );
    _arrayMap->setWindowTitle( tr( "%1 - array map" ).arg( _subPool->name() ) );
    _arrayMap->setAttribute( Qt::WA_DeleteOnClose, false );
    _coArrayMap->QWidget::resize( 300, 300 ); // default size
    _coArrayMap->setObjectName( "coArrayMap" );
    _coArrayMap->setWindowTitle( tr( "%1 - co-array map " ).arg( _subPool->name() ) );
    _coArrayMap->setAttribute( Qt::WA_DeleteOnClose, false );
    _d->ringEdit->setCoArrayGraph( _coArrayMap );
    geopsyGui->addWindow( _arrayMap );
    geopsyGui->addWindow( _coArrayMap );
  }
  setArrayMap();
  setCoArrayMap();
  geopsyGui->showWindow( _arrayMap );
  geopsyGui->showWindow( _coArrayMap );
  if (timeWindowLayer()) {
    setTimeWindowLayer(&_winList);
  }
  emit updateSubPool();
  return true;
}

SPACParameters * ToolSPAC::parameters()
{
  TRACE;
  SPACParameters * param = new SPACParameters;
  _d->getParameters( *param );
  // get rings
  int nRings = _d->ringEdit->rings->rowCount();
  for ( int i = 0;i < nRings;i++ ) {
    param->addRing( _stationCouples,
                    _d->ringEdit->rings->item( i, RingEditor_MinCol ) ->text().toDouble(),
                    _d->ringEdit->rings->item( i, RingEditor_MaxCol ) ->text().toDouble() );
  }
  return param;
}

/*!
  Just computes and shows time window selection
*/
void ToolSPAC::parametersChanged()
{
  if (timeWindowLayer() && _d->testBut->isChecked()) {
    SPACArrayProcess process(_array);
    process.setTimeRangeList(&_winList);
    process.setParameters(parameters(), false);
    LayerLocker ll(timeWindowLayer());
    process.setFrequency(_d->testFrequency->value());
    process.setTimeRangeList(0); // windows are not deleted by process
    timeWindowLayer()->deepUpdate();
  }
}

void ToolSPAC::start()
{
  TRACE;
  if (subPoolLocked()) return;
  resetLogs();
  // Get parameters from dialog box
  SPACParameters * param = parameters();
  param->outputFile = _d->outputFile();
  // Prepare loop
  geopsyCore->setProgressMaximum( param->frequencySampling.count() );
  SPACLoop * loop = new SPACLoop;
  loop->setArray( &_array );
  loop->setLog( &_log );
  if (!loop->setParameters( param )) {
    delete loop;
    return;
  }
  connect( loop, SIGNAL(finished()), this, SLOT(finish()));
  startLoop( loop, param );
}

void ToolSPAC::startLoop( SPACLoop * loop, SPACParameters * param )
{
  _d->detailedStatus->setLoop( loop );
  _loop = loop;
  _param = param;
  // Start main loop
  lockSubPool(); // Prevent any change on the orignal signals
  _d->setRunning(true);
  writeParameterLogs( _param->outputFile );
  _log += tr("Process started at %1\n").arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
  _chrono.start();
  _loop->start(0, _param->frequencySampling.count());
}

void ToolSPAC::finish()
{
  QTime timeElapsed(0,0);
  _log += tr("Process run in %1\n").arg(timeElapsed.addMSecs(_chrono.elapsed()).toString("hh:mm:ss"));
  _log += tr("Process ended at %1\n").arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
  delete _loop;
  _loop = 0;
  writeProcessLogs( _param->outputFile );
  unlockSubPool();
  _param = 0;
  _d->setRunning(false);
}

void ToolSPAC::waitFinished()
{
  TRACE;
  if(_loop) {
    _loop->waitFinished();
  }
}

void ToolSPAC::stop()
{
  TRACE;
  if(_loop) {
    _loop->terminate();
  }
}

QString ToolSPAC::logParameters() const
{
  TRACE;
  QString log;
  _d->winParam->exportParameters( log );
  _d->freqSamp->exportParameters( log );
  _d->timeLimits->exportParameters( log );
  log += QString("OUTPUT TARGET FILE = ") + (_d->outputTarget->isChecked() ? "y" : "n") + "\n";
  log += QString("OUTPUT STMAP FILE = ") + (_d->outputStmap->isChecked() ? "y" : "n") + "\n";
  log += QString("OUTPUT MAX FILE = ") + (_d->outputMax->isChecked() ? "y" : "n") + "\n";
  log += "OUTPUT FILE = " + _d->outputFileEdit->text() + "\n";
  return log;
}

bool ToolSPAC::setLogParameters( QString& keyword, QString& value )
{
  TRACE;
  if ( _d->winParam->loadParameters( keyword, value ) ) ;
  else if ( keyword.contains( "OUTPUT FILE" ) )
    _d->outputFileEdit->setText( value );
  else if ( keyword.contains( "OUTPUT TARGET FILE" ) )
    _d->outputTarget->setChecked( value == "y" );
  else if ( keyword.contains( "OUTPUT STMAP FILE" ) )
    _d->outputStmap->setChecked( value == "y" );
  else if ( keyword.contains( "OUTPUT MAX FILE" ) )
    _d->outputMax->setChecked( value == "y" );
  else if ( _d->freqSamp->loadParameters( keyword, value ) );
  else if ( _d->timeLimits->loadParameters( keyword, value ) );
  else return false;
  return true;
}

void ToolSPAC::setRings( QString fileName )
{
  TRACE;
  _d->ringEdit->load( fileName );
}

void ToolSPAC::setArrayMap()
{
  TRACE;
  int n = _array.count();
  NameLineLayer * plot = _arrayMap->mapLayer();
  LayerLocker ll(plot);
  NameLine * l = static_cast<NameLine *>( _arrayMap->line(0) );
  Curve<NamedPoint>& c = l->curve();
  c.resize( n );
  StationSignals * stat;
  for ( int i = 0;i < _array.count(); i++ ) {
    NamedPoint& p = c[ i ];
    stat = _array.at( i );
    _log += QString( "Station %1, coord %2\n" ).
            arg( stat->name() ).arg( stat->coordinates().toString() );
    p = stat->coordinates();
    p.setName(stat->name());
  }
  _arrayMap->setLimitsArray();
}

void ToolSPAC::setCoArrayMap()
{
  TRACE;
  // Construct the couple list
  int nStations = _array.count();
  int nCouples = nStations * ( nStations - 1 ) / 2;
  _stationCouples.resize(nCouples);
  QList<StationSignals *>::iterator statIt1, statIt2;
  int iCouple = 0;
  for ( statIt1 = _array.begin();statIt1 != _array.end();++statIt1 ) {
    statIt2 = statIt1;
    for ( ++statIt2;statIt2 != _array.end();++statIt2, iCouple++ )
      _stationCouples[ iCouple ].setStations( *statIt1, *statIt2 );
  }
  _initLog += tr( "Found %1 couples\n" ).arg( iCouple );

  NameLineLayer * plot = _coArrayMap->mapLayer();
  LayerLocker ll(plot);
  NameLine * l = static_cast<NameLine *>( _coArrayMap->line(0) );
  Curve<NamedPoint>& c = l->curve();
  c.resize( nCouples );
  for ( int i = 0;i < nCouples;i++ ) {
    NamedPoint& p = c[ i ];
    const StationCouple& couple = _stationCouples[ i ];
    const Point& p1 = couple.station1()->coordinates();
    const Point& p2 = couple.station2()->coordinates();
    double dx = p1.x() - p2.x();
    double dy = p1.y() - p2.y();
    if ( ( dx < 0 && dy > 0 ) || ( dx > 0 && dy < 0 ) ) p.setX( -fabs( dx ) ); else p.setX( fabs( dx ) );
    p.setY( fabs( dy ) );
    p.setName( couple.name() );
  }
  _coArrayMap->setLimitsCoArray( );
}

void ToolSPAC::setParameters( int& argc, char ** argv )
{
  TRACE;
  ToolBase::setParameters(argc, argv);
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-param") {
        CoreApplication::checkOptionArg(i, argc, argv);
        loadLogParameters( argv[i] );
      } else if (arg=="-rings") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _d->ringEdit->load( argv[i] );
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
}
