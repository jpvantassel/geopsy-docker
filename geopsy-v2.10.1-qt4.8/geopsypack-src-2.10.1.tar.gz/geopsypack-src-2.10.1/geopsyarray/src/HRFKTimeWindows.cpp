/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-06
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyGui.h>
#include <ArrayCore.h>

#include "HRFKTimeWindows.h"

void HRFKTimeWindows::setArray( const ArrayStations& array )
{
  // Check whether there are multi component
  StationSignals::Components c = array.components();
  if (c & StationSignals::VerticalComponent) {
    component->addItem(tr("Vertical"));
  }
  if (c & StationSignals::HorizontalComponent) {
    component->addItem(tr("Horizontal"));
    component->addItem(tr("North"));
    component->addItem(tr("East"));
  }
  _process = new HRFKArrayProcess(array);
  _process->setTimeRangeList(new TimeWindowList);
}

void HRFKTimeWindows::setCurrentWindow()
{
  FKTimeWindows::setCurrentWindow();
  setComponent();
}

void HRFKTimeWindows::setComponent()
{
  TRACE;
  if ( _currentWindow<0 ) return ;

  HRFK * fk = static_cast<HRFK *>(_process->function(0));
  double damping = static_cast<HRFKArrayProcess *>(_process)->parameters()->damping();
  double winLength = _process->timeRangeList()->at(_currentWindow).lengthSeconds();
  fk->setMaximumWavenumber(1e99); // No limit for plot
  fk->setMaximumSlowness(1e99);
  fk->setFrequencyBand( _process->frequency(), winLength );
  Complex * covmat;
  if (component->currentText()==tr("North")) {
    covmat = fk->crossCorrelationMatrix( 1 );
  } else if (component->currentText()==tr("East")) {
    covmat = fk->crossCorrelationMatrix( 2 );
  } else if (component->currentText()==tr("Horizontal")) {
    covmat = fk->crossCorrelationMatrix( direction->value() );
  } else {
    covmat = fk->crossCorrelationMatrix( 0 );
  }
  fk->initOperator(covmat, damping);

  _gridLayer->setFunction( fk );
  waveNumGrid->deepUpdate();
}
