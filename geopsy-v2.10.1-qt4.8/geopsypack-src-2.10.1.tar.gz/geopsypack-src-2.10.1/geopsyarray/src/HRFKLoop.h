/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-02-11
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef HRFKLOOP_H
#define HRFKLOOP_H

#include <ArrayCore.h>
#include "FKLoop.h"

class HRFKLoop : public FKLoop
{
public:
  bool setParameters( HRFKParameters * p );
  const HRFKParameters * parameters() const { return reinterpret_cast<const HRFKParameters *>(_param); }
protected:
  virtual LoopTask * newTask();
};

inline bool HRFKLoop::setParameters( HRFKParameters * p )
{
  return FKLoop::setParameters(reinterpret_cast<FKParameters *>(p));
}

class HRFKLoopTask : public FKLoopTask
{
public:
  virtual void setArray( const ArrayStations& array );
  virtual void setGrid();
protected:
  virtual void initGridValues();
  virtual void getPower( const Point2D& pos, double& beampower, double& semblance );
};

#endif // HRFKLOOP_H
