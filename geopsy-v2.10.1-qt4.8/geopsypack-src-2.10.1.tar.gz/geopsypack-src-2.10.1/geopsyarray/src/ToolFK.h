/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef ToolFK_H
#define ToolFK_H

#include <ArrayCore.h>

#include "ToolArrayBase.h"

class ToolFKd;
class FKLoop;

class ToolFK : public ToolArrayBase
{
  Q_OBJECT
public:
  ToolFK(QWidget * parent);
  ~ToolFK();

  virtual bool initStations(SubSignalPool * subPool);
  virtual void setParameters( int& argc, char ** argv );
  virtual void waitFinished();
public slots:
  virtual void test();
  virtual void start();
  void stop();
protected slots:
  void parametersChanged();
  void kmaxChanged();
  void gridChanged();
  void finish();
  void setTemporaryKmax();
  void setComputedKmax();
protected:
  void setDefaultGridParameters();
  virtual void setDefaultGridStep(double kmin);
  virtual void setDefaultGridSize(double kmax);
  void startLoop(FKLoop * loop, FKParameters * param, const QString& message=QString::null);
  virtual FKParameters * parameters();
  virtual void updateAllFields();
  virtual const char * toolName();
  virtual bool setLogParameters(QString& keyword, QString& value);
  virtual QString logParameters() const;
  bool checkParameters(FKParameters * param) const;

  ToolFKd * _d;
  bool _exportAllFKGrids;
  // Kmax computation
  QTimer _kmaxTimer;
  bool _kmaxTouched, _kminTouched;
  KmaxSolver * _kmaxSolver;
  // Process loop members
  FKLoop * _loop;
  FKParameters * _param;
  QTime _chrono;
};

#endif
