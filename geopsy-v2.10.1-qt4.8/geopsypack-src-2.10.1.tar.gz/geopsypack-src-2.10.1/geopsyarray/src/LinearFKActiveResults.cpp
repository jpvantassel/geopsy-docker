/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-03-27
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyGui.h>
#include <QGpGuiTools.h>
#include <QGpGuiWave.h>
#include <SciFigs.h>
#include "LinearFKActiveResults.h"
#include "LinearFKActiveArrayStations.h"

/*!
  \class LinearFKActiveResults qtblinearfkactiveresults.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
LinearFKActiveResults::LinearFKActiveResults(QWidget* parent)
    : GraphicSheetMenu(parent)
{
  TRACE;
  Settings::getSize( this, "LinearFKActiveResults" );

  // Tools menu
  QMenu * m;
  QAction * a;

  m = addMenu( tr( "&Tools" ) );

  a = new QAction( tr( "Stack selected plots" ), this );
  a->setStatusTip( tr( "Grids of selected plot are stacked and a new plot is added" ) );
  connect( a, SIGNAL( triggered() ), this, SLOT( stackGrids() ) );
  m->addAction( a );

  m->addSeparator();

  a = new QAction( tr( "Pick curves" ), this );
  a->setStatusTip( tr( "Switch all selected graphs to pick mode (pick ordered)" ) );
  a->setCheckable(true);
  connect( a, SIGNAL( toggled(bool) ), this, SLOT( setPick(bool) ) );
  m->addAction( a );

  a = new QAction( tr( "Auto pick curves" ), this );
  a->setStatusTip( tr( "Scan grids to find the absolute maximum and start picking from there" ) );
  connect( a, SIGNAL( triggered() ), this, SLOT( autoPick() ) );
  m->addAction( a );

  a = new QAction( tr( "Export all curves" ), this );
  a->setStatusTip( tr( "Export al curves from all selected plots" ) );
  connect( a, SIGNAL( triggered() ), this, SLOT( exportCurves() ) );
  m->addAction( a );
}

/*!
  Description of destructor still missing
*/
LinearFKActiveResults::~LinearFKActiveResults()
{
  TRACE;
  Settings::setSize( this, "LinearFKActiveResults" );
}

ModalLine * LinearFKActiveResults::createReferenceLine()
{
  TRACE;
  ModalLine * line=new ModalLine;
  line->setPen(Pen(Qt::black, 0.6));
  line->setSymbol(Symbol(Symbol::Circle, 1.2, Pen( Qt::black, 0.0),
                         Brush(Qt::black, Qt::SolidPattern)));
  return line;
}

void LinearFKActiveResults::createObjects(const QList<LinearFKActiveArrayStations *>& arrays)
{
  TRACE;
  sheet()->setStatusBar(geopsyGui->statusBar());
  int n = arrays.count();
  double x = 0.5, y = 0.5;
  _gridLayers.resize(n);
  _curveLayers.resize(n);
  _limitLayers.resize(n);
  for ( int ig = 0;ig < n;ig++ ) {
    AxisWindow * w = addGraph();
    setGraphGeometry( w, x, 9, y+1, 9 );
    TextEdit * c = addText(x, y, 9, 1);
    c->setText( arrays.at(ig)->name() );
    x += 9;
    if ( x == 18.5 ) {x = 0.5;y += 10;}
    _gridLayers[ig]=new IrregularGrid2DPlot( w );
    _curveLayers[ig]=new LineLayer(w);
    _limitLayers[ig]=new DispersionLimitLayer(w);
    _curveLayers[ig]->setReferenceLine(createReferenceLine());
    _limitLayers[ig]->addLine();
  }
}

void LinearFKActiveResults::setXAxis(const Sampling& s)
{
  TRACE;
  int n = _gridLayers.count();
  for ( int ig = 0;ig < n;ig++ ) {
    AxisWindow * w = _gridLayers[ ig ]->graph();
    if(s.type()==Sampling::Linear) {
      w->xAxis()->setScaleType(Scale::Linear);
    } else {
      w->xAxis()->setScaleType(Scale::Log);
    }
    w->xAxis()->setRange(s.min(), s.max());
    _limitLayers[ig]->setFrequencySampling(s);
    w->updateInternalGeometry();
    w->deepUpdate();
  }
}

void LinearFKActiveResults::setYAxis(Scale::Type t, double min, double max)
{
  TRACE;
  int n = _gridLayers.count();
  for ( int ig = 0;ig < n;ig++ ) {
    AxisWindow * w = _gridLayers[ ig ]->graph();
    w->yAxis()->setScaleType(t);
    w->yAxis()->setRange(min, max);
    w->updateInternalGeometry();
    w->deepUpdate();
  }
}

void LinearFKActiveResults::setWaveLengthLimit(int ig, double wl)
{
  TRACE;
  _limitLayers[ig]->setConstantWaveNumber(0, 2.0*M_PI/wl);
  _limitLayers[ig]->graph()->deepUpdate();
}

bool LinearFKActiveResults::selectAll( QString title )
{
  int n = _gridLayers.count();
  for ( int ig = 0;ig < n;ig++ ) {
    if (_curveLayers[ ig ]->graph()->isSelected()) {
      return true;
    }
  }
  return _sheet.selectAll( title );
}

void LinearFKActiveResults::setPick(bool on)
{
  TRACE;
  int n = _gridLayers.count();
  for ( int ig = 0;ig < n;ig++ ) {
    if (_curveLayers[ ig ]->graph()->isSelected()) {
      _curveLayers[ig]->setTrackingAction( LineLayer::PickOrdered, on );
    }
  }
}

void LinearFKActiveResults::autoPick()
{
  TRACE;
  if (!selectAll(tr("Automatic picking"))) return;
  int n = _gridLayers.count();
  for ( int ig = 0;ig < n;ig++ ) {
    if (_curveLayers[ ig ]->graph()->isSelected()) {
      ModalCurve& curve = static_cast<ModalLine *>( _curveLayers[ig]->addLine() )->curve();
      curve = _gridLayers[ig]->grid().followMaximumX<ModalCurve, FactoryPoint>();
      _curveLayers[ig]->deepUpdate();
      emit newCurve( ig );
    }
  }
}

void LinearFKActiveResults::adjust( int ig, ModalCurve& curve, double min, double max, SamplingOptions options )
{
  TRACE;
  ASSERT( options & Function );
  // Transforms X scale according to options (log and inv)
  if ( options & InversedScale ) {
    curve.xInverse( options );
  }
  _gridLayers[ig]->grid().followMaximumX<ModalCurve, FactoryPoint>(curve, min, max);
  // Re-Transforms axis according options (log and inv)
  if ( options & InversedScale )
    curve.xInverse( options);
}

void LinearFKActiveResults::exportCurves()
{
  TRACE;
  if (!selectAll(tr("Export all curves"))) return;
  QString fileName = Message::getSaveFileName(tr("Export all curves"), tr("4 columns file(*)"));
  if ( !fileName.isEmpty() ) {
    QFile f( fileName );
    if ( !f.open( QIODevice::WriteOnly ) ) {
      Message::warning( MSG_ID, tr("Export all curves"),
                            tr("Impossible to access to file"), Message::cancel());
      return ;
    }
    QTextStream s( &f );
    int n = _gridLayers.count();
    DispersionProxy proxy;
    for ( int ig = 0;ig < n;ig++ ) {
      LineLayer * curveLayer = _curveLayers[ig];
      if (curveLayer->graph()->isSelected()) {
        proxy.setCurrentLayer(curveLayer);
        int n = curveLayer->count();
        s << "# Shot " << ig << endl;
        for (int i = 0;i<n;i++ ) {
          proxy.save(i, s);
        }
      }
    }
  }
}

void LinearFKActiveResults::stackGrids()
{
  TRACE;
  if (!selectAll(tr("Stack grids"))) return;
  IrregularGrid2D stackedGrid;
  int nStacks = 0;
  int n = _gridLayers.count();
  for ( int ig = 0;ig < n;ig++ ) {
    IrregularGrid2DPlot * gridLayer = _gridLayers[ig];
    if (gridLayer->graph()->isSelected()) {
      if (nStacks==0) {
        stackedGrid = gridLayer->grid();
        nStacks++;
      } else {
        stackedGrid += gridLayer->grid();
        nStacks++;
      }
    }
  }
  // Add plot
  if (nStacks>0) {
    double x = 0.5 + 9 * ( n % 2), y = 0.5 + ( n / 2 ) * 10;
    AxisWindow * w = addGraph();
    setGraphGeometry( w, x, 9, y+1, 9 );
    IrregularGrid2DPlot * gridLayer = new IrregularGrid2DPlot( w );
    _gridLayers.append( gridLayer );
    LineLayer * curveLayer = new LineLayer(w);
    curveLayer->setReferenceLine(createReferenceLine());
    _curveLayers.append( curveLayer );
    gridLayer->setGrid( stackedGrid );
    gridLayer->setLinearPalette( 0 );
    DispersionLimitLayer * dispLimitLayer=new DispersionLimitLayer(w);
    dispLimitLayer->addLine();
    _limitLayers.append(dispLimitLayer);
   // Add text label
    TextEdit * c = addText(x, y, 9, 1);
    c->setText( tr("Stack of %1 grids").arg(nStacks) );
    c->deepUpdate();
    // Copy axis range and scale from last plot
    AxisWindow * w1 = _gridLayers[n-1]->graph();
    emit newPlot( curveLayer, c->text() );
    w->xAxis()->setScaleType( w1->xAxis()->scaleType() );
    w->yAxis()->setScaleType( w1->yAxis()->scaleType() );
    w->xAxis()->setRange( w1->xAxis()->minimum(), w1->xAxis()->maximum() );
    w->yAxis()->setRange( w1->yAxis()->minimum(), w1->yAxis()->maximum() );
    w->updateInternalGeometry();
  }
}
