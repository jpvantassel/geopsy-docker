/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef TOOLSPACD_H
#define TOOLSPACD_H

#include <ArrayCore.h>
#include <ArrayGui.h>

#include "ui_ToolSPACd.h"

class ToolSPACd : public QWidget, public Ui::ToolSPACd
{
  Q_OBJECT
public:
  ToolSPACd( QWidget* parent = 0, Qt::WFlags fl = 0 );
  ~ToolSPACd();

  QString outputFile();
  void getParameters( SPACParameters& param );
  void setRunning(bool r);
public slots:
  void on_outputFileBrowse_clicked();
  void on_freqScroll_valueChanged(int);
signals:
  void updateSubPool();
private:
  void removeExtension(QString& fileName);
};

#endif // QTBTOOLSPACD_H
