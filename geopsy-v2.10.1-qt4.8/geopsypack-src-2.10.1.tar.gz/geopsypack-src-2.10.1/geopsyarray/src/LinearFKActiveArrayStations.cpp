/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-03-27
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "LinearFKActiveArrayStations.h"
#include "LinearFKActiveStationSignals.h"

/*!
  \class LinearFKActiveArrayStations qtblinearfkactivearraystations.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

LinearFKActiveArrayStations::LinearFKActiveArrayStations()
{
  setComponents(StationSignals::AnySingleComponent);
}

LinearFKActiveArrayStations::~LinearFKActiveArrayStations()
{
  qDeleteAll(_stations);
}

QString LinearFKActiveArrayStations::name()
{
  TRACE;
  const Point& p = first()->source();
  return tr("Shot at (%1, %2, %3), time=%4")
       .arg(p.x()).arg(p.y()).arg(p.z())
       .arg(first()->timeReference().toString("yyyy-MM-dd hh:mm:ss ") );
}

bool LinearFKActiveArrayStations::addSignals( SubSignalPool * subPool )
{
  QString log;
  if ( !ArrayStations::addSignals(subPool, &log) ||
       !hasAllComponents(&log) ||
       !hasCompatibleStations(&log) ) {
    Message::warning( MSG_ID, tr("Checking stations"), log, Message::cancel());
    return false;
  }
  for (iterator it = begin(); it!= end(); it++ ) {
    _stations.append( new LinearFKActiveStationSignals(*it) );
  }
  return true;
}

void LinearFKActiveArrayStations::setRelativeCoordinates()
{
  TRACE;
  ArrayStations::setRelativeCoordinates();
  for (int i = 0; i<_stations.count(); i++ ) {
    _stations.at(i)->setRelativeCoordinates(relativeCoordinates(i));
  }
}

const QList<FKStationSignals *> LinearFKActiveArrayStations::stations() const
{
  QList<FKStationSignals *> s;
  for (QList<LinearFKActiveStationSignals *>::const_iterator it = _stations.begin(); it!=_stations.end(); it++) {
    s.append(static_cast<FKStationSignals *>(*it));
  }
  return s;
}

void LinearFKActiveArrayStations::selectStations( double minDist, double maxDist )
{
  TRACE;
  for (int i = 0; i<_stations.count(); i++ ) {
    double d = at(i)->sourceReceiverDistance();
    _stations.at(i)->select(d>=minDist && d<=maxDist);
  }
}

bool LinearFKActiveArrayStations::isSelected( int stationIndex ) const
{
  return _stations.at(stationIndex)->isSelected();
}

int LinearFKActiveArrayStations::selectedCount() const
{
  TRACE;
  int c=0;
  for (int i=0; i<_stations.count(); i++) {
    if(_stations.at(i)->isSelected()) {
      c++;
    }
  }
  return c;
}

void LinearFKActiveArrayStations::beginPreprocess( int winIndex )
{
  TRACE;
  const TimeRange& tw = _timeWindows.at(winIndex);
  for (QList<LinearFKActiveStationSignals *>::iterator it = _stations.begin(); it!= _stations.end(); it++ ) {
    LinearFKActiveStationSignals * s = *it;
    if (s->isSelected()) s->beginPreprocess( tw );
  }
}

void LinearFKActiveArrayStations::taper( RelativeTimeRange& tw, double width )
{
  TRACE;
  for (QList<LinearFKActiveStationSignals *>::iterator it = _stations.begin(); it!= _stations.end(); it++ ) {
    LinearFKActiveStationSignals * s = *it;
    if (s->isSelected()) s->taper( tw, width );
  }
}

void LinearFKActiveArrayStations::normalize( const NormalizationParam& p )
{
  TRACE;
  for (QList<LinearFKActiveStationSignals *>::iterator it = _stations.begin(); it!= _stations.end(); it++ ) {
    LinearFKActiveStationSignals * s = *it;
    if (s->isSelected()) s->normalize( p );
  }
}

void LinearFKActiveArrayStations::endPreprocess()
{
  TRACE;
  for (QList<LinearFKActiveStationSignals *>::iterator it = _stations.begin(); it!= _stations.end(); it++ ) {
    LinearFKActiveStationSignals * s = static_cast<LinearFKActiveStationSignals *>(*it);
    if (s->isSelected()) s->endPreprocess();
  }
}

void LinearFKActiveArrayStations::addTimeWindow( RelativeTimeRange& p )
{
  TRACE;
  Signal * sig = first()->firstValidSignal();
  if (sig) {
    _timeWindows.addOne( p.absoluteRange(sig) );
  } else {
    App::stream() << tr("Cannot add time window to an empty array") << endl;
  }
}

/*!
  Calculate average azimuth from source
*/
double LinearFKActiveArrayStations::propagationAzimuth()
{
  TRACE;
  double sum = 0.0;
  int n = 0;
  for (iterator it = begin(); it!= end(); it++ ) {
    if ((*it)->sourceReceiverDistance()>0.0 ) {
      sum += (*it)->sourceReceiverAzimuth();
      n++;
    }
  }
  return sum / (double) n;
}

/*!
  lock process signals for all stations of the array. If successful, you must call UNLOCK_SAMPLES.
*/
bool LinearFKActiveArrayStations::lockSamples()
{
  TRACE;
  LinearFKActiveStationSignals * stat;
  int n = count();
  for ( int i = 0; i<n; i++ ) {
    stat = _stations.at(i);
    if ( stat->isSelected() && !stat->lockSamples() ) {
      for (i--;i>=0;i--) _stations.at(i)->unlockSamples();
      App::stream() << tr("cannot allocate all signals, increase memory buffer size\n") << endl;
      return false;
    }
  }
  return true;
}

/*!
  Can be called only after a successful LOCK_SAMPLES.
*/
void LinearFKActiveArrayStations::unlockSamples()
{
  TRACE;
  for ( QList<LinearFKActiveStationSignals *>::iterator it = _stations.begin();it != _stations.end();++it ) {
    LinearFKActiveStationSignals * stat = *it;
    if (stat->isSelected()) stat->unlockSamples();
  }
}
