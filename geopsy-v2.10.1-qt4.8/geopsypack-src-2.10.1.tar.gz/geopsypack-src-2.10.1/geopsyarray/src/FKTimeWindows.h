/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-03
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef FKTIMEWINDOWS_H
#define FKTIMEWINDOWS_H

#include <ArrayCore.h>
#include <ArrayGui.h>
#include <GeopsyGui.h>

#include "ui_FKTimeWindows.h"

class FKMeshLayer;

class FKTimeWindows : public QWidget, public Ui::FKTimeWindows
{
  Q_OBJECT
public:
  FKTimeWindows(QWidget * parent=0);
  ~FKTimeWindows();

  virtual void setArray(const ArrayStations& array);
  void setTimeWindowLayer(TimeWindowLayer * twLayer);

  bool setParameters(double frequency, FKParameters * param, bool doNSampleWarning=true);
  void setGrid(FKParameters * param);
  TimeWindowList * timeWindowList() const {return static_cast<TimeWindowList *>(_process->timeRangeList());}
protected slots:
  virtual void setComponent();
  virtual void setCurrentWindow();

  void on_kEdit_valueChanged( const QString & );
  void on_vEdit_valueChanged( const QString & );
  void on_component_currentIndexChanged( int index );
  void on_direction_valueChanged( double value );

  void currentVelocitySlowness( QPoint mousePos );
protected:
  FKArrayProcess * _process;
  TimeWindowLayer * _timeWindowLayer;
  LiveGridLayer * _gridLayer;
  FKMeshLayer * _fkMeshLayer;
  CircleViewer * _fkCircleLayer;
  int _currentWindow;
};

#endif // QTBFKTIMEWINDOWS_H
