/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyGui.h>
#include <ArrayCore.h>

#include "ToolFK.h"
#include "ToolFKd.h"
#include "FKLoop.h"
#include "FKTimeWindows.h"

#define _fkBrowser static_cast<FKTimeWindows*>(_childrenList[0])

const char * ToolFK::toolName()
{
  return "FK Array analysis";
}

ToolFK::ToolFK( QWidget * parent ) :
    ToolArrayBase( parent, 1 )
{
  TRACE;
  setWindowIcon( QIcon( ":/images/fk-22x22.png" ) );
  setObjectName("ToolFK");
  QVBoxLayout * baseLayout=new QVBoxLayout(this);
  _d = new ToolFKd( this );
  baseLayout->addWidget( _d );
  _exportAllFKGrids = false;

  setWindowTitle( "FK toolbox" );

  connect( _d->startBut, SIGNAL( clicked() ), this, SLOT( start() ) );
  connect( _d->stopBut, SIGNAL( clicked() ), this, SLOT( stop() ) );
  connect( _d->testBut, SIGNAL( clicked() ), this, SLOT( test() ) );
  connect( _d->loadParam, SIGNAL( clicked() ), this, SLOT( loadLogParameters() ) );
  connect( _d->freqSamp, SIGNAL( sampleCountChanged() ), _d, SLOT( numFreqChanged() ) );

  connect( _d->winParam, SIGNAL( parametersChanged() ), this, SLOT( parametersChanged() ) );
  connect( _d->timeLimits, SIGNAL( parametersChanged() ), this, SLOT( parametersChanged() ) );
  connect( _d->testFrequency, SIGNAL( valueChanged( const QString& ) ), this, SLOT( parametersChanged() ) );
  connect( _d->freqBandWidth, SIGNAL( valueChanged( const QString& ) ), this, SLOT( parametersChanged() ) );

  connect( _d->kminEdit, SIGNAL(valueChanged( const QString& ) ), this, SLOT(gridChanged()));
  connect( _d->kmaxEdit, SIGNAL(valueChanged( const QString& ) ), this, SLOT(kmaxChanged()));
  connect( _d->vminEdit, SIGNAL(valueChanged( const QString& ) ), this, SLOT(gridChanged()));

  _kmaxSolver=0;
  _kmaxTouched=false;
  _kminTouched=false;
  _loop=0;
}

ToolFK::~ToolFK()
{
  TRACE;
  if(_kmaxSolver) {
    _kmaxSolver->terminate();
    delete _kmaxSolver;
  }
}

void ToolFK::updateAllFields()
{
  TRACE;
  _d->winParam->updateAllFields();
  _d->timeLimits->updateAllFields();
  _d->numFreqChanged();
  _d->on_freqScroll_valueChanged(0);
  // After restoring last values from registry
  setDefaultGridParameters();
}

FKParameters * ToolFK::parameters()
{
  TRACE;
  FKParameters * param = new FKParameters;
  _d->getParameters( *param );
  if (!checkParameters(param)) {
    delete param;
    return 0;
  } else {
    return param;
  }
}

void ToolFK::setDefaultGridParameters()
{
  TRACE;
  if(_kmaxSolver) {
    _kmaxSolver->terminate();
    _kmaxSolver->deleteLater();
    _kmaxSolver=0;
  }

  QVector<Point2D> stations;
  for(int i=0;i<_array.count();i++) {
    stations.append(Point2D(_array.relativeCoordinates(i)));
  }
  // Estimate kmin and kmax from station coordinates
  KminSolver kminSolver(stations);
  bool ok=true;
  double kmin=kminSolver.calculate(ok);
  if(!_kmaxTouched) {
    if (ok && kmin>0.0) {
      _kmaxSolver=new KmaxSolver(stations, kmin);
      connect(&_kmaxTimer, SIGNAL(timeout()), this, SLOT(setTemporaryKmax()));
      connect(_kmaxSolver, SIGNAL(finished()), this, SLOT(setComputedKmax()));
      _kmaxSolver->calculate();
      _kmaxTimer.start(1000);
    } else {
      App::stream() << tr("Error computing kmin for station coordinates") << endl;
      return;
    }
  }
  if(!_kminTouched) {
    setDefaultGridStep(kmin);
  }
}

void ToolFK::setTemporaryKmax()
{
  TRACE;
  if(_kmaxTouched) {
    _kmaxTimer.stop();
    _kmaxSolver->terminate();
    _kmaxSolver->deleteLater();
    _kmaxSolver=0;
  }
  if(_kmaxSolver) {
    bool ok;
    double kmax=_kmaxSolver->kmax(ok);
    if(ok) {
      // TODO: implement the maximum allowed K in KmaxSolver
      double maxK=2.0*M_PI*_d->freqSamp->maximum()/_d->vminEdit->value();
      if(kmax>=maxK) {
        kmax=maxK;
        _kmaxTimer.stop();
        _kmaxSolver->terminate();
        _kmaxSolver->deleteLater();
        _kmaxSolver=0;
      }
      setDefaultGridSize(kmax);
    }
  }
}

void ToolFK::setComputedKmax()
{
  TRACE;
  // Upon termination, _kmaxSolver might be replaced by another solver
  // and this function called by an old event still in the stack
  // Make sure that it still refers to the current solver.
  KmaxSolver * solver=qobject_cast<KmaxSolver *>(sender());
  if(solver && _kmaxSolver==solver) {
    if(!_kmaxTouched) {
      bool ok;
      double kmax=_kmaxSolver->kmax(ok);
      if(ok) {
        setDefaultGridSize(kmax);
      }
    }
    _kmaxTimer.stop();
    _kmaxSolver->deleteLater();
    _kmaxSolver=0;
  }
}

void ToolFK::setDefaultGridStep(double kmin)
{
  TRACE;
  kmin*=0.25;
  // Check if enough precision to represent these numbers, at least 3 significant digits
  if(kmin<pow(10.0, -_d->kminEdit->decimals())) {
    _d->kminEdit->setDecimals(3-floor(log10(kmin)));
  }
  // Set value
  _d->kminEdit->setValue(kmin);
}

void ToolFK::setDefaultGridSize(double kmax)
{
  TRACE;
  _d->kmaxEdit->blockSignals(true);
  kmax*=2.0;
  // Check if enough precision to represent these numbers, at least 3 significant digits
  if(kmax<pow(10.0, -_d->kmaxEdit->decimals())) {
    _d->kmaxEdit->setDecimals(3-floor(log10(kmax)));
  }
  // Set value
  _d->kmaxEdit->setValue(kmax);
  _d->kmaxEdit->blockSignals(false);
  gridChanged();
}

bool ToolFK::checkParameters(FKParameters * param) const
{
  if (param->frequencyBandWidth<=0) {
    Message::warning( MSG_ID,tr("FK parameters"),tr("Band width cannot be null or negative."), true);
    return false;
  }
  if (param->minimumWaveNumber()>param->maximumWaveNumber()) {
    Message::warning( MSG_ID,tr("FK parameters"),tr("kmin must be less than kmax."), true);
    return false;
  }
  if (param->minimumWaveNumber()<=0.0) {
    Message::warning( MSG_ID,tr("FK parameters"),tr("kmin cannot be null or negative."), true);
    return false;
  }
  if (param->minimumWaveNumber()*3600<param->maximumWaveNumber()) {
    Message::warning( MSG_ID,tr("FK parameters"),tr("kmin cannot be more than 3600 times smaller than kmax. "
                                                  "If kmin*3600==kmax, the approximate size of a FK map is 100 Mb."), true);
    return false;
  }
  return true;
}

void ToolFK::parametersChanged()
{
  if ( _fkBrowser && _d->testBut->isChecked()) {
    FKParameters * param = parameters();
    if (param) _fkBrowser->setParameters( _d->testFrequency->value(), param );
  }
}

void ToolFK::kmaxChanged()
{
  TRACE;
  if(_kmaxSolver) {
    if(Message::question(MSG_ID, tr("Changing grid size"),
                         tr("The grid size is currently been computed, do you want to "
                            "stop this computation and set your own value?"),
                         Message::yes(), Message::no())==Message::Answer0) {
      _kmaxTouched=true;
    }
  }
  gridChanged();
}

void ToolFK::gridChanged()
{
  TRACE;
  if ( _fkBrowser && _d->testBut->isChecked()) {
    FKParameters * param = parameters();
    if (param) {
      _fkBrowser->setGrid( param );
      delete param;
    }
  }
}

bool ToolFK::initStations(SubSignalPool * subPool)
{
  TRACE;
  if (!ToolArrayBase::initStations(subPool, _d->winParam)) return false;
  _d->timeLimits->setPicks(_subPool);
  _array.setRelativeCoordinates();
  emit updateSubPool();
  return true;
}

void ToolFK::test()
{
  TRACE;
  if ( !_fkBrowser ) {
    _childrenList[ 0 ] = new FKTimeWindows;
    _fkBrowser->setObjectName( "FKBrowser" );
    _fkBrowser->setArray(_array);
    _fkBrowser->setTimeWindowLayer(timeWindowLayer());
    setTimeWindowLayer(_fkBrowser->timeWindowList());
    geopsyGui->addWindow( _fkBrowser );
  }
  geopsyGui->showWindow( _fkBrowser );
  QApplication::processEvents();
  parametersChanged();
  geopsyCore->showMessage( tr( "Signals are ready" ) );
}

void ToolFK::start()
{
  TRACE;
  if (subPoolLocked()) return;
  resetLogs();
  // Get parameters from dialog box
  FKParameters * param = parameters();
  if (!param) return;
  param->outputFile = _d->outputFile();
  param->setExportAllFKGrids( _exportAllFKGrids );
  // Prepare loop
  FKLoop *loop = new FKLoop;
  loop->setArray( &_array );
  loop->setLog( &_log );
  if ( !loop->setParameters( param ) ) {
    delete loop;
    return ;
  }
  connect(loop, SIGNAL(finished()), this, SLOT(finish()));
  startLoop(loop, param);
}

/*!
  \a message is displayed at the top while running. If empty, 'Runnning...' is displayed.
*/
void ToolFK::startLoop(FKLoop * loop, FKParameters * param, const QString& message)
{
  _d->detailedStatus->setLoop( loop );
  _loop=loop;
  _param=param;
  // Start main loop
  lockSubPool(); // Prevent any change on the orignal signals
  _d->setRunning(true, message);
  writeParameterLogs( _param->outputFile );
  _log += tr("Process started at %1\n").arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
  _chrono.start();
  _loop->start(0, _param->frequencySampling.count());
}

void ToolFK::finish()
{
  QTime timeElapsed(0,0);
  _log += tr("Process run in %1\n").arg(timeElapsed.addMSecs(_chrono.elapsed()).toString("hh:mm:ss"));
  _log += tr("Process ended at %1\n").arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
  delete _loop;
  _loop = 0;
  writeProcessLogs( _param->outputFile );
  unlockSubPool();
  _param = 0;
  _d->setRunning(false);
}

void ToolFK::waitFinished()
{
  TRACE;
  if(_loop) {
    _loop->waitFinished();
  }
}

void ToolFK::stop()
{
  TRACE;
  if(_loop) {
    _loop->terminate();
  }
}

QString ToolFK::logParameters() const
{
  TRACE;
  QString log;
  _d->winParam->exportParameters( log );
  _d->freqSamp->exportParameters( log );
  _d->timeLimits->exportParameters( log );
  log += "MIN K = " + QString::number(_d->kminEdit->value()) + "\n";
  log += "MAX K = " + QString::number(_d->kmaxEdit->value()) + "\n";
  log += "MIN V = " + QString::number(_d->vminEdit->value()) + "\n";
  log += "FREQ BAND WIDTH = " + QString::number(_d->freqBandWidth->value()) + "\n";
  log += "N MAXIMA = " + QString::number(_d->maxPeakCount->value()) + "\n";
  log += "OUTPUT FILE = " + _d->outputFileEdit->text() + "\n";
  return log;
}

bool ToolFK::setLogParameters( QString& keyword, QString& value )
{
  TRACE;
  if ( _d->winParam->loadParameters( keyword, value ) ) ;
  else if (keyword.contains("MIN K")) {
    _d->kminEdit->setValue(value.toDouble());
    _kminTouched=true;
  } else if (keyword.contains("MAX K" )) {
    _d->kmaxEdit->setValue(value.toDouble());
    _kmaxTouched=true;
  } else if ( keyword.contains( "MIN V" ) )
    _d->vminEdit->setValue( value.toDouble() );
  else if ( keyword.contains( "FREQ BAND WIDTH" ) )
    _d->freqBandWidth->setValue( value.toDouble() );
  else if ( keyword.contains( "N MAXIMA" ) )
    _d->maxPeakCount->setValue( value.toInt() );
  else if ( keyword.contains( "OUTPUT FILE" ) )
    _d->outputFileEdit->setText( value );
  else if ( _d->freqSamp->loadParameters( keyword, value ) );
  else if ( _d->timeLimits->loadParameters( keyword, value ) );
  else return false;
  return true;
}

void ToolFK::setParameters( int& argc, char ** argv )
{
  TRACE;
  ToolBase::setParameters(argc, argv);
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-param") {
        CoreApplication::checkOptionArg(i, argc, argv);
        loadLogParameters( argv[i] );
      } else if (arg=="-export-grids") {
        _exportAllFKGrids = true;
      } else if (arg=="-f") {
        _d->setOutputFileChecked(true);
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
}
