/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-02
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef ToolLinearFKActive_H
#define ToolLinearFKActive_H

#include <GeopsyCore.h>
#include <QGpCoreWave.h>
#include <SciFigs.h>

#include "ToolArrayBase.h"

class ToolLinearFKActived;
class LinearFKActiveArrayStations;

class ToolLinearFKActive :  public ToolBase
{
  Q_OBJECT
public:
  ToolLinearFKActive(QWidget * parent);
  ~ToolLinearFKActive();

  virtual bool initStations(SubSignalPool *);
  virtual void setParameters( int& argc, char ** argv );
private slots:
  virtual void start();
  void on_currentSource_currentIndexChanged( int index );
  void setResultXAxis();
  void setResultYAxis();
  void timeWindowChanged();
  void addCurvePlot( LineLayer * w, QString caption );
  void newLine(int iGraph);
  void adjustCurve();
  void graphSelected(GraphicObject * obj);
  void setWavelengthLimit(double waveLength);
protected:
  virtual void updateAllFields();
  virtual const char * toolName();
  virtual bool setLogParameters(QString& keyword, QString& value);
  virtual QString logParameters() const;
  bool addArray( SubSignalPool& arraySubPool);
  double dampingFactor() const;
protected:
  ToolLinearFKActived * _d;
  QList<LinearFKActiveArrayStations *> _arrays;
};

#endif
