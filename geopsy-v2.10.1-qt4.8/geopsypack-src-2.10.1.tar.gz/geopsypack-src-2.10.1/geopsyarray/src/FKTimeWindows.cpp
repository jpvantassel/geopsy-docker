/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-03
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyGui.h>
#include <ArrayCore.h>

#include "FKTimeWindows.h"
#include "FKMeshLayer.h"

/*!

*/
FKTimeWindows::FKTimeWindows( QWidget* parent )
    : QWidget( parent )
{
  TRACE;
  setupUi( this );
  _currentWindow = -1;
  _timeWindowLayer = 0;
  /*
    setup graph properties
  */
  waveNumGrid->graphContent()->setGridLines(false);
  _gridLayer = new LiveGridLayer( waveNumGrid );
  _gridLayer->setSampling(3);
  _fkMeshLayer = new FKMeshLayer ( waveNumGrid );
  _fkMeshLayer->setObjectName( "fkMesh" );
  _fkCircleLayer = new CircleViewer( waveNumGrid );
  _fkCircleLayer->setObjectName( "userSlowness" );
  _fkCircleLayer->resize( 1 );
  connect( waveNumGrid->graphContent(), SIGNAL( mouseMoved( QPoint, Qt::MouseButtons, Qt::KeyboardModifiers ) ),
           this, SLOT( currentVelocitySlowness( QPoint ) ) );
  /*
   Set axis
  */
  waveNumGrid->xAxis()->setTitle( "Wave number X (rad/m)" );
  waveNumGrid->xAxis()->setTitleInversedScale( "Wave length X/(2*pi) (m/rad)" );
  waveNumGrid->xAxis()->setSizeType( Axis::Scaled );
  waveNumGrid->yAxis()->setTitle( "Wave number Y (rad/m)" );
  waveNumGrid->yAxis()->setTitleInversedScale( "Wave length Y/(2*pi) (m/rad)" );
  waveNumGrid->yAxis()->setSizeType( Axis::Scaled );

  connect( component, SIGNAL( activated(int) ), this, SLOT( setComponent() ) );
  connect( winScroll, SIGNAL( valueChanged(int) ), this, SLOT( setCurrentWindow() ) );

  _process=0;
}

/*!

*/
FKTimeWindows::~FKTimeWindows()
{
  TRACE;
  delete _process;
}

void FKTimeWindows::setArray(const ArrayStations& array)
{
  // Check whether we are multi component
  StationSignals::Components c = array.components();
  if (c & StationSignals::VerticalComponent) {
    component->addItem(tr("Vertical"));
  }
  if (c & StationSignals::HorizontalComponent) {
    component->addItem(tr("Horizontal"));
    component->addItem(tr("Radial"));
    component->addItem(tr("Transverse"));
  }
  _process=new FKArrayProcess(array);
  _process->setTimeRangeList(new TimeWindowList);
}

void FKTimeWindows::setTimeWindowLayer( TimeWindowLayer * twLayer )
{
  if (twLayer) {
    twLayer->setShowColors( true );
    _timeWindowLayer = twLayer;
  }
}

/*!
  
*/
bool FKTimeWindows::setParameters( double frequency, FKParameters * param, bool doNSampleWarning )
{
  TRACE;
  // Before changing anything to parameters, disable the grid plot (setComponent will reset it
  _gridLayer->setFunction(0);

  if (!_process->setParameters( param, doNSampleWarning )) {
    return false;
  }
  LayerLocker ll(_timeWindowLayer);
  if (!_process->setFrequency(frequency)) {
    return false;
  }
  ll.unlock();

  winScroll->setMaximum( timeWindowList()->count() - 1 );
  setCurrentWindow();
  setGrid( param );
  waveNumGrid->setMapScale(-param->maximumWaveNumber(), -param->maximumWaveNumber(),
                            param->maximumWaveNumber(),  param->maximumWaveNumber());
  setComponent();
  on_vEdit_valueChanged( "" );
  if(_timeWindowLayer) _timeWindowLayer->deepUpdate();
  return true;
}

void FKTimeWindows::setGrid( FKParameters * param )
{
  double kmax = 2.0*M_PI*_process->frequency().center()*param->maximumSlowness();
  if (param->maximumWaveNumber()<kmax) {
    kmax = param->maximumWaveNumber();
  }
  _fkMeshLayer->lockDelayPainting();
  _fkMeshLayer->setKmax( kmax );
  _fkMeshLayer->setKmin( param->minimumWaveNumber() );
  _fkMeshLayer->unlock();
  _fkMeshLayer->deepUpdate();
}

/*!
  
*/
void FKTimeWindows::setCurrentWindow()
{
  // Before changing anything to parameters, disable the grid plot
  AbstractFunction2 * func = _gridLayer->takeFunction();
  /*
    Make sure _currentWin is valid and uncolor previous time window
    Set color for the new current time window 
  */
  LayerLocker ll(_timeWindowLayer);
  TimeWindowList& winList=*static_cast<TimeWindowList *>(_process->timeRangeList());
  if (winList.isEmpty()) {
    _currentWindow=-1;
    return ;
  }
  winList.resetColors();
  _currentWindow=winScroll->value();
  if (_currentWindow < 0 || _currentWindow >= winList.count()) {
    _currentWindow = 0;
  }
  winList.at(_currentWindow).setColor(QColor(255, 166, 166));
  ll.unlock();

  if ( !_process->lockTimeWindow( &winList.at(_currentWindow) ) ) {
    App::stream() << tr("cannot allocate all signals, increase buffer size\n") << endl;
    return;
  }
  _gridLayer->setFunction( func );
  waveNumGrid->deepUpdate();
  if(_timeWindowLayer) _timeWindowLayer->deepUpdate();
}

void FKTimeWindows::setComponent()
{
  TRACE;
  // Before changing anything to parameters, disable the grid plot
  _gridLayer->setFunction(0);
  if ( _currentWindow<0 ) {
    return;
  }
  _process->setHorizontalDirection( direction->value() );

  FK * fk;
  if (component->currentText()==tr("Radial")) {
    fk = _process->function(1);
  } else if (component->currentText()==tr("Transverse")) {
    fk = _process->function(2);
  } else if (component->currentText()==tr("Horizontal")) {
    fk = _process->function(3);
  } else {
    fk = _process->function(0);
  }
  fk->setMaximumWavenumber(1e99); // No limit for plot
  fk->setMaximumSlowness(1e99);
  double winLength = _process->timeRangeList()->at(_currentWindow).lengthSeconds();
  fk->setFrequencyBand( _process->frequency(), winLength );

  _gridLayer->setFunction( fk );
  waveNumGrid->deepUpdate();
}

void FKTimeWindows::on_kEdit_valueChanged( const QString & )
{
  TRACE;
  double val = kEdit->value();
  vEdit->blockSignals( true );
  vEdit->setValue( 2 * M_PI * _process->frequency().center() / val );
  vEdit->blockSignals( false );
  _fkCircleLayer->setCircle( 0, 0, 0, val, val, Qt::black );
  _fkCircleLayer->deepUpdate();
}

void FKTimeWindows::on_vEdit_valueChanged( const QString & )
{
  TRACE;
  double val = vEdit->value();
  kEdit->blockSignals( true );
  kEdit->setValue( 2 * M_PI * _process->frequency().center() / val );
  kEdit->blockSignals( false );
  double r=2 * M_PI * _process->frequency().center() / val;
  _fkCircleLayer->setCircle( 0, 0, 0, r, r, Qt::black );
  _fkCircleLayer->deepUpdate();
}

void FKTimeWindows::on_component_currentIndexChanged( int )
{
  if (component->currentText() == tr("Horizontal")) {
    direction->setEnabled(true);
  } else {
    direction->setEnabled(false);
  }
  setComponent();
}

void FKTimeWindows::on_direction_valueChanged( double )
{
  setComponent();
}

void FKTimeWindows::currentVelocitySlowness( QPoint mousePos )
{
  TRACE;
  Point2D p = waveNumGrid->graphContent()->options().s2r( mousePos );
  Point2D origin( 0, 0 );
  double kr=p.distanceTo( origin );
  double az=Angle::mathToGeographic(origin.azimuthTo(p));
  double sr=kr/(2.0*M_PI*_process->frequency().center());
  velSlowLabel->setText( tr( "Propagation towards %1 counted from North\nat k=%2 rad/m, v=%3 m/s or s=%4 s/km" ).
                         arg( az, 0, 'f', 4 ).arg( kr, 0, 'g', 3 ).
                         arg( 1.0 / sr, 0, 'f', 0 ).arg( sr*1000.0, 0, 'g', 5 ) );;
}
