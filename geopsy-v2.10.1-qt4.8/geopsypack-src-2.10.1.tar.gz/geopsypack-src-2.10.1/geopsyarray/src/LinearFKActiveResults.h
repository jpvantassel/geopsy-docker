/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-03-27
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef LINEARFKRESULTS_H
#define LINEARFKRESULTS_H

#include <QGpGuiWave.h>

class LinearFKActiveArrayStations;

class LinearFKActiveResults : public GraphicSheetMenu
{
  Q_OBJECT
public:
  LinearFKActiveResults( QWidget* parent = 0 );
  ~LinearFKActiveResults();

  void createObjects( const QList<LinearFKActiveArrayStations *>& arrays );
  void setXAxis(const Sampling& s);
  void setYAxis(Scale::Type t, double min, double max);
  void setWaveLengthLimit(int ig, double wl);
  void setLimits();
  IrregularGrid2DPlot * gridLayer( int index ) const { return _gridLayers[index]; }
  LineLayer * curveLayer( int index ) const { return _curveLayers[index]; }
public slots:
  void setPick(bool on);
  void autoPick();
  void adjust( int ig, ModalCurve& curve, double min, double max, SamplingOptions options );
  void stackGrids();
  void exportCurves();
signals:
  void newPlot( LineLayer * curveLayer, QString caption );
  void newCurve( int iGraph );
private:
  bool selectAll( QString title );
  ModalLine * createReferenceLine();

  QVector<IrregularGrid2DPlot *> _gridLayers;
  QVector<LineLayer *> _curveLayers;
  QVector<DispersionLimitLayer *> _limitLayers;
};

#endif // LINEARFKRESULTS_H
