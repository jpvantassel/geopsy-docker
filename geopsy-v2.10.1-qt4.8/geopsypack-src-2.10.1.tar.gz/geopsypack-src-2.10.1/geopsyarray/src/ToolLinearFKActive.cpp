/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-09-02
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QPushButton>

#include <GeopsyCore.h>
#include <GeopsyGui.h>
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include <QGpGuiWave.h>
#include <SciFigs.h>
#include "ToolLinearFKActive.h"
#include "ToolLinearFKActived.h"
#include "LinearFKActiveArrayStations.h"
#include "LinearHRFKSearch.h"
#include "LinearFKActiveResults.h"

#define _linearFKResults static_cast<LinearFKActiveResults*>(_childrenList[0])

const char * ToolLinearFKActive::toolName()
{
  return "Linear FK Array analysis for active sources";
}

ToolLinearFKActive::ToolLinearFKActive( QWidget * parent ) :
    ToolBase( parent, 1 )
{
  TRACE;
  setWindowIcon( QIcon( ":/images/linearfkactive-22x22.png" ) );
  setObjectName("ToolLinearFKActive");
  QVBoxLayout * baseLayout=new QVBoxLayout(this);
  _d = new ToolLinearFKActived(this);
  baseLayout->addWidget( _d );
  setWindowTitle( "Linear FK toolbox" );

  connect( _d->startBut, SIGNAL(clicked()), this, SLOT(start()));
  connect( _d->currentSource, SIGNAL(currentIndexChanged( int )),
           this, SLOT(on_currentSource_currentIndexChanged( int )));
  connect( _d->minDistance, SIGNAL(valueChanged(double)), this, SLOT(timeWindowChanged()) );
  connect( _d->maxDistance, SIGNAL(valueChanged(double)), this, SLOT(timeWindowChanged()) );
  connect( _d->xSampling, SIGNAL(parametersChanged()), this, SLOT(setResultXAxis()) );
  connect( _d->ySampling, SIGNAL(parametersChanged()), this, SLOT(setResultYAxis()) );
  connect( _d, SIGNAL(slowTypeChanged()), this, SLOT(setResultYAxis()) );
  connect( _d->timeLimits, SIGNAL(parametersChanged()), this, SLOT(timeWindowChanged()) );
  connect( _d->loadParam, SIGNAL( clicked() ), this, SLOT( loadLogParameters() ) );
  connect( _d->saveParam, SIGNAL( clicked() ), this, SLOT( saveLogParameters() ) );
  connect(_d->wavelengthLimit, SIGNAL(valueChanged(double)), this, SLOT(setWavelengthLimit(double)));

  QAction * a = _d->curves->addCurveAction(tr("&Adjust"), tr("Adjust current curve to the closest maximum"), true);
  connect( a, SIGNAL( triggered() ), this, SLOT( adjustCurve() ) );
}

ToolLinearFKActive::~ToolLinearFKActive()
{
  TRACE;
  qDeleteAll( _arrays );
}

void ToolLinearFKActive::updateAllFields()
{
  TRACE;
  _d->timeLimits->updateAllFields();
  _d->taperTimeLimits->updateAllFields();
  _d->ySampling->setInversed( _d->slowType->currentIndex() == 1, false );
  _d->setSlownessType();
  setResultXAxis();
  timeWindowChanged();
}

void ToolLinearFKActive::setResultXAxis()
{
  TRACE;
  Sampling s;
  _d->xSampling->getParameters(s);
  _linearFKResults->setXAxis(s);
}

void ToolLinearFKActive::setResultYAxis()
{
  TRACE;
  double min = _d->ySampling->minimum();
  double max = _d->ySampling->maximum();
  if ( _d->slowType->currentIndex() == 0 ) {
    _linearFKResults->setYAxis( Scale::Linear, min, max );
  } else {
    _linearFKResults->setYAxis( Scale::Inversed, 1.0/max, 1.0/min );
  }
}

bool ToolLinearFKActive::addArray( SubSignalPool& arraySubPool )
{
  TRACE;
  LinearFKActiveArrayStations * array = new LinearFKActiveArrayStations;
  if(!array->addSignals(&arraySubPool)) {
    return false;
  }
  if (!array->isEmpty()) {
    array->setRelativeCoordinates();
    _arrays << array;
  } else {
    delete array;
  }
  arraySubPool.removeAll();
  return true;
}

bool ToolLinearFKActive::initStations( SubSignalPool * subPool )
{
  TRACE;
  _subPool = subPool;
  // Sorting by source
  Signal::clearSortKeys();
  Signal::addSortKey( Signal::SourceX );
  Signal::addSortKey( Signal::SourceY );
  Signal::addSortKey( Signal::SourceZ );
  Signal::addSortKey( Signal::T0 );
  Signal::addSortKey( Signal::TimeReference );
  Signal::addSortKey( Signal::SourceReceiverRoughAzimuth );
  Signal::addSortKey( Signal::SourceReceiverDistance );
  _subPool->sort();
  // Split subPool into distinct arrays
  SubSignalPool::iterator itPool = _subPool->begin();
  Signal * sig = *itPool;
  Signal * refSig = sig;
  Point s = sig->source();
  double t0 = sig->t0();
  QDateTime refTime = sig->timeReference();
  SubSignalPool arraySubPool;
  arraySubPool.addSignal(sig);
  Signal::clearSortKeys();
  Signal::addSortKey( Signal::SourceReceiverRoughAzimuth );
  for ( ++itPool;itPool != _subPool->end();++itPool ) {
    sig = *itPool;
    if ( s != sig->source() || t0 != sig->t0() || refTime != sig->timeReference() || sig->compare(*refSig)!=0) {
      if(arraySubPool.count()>1) {
        if(!addArray(arraySubPool)) {
          return false;
        }
      }
      refSig = sig;
      s = sig->source();
      t0 = sig->t0();
      refTime = sig->timeReference();
    }
    arraySubPool.addSignal(sig);
  }
  if(!arraySubPool.isEmpty()) {
    if(!addArray(arraySubPool)) {
      return false;
    }
  }
  _d->timeLimits->setPicks( _subPool );
  _d->taperTimeLimits->setPicks( _subPool );
  // setup results graphs
  _childrenList[ 0 ] = new LinearFKActiveResults;
  _childrenList[ 0 ] ->setObjectName( "LinearFKActiveResults" );
  _linearFKResults->createObjects( _arrays );
  _linearFKResults->setWindowTitle(tr("Linear fk results (%1 arrays)").arg(_arrays.count()));
  connect( _linearFKResults, SIGNAL( newPlot(LineLayer *, QString) ),
           this, SLOT( addCurvePlot(LineLayer *, QString) ) );
  connect( _linearFKResults, SIGNAL( newCurve(int) ), this, SLOT( newLine(int) ) );
  geopsyGui->addWindow( _linearFKResults );
  geopsyGui->showWindow( _linearFKResults);
  for (int i = 0; i<_arrays.count();i++) {
    _d->currentSource->addItem(_arrays.at(i)->name());
    _d->curves->initLayer( _linearFKResults->curveLayer(i) );
    connect( _linearFKResults->sheet(), SIGNAL(activeSelectionChanged(GraphicObject *)),
             this, SLOT( graphSelected(GraphicObject *) ));
  }
  if (pickLayer()) {
    connect( pickLayer(), SIGNAL( pickChanged( Signal * ) ), _d->timeLimits, SLOT( setPicks( Signal * ) ) );
    connect( pickLayer(), SIGNAL( pickChanged( Signal * ) ), _d->taperTimeLimits, SLOT( setPicks( Signal * ) ) );
  }
  emit updateSubPool();
  return true;
}

void ToolLinearFKActive::addCurvePlot( LineLayer * curveLayer, QString caption )
{
  TRACE;
  _d->currentSource->addItem( caption );
  _d->curves->initLayer(curveLayer);

}

void ToolLinearFKActive::newLine(int iGraph)
{
  TRACE;
  if (_d->currentSource->currentIndex()==iGraph) {
    _d->curves->curvesChanged();
  }
}

void ToolLinearFKActive::on_currentSource_currentIndexChanged( int index )
{
  TRACE;
  _d->curves->setCurrentLayer( _linearFKResults->curveLayer(index) );
}

void ToolLinearFKActive::timeWindowChanged()
{
  TRACE;
  if (!timeWindowLayer()) return;
  timeWindowLayer()->clearTimeWindows();
  RelativeTimeRange timeWindow;
  _d->timeLimits->getParameters(timeWindow);
  double minDist = _d->minDistance->value();
  double maxDist = _d->maxDistance->value();
  int nArrays = _arrays.count();
  LayerLocker ll(timeWindowLayer());
  for (int iArray = 0; iArray<nArrays; iArray++) {
    LinearFKActiveArrayStations * a = _arrays.at(iArray);
    a->clearTimeWindows();
    a->addTimeWindow( timeWindow );
    a->selectStations( minDist, maxDist );
    for ( int i = 0; i< a->count(); i++ ) {
      if (a->isSelected(i)) {
        StationSignals * s = a->at(i);
        const SubSignalPool subPool = s->originals(0);
        for (SubSignalPool::const_iterator itSig = subPool.begin();itSig!=subPool.end(); itSig++) {
          timeWindowLayer()->addTimeWindows( *itSig, a->timeWindows());
        }
      }
    }
  }
  timeWindowLayer() ->deepUpdate();
}

void ToolLinearFKActive::start()
{
  TRACE;
  MessageContext();
  // Get parameters
  RelativeTimeRange timeLimits;
  NormalizationParam normParam;
  RelativeTimeRange taperParam;
  bool doTaper;
  double taperWidth = 0.0;
  if (_d->taperGroup->isChecked()) {
    doTaper = true;
    taperWidth = _d->taperWidth->text().toDouble() * 0.01;
    _d->taperTimeLimits->getParameters(taperParam);
  } else doTaper = false;
  _d->normalization->getParameters(normParam);
  if (!_d->normalizationGroup->isChecked()) {
    normParam.setType( NormalizationParam::None );
  }
  _d->timeLimits->getParameters(timeLimits);
  Sampling xSampling, ySampling;
  _d->xSampling->getParameters( xSampling );
  _d->ySampling->getParameters( ySampling );
  normParam.setRange( xSampling.min(), xSampling.max());
  if (_d->slowType->currentIndex()==1) {
    ySampling.inverse();
  }
  FrequencyBand frequency;
  frequency.setRelativeWidth(_d->freqBandWidth->text().toDouble());
  bool highResolution = _d->hrParamGroup->isChecked();
  double dampingFac = dampingFactor();
  double minDist = _d->minDistance->value();
  double maxDist = _d->maxDistance->value();
  // Beam power normalization
  enum BeamPowerNormalization {Raw, Spectrum, MaximumBeam};
  BeamPowerNormalization beamPowerNormalization=MaximumBeam;
  if(_d->rawBeamPowerNorm->isChecked()) {
    beamPowerNormalization=Raw;
  } else if(_d->spectrumBeamPowerNorm->isChecked()) {
    beamPowerNormalization=Spectrum;
  }
  // Loop on all arrays
  int nArrays = _arrays.count();
  if (nArrays>1) geopsyCore->setProgressMaximum( nArrays );
  for (int iArray = 0; iArray<nArrays; iArray++) {
    if (nArrays>1) geopsyCore->setProgressValue( iArray + 1 );
    LinearFKActiveArrayStations * a=_arrays.at(iArray);
    // Shots might have a distinct recording length (Bug 2012-04-18 B. Guillier)
    // Sets tw for each shot individually.
    TimeRange tw=timeLimits.absoluteRange(a->first()->firstValidSignal());
    if (tw.lengthSeconds()<=0) {
      Message::warning(MSG_ID, tr("Linear F-K"), tr("Null time window length for %1").arg(a->name()), true);
      continue;
    }
    LayerLocker ll(timeWindowLayer());
    a->clearTimeWindows();
    a->addTimeWindow( timeLimits );
    ll.unlock();
    a->selectStations(minDist, maxDist);
    if(a->selectedCount()<2) {
      Message::warning(MSG_ID, tr("Linear FK"), tr("Number of selected stations is less than 2 for array %1").arg(iArray+1),
                       Message::ok(), true);
      continue;
    }
    a->beginPreprocess(0);
    a->normalize( normParam );
    if (doTaper) a->taper(taperParam, taperWidth);
    a->endPreprocess();
    IrregularGrid2DPlot * plot = _linearFKResults->gridLayer(iArray);
    IrregularGrid2D grid( xSampling.count(), ySampling.count() );
    // Init the shift tables (one per station) with a coarse gridding
    // and the grid for max seeking
    double az = a->propagationAzimuth();
    LinearFKSearch * fkgrid;
    if (highResolution) {
      fkgrid = new LinearHRFKSearch;
      fkgrid->setFunction( new HRFK(a->stations()) );
    } else {
      fkgrid = new LinearFKSearch;
      fkgrid->setFunction( new FK(a->stations()) );
    }
    fkgrid->setAzimuth(az);
    fkgrid->function()->setMaximumWavenumber(1e99);
    for ( int iSlow = 0;iSlow < ySampling.count();iSlow++ ) {
      grid.setY( iSlow, ySampling.value( iSlow ) );
    }
    if (a->lockSamples()) {
      if (nArrays==1) geopsyCore->setProgressMaximum( xSampling.count() );
      for ( int iOmega = 0;iOmega < xSampling.count();iOmega++ ) {
        if (nArrays==1) geopsyCore->setProgressValue( iOmega + 1 );
        frequency.setCenter( xSampling.value( iOmega) );
        grid.setX( iOmega, frequency.center() );
        fkgrid->function()->setFrequencyBand( frequency, tw.lengthSeconds() );
        if(highResolution) {
          static_cast<HRFK*>(fkgrid->function())->initOperator(static_cast<HRFK*>(fkgrid->function())->crossCorrelationMatrix(0), dampingFac);
          for ( int iSlow = 0;iSlow < ySampling.count();iSlow++ ) {
            *grid.valuePointer( iOmega, iSlow ) = fkgrid->value( frequency.omega() * ySampling.value( iSlow ) );
          }
        } else {
          //double invPower = 1.0 / fkgrid->function()->absolutePower(0);
          for ( int iSlow = 0;iSlow < ySampling.count();iSlow++ ) {
            *grid.valuePointer( iOmega, iSlow ) = fkgrid->value( frequency.omega() * ySampling.value( iSlow ) );
          }
        }
        // Normalize FK spectrum frequency by frequency and following spectrum energy
        switch(beamPowerNormalization) {
        case Raw:
          break;
        case Spectrum:
          grid.multiplyValues( YAxis, iOmega, 1.0/fkgrid->function()->absolutePower(0));
          break;
        case MaximumBeam: {
            Curve<Point2D> c = grid.crossSection(YAxis, iOmega);
            int im = c.maximumY();
            grid.multiplyValues( YAxis, iOmega, 1.0/c.at(im).y());
          }
          break;
        }

      }
      a->unlockSamples();
    }
    delete fkgrid;
    plot->setGrid( grid );
    plot->setLinearPalette( 0 );
    _linearFKResults->gridLayer(iArray)->graph()->deepUpdate();
  }
}

QString ToolLinearFKActive::logParameters() const
{
  TRACE;
  QString log;
  log += QString( "DO TAPER = %1\n").arg(_d->taperGroup->isChecked() ? "y" : "n");
  log += QString( "TAPER WIDTH (%)= %1\n").arg(QString::number(_d->taperWidth->text().toDouble()));
  _d->taperTimeLimits->exportParameters( log, "TAPER " );
  if (_d->normalizationGroup->isChecked()) {
    _d->normalization->exportParameters( log );
  } else {
    log += QString("NORMALIZATION TYPE (0=none, 1=Surface, 2=Volume, 3=Amplitude, 4=Spectrum)= 0\n");
  }
  _d->timeLimits->exportParameters( log );
  _d->xSampling->exportParameters( log, "X " );
  _d->ySampling->exportParameters( log, "Y " );
  log += "FREQ BAND WIDTH = " + _d->freqBandWidth->text() + "\n";
  log += "HIGH RESOLUTION = ";
  log += (_d->hrParamGroup->isChecked() ? "y" : "n");
  log += "\n";
  log += "DO DAMPING FACTOR = ";
  log += _d->doDampingFactor->isChecked() ? "true" : "false";
  log += "\n";
  log += "DAMPING FACTOR = " + QString::number(_d->dampingFactorEdit->value()) + "\n";
  return log;
}

bool ToolLinearFKActive::setLogParameters(QString& keyword, QString& value)
{
  TRACE;
  if ( keyword.contains( "HIGH RESOLUTION" ) )
    _d->hrParamGroup->setChecked( value == "y" );
  else if ( keyword.contains( "DO DAMPING FACTOR" ) )
    _d->doDampingFactor->setChecked( value == "true" );
  else if ( keyword.contains( "DAMPING FACTOR" ) )
    _d->dampingFactorEdit->setValue( value.toDouble() );
  else if ( keyword.contains( "FREQ BAND WIDTH" ) )
    _d->freqBandWidth->setText( value );
  else if ( _d->ySampling->loadParameters( keyword, value, "Y " ) ) {
    _d->slowType->setCurrentIndex( _d->ySampling->isInversed() );
  }
  else if ( _d->xSampling->loadParameters( keyword, value, "X " ) );
  else if ( _d->timeLimits->loadParameters( keyword, value ) );
  else if ( keyword.contains( "NORMALIZATION TYPE" ) && value.toInt()==0 )
    _d->normalizationGroup->setChecked(false);
  else if ( _d->normalization->loadParameters( keyword, value ) );
  else if ( _d->taperTimeLimits->loadParameters( keyword, value, "TAPER " ) );
  else if ( keyword.contains( "TAPER WIDTH" ) )
    _d->taperWidth->setText( value );
  else if ( keyword.contains( "DO TAPER" ) )
    _d->taperGroup->setChecked( value == "y" );
  else return false;
  return true;
}

void ToolLinearFKActive::setParameters( int& argc, char ** argv )
{
  TRACE;
  ToolBase::setParameters(argc, argv);
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-param") {
        CoreApplication::checkOptionArg(i, argc, argv);
        loadLogParameters( argv[i] );
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
}

void ToolLinearFKActive::adjustCurve()
{
  TRACE;
  int index = _d->curves->currentLine();
  CurveBrowserProxy * proxy = _d->curves->proxy();
  proxy->setFunction( index );
  if(proxy->sampleCount(index)==0) return;
  // Activate dialog
  CurveBrowserCut * d = new CurveBrowserCut( this );
  d->setCurveLimits( proxy->minimumX( index ), proxy->maximumX( index ) );
  d->setAxisNames( proxy->xName(), proxy->xInversedName() );
  d->setWindowTitle( tr("Adjust") );
  Settings::getWidget( d, "ToolLinearFKActive::adjustCurve" );
  if ( d->exec() == QDialog::Accepted ) {
    Settings::setWidget( d, "ToolLinearFKActive::adjustCurve" );
    double minimum = d->minimumEdit->text().toDouble();
    double maximum = d->maximumEdit->text().toDouble();
    QString unit;
    SamplingOptions options = Function;
    if ( d->linearBut->isChecked() ) {
      unit = proxy->xUnit();
    } else {
      unit = proxy->xInversedUnit();
      options |= InversedScale;
    }
    ModalLine * l = static_cast<ModalLine *>( proxy->currentLayer()->line(index) );
    _linearFKResults->adjust(_d->currentSource->currentIndex(), l->curve(), minimum, maximum, options);
    proxy->addLog( index, tr( "Adjust from %1 %2 to %3 %4\n" )
                          .arg( minimum ).arg( unit ).arg( maximum ).arg( unit ) );
    _d->curves->curvesChanged();
  }
  delete d;
}

double ToolLinearFKActive::dampingFactor() const
{
  TRACE;
  if (_d->doDampingFactor->isChecked()) {
    return _d->dampingFactorEdit->value();
  } else {
    return 0.0;
  }
}

/*!
  Activate the shot corresponding to the selected graph
*/
void ToolLinearFKActive::graphSelected(GraphicObject * obj)
{
  TRACE;
  AxisWindow * w = qobject_cast<AxisWindow *>(obj);
  if (w) {
    int n = _d->currentSource->count();
    for (int i = 0;i<n;i++) {
      if (_linearFKResults->curveLayer(i)->graph()==w) {
        _d->currentSource->setCurrentIndex( i );
      }
    }
  }
}

void ToolLinearFKActive::setWavelengthLimit(double waveLength)
{
  _linearFKResults->setWaveLengthLimit(_d->currentSource->currentIndex(), waveLength);
}
