/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyGui.h>
#include <QGpGuiTools.h>
#include <QGpGuiWave.h>
#include <SciFigs.h>
#include "ToolLinearFKActived.h"

/*!
  Constructs a ToolLinearFKActived as a child of 'parent', with the
  name 'name' and widget flags set to 'f'.
*/
ToolLinearFKActived::ToolLinearFKActived( QWidget* parent, Qt::WFlags fl )
    : QWidget( parent, fl )
{
  TRACE;
  setupUi( this );

  normalization->setExternalRange();
  xSampling->setFileId("FREQUENCY");
  xSampling->setUnit(tr(" Hz"));
  xSampling->setPrecision( 2 );
  xSampling->setSingleStep( 0.25 );
  xSampling->setAdmissibleRange(1e-99, 1e99);
  xSampling->setMinimum(10.0);
  xSampling->setMaximum(50.0);
  ySampling->setFileId("SLOWNESS");
  slowType->setCurrentIndex(0);
  setSlownessType();
  ySampling->setPrecision( 5 );    // Avoid rounding errors when reloading parameters
  ySampling->setCount(500);
  ySampling->setSampling(Sampling::Linear);
  ySampling->setMinimum(0.001);
  ySampling->setMaximum(0.01);
  timeLimits->removeUseFirstOnly();

  curves->setProxy( new DispersionProxy );
}

void ToolLinearFKActived::on_slowType_activated( int index )
{
  TRACE;
  ySampling->setPrecision( 5 );                   // Avoid rounding errors
  ySampling->setAdmissibleRange(1e-99, 1e99);
  ySampling->setInversed( index ==1 );
  setSlownessType();
}

void ToolLinearFKActived::setSlownessType()
{
  TRACE;
  ySampling->blockSignals(true);
  if (slowType->currentIndex()==0) {  // Slowness
    ySampling->setUnit( tr(" s/m") );
    ySampling->setPrecision( 5 );
    ySampling->setSingleStep( 0.001 );
    ySampling->setAdmissibleRange(1e-99, 1e99);
  } else {         // Velocity
    ySampling->setUnit( tr(" m/s") );
    ySampling->setPrecision( 0 );
    ySampling->setSingleStep( 10.0 );
    ySampling->setAdmissibleRange(1.0, 1e99);
  }
  ySampling->blockSignals(false);
  emit slowTypeChanged();
}
