/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-03
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyGui.h>
#include <ArrayCore.h>
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include "ToolFKd.h"

/*
 *  Constructs a ToolFKd as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
ToolFKd::ToolFKd( QWidget* parent, Qt::WFlags fl )
    : QWidget( parent, fl )
{
  TRACE;
  setupUi( this );

  freqSamp->setFileId("FREQUENCY");
  freqSamp->setUnit(tr(" Hz"));
  freqSamp->setPrecision( 2 );
  freqSamp->setSingleStep( 0.25 );
  freqSamp->setAdmissibleRange(1e-99, 1e99);
  timeLimits->removeUseFirstOnly();
  winParam->removeFilterOption();
  winParam->setLength( WindowingParameters::FreqDep, 50.0 );

  _outputFileChecked=false;
}

void ToolFKd::getParameters( FKParameters& param )
{
  TRACE;

  timeLimits->getParameters( param.timeLimits );
  winParam->getParameters( param.windowing );
  freqSamp->getParameters( param.frequencySampling );
  // Output file not set here (useless and annoying for time window browsing)
  param.setMaximumPeakCount( maxPeakCount->value() );
  param.setAbsoluteThreshold( maxAbsoluteThres->value() );
  param.setRelativeThreshold( maxRelativeThres->value() );
  param.setMinimumWaveNumber( kminEdit->value() );
  param.setMaximumWaveNumber( kmaxEdit->value() );
  param.setMaximumSlowness( 1.0 / vminEdit->value() );
  param.frequencyBandWidth = freqBandWidth->value();
}

void ToolFKd::on_outputFileBrowse_clicked()
{
  TRACE;
  QString str = Message::getSaveFileName( tr( "Output .max file" ), tr( "FK max file (*.max)" ), outputFileEdit->text() );
  if ( str.length() > 0 ) {
    outputFileEdit->setText( str );
    _outputFileChecked=true;
  }
}

void ToolFKd::on_outputFileEdit_textChanged(QString )
{
  TRACE;
  _outputFileChecked=false;
}

QString ToolFKd::outputFile()
{
  TRACE;
  if (outputFileEdit->text().isEmpty()) {
    on_outputFileBrowse_clicked();
    if (outputFileEdit->text().isEmpty()) return QString::null;
  }
  if (!_outputFileChecked) {
    QFileInfo fi (outputFileEdit->text());
    if (fi.exists()) {
      if (Message::question( MSG_ID, tr( "Output .max file" ), tr("File already exist. Do you want to overwrite?"),
                            Message::no(), Message::yes())==Message::Answer0) {
        return QString::null;
      }
    }
  }
  return outputFileEdit->text();
}

void ToolFKd::numFreqChanged()
{
  TRACE;
  freqScroll->setMaximum( freqSamp->count() - 1 );
}

void ToolFKd::on_freqScroll_valueChanged( int )
{
  TRACE;
  Sampling fparam;
  freqSamp->getParameters( fparam );
  testFrequency->setValue( fparam.value( freqScroll->value() ));
}

void ToolFKd::setRunning(bool r, const QString& message)
{
  TRACE;
  startBut->setEnabled(!r);
  stopBut->setEnabled(r);
  if(r) {
    if(message.isEmpty()) {
      mainStatus->setText(tr("Running..."));
    } else {
      mainStatus->setText(message);
    }
  } else {
    mainStatus->setText(tr("Not running"));
  }
}
