/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2005-10-03
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef TOOLFKD_H
#define TOOLFKD_H

#include <ArrayCore.h>
#include <GeopsyGui.h>

#include "ui_ToolFKd.h"

class ToolFKd : public QWidget, public Ui::ToolFKd
{
  Q_OBJECT
public:
  ToolFKd( QWidget* parent = 0, Qt::WFlags fl = 0 );

  QString outputFile();
  void getParameters( FKParameters& param );
  void setRunning(bool r, const QString& message=QString::null);
  void setOutputFileChecked(bool c) {_outputFileChecked=c;}
public slots:
  void on_freqScroll_valueChanged( int );
  void numFreqChanged();
private slots:
  void on_outputFileBrowse_clicked();
  void on_outputFileEdit_textChanged(QString );
signals:
  void updateSubPool();
private:
  bool _outputFileChecked;
};

#endif // QTBTOOLFKD_H
