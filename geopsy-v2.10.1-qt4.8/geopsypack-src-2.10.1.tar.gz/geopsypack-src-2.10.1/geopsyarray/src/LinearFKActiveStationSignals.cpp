/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-03-27
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <GeopsyCore.h>
#include "LinearFKActiveStationSignals.h"

/*!
  \class LinearFKActiveStationSignals qtblinearfkactivestationsignals.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

void LinearFKActiveStationSignals::beginPreprocess( const TimeRange& tw )
{
  TRACE;
  copyOriginalSignal(0, tw);
  //printf("nStart=%i nSamples=%i\n",nStart,nSamples);
  processed(0)->subtractValue();
  _t0 = tw.start();
}

void LinearFKActiveStationSignals::taper( RelativeTimeRange& timeLimits, double width )
{
  TRACE;
  Signal * sig = originalSignals()->firstValidSignal();
  if (sig) {
    TimeRange tw = timeLimits.absoluteRange(sig);
    processed(0)->taper( tw.start() - _t0, tw.end() - _t0, tw.lengthSeconds() * width );
  } else {
    App::stream() << tr("Cannot calculate taper lenght for an empty station") << endl;
  }
}

void LinearFKActiveStationSignals::normalize(const NormalizationParam& p)
{
  TRACE;
  Signal * sig=originalSignals()->firstValidSignal();
  if (sig) {
    double fac;
    SAFE_UNINITIALIZED(fac,0);
    switch(p.type()) {
    case NormalizationParam::None:
      fac=1.0;
      break;
    case NormalizationParam::SurfaceAttenuation:
      fac=sqrt(sig->sourceReceiverDistance());
      break;
    case NormalizationParam::VolumeAttenuation:
      fac=sig->sourceReceiverDistance();
      break;
    case NormalizationParam::MaximumAmplitude:
      fac=1.0/processed(0)->maximumAmplitude(0, processed(0)->nSamples()-1);
      break;
    case NormalizationParam::SpectrumEnergy:
      processed(0)->fastFourierTransform(DoubleSignal::Spectrum);
      fac=1.0/processed(0)->energy(p.minimumFrequency(), p.maximumFrequency());
      processed(0)->fastFourierTransform(DoubleSignal::Waveform);
      break;
    }
    if(fac>0.0) {
      processed(0)->multiply(fac);
    } else {
      App::stream() << tr("Null factor for nomalization, skipped") << endl;
    }
  } else {
    App::stream() << tr("Cannot calculate normalization for an empty station") << endl;
  }
}

void LinearFKActiveStationSignals::endPreprocess()
{
  TRACE;
  // Set a 10% taper in time domain
  double winLen=processed(0)->duration();
  processed(0)->taper(0.0,winLen,0.1*winLen);
  // Switch to frequency domain
  processed(0)->fastFourierTransform(DoubleSignal::Spectrum);
  /*for (int i=0; i<nSamples/2;i++) 
    printf("%lg %lg\n",(double)i*_signals[0].processed->duration(),
           _signals[0].processed->spectrumAmplitude(i));*/
}
