/***************************************************************************
**
**  This file is part of geopsyarray.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-02-20
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <ArrayCore.h>
#include "LinearFKPassiveLoop.h"
#include "LinearFKSearch.h"

/*!
  \class LinearFKPassiveLoop qtblinearfkpassiveloop.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

LoopTask * LinearFKPassiveLoop::newTask()
{
  TRACE;
  LinearFKPassiveLoopTask * t = new LinearFKPassiveLoopTask;
  t->setLoop(this);
  t->setArray(*_array);
  t->setParameters(_param);
  t->setGrid(_azimuth);
  return t;
}

LinearFKPassiveLoopTask::LinearFKPassiveLoopTask()
{
  TRACE;
  _linearGrid = 0;
}

LinearFKPassiveLoopTask::~LinearFKPassiveLoopTask()
{
  TRACE;
  delete _linearGrid;
}

void LinearFKPassiveLoopTask::setGrid(double azimuth)
{
  TRACE;
  // FK tools use a FKGridSearch which is not valid in this case.
  // We must initialize to null to avoid problems with destructors.
  _grid[0]=0;
  // We need two search objets for both directions (initialization of shifts)
  _linearGrid = new LinearFKSearch;
  _linearGrid->setFunction( _process->function(0) );
  _linearGrid->setAzimuth(azimuth);
  const FKParameters * param = _process->parameters();
  _linearGrid->setGrid( param->minimumWaveNumber(), param->maximumWaveNumber() );
  _linearGrid->function()->setMaximumSlowness( param->maximumSlowness() );
}

void LinearFKPassiveLoopTask::run(int index)
{
  TRACE;
  // Revert the order: start with expensive high frequencies
  // When the number of cores increases and tends to the number
  // of frequencies, it is more efficient to start with with the
  // most expensive frequencies.
  index=endIndex()-index-1;

  QString freqLog, freqStatus;
  _process->setFrequency(index, &freqLog, &freqStatus);
  setStatus(freqStatus);
  _loop->addLog(freqLog);
  // Loop over all time windows
  const TimeRangeList& winList=*_process->timeRangeList();
  int nWin=winList.count();
  setProgressMaximum(nWin);
  for (int iWin=0; iWin<nWin; iWin++) {
    if (terminated()) break;
    setProgressValue(iWin);
    _win = &winList.at(iWin);
    if (!_process->lockTimeWindow(_win)) continue;
    _currentComponent = 0;
    exportMax();
    _process->unlockTimeWindow();
  }
}

void LinearFKPassiveLoopTask::exportMax()
{
  TRACE;
  _linearGrid->function()->setFrequencyBand( _process->frequency(), _win->lengthSeconds());
  const FKParameters * param = _process->parameters();
  if ( param->maximumPeakCount()>1 ) {
    Function2MaximaIterator it = _linearGrid->localMax( param->maximumPeakCount() ,
                                                           param->absoluteThreshold(),
                                                           param->relativeThreshold() );
    for ( ;it != _linearGrid->localMaxEnd();++it ) {
      exportResults( it->pos() );
    }
  } else {
    if (_linearGrid->globalMax()>param->absoluteThreshold()) {
      exportResults( _linearGrid->pos() );
    }
  }
}

void LinearFKPassiveLoopTask::getPower( const Point2D& pos, double& beampower, double& semblance )
{
  TRACE;
  const FK * fk = _linearGrid->function();
  beampower = fk->value( pos.x(), pos.y() );
  semblance = beampower / fk->absolutePower(0);
  // Normalizations by number of stations or band width
  const FrequencyBand& fb = _process->frequency();
  double freqBandWidth=fb.width();
  if ( freqBandWidth > 0.0 ) {
    beampower = 10.0 * log10( beampower / ( freqBandWidth * _nStations2 ) );
    semblance /= _nStations;
  } else {
    beampower = 10.0 * log10( beampower / ( fb.center() * _nStations2 ) );
    semblance /= _nStations;
  }
}
