<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbArrayPlugin</name>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="56"/>
        <source>F-K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="62"/>
        <source>High resolution F-K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.h" line="37"/>
        <source>Array analysis: F-K and SPAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="68"/>
        <source>SPAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="74"/>
        <source>Linear F-K for active experiments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="80"/>
        <source>Linear F-K for passive experiments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="108"/>
        <source>FK (tag=%1, slot=0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="112"/>
        <source>High resolution FK (tag=%1, slot=1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="114"/>
        <source>SPAC (tag=%1, slot=2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="117"/>
        <source>Linear FK Active (tag=%1, slot=3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbarrayplugin.cpp" line="119"/>
        <source>Linear FK Passive (tag=%1, slot=4)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbFKLoop</name>
    <message>
        <location filename="../src/qtbfkloop.cpp" line="80"/>
        <location filename="../src/qtbfkloop.cpp" line="117"/>
        <source>FK toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkloop.cpp" line="80"/>
        <source>Condition on velocity is too restricitive, no FK maximum searched, either decrease Vmin, increase minimum frequency or refine the grid resolution.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbFKLoopTask</name>
    <message>
        <location filename="../src/qtbfkloop.cpp" line="250"/>
        <source>Export FK grid values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkloop.cpp" line="251"/>
        <source>Cannot write to file %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbFKTimeWindows</name>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="13"/>
        <source>Time Window browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="46"/>
        <source>Time window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="73"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Angle is counted in degrees from North, clockwize.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="82"/>
        <source> °</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="115"/>
        <source>k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="128"/>
        <source> rad/m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="144"/>
        <source>v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="157"/>
        <source> m/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.ui" line="185"/>
        <source>300 m/s - 0.0033 s/m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.cpp" line="92"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.cpp" line="95"/>
        <location filename="../src/qtbfktimewindows.cpp" line="200"/>
        <location filename="../src/qtbfktimewindows.cpp" line="239"/>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.cpp" line="96"/>
        <location filename="../src/qtbfktimewindows.cpp" line="196"/>
        <source>Radial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.cpp" line="97"/>
        <location filename="../src/qtbfktimewindows.cpp" line="198"/>
        <source>Transverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.cpp" line="177"/>
        <source>cannot allocate all signals, increase buffer size
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfktimewindows.cpp" line="261"/>
        <source>Propagation towards %1 counted from North
at k=%2 rad/m, v=%3 m/s or s=%4 s/km</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbHRFKTimeWindows</name>
    <message>
        <location filename="../src/qtbhrfktimewindows.cpp" line="38"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhrfktimewindows.cpp" line="41"/>
        <location filename="../src/qtbhrfktimewindows.cpp" line="70"/>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhrfktimewindows.cpp" line="42"/>
        <location filename="../src/qtbhrfktimewindows.cpp" line="66"/>
        <source>North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhrfktimewindows.cpp" line="43"/>
        <location filename="../src/qtbhrfktimewindows.cpp" line="68"/>
        <source>East</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbLinearFKActiveArrayStations</name>
    <message>
        <location filename="../src/qtblinearfkactivearraystations.cpp" line="43"/>
        <source>Shot at (%1, %2, %3), time=%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactivearraystations.cpp" line="54"/>
        <source>Checking stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactivearraystations.cpp" line="139"/>
        <source>Cannot add time window to an empty array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactivearraystations.cpp" line="172"/>
        <source>cannot allocate all signals, increase memory buffer size
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbLinearFKActiveResults</name>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="57"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="59"/>
        <source>Stack selected plots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="60"/>
        <source>Grids of selected plot are stacked and a new plot is added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="66"/>
        <source>Pick curves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="67"/>
        <source>Switch all selected graphs to pick mode (pick ordered)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="72"/>
        <source>Auto pick curves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="73"/>
        <source>Scan grids to find the absolute maximum and start picking from there</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="77"/>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="197"/>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="198"/>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="202"/>
        <source>Export all curves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="78"/>
        <source>Export al curves from all selected plots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="168"/>
        <source>Automatic picking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="198"/>
        <source>4 columns file(*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="203"/>
        <source>Impossible to access to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="226"/>
        <source>Stack grids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactiveresults.cpp" line="255"/>
        <source>Stack of %1 grids</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbLinearFKActiveStationSignals</name>
    <message>
        <location filename="../src/qtblinearfkactivestationsignals.cpp" line="51"/>
        <source>Cannot calculate taper lenght for an empty station</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactivestationsignals.cpp" line="84"/>
        <source>Null factor for nomalization, skipped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblinearfkactivestationsignals.cpp" line="87"/>
        <source>Cannot calculate normalization for an empty station</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbSPACLoop</name>
    <message>
        <location filename="../src/qtbspacloop.cpp" line="86"/>
        <source>SPAC toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacloop.cpp" line="87"/>
        <source>You forgot to define the rings
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolArrayBase</name>
    <message>
        <location filename="../src/qtbtoolarraybase.cpp" line="61"/>
        <source>Loading samples ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolarraybase.cpp" line="66"/>
        <source>Checking stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolarraybase.cpp" line="75"/>
        <source>Found %1 different stations
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolarraybase.cpp" line="115"/>
        <location filename="../src/qtbtoolarraybase.cpp" line="135"/>
        <source>Cannot open .log file for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolarraybase.cpp" line="70"/>
        <source>Creating array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolarraybase.cpp" line="71"/>
        <source>Found less than 2 stations.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolFK</name>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="94"/>
        <location filename="../src/qtbtoolfk.cpp" line="98"/>
        <location filename="../src/qtbtoolfk.cpp" line="102"/>
        <location filename="../src/qtbtoolfk.cpp" line="106"/>
        <source>FK parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="94"/>
        <source>Band width cannot be null or negative.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="98"/>
        <source>kmin must be less than kmax.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="102"/>
        <source>kmin cannot be null or negative.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="106"/>
        <source>kmin cannot be more than 3600 times smaller than kmax. If kmin*3600==kmax, the approximate size of a FK map is 100 Mb.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="156"/>
        <source>Signals are ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="190"/>
        <source>Process started at %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="198"/>
        <source>Process run in %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfk.cpp" line="199"/>
        <source>Process ended at %1
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolFKd</name>
    <message>
        <location filename="../src/qtbtoolfkd.cpp" line="76"/>
        <location filename="../src/qtbtoolfkd.cpp" line="99"/>
        <source>Output .max file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.cpp" line="76"/>
        <source>FK max file (*.max)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.cpp" line="99"/>
        <source>File already exist. Do you want to overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.cpp" line="128"/>
        <source>Running...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.cpp" line="130"/>
        <location filename="../src/qtbtoolfkd.ui" line="525"/>
        <source>Not running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="13"/>
        <source>QtbToolFKd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="77"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Thanks to this test viewer, you can visualize the beam power pattern for all the selected windows at a given frequency. It helps you to choose appropriate grid parameters, to get some ideas of the phase velocity, to observe when do appear aliasing effect and resolution limit. With the scroll bar on the left you can view the results for different frequencies.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="80"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="90"/>
        <source>at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.cpp" line="45"/>
        <location filename="../src/qtbtoolfkd.ui" line="103"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="119"/>
        <source>Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="220"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It is the sampling step in the wavenumber domainfor the power spectrum. It is used in two distinct ways.&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In &quot;Test&quot; mode, it drives the total range of the obtained plot.&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;After clicking on &quot;Start&quot;, when all frequencies are sequentially browsed, it is the range for searching for peaks of the beam power pattern. If you estimated kmin and kmax with build_array, kmax is a good candidate for the grid step. Choosing a lower value may distord the statitics at high frequency.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="223"/>
        <source>Grid size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="200"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The frequency sampling gives a list of central frequencies (fc). Around these frequencies, the power spectra are evaluated after a narrow band pass filter which size is adjusted by this parameter. A value of 0.1 means a frequency band from 0.9*fc to 1.1*fc.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="236"/>
        <location filename="../src/qtbtoolfkd.ui" line="264"/>
        <source> rad/m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="336"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It is the sampling step in the wavenumber domain for the power spectrum. It is used in two distinct ways.&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In &quot;Test&quot; mode, it drives the graphical resolution of the obtained plot.&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;After clicking on &quot;Start&quot;, when all frequencies are sequentially browsed, it is the resolution of a coarse gridding of the beam power pattern. It should be at least 4 times thinner than the width of the peaks (at least 4 samples in each direction kx or ky above the mid-height). If you estimated kmin and kmax with build_array, kmin/4 is a good candidate for the grid step.&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Note for high resolution f-k: the size of the peaks may be less than the one obtained with a basic f-k processing. Hence, a safe approach may requires that you manually check with &quot;Test&quot; the condition mentionned hereabove.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="339"/>
        <source>Grid step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="210"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This parameter is also related to the discretization of the power spectrum like the grid step and the grid size. The grid size is defined in wavenumber, hence at low frequency, it may correspond to abnormally low velocities, to speed up the search and to discard non physical results, you can limit the grid size in terms of velocity. This is the minimum velocity that will be take into account.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="203"/>
        <source>Band width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="213"/>
        <source>v min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="292"/>
        <source> m/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="349"/>
        <source>Power spectrum maxima</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="408"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If a value of zero is entered noting is performed.&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In other cases, all (local) maxima found which value are less than the absolute threshold are discarded. In other words, only the most energetic peaks are output to file.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This option works even if the maximum number of power spectrum maxima is 1 (rejection of local maxima).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="434"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If a value of zero is entered noting is performed.&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In other cases, all (local) maxima found which value is less than a threshold % of the most energetic maximum are discarded. In other words, only the most energetic peaks are output to file, the energetic criterium being relative to the highest peak of the power spectrum.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This option works only when the maximum number of power spectrum maxima is at least 2.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="450"/>
        <source> %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="470"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The main output file where all values of slowness and propagating azimuths are saved (.max file). This kind of file can be analysed with fk2disp to extract an average dispersion curve. A .log file with the same base name is also saved. It contains all input parameters and processing information.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="369"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans Serif&apos;;&quot;&gt;It is the number of maxima that are seached for in the power spectrum. A value of 1 means export only the highest peak, any other values will also export sub-maxima that may correspond to higher modes.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="375"/>
        <source>Maximum number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="411"/>
        <source>Absolute th.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="437"/>
        <source>Relative th.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="473"/>
        <source>Output file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="493"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="519"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="557"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Every time you start a process, a .log file is saved containing the input parameters. You can recall them from a previous calculation.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="560"/>
        <source>Load parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="586"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Stop the currently running process. Do not be surprised if it do not stop immediately. If will effectively stop once the curent frequency band will be computed for all time windows.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="589"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="599"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Start the computation for all frequency samples and export the results to the specified .max file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="602"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="29"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="161"/>
        <source>Processing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="41"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="167"/>
        <source>Frequency sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolfkd.ui" line="185"/>
        <source>FK gridding</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolHRFK</name>
    <message>
        <location filename="../src/qtbtoolhrfk.cpp" line="50"/>
        <source>High resolution matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhrfk.cpp" line="55"/>
        <source>Damping factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhrfk.cpp" line="112"/>
        <source>Signals are ready</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolLinearFKActive</name>
    <message>
        <location filename="../src/qtbtoollinearfkactive.cpp" line="81"/>
        <source>&amp;Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactive.cpp" line="81"/>
        <source>Adjust current curve to the closest maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactive.cpp" line="179"/>
        <source>Linear fk results (%1 arrays)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactive.cpp" line="272"/>
        <source>Linear F-K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactive.cpp" line="272"/>
        <source>Null time window length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactive.cpp" line="446"/>
        <source>Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactive.cpp" line="462"/>
        <source>Adjust from %1 %2 to %3 %4
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolLinearFKActived</name>
    <message>
        <location filename="../src/qtbtoollinearfkactived.cpp" line="44"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.cpp" line="69"/>
        <source> s/m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.cpp" line="74"/>
        <source> m/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="38"/>
        <source>Pre-processing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="59"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Select for processing signals for which source to receiver distance is between minimum and maximum.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This is handy if you want to exclude signals close to the source point (usually at least a wavelength).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="67"/>
        <source>Source-receiver distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="75"/>
        <source>Minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="88"/>
        <location filename="../src/qtbtoollinearfkactived.ui" line="117"/>
        <source> m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="104"/>
        <source>Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="138"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The time limits can be different for all signals inside each array. If &apos;Use picks from first...&apos; is selected, the picks of the first signal are considered (as displayed in signal viewer after creation of this toolbox).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="144"/>
        <source>Taper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="191"/>
        <source>&lt;p&gt;The signal will be multiplied by a factor between 0 and 1. The width defines the length of the transition between those two values.&lt;/p&gt;
&lt;p&gt;It is the ratio of the transition length over the difference between the time limits (in percentage)&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="195"/>
        <source>Width (%) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="214"/>
        <source>Normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="261"/>
        <source>Processing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="282"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The time limits are the same for all signals inside each array. Hence time picks are considered only for the first signal of each array (as displayed in signal viewer after creation of this toolbox).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="288"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="332"/>
        <source>Frequency band width (ratio)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="345"/>
        <source>0.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="357"/>
        <source>High resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="369"/>
        <source>Damping factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="409"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="415"/>
        <source>X axis sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="442"/>
        <source>Y axis sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="464"/>
        <source>Slowness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="469"/>
        <source>Velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="483"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Verdana&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Normalize the grid by the total power available for each frequency.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="489"/>
        <source>Normalize by absolute power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="513"/>
        <source>Curves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="568"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Load parameters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="574"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Every time you start a process, a .log file is saved containing the input parameters. You can recall them from a previous calculation.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="577"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="584"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Save parameters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="590"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="616"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Start the computation for all frequency samples and export the results to the specified .report file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoollinearfkactived.ui" line="619"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolLinearFKPassive</name>
    <message>
        <location filename="../src/qtbtoollinearfkpassive.cpp" line="59"/>
        <source>Only vertical component are accepted for pssive recording with linear arrays.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolSPAC</name>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="109"/>
        <source>Creating array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="110"/>
        <source>Error while checking components: only vertical or 3 components allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="121"/>
        <source>%1 - array map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="125"/>
        <source>%1 - co-array map </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="204"/>
        <source>Process started at %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="212"/>
        <source>Process run in %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="213"/>
        <source>Process ended at %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspac.cpp" line="306"/>
        <source>Found %1 couples
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolSPACd</name>
    <message>
        <location filename="../src/qtbtoolspacd.cpp" line="42"/>
        <location filename="../src/qtbtoolspacd.ui" line="97"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.cpp" line="60"/>
        <source>Autocorrelation output file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.cpp" line="61"/>
        <source>SPAC output file (*.target *.stmap *.max)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.cpp" line="120"/>
        <source>Running...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.cpp" line="122"/>
        <location filename="../src/qtbtoolspacd.ui" line="292"/>
        <source>Not running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="13"/>
        <source>SPAC Toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="29"/>
        <source>Rings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="45"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="51"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="77"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Thanks to this test viewer, you can visualize the automatic window selection at a given frequency. Unlike f-k processing, not other pre-visualization is possible.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="80"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="87"/>
        <source>at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="142"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="154"/>
        <source>Frequency sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="172"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="184"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This format contains only the statistics: mean, stddev and number of windows for each sample. Additionaly, it includes the correct mode for each curve and the list of selected rings. Hence, these files are ready for dinver (inversion).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="190"/>
        <source>Dinver target (.target)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="200"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This format contains only the statistics: mean, stddev and number of windows for each sample. Additionaly, it includes the list of selected rings. These files can be directly imported in Dinver but they require some editing in Dinver. As text files arranged in columns, they are handy for text processors. For multi-component, various files with explicit file names are created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="206"/>
        <source>Cap spac output (.stmap)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="213"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This format does not contain any statistic. It is the raw results from the autocorrelation processing. It may be a huge file. You can process it with max2curve.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="219"/>
        <source>All results for each time window (.max)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="234"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The main output file where all values of auto-correlation  are saved per ring (.report file). This kind of file can be analysed with spac2disp to select auto-correlation values that correspond to a common dispersion curve. A .log file with the same base name is also saved. It contains all input parameters and processing information.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="237"/>
        <source>Output file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="244"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;File name extension is added automatically&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="257"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="286"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="324"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Every time you start a process, a .log file is saved containing the input parameters. You can recall them from a previous calculation.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="327"/>
        <source>Load parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="353"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Stop the currently running process. Do not be surprised if it do not stop immediately. If will effectively stop once the curent frequency band will be computed for all time windows.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="356"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="366"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Start the computation for all frequency samples and export the results to the specified .report file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspacd.ui" line="369"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
