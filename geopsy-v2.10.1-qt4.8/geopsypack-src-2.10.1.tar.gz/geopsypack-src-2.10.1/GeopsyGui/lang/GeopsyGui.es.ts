<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ArrayDefinition</name>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="40"/>
        <source>Group name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="41"/>
        <source>Signal name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="42"/>
        <source>Component</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="43"/>
        <source>Time reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="44"/>
        <location filename="../src/ArrayDefinition.ui" line="97"/>
        <source>Start time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="45"/>
        <location filename="../src/ArrayDefinition.ui" line="127"/>
        <source>End time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="46"/>
        <source>Rec x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="47"/>
        <location filename="../src/ArrayDefinition.cpp" line="48"/>
        <source>Rec y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="81"/>
        <source>Choose CAP Settings file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="81"/>
        <source>settings file (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.cpp" line="165"/>
        <source>Cap working directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="22"/>
        <source>Array definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="46"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="51"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="56"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="61"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="66"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="71"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="76"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="81"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="104"/>
        <source>MM/dd/yy hh:mm:ss.zzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="154"/>
        <source>Selected group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="161"/>
        <location filename="../src/ArrayDefinition.ui" line="182"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="175"/>
        <source>Working directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="189"/>
        <source>CAP settings file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="218"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayDefinition.ui" line="231"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ArrayMap</name>
    <message>
        <location filename="../src/ArrayMap.cpp" line="36"/>
        <source>&amp;Set image scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArrayMap.cpp" line="36"/>
        <source>Click on at least two points to scale image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CityLoader</name>
    <message>
        <location filename="../src/CityLoader.cpp" line="92"/>
        <source>Cityshark software version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.cpp" line="100"/>
        <source>Flash card successfully mounted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.cpp" line="113"/>
        <source>Flash card successfully unmounted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.cpp" line="135"/>
        <location filename="../src/CityLoader.cpp" line="140"/>
        <source>Unmounting/Mounting flash card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.cpp" line="135"/>
        <source>No responding after %1 seconds, do want to wait again?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.cpp" line="171"/>
        <source>Loading flash card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.cpp" line="172"/>
        <source>No files were selected, do you want to load all of them?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.cpp" line="222"/>
        <source>Flash card directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="13"/>
        <source>Cityshark signal loader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="25"/>
        <source>Flash card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="45"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="55"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="78"/>
        <source>No card mounted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="91"/>
        <source>Mount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="107"/>
        <source>Unmount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="152"/>
        <source>Reset flash card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="155"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="165"/>
        <source>Load selected signals into current database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="168"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CityLoader.ui" line="181"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CitySignalItem</name>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="82"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="82"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="123"/>
        <source>Erased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="125"/>
        <source>Start time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="127"/>
        <source>End time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="129"/>
        <source>File index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="131"/>
        <source>Channel num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="133"/>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="135"/>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="137"/>
        <source>Max Allowed Ampl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="139"/>
        <source>Max Reached Ampl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="141"/>
        <source>Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="143"/>
        <source>N Samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CitySignalItem.cpp" line="145"/>
        <source>Saturation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DirectoryMonitor</name>
    <message>
        <location filename="../src/DirectoryMonitor.cpp" line="49"/>
        <location filename="../src/DirectoryMonitor.cpp" line="92"/>
        <source>Not active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.cpp" line="90"/>
        <source>Active: %1/%2 files loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.cpp" line="98"/>
        <source>Directory to monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="13"/>
        <source>Directory monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="21"/>
        <source>Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="31"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="42"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Wait for delay seconds after last file modification before loading it in geopsy. Increase this time is you notice file error during automatic load (file partially writen at time of load).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="48"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="61"/>
        <source> s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="80"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Check at interval seconds for new files in directory&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="86"/>
        <source>Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="99"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="122"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="142"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DirectoryMonitor.ui" line="149"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilterParamWidget</name>
    <message>
        <location filename="../src/FilterParamWidget.cpp" line="76"/>
        <location filename="../src/FilterParamWidget.cpp" line="86"/>
        <location filename="../src/FilterParamWidget.ui" line="37"/>
        <source>Low pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="13"/>
        <source>Filter parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="42"/>
        <source>High pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="47"/>
        <source>Band pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="52"/>
        <source>Band reject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="60"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="86"/>
        <source>Hz to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="112"/>
        <source>Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="121"/>
        <source>Filter method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="132"/>
        <source>Butterworth filter (outphasing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="155"/>
        <source>Causal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="185"/>
        <source>Order of Butterworth&apos;s filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="209"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Multiplication of the complex spetrum by a cosine taper function (zero phase filter)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="212"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The modulus of the spectrum will be multiplied by a factor between 0 and 1, not changing the phase of the spectrum.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The width defines the length of the transition between those two values.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It is the ratio of the transition range in Hz over the threshold frequency(ies).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="220"/>
        <source>Cosine taper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="243"/>
        <location filename="../src/FilterParamWidget.ui" line="246"/>
        <source>Width must be between 0 and 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterParamWidget.ui" line="249"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoadFormat</name>
    <message>
        <location filename="../src/LoadFormat.ui" line="19"/>
        <source>File Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/LoadFormat.ui" line="80"/>
        <source>Show this dialog next time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/LoadFormat.ui" line="112"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/LoadFormat.ui" line="125"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MorletParamWidget</name>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="17"/>
        <location filename="../src/MorletParamWidget.ui" line="31"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="37"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="50"/>
        <location filename="../src/MorletParamWidget.ui" line="97"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Modified Morlet Wavelet in spectral domain:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;M(f) = 1/pow(&lt;span style=&quot; font-family:&apos;Symbol&apos;;&quot;&gt;p&lt;/span&gt;,0.25)*exp( (w&lt;span style=&quot; vertical-align:sub;&quot;&gt;0&lt;/span&gt;*f/f&lt;span style=&quot; vertical-align:sub;&quot;&gt;i&lt;/span&gt; - w&lt;span style=&quot; vertical-align:sub;&quot;&gt;0&lt;/span&gt; )&lt;span style=&quot; vertical-align:super;&quot;&gt;2&lt;/span&gt; * m )&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;w&lt;span style=&quot; vertical-align:sub;&quot;&gt;0&lt;/span&gt;, m are the wavelet parameters. Theoretically w&lt;span style=&quot; vertical-align:sub;&quot;&gt;0&lt;/span&gt;&amp;gt;5.5. A typical value for w&lt;span style=&quot; vertical-align:sub;&quot;&gt;0&lt;/span&gt; is 6. A typical value for m is 10.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;f&lt;span style=&quot; vertical-align:sub;&quot;&gt;i&lt;/span&gt; is the analysed frequency.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="78"/>
        <source>fi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="109"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="124"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The uncertainties in time and frequency:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Symbol&apos;;&quot;&gt;D&lt;/span&gt;T&lt;span style=&quot; vertical-align:sub;&quot;&gt;i&lt;/span&gt; = w&lt;span style=&quot; vertical-align:sub;&quot;&gt;0 &lt;/span&gt;/ ( 2 &lt;span style=&quot; font-family:&apos;Symbol&apos;;&quot;&gt;p&lt;/span&gt; f&lt;span style=&quot; vertical-align:sub;&quot;&gt;i &lt;/span&gt;) sqrt(m)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Symbol&apos;;&quot;&gt;D&lt;/span&gt;F&lt;span style=&quot; vertical-align:sub;&quot;&gt;i&lt;/span&gt; = f&lt;span style=&quot; vertical-align:sub;&quot;&gt;i &lt;/span&gt;/ (2 w&lt;span style=&quot; vertical-align:sub;&quot;&gt;0 &lt;/span&gt;sqrt(m) )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MorletParamWidget.ui" line="133"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NormalizationWidget</name>
    <message>
        <location filename="../src/NormalizationWidget.cpp" line="46"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NormalizationWidget.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NormalizationWidget.ui" line="25"/>
        <source>Spectrum energy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NormalizationWidget.ui" line="32"/>
        <source>Maximum amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NormalizationWidget.ui" line="42"/>
        <location filename="../src/NormalizationWidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Distance is counted between the source and the receiver coordinates.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NormalizationWidget.ui" line="48"/>
        <source>1/distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NormalizationWidget.ui" line="61"/>
        <source>1/sqrt(distance)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PickItem</name>
    <message>
        <location filename="../src/PickItem.cpp" line="90"/>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickItem.cpp" line="91"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PickLayer</name>
    <message>
        <location filename="../src/PickLayer.cpp" line="86"/>
        <source>&amp;Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickLayer.cpp" line="90"/>
        <source>Ctrl+Shift+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickLayer.cpp" line="91"/>
        <source>Pick time events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickLayer.cpp" line="301"/>
        <source>f=%1 Hz, Amplitude=%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickLayer.cpp" line="303"/>
        <source>t=%1 (%2 from T0), Amplitude=%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickLayer.cpp" line="310"/>
        <source>t=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickLayer.cpp" line="346"/>
        <location filename="../src/PickLayer.cpp" line="352"/>
        <source>Switching to TimePick[%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickLayer.cpp" line="391"/>
        <source>Picks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PickToPick</name>
    <message>
        <location filename="../src/PickToPick.ui" line="14"/>
        <source>Graphic - Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="29"/>
        <source>Magnifier window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="44"/>
        <source> s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="76"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This is the number of signal to display around the current trace being picked.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="82"/>
        <source>Size of context</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="89"/>
        <source>Display time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="107"/>
        <source>Use pick n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="143"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PickToPick.ui" line="165"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PicksProperties</name>
    <message>
        <location filename="../src/PicksProperties.ui" line="13"/>
        <source>Picks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PicksProperties.ui" line="67"/>
        <source>Default colors</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RD3LogParameter</name>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="16"/>
        <source>RD3 Default Log Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="36"/>
        <source>T0 (10e-6 s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="43"/>
        <source>578</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="53"/>
        <source>-0.965</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="63"/>
        <source>1024</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="73"/>
        <source>Samp. freq. (MHz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="80"/>
        <source>Number of samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="105"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RD3LogParameter.ui" line="120"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RelativePositions</name>
    <message>
        <location filename="../src/RelativePositions.cpp" line="95"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.cpp" line="95"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.cpp" line="95"/>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.cpp" line="95"/>
        <source>Azimuth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.ui" line="16"/>
        <source>Calculate relative positions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.ui" line="72"/>
        <source>Average distance=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.ui" line="86"/>
        <source>Aver. azimuth=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.ui" line="110"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.ui" line="117"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RelativePositions.ui" line="140"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RingEditor</name>
    <message>
        <location filename="../src/RingEditor.cpp" line="77"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.cpp" line="77"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.cpp" line="77"/>
        <source>Pairs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.cpp" line="77"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.cpp" line="230"/>
        <source>Open rings file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.cpp" line="230"/>
        <source>Rings file (*.rings)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="16"/>
        <source>Rings list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="59"/>
        <source>Total number of couples in rings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="123"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To remove the selected ring&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="126"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="133"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It lets you load a text file containing rings (see format generated by save). Only the first two columns are mandatory.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="136"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="143"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This tool selects the minimum and maximum radii for all rings. It keeps the selected couples of stations constant in each ring. It is used to get ring as thinner as possible.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="146"/>
        <source>Optimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="153"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To add a new ring&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="156"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="163"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Save the current list of rings to a text file (.ring)&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Format:&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 1: minimum radius&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 2: maximum radius&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 3: red component index (0 to 255)&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 4: green component index (0 to 255)&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 5: blue component index (0 to 255)&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 6: the number of couples selected&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RingEditor.ui" line="166"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignalFileItem</name>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="83"/>
        <source>All signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="85"/>
        <source>A list of all signals (permanent and temporary)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="93"/>
        <location filename="../src/SignalFileItem.cpp" line="197"/>
        <source>Temporary signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="95"/>
        <source>A list of all temporary signals including temporary files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="103"/>
        <location filename="../src/SignalFileItem.cpp" line="207"/>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="105"/>
        <source>A list of all signals in all files (permanent and temporary), excludes temporary signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="113"/>
        <location filename="../src/SignalFileItem.cpp" line="217"/>
        <source>Temporary files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="115"/>
        <source>A list of all signals in all temporary files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="123"/>
        <location filename="../src/SignalFileItem.cpp" line="227"/>
        <source>Permanent files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="125"/>
        <source>A list of all signals in all permanent files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="199"/>
        <source>+Temporary signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="209"/>
        <source>+All files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="219"/>
        <source>+Temporary files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalFileItem.cpp" line="229"/>
        <source>+Permanent files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignalLayer</name>
    <message>
        <location filename="../src/SignalLayer.cpp" line="1365"/>
        <source>Index &apos;%1&apos; out of range for &apos;signalColor&apos; property.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalLayer.cpp" line="1368"/>
        <source>No &apos;index&apos; for &apos;signalColor&apos; property.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalLayer.cpp" line="1380"/>
        <source>Index &apos;%1&apos; out of range for &apos;signalOverlap&apos; property.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalLayer.cpp" line="1383"/>
        <source>No &apos;index&apos; for &apos;signalOverlap&apos; property.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalLayer.cpp" line="1542"/>
        <source>Signals</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignalsProperties</name>
    <message>
        <location filename="../src/SignalsProperties.ui" line="14"/>
        <source>Signals display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="26"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="34"/>
        <source>Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="44"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Set default values for color palette&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="50"/>
        <source>Default values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="61"/>
        <source>Variable area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="71"/>
        <source>Wiggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="86"/>
        <source>Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="93"/>
        <source>max. of all traces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="98"/>
        <source>max. of each trace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="103"/>
        <source>visible max. of all traces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="108"/>
        <source>visible max. of each trace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="113"/>
        <source>specified value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="126"/>
        <source>Normalize by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="145"/>
        <location filename="../src/SignalsProperties.ui" line="205"/>
        <source>20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="162"/>
        <source>Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="176"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="181"/>
        <source>Overlap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="186"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="191"/>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="222"/>
        <source>Overlap traces by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="235"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="248"/>
        <source>No offset correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="253"/>
        <source>Global offset correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="258"/>
        <source>Visible offset correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="269"/>
        <source>Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="276"/>
        <source>Signal index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="281"/>
        <source>Projection of receiver coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="286"/>
        <source>Station names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="291"/>
        <source>Overlayed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="302"/>
        <source>Time range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="309"/>
        <source>Available range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="314"/>
        <source>Around a pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="319"/>
        <source>Custom range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="329"/>
        <source>Around</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="343"/>
        <source>Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="356"/>
        <location filename="../src/SignalsProperties.ui" line="385"/>
        <source> s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SignalsProperties.ui" line="372"/>
        <source>After</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StationCoordinatesItem</name>
    <message>
        <location filename="../src/StationCoordinatesItem.cpp" line="157"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/StationCoordinatesItem.cpp" line="158"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/StationCoordinatesItem.cpp" line="159"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/StationCoordinatesItem.cpp" line="160"/>
        <source>Z</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubPoolWindow</name>
    <message>
        <location filename="../src/SubPoolWindow.cpp" line="94"/>
        <source>Adding signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SubPoolWindow.cpp" line="95"/>
        <source>The added signals will not be processed as the others. To process all of them create a new window and start your interpretation tool.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeLimitsSelector</name>
    <message>
        <location filename="../src/TimeLimitsSelector.cpp" line="81"/>
        <source>Use only the properties of the first signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.cpp" line="82"/>
        <source>Properties means &apos;start&apos;, &apos;end&apos; and &apos;picks&apos; of first signal
(signal named &apos;%1&apos;). If this option is checked,
the individual properties of the other signals are ignored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.cpp" line="93"/>
        <source>TimePick[%1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="14"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="41"/>
        <location filename="../src/TimeLimitsSelector.ui" line="104"/>
        <source>this time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="46"/>
        <source>T0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="51"/>
        <location filename="../src/TimeLimitsSelector.ui" line="114"/>
        <source>during</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="59"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Enter the time where you want to start the processing. Time can be expressed in &quot;seconds&quot; since time reference or in &quot;hours:minutes:seconds&quot;. Hours and minutes are only integers and seconds can have as many decimals as needed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="62"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="69"/>
        <location filename="../src/TimeLimitsSelector.ui" line="83"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Time can be specified in seconds or hh:mm:ss.ss&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="75"/>
        <source>Enter the time where you want to start the taper. Before that time the signal will be set to zero. Time can be expressed in &quot;seconds&quot; since time datum or in &quot;hours:minutes:seconds&quot;. Hours and minutes are only integers and seconds can have as many decimals needed.
If the given time exceeed the start of the signal nothing will be done before the taper start time. As the width is expressed as a ratio of time, the length of transition is a function of time difference between time limits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="89"/>
        <source>Enter the time where you want to end the taper. After that time the signal will be set to zero. Time can be expressed in &quot;seconds&quot; since time datum or in &quot;hours:minutes:seconds&quot;. Hours and minutes are only integers and seconds can have as many decimals needed.
If the given time exceeed the end of the signal nothing will be done after the taper end time. As the width is expressed as a ratio of time, the length of transition is a function of time difference between time limits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="109"/>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="122"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Enter the time where you want to stop the processing. Time can be expressed in &quot;seconds&quot; since time reference or in &quot;hours:minutes:seconds&quot;. Hours and minutes are only integers and seconds can have as many decimals as needed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="125"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeLimitsSelector.ui" line="134"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;T0, End and Pick are measured on the first signal to define the time window ifthis option is selected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeReference</name>
    <message>
        <location filename="../src/TimeReference.ui" line="13"/>
        <source>Setting Time Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="71"/>
        <source>The initial time of your signal is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="81"/>
        <source>d MMM yyyy HH:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="88"/>
        <source>To compare different signals recorded
at the same time it is necessary to choose a
common time reference (e.g. 1 per day).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="114"/>
        <source>Time Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="121"/>
        <source>MM/dd/yy hh:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="147"/>
        <source>T0 of a signal is the time of the first recorded sample measured from the time reference. It may be negative.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="150"/>
        <source>T0 (seconds):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="157"/>
        <source>45.023</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="191"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="213"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeReference.ui" line="246"/>
        <source>Show this dialog next time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeWindowList</name>
    <message>
        <location filename="../src/TimeWindowList.cpp" line="176"/>
        <location filename="../src/TimeWindowList.cpp" line="207"/>
        <source>Adding window from %1 to %2 s.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeWindowList.cpp" line="229"/>
        <source>Removing window from %1 to %2 s.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeWindowList.cpp" line="243"/>
        <source>Inverse windows
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeWindowList.cpp" line="268"/>
        <source># Number= %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TimeWindowList.cpp" line="269"/>
        <source># Start time 	 End Time 	 Window length
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolBase</name>
    <message>
        <location filename="../src/ToolBase.cpp" line="128"/>
        <source>What&apos;s This?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolBase.cpp" line="138"/>
        <location filename="../src/ToolBase.cpp" line="144"/>
        <location filename="../src/ToolBase.cpp" line="171"/>
        <source>Loading parameters in log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolBase.cpp" line="139"/>
        <location filename="../src/ToolBase.cpp" line="186"/>
        <source>Log file (*.log)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolBase.cpp" line="145"/>
        <source>Unable to open file for reading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolBase.cpp" line="172"/>
        <source>Unknown keyword: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolBase.cpp" line="185"/>
        <location filename="../src/ToolBase.cpp" line="191"/>
        <source>Saving parameters in log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolBase.cpp" line="192"/>
        <source>Unable to open file for writing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolSeparator</name>
    <message>
        <location filename="../src/ToolInterface.h" line="78"/>
        <source>--- Separator ---</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WindowingParamWidget</name>
    <message>
        <location filename="../src/WindowingParamWidget.cpp" line="259"/>
        <location filename="../src/WindowingParamWidget.cpp" line="266"/>
        <location filename="../src/WindowingParamWidget.cpp" line="267"/>
        <location filename="../src/WindowingParamWidget.cpp" line="274"/>
        <location filename="../src/WindowingParamWidget.ui" line="140"/>
        <location filename="../src/WindowingParamWidget.ui" line="172"/>
        <location filename="../src/WindowingParamWidget.ui" line="312"/>
        <location filename="../src/WindowingParamWidget.ui" line="544"/>
        <location filename="../src/WindowingParamWidget.ui" line="577"/>
        <location filename="../src/WindowingParamWidget.ui" line="946"/>
        <location filename="../src/WindowingParamWidget.ui" line="979"/>
        <source> s.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.cpp" line="272"/>
        <source>include</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.cpp" line="275"/>
        <source> T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="13"/>
        <source>Windowing parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="44"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="82"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Length of the time windows that will be selected for processing (unit: seconds). Various modes are possible: fixed lengths, variable lengths limited by a minimum and a maximum (the longest time windows are selected if possible), and variable lengths set according to the considered frequency (not available for all types of processing).&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The selection of time windows may be forbiden in some parts of the signal defined automatically by the criteria here below: amplitude maximum (e.g. discard saturated samples), anti-triggering technique (STA/LTA). &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="89"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="97"/>
        <source>Exactly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="102"/>
        <source>At least</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="107"/>
        <source>Freq. dep.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="137"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The time lenght is expressed either in seconds or cycles. In this later case, the exact time lenght depends upon the current frequency. What is specified is the number of signal period (T) contained in each time window.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="156"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="169"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The time lenght is expressed either in seconds or cycles. In this later case, the exact time lenght depends upon the current frequency. What is specified is the number of signal period (T) contained in each time window.&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you introduce a negative value, the max length will be the first power of 2 greater than minimum length.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="223"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The selected time windows may overlap by a percentage of their lengths.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="226"/>
        <source>Overlap by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="242"/>
        <location filename="../src/WindowingParamWidget.ui" line="379"/>
        <source> %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="277"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each signal sample is qualified according to the selected criteria (maximum amplitude or anti-triggering), is a very simple manner: &quot;good&quot; or &quot;bad&quot;.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To place more time windows in a recorded signal, it may be usefull to allow some &quot;bad&quot; samples but not too much into the selected time windows. This parameter adjusts the maximum admissible time length of &quot;bad&quot; samples in a time window.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="280"/>
        <source>Bad sample tolerance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="347"/>
        <location filename="../src/WindowingParamWidget.ui" line="376"/>
        <source> All amplitudes exceeding XX % of signal maximum are considered as bad samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="350"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; All amplitudes exceeding XX % of signal maximum are considered as &quot;bad&quot; samples&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="353"/>
        <source>Bad sample threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="397"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The samples are qualified as &quot;good&quot; if the ratio STA/LTA lies inside a given range (specified in tab &quot;Raw&quot;)&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Do not forget to check the parameters of anti-trigger in the &lt;span style=&quot; font-weight:600;&quot;&gt;Raw Signal&lt;/span&gt; tab.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="400"/>
        <location filename="../src/WindowingParamWidget.ui" line="747"/>
        <source>Anti-triggering on raw signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="410"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The anti-trigger test is also performed on a filtered signal. In this case you must select the approriate filter and specific STA/LTA parameters.&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The samples are qualified as &quot;good&quot; if the ratio STA/LTA lies inside a given range (specified in tab &quot;Filtered&quot;)&lt;/p&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Do not forget to check the parameters of anti-trigger in the &lt;span style=&quot; font-weight:600;&quot;&gt;Filtered Signal&lt;/span&gt; tab.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="413"/>
        <location filename="../src/WindowingParamWidget.ui" line="1120"/>
        <source>Anti-triggering on filtered signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="441"/>
        <source>Raw signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="560"/>
        <location filename="../src/WindowingParamWidget.ui" line="962"/>
        <source>&lt;p&gt;Anti-triggering test constists of checking the values of the ratio STA/LTA.&lt;/p&gt;
&lt;p&gt;Min is the minimum of the acceptable range.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="564"/>
        <location filename="../src/WindowingParamWidget.ui" line="966"/>
        <source>Min STA/LTA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="593"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Long Term Average&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It should be of the same order as the time window length.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="600"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Long Term Average: the amplitude average is calculated over the specified time length (unit: seconds).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This lenght must always be greater than the STA&apos;s length and usually of the same order as the selected time window length (see tab &quot;General&quot;).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;See also STA&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="612"/>
        <location filename="../src/WindowingParamWidget.ui" line="998"/>
        <source>LTA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="641"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Short Term Average&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="647"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Short Term Average: the amplitude average is calculated over the specified time length (unit: seconds).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This lenght must always be less than the LTA&apos;s length.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;See also LTA&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="657"/>
        <location filename="../src/WindowingParamWidget.ui" line="1030"/>
        <source>STA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="667"/>
        <location filename="../src/WindowingParamWidget.ui" line="1040"/>
        <source>&lt;p&gt;Anti-triggering test constists of checking the values of the ratio STA/LTA.&lt;/p&gt;
&lt;p&gt;Max is the maximum of the acceptable range.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="671"/>
        <location filename="../src/WindowingParamWidget.ui" line="1044"/>
        <source>Max STA/LTA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="710"/>
        <location filename="../src/WindowingParamWidget.ui" line="1083"/>
        <source>&lt;p&gt;If 1 component is selected: STA/LTA is calculated over the single component.&lt;/p&gt;
&lt;p&gt;If 2 components are selected: STA/LTA is calculated over the signal formed by sqrt(c1^2+c2^2).&lt;/p&gt;
&lt;p&gt;If 3 components are selected: STA/LTA is calculated over the signal formed by sqrt(c1^2+c2^2+c3^2).&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="715"/>
        <location filename="../src/WindowingParamWidget.ui" line="1088"/>
        <source>Apply to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="744"/>
        <source>&lt;p&gt;Do not forget to check the parameters of anti-trigger in the &lt;b&gt;Raw Signal&lt;/b&gt; tab.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="818"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="843"/>
        <source>Filtered signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="995"/>
        <source>Long Term Average</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="1027"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Short Term Average&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/WindowingParamWidget.ui" line="1117"/>
        <source>&lt;p&gt;Do not forget to check the parameters of anti-trigger in the &lt;b&gt;Filtered Signal&lt;/b&gt; tab.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
