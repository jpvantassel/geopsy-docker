/***************************************************************************
**
**  This file is part of waranmond.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-07-06
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <string.h>

#include <GpCoreTools.h>

#include "waranmondVersion.h"
#include "waranmondInstallPath.h"

PACKAGE_INFO( waranmond, WARANMOND );

ApplicationHelp * help();

int main( int argc, char ** argv )
{
  CoreApplication a( argc, argv, help );

  // Options
  //<your option variable>
  // Check arguments
  int i, j = 1;
  for (i=1; i<argc; i++) {
    if (argv[i][0]=='-') {
      if (strcmp(argv[i], "<long option>")==0 || strcmp(argv[i], "<short option>")==0) {
        CoreApplication::checkOptionArg(i, argc, argv);
        //<your option variable> = argv[i];
      } else {
        fprintf(stderr,"waranmond: bad option %s, see -help", argv[i]);
        CoreApplication::exit(2);
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }

  return 0;
}

ApplicationHelp * help()
{
  ApplicationHelp * h = new ApplicationHelp;
  h->setOptionSummary( "[OPTIONS]" );
  h->setComments( "No implemented yet" );
  h->addGroup("", "main");
  h->addOption("<short option>, <long option>","<comments>");
  return h;
}

