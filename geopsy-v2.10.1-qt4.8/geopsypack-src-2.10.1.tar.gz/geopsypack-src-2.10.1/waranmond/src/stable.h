#if defined __cplusplus
#include <QtCore>
#ifndef Q_WS_MAC
#include <GpCoreTools.h>
#endif // Q_WS_MAC
#endif // __cplusplus
