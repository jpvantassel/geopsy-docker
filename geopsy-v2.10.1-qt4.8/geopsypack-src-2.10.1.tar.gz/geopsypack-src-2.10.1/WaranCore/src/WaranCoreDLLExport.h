#ifndef WARANCOREDLLEXPORT_H
#define WARANCOREDLLEXPORT_H

/* *_STATIC and MAKE_*_DLL are defined by the capitalization of
  the package name, included in the compiler options (only for Windows).
  Use directly WIN32 to allow transparent usage with or without Qt.
  WaranCoreInstallPath.h may contain WARANCORE_STATIC macro definition.
  This define was introduced there to mark this library as static for
  all projects that link to this library.
*/

#include "WaranCoreInstallPath.h"

#if defined(WIN32) && !defined(WARANCORE_STATIC)
#ifdef MAKE_WARANCORE_DLL
# define WARANCORE_EXPORT __declspec(dllexport)
#else
# define WARANCORE_EXPORT __declspec(dllimport)
#endif
#else
# define WARANCORE_EXPORT
#endif

#endif  // WARANCOREDLLEXPORT_H

