#ifndef WARANCORE_HEADERS
#define WARANCORE_HEADERS

// All headers of WaranCore library

#include "WaranCore/GpsBlock.h"
#include "WaranCore/GpsFix.h"
#include "WaranCore/TcpHeader.h"
#include "WaranCore/WaranCoreDLLExport.h"

#ifndef GP_EXPLICIT_LIBRARY_NAMESPACE
using namespace WaranCore;
#endif

#endif // WARANCORE_HEADERS
