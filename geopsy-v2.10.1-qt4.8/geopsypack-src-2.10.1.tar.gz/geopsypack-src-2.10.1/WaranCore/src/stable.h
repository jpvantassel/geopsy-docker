#if defined __cplusplus
#ifndef Q_WS_MAC
#endif // Q_WS_MAC
#endif // __cplusplus
