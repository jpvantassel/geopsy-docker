/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-15
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui>

#include <QGpCoreWave.h>

class Results;
class ControlPanel;

class MainWindow : public QMainWindow
{
  Q_OBJECT
public:
  MainWindow( QWidget * parent = 0 );
  ~MainWindow();

  void addBackground( LayeredModel * m, QString comments );
  Results * results() const { return _results; }
  void loadPanel( QString fileName );
  int scan( LayeredModel * m, QString sliderPattern, int nSteps );
public slots:
  void setBackground();
private slots:
  void setReferenceModel();
  void setForeground( LayeredModel * m );
  void setToolsMenuState();
  void helpDocumentation();
  void helpAbout();
  void quit();
protected:
  void closeEvent( QCloseEvent * e );
private:
  void addActions();
  void addToolsActions();
  void addHelpActions();

  QMenu * _toolsMenu;
  Results * _results;
  QPlainTextEdit * _backgroundModels;
  QPlainTextEdit * _referenceModel;
  QPlainTextEdit * _foregroundModel;
  ControlPanel * _controlPanel;
};

#endif // MAINWINDOW_H
