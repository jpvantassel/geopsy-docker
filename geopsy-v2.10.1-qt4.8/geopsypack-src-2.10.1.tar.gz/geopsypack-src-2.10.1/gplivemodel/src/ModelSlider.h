/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-13
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef MODELSLIDER_H
#define MODELSLIDER_H

#include <QtGui>

#include <QGpCoreTools.h>
#include <QGpCoreWave.h>

class ModelSlider : public QWidget, public XMLClass
{
  Q_OBJECT
public:
  ModelSlider( QWidget * parent=0 );
  ~ModelSlider();

  virtual const QString& xml_tagName() const {return xmlModelSliderTag;}
  static const QString xmlModelSliderTag;

  void setReferenceModel( LayeredModel * m );
  bool modify( LayeredModel * m, double p );

  void setTitle( const QString& t );
  QString title() const;

  void setCode( const QString& c );
  QString code() const { return _code; }
private slots:
  void edit();
  void sliderChanged();
signals:
  void modelChanged( LayeredModel * m );
protected:
  virtual void xml_writeProperties(XML_WRITEPROPERTIES_ARGS) const;
  virtual XMLMember xml_member(XML_MEMBER_ARGS);
  virtual bool xml_setProperty(XML_SETPROPERTY_ARGS);
private:
  QString _code;
  QLabel * _titleWidget;
  QSlider * _sliderWidget;

  LayeredModel * _referenceModel;
  LayeredModelExpressionContext _codeContext;
  ExpressionActions _codeActions;
};

#endif // MODELSLIDER_H
