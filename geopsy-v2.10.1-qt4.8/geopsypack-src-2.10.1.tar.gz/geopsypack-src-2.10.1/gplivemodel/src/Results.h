/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef RESULTS_H
#define RESULTS_H

#include <QGpCoreWave.h>
#include <SciFigs.h>

class ResultsThread;

class Results : public GraphicSheet
{
  Q_OBJECT
public:
  Results( QWidget * parent = 0 );
  ~Results();

  enum CurveType { Dispersion, DispersionGrid, Ellipticity, ShAmplification };

  bool setCurveType( CurveType curveType, int& argc, char ** argv );

  void setForeground( LayeredModel * m );
  void addBackground( LayeredModel * m );
  void calculateBackground();
  void clearBackground();
  ResultsThread * calculator() const { return _foregroundThread; }
public slots:
  void setAutomaticLimits( bool a );
private:
  void calculate( ResultsThread * t, QList<LayeredModel *> models );
  void deepUpdate();
  void setLimits();

  bool _automaticLimits;

  QList<LayeredModel *> _backgroundModels;

  LineLayer * _backgroundVp;
  LineLayer * _backgroundVs;

  LineLayer * _foregroundVp;
  LineLayer * _foregroundVs;

  ResultsThread * _backgroundThread;
  ResultsThread * _foregroundThread;

  LegendWidget * _backgroundLegend;
  LegendWidget * _foregroundLegend;
};

#endif // RESULTS_H
