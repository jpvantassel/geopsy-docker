/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-16
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreWave.h>
#include <SciFigs.h>
#include "DispersionGridThread.h"
#include "DispersionThread.h"

/*!
  \class DispersionGridThread qtbdispersiongridthread.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
DispersionGridThread::DispersionGridThread(QObject * parent)
    : ResultsThread(parent)
{
  TRACE;
  _polarisation = Mode::Rayleigh;
  _vMinRange = 100.0;
  _vMaxRange = 1000.0;
}

/*!
  Description of destructor still missing
*/
DispersionGridThread::~DispersionGridThread()
{
  TRACE;
}

void DispersionGridThread::initGraphs( GraphicSheet * sheet )
{
  TRACE;
  AxisWindow * w = new AxisWindow;
  GraphicSheetMenu::setGraphGeometry( w, sheet->printRight(), 10.0, 0.5, 8.0 );
  sheet->addObject( w );
  sheet->showObject( w );
  sheet->autoResizeContent();

  _layer = new LiveGridLayer(w);
  _layer->setObjectName(objectName()+" grid");
  _layer->setForceMinimumValue( true );
  _layer->setMinimumValue( -10.0 );
  _layer->setForceMaximumValue( true );
  _layer->setMaximumValue( 10.0 );
  ColorPalette pal;
  pal.defaultColors(128);
  pal.setColor( 63, QColor(120,120,120) );
  pal.setColor( 64, QColor(130,130,130) );
  _layer->setPalette(pal);

  GraphicSheetMenu::setFrequencyTitles( w, tr("Slowness (s/m)"), tr("Velocity (m/s)"), Number::Fixed );
}

AxisWindow * DispersionGridThread::graph() const
{
  TRACE;
  return _layer->graph();
}

void DispersionGridThread::setParameters( int& argc, char ** argv )
{
  TRACE;
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-grid") {
        CoreApplication::checkOptionArg(i, argc, argv);
        if (argv[i][0]=='R') {
          _polarisation = Mode::Rayleigh;
        } else {
          _polarisation = Mode::Love;
        }
      } else if (arg=="-vmin") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _vMinRange = atof(argv[i]);
      } else if (arg=="-vmax") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _vMaxRange = atof(argv[i]);
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
}

void DispersionGridThread::setParameters( const DispersionThread * o )
{
  _xMinRange = o->minX();
  _xMaxRange = o->maxX();
  setLimits();
}

void DispersionGridThread::start( QList<LayeredModel *> models )
{
  TRACE;
  ASSERT(models.count() == 1);
  delete _layer->takeFunction();
  AbstractFunction2 * f;
  if (_polarisation == Mode::Rayleigh) {
    RayleighFunction * rf = new RayleighFunction;
    rf->setModel( models.first() );
    f = rf;
  } else {
    LoveFunction * lf = new LoveFunction;
    lf->setModel( models.first() );
    f = lf;
  }
  _layer->setFunction( f );
  deepUpdate();
}

void DispersionGridThread::setLimits()
{
  TRACE;
  _layer->graph()->xAxis()->setRange( _xMinRange, _xMaxRange );
  _layer->graph()->yAxis()->setRange( _vMinRange*0.9, _vMaxRange*1.1 );
}

void DispersionGridThread::deepUpdate()
{
  TRACE;
  _layer->graph()->deepUpdate();
}
