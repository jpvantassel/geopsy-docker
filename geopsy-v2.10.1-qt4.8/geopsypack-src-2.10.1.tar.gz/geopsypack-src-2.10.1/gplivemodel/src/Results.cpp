/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-04
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreWave.h>
#include <SciFigs.h>
#include "Results.h"
#include "DispersionThread.h"
#include "DispersionGridThread.h"
#include "EllipticityThread.h"

/*!
  \class Results qtbresults.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
Results::Results( QWidget * parent )
    : GraphicSheet(parent)
{
  TRACE;

  _backgroundThread = 0;
  _foregroundThread = 0;
  _automaticLimits = true;

  AxisWindow * w;

  w = new AxisWindow;
  GraphicSheetMenu::setGraphGeometry( w, 0.5, 6.0, 0.5, 8.0 );
  w->yAxis()->setReversedScale( true );
  w->yAxis()->setTitle( tr("Depth (m)") );
  w->xAxis()->setTitle( tr("Vp (m/s)") );
  _backgroundVp = new LineLayer(w);
  _backgroundVp->setObjectName("background Vp");
  _backgroundVp->setReferenceLine( new PlotLine2D );
  _foregroundVp = new LineLayer(w);
  _foregroundVp->setObjectName("foreground Vp");
  _foregroundVp->setReferenceLine( new PlotLine2D );
  _foregroundVp->addLine( Pen(), Symbol() );
  addObject( w );
  showObject( w );

  w = new AxisWindow;
  GraphicSheetMenu::setGraphGeometry( w, 6.5, 6.0, 0.5, 8.0 );
  w->yAxis()->setReversedScale( true );
  w->yAxis()->setTitle( tr("Depth (m)") );
  w->xAxis()->setTitle( tr("Vs (m/s)") );
  _backgroundVs = new LineLayer(w);
  _backgroundVs->setObjectName("background Vs");
  _backgroundVs->setReferenceLine( new PlotLine2D );
  _foregroundVs = new LineLayer(w);
  _foregroundVs->setObjectName("foreground Vs");
  _foregroundVs->setReferenceLine( new PlotLine2D );
  _foregroundVs->addLine( Pen(), Symbol() );
  addObject( w );
  showObject( w );

  _backgroundLegend = new LegendWidget;
  _backgroundLegend->setPrintXAnchor( 12.5 );
  _backgroundLegend->setPrintYAnchor( 0.5 );
  _backgroundLegend->setTitle( tr("Background models") );
  _backgroundLegend->update();
  addObject( _backgroundLegend );
  showObject( _backgroundLegend );
  connect( _backgroundLegend, SIGNAL( changed( Legend ) ), _backgroundVp, SLOT( setLegend( Legend ) ) );
  connect( _backgroundLegend, SIGNAL( changed( Legend ) ), _backgroundVs, SLOT( setLegend( Legend ) ) );

  _foregroundLegend = new LegendWidget;
  _foregroundLegend->setPrintXAnchor( 12.5 );
  _foregroundLegend->setPrintYAnchor( 4.5 );
  _foregroundLegend->setTitle( tr("Foreground models") );
  _foregroundLegend->update();
  addObject( _foregroundLegend );
  showObject( _foregroundLegend );
  connect( _foregroundLegend, SIGNAL( changed( Legend ) ), _foregroundVp, SLOT( setLegend( Legend ) ) );
  connect( _foregroundLegend, SIGNAL( changed( Legend ) ), _foregroundVs, SLOT( setLegend( Legend ) ) );

  setWindowTitle("Results");
}

/*!
  Description of destructor still missing
*/
Results::~Results()
{
  TRACE;
}

/*!
  Set curve type and fetch related arguments in \a argv
*/
bool Results::setCurveType( CurveType curveType, int& argc, char ** argv )
{
  TRACE;
  switch(curveType) {
  case Dispersion: {
      DispersionThread * bg = new DispersionThread(this);
      bg->setObjectName( "background" );
      bg->initGraphs( this, _backgroundLegend );
      _backgroundThread = bg;
      DispersionThread * fg = new DispersionThread(this);
      fg->setObjectName( "foreground" );
      fg->initGraphs( bg->graph(), _foregroundLegend );
      _foregroundThread = fg;
      if ( bg->setParameters( argc, argv ) ) {
        fg->setParameters( bg );
        return true;
      }
    }
    break;
  case DispersionGrid: {
      DispersionGridThread * fg = new DispersionGridThread(this);
      fg->setObjectName( "foreground" );
      fg->initGraphs( this );
      _foregroundThread = fg;
      DispersionThread * bg = new DispersionThread(this);
      bg->setObjectName( "background" );
      bg->initGraphs( fg->graph(), _backgroundLegend );
      _backgroundThread = bg;
      if ( bg->setParameters( argc, argv ) ) {
        fg->setParameters( argc, argv );
        fg->setParameters( bg );
        return true;
      }
    }
    break;
  case Ellipticity: {
      EllipticityThread * bg = new EllipticityThread(this);
      bg->setObjectName( "background" );
      bg->initGraphs( this, _backgroundLegend );
      _backgroundThread = bg;
      EllipticityThread * fg = new EllipticityThread(this);
      fg->setObjectName( "foreground" );
      fg->initGraphs( bg->graph(), _foregroundLegend );
      _foregroundThread = fg;
      if ( bg->setParameters( argc, argv ) ) {
        fg->setParameters( bg );
        return true;
      }
    }
    break;
  case ShAmplification:
    //GraphicSheetMenu::setFrequencyTitles( w, tr("Amplification factor"), tr("De-amplification factor"), Number::Fixed );
    break;
  }
  return false;
}

void Results::addBackground( LayeredModel * m )
{
  TRACE;
  PlotLine2D * line;
  const Legend& leg = _backgroundLegend->legend();
  int i;
  i = _backgroundVp->count();
  line = static_cast<PlotLine2D *>( _backgroundVp->addLine( leg.pen(i), leg.symbol(i) ) );
  line->curve() = m->vpProfile().curve();
  i = _backgroundVs->count();
  line = static_cast<PlotLine2D *>( _backgroundVs->addLine( leg.pen(i), leg.symbol(i) ) );
  line->curve() = m->vsProfile().curve();
  _backgroundModels.append( m );
}

void Results::calculateBackground()
{
  calculate( _backgroundThread, _backgroundModels );
  if (_automaticLimits) setLimits();
  deepUpdate();
}

void Results::clearBackground()
{
  TRACE;
  _backgroundVp->clear();
  _backgroundVs->clear();
  deepUpdate();
  _backgroundThread->clear();
  _backgroundModels.clear();
}

void Results::setForeground( LayeredModel * m )
{
  TRACE;
  static_cast<PlotLine2D *>( _foregroundVp->line( 0 ) )->curve() = m->vpProfile().curve();
  static_cast<PlotLine2D *>( _foregroundVs->line( 0 ) )->curve() = m->vsProfile().curve();
  QList<LayeredModel *> mList;
  mList.append( m );
  calculate( _foregroundThread, mList );
  if (_automaticLimits) setLimits();
  deepUpdate();
}

void Results::calculate( ResultsThread * t, QList<LayeredModel *> models )
{
  TRACE;
  if (t->isRunning()) {
    t->terminate();
    t->wait();
  }
  t->start( models );
}

void Results::setAutomaticLimits(bool a)
{
  TRACE;
  _automaticLimits = a;
  _backgroundThread->setAutomaticLimits(a);
  _foregroundThread->setAutomaticLimits(a);
  if (_automaticLimits) setLimits();
}

void Results::deepUpdate()
{
  TRACE;
  _backgroundVp->graph()->deepUpdate();
  _backgroundVs->graph()->deepUpdate();
}

void Results::setLimits()
{
  TRACE;
  Rect rp = _backgroundVp->graphContent()->boundingRect();
  Rect rs = _backgroundVs->graphContent()->boundingRect();
  _backgroundVp->graph()->xAxis()->setRange( 0.0, rp.x2()*1.1 );
  _backgroundVs->graph()->xAxis()->setRange( 0.0, rs.x2()*1.1 );
  double maxDepth = rp.y2() > rs.y2() ? rp.y2() : rs.y2();
  maxDepth*=1.1;
  _backgroundVp->graph()->yAxis()->setRange( 0.0, maxDepth );
  _backgroundVs->graph()->yAxis()->setRange( 0.0, maxDepth );
}
