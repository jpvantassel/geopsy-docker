/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-16
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef DISPERSIONGRIDTHREAD_H
#define DISPERSIONGRIDTHREAD_H

#include <QGpCoreWave.h>
#include <SciFigs.h>

#include "ResultsThread.h"

class DispersionThread;

class DispersionGridThread : public ResultsThread
{
  Q_OBJECT
public:
  DispersionGridThread( QObject * parent = 0 );
  ~DispersionGridThread();

  virtual void start( QList<LayeredModel *> models );

  void initGraphs( GraphicSheet * sheet );
  void setParameters( int& argc, char ** argv );
  void setParameters( const DispersionThread * o );

  virtual void setLimits();
  virtual void deepUpdate();

  AxisWindow * graph() const;
private:
  virtual void run( LayeredModel * ) {}

  LiveGridLayer * _layer;
  double _xMinRange, _xMaxRange;
  double _vMinRange, _vMaxRange;
  Mode::Polarisation _polarisation;
};

#endif // DISPERSIONGRIDTHREAD_H
