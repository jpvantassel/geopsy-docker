/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-17
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include <SciFigs.h>
#include "CurvesThread.h"

/*!
  \class CurvesThread qtbcurvesthread.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
CurvesThread::CurvesThread( QObject * parent )
    : ResultsThread(parent)
{
  TRACE;
  _layer = 0;
  connect(this, SIGNAL(finished()), this, SLOT(showCurves()), Qt::QueuedConnection);
}

/*!
  Description of destructor still missing
*/
CurvesThread::~CurvesThread()
{
  TRACE;
}

void CurvesThread::initGraphs( GraphicSheet * sheet, LegendWidget * leg )
{
  TRACE;
  AxisWindow * w = new AxisWindow;
  GraphicSheetMenu::setGraphGeometry( w, sheet->printRight(), 10.0, 0.5, 8.0 );
  sheet->addObject( w );
  sheet->showObject( w );
  sheet->autoResizeContent();

  _layer = new LineLayer(w);
  _layer->setObjectName(objectName()+" curves");
  _layer->setReferenceLine( new PlotLine2D );
  QObject::connect( leg, SIGNAL( changed( Legend ) ), _layer, SLOT( setLegend( Legend ) ) );
  _legend = leg;
}

void CurvesThread::initGraphs( AxisWindow * w, LegendWidget * leg )
{
  TRACE;
  _layer = new LineLayer(w);
  _layer->setObjectName(objectName()+" curves");
  _layer->setReferenceLine( new PlotLine2D );
  connect( leg, SIGNAL( changed( Legend ) ), _layer, SLOT( setLegend( Legend ) ) );
  _legend = leg;
}

AxisWindow * CurvesThread::graph() const
{
  TRACE;
  return _layer->graph();
}

bool CurvesThread::setParameters( int& argc, char ** argv )
{
  TRACE;
  SamplingOption samplingType = LogScale;
  int nSamples = 100;
  double minRange = 0.2;
  double maxRange = 20.0;
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-s") {
        CoreApplication::checkOptionArg(i, argc, argv);
        if (strcmp(argv[i],"period")==0) {
          samplingType = InversedScale;
        } else if (strcmp(argv[i],"frequency")==0) {
          samplingType = LinearScale;
        } else {
          samplingType = LogScale;
        }
      } else if (arg=="-min") {
        CoreApplication::checkOptionArg(i, argc, argv);
        minRange = atof(argv[i]);
      } else if (arg=="-max") {
        CoreApplication::checkOptionArg(i, argc, argv);
        maxRange = atof(argv[i]);
      } else if (arg=="-n") {
        CoreApplication::checkOptionArg(i, argc, argv);
        nSamples = atoi(argv[i]);
        if (nSamples<=0) {
          App::stream() << tr("gpdclive: negative or null number of samples (option -n)") << endl;
          return false;
        }
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  // Compute common sampling scale
  Curve<Point1D> c;
  c.line( minRange, 0.0, maxRange, 0.0 );
  c.resample( nSamples, minRange, maxRange, samplingType | Function );
  c.xMultiply( 2*M_PI ); // convert to angular frequency
  _x = c.xVector();
  return true;
}

void CurvesThread::setParameters( const CurvesThread * o )
{
  TRACE;
  _x = o->_x;
}

void CurvesThread::showCurves()
{
  TRACE;
  if (isRunning()) return;
  _layer->clear();
  PlotLine2D * line;
  const Legend& leg = _legend->legend();
  int n = _curves.count();
  for(int i = 0;i<n; i++) {
    line = static_cast<PlotLine2D *>( _layer->addLine( leg.pen(i), leg.symbol(i) ) );
    line->curve() = _curves.at(i);
  }
  if (automaticLimits()) setLimits();
  _layer->graph()->deepUpdate();
}

void CurvesThread::clear()
{
  TRACE;
  _layer->clear();
  deepUpdate();
}

void CurvesThread::run()
{
  TRACE;
  _curves.clear();
  QList<LayeredModel *>::iterator it;
  for(it = _models.begin(); it!=_models.end(); it++) {
    if (terminated()) break;
    run( *it );
  }
  qDeleteAll(_models);
}

void CurvesThread::setLimits()
{
  TRACE;
  Rect r = _layer->boundingRect();
  if (!r.isNull()) {
    _layer->graph()->xAxis()->setRange( r.x1(), r.x2() );
    _layer->graph()->yAxis()->setRange( r.y1()*0.9, r.y2()*1.1 );
  }
}

void CurvesThread::deepUpdate()
{
  TRACE;
  _layer->graph()->deepUpdate();
}
