/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-15
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreWave.h>
#include "ModelSliderEditor.h"

/*!
  \class ModelSliderEditor qtbmodelslidereditor.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
ModelSliderEditor::ModelSliderEditor( QWidget * parent )
    : Dialog(parent)
{
  TRACE;
  setupUi(this);
  LayeredModelExpressionContext context;
  context.addVariable("p", 0.0);
  codeEdit->setContext( context );
}

/*!
  Description of destructor still missing
*/
ModelSliderEditor::~ModelSliderEditor()
{
  TRACE;
}

QString ModelSliderEditor::title() const
{
  TRACE;
  return titleEdit->text();
}

void ModelSliderEditor::setTitle( const QString& t )
{
  TRACE;
  return titleEdit->setText(t);
}


QString ModelSliderEditor::code() const
{
  TRACE;
  return codeEdit->text();
}

void ModelSliderEditor::setCode( const QString& t )
{
  TRACE;
  codeEdit->setText(t);
}
