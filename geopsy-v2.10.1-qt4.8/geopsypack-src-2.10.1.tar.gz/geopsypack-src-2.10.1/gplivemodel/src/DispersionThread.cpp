/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-16
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include <QGpCoreWave.h>
#include <SciFigs.h>
#include "DispersionThread.h"
#include "DispersionThread.h"

/*!
  \class DispersionThread qtbdispersionthread.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
DispersionThread::DispersionThread( QObject * parent )
    : CurvesThread(parent)
{
  TRACE;
  _nRayleigh = 1;
  _nLove = 0;
  _slowness = Mode::Phase;
}

/*!
  Description of destructor still missing
*/
DispersionThread::~DispersionThread()
{
  TRACE;
}

void DispersionThread::initGraphs( GraphicSheet * sheet, LegendWidget * leg )
{
  TRACE;
  CurvesThread::initGraphs( sheet, leg );
  GraphicSheetMenu::setFrequencyTitles( _layer->graph(), tr("Slowness (s/m)"), tr("Velocity (m/s)"), Number::Fixed );
}

bool DispersionThread::setParameters( int& argc, char ** argv )
{
  TRACE;
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-R") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _nRayleigh = atoi(argv[i]);
      } else if (arg=="-L") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _nLove = atoi(argv[i]);
      } else if (arg=="-group") {
        _slowness = Mode::Group;
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  return CurvesThread::setParameters( argc, argv );
}

void DispersionThread::setParameters( const DispersionThread * o )
{
  TRACE;
  _nRayleigh = o->_nRayleigh;
  _nLove = o->_nLove;
  _slowness = o->_slowness;
  CurvesThread::setParameters( o );
}

void DispersionThread::run( LayeredModel * m )
{
  if (_nRayleigh>0) {
    Rayleigh rayleigh( m );
    Dispersion dispersion (_nRayleigh, &_x);
    if (!dispersion.calculate( &rayleigh, 0, &_terminated )) {
      return;
    }
    if (_slowness == Mode::Group ) {
      dispersion.setGroupSlowness();
    }
    for(int i = 0;i<_nRayleigh;i++) {
      _curves.append( dispersion.curve(i) );
    }
  }
  if (_nLove>0) {
    Love love( m );
    Dispersion dispersion (_nLove, &_x);
    if (!dispersion.calculate( &love, &_terminated )) return;
    if (_slowness == Mode::Group ) {
      dispersion.setGroupSlowness();
    }
    for(int i = 0;i<_nLove;i++) {
      _curves.append( dispersion.curve(i) );
    }
  }
}
