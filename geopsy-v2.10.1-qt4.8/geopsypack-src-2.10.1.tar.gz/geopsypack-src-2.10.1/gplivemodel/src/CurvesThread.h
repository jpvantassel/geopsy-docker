/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-17
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef CURVESTHREAD_H
#define CURVESTHREAD_H

#include <SciFigs.h>

#include "ResultsThread.h"

class CurvesThread : public ResultsThread
{
  Q_OBJECT
public:
  CurvesThread( QObject * parent = 0 );
  ~CurvesThread();

  void initGraphs( GraphicSheet * sheet, LegendWidget * leg );
  void initGraphs( AxisWindow * w, LegendWidget * leg );
  bool setParameters( int& argc, char ** argv );
  void setParameters( const CurvesThread * o );

  virtual void clear();
  virtual void setLimits();
  virtual void deepUpdate();

  AxisWindow * graph() const;
  double minX() const { return _x[0]; }
  double maxX() const { return _x[_x.count()-1]; }
  const QList< Curve<Point2D> >& curves() const { return _curves; }
  virtual void run( LayeredModel * model ) = 0;
private slots:
  void showCurves();
protected:
  virtual void run();

  QVector<double> _x;
  QList< Curve<Point2D> > _curves;
  LineLayer * _layer;
  LegendWidget * _legend;
};

#endif // CURVESTHREAD_H
