/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-15
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef LIVEMODELREADER_H
#define LIVEMODELREADER_H

#include <QGpCoreTools.h>
#include "Results.h"
#include "ResultsThread.h"

class MainWindow;

class LiveModelReader : public ArgumentStdinReader
{
  TRANSLATIONS("LiveModelReader")
public:
  LiveModelReader();
  ~LiveModelReader();

  bool setOptions( int& argc, char ** argv );
  int exec();
protected:
  virtual bool parse( QTextStream& s );
private:
  Results::CurveType _curveType;
  bool _readStdin;
  QString _panelFile;
  QString _sliderName;
  int _scanCount;

  MainWindow  * _w;
};

#endif // LIVEMODELREADER_H
