/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-16
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef DISPERSIONTHREAD_H
#define DISPERSIONTHREAD_H

#include <QGpCoreWave.h>
#include "CurvesThread.h"

class DispersionThread : public CurvesThread
{
  Q_OBJECT
public:
  DispersionThread( QObject * parent = 0 );
  ~DispersionThread();

  void initGraphs( GraphicSheet * sheet, LegendWidget * leg );
  void initGraphs( AxisWindow * w, LegendWidget * leg ) { CurvesThread::initGraphs( w, leg ); }
  bool setParameters( int& argc, char ** argv );
  void setParameters( const DispersionThread * o );
  virtual void run( LayeredModel * m );
private:
  int _nRayleigh, _nLove;
  Mode::Slowness _slowness;
};

#endif // DISPERSIONTHREAD_H
