/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-11-07
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include <QGpCoreWave.h>
#include <SciFigs.h>
#include "EllipticityThread.h"
#include "DispersionThread.h"
#include "EllipticityThread.h"

/*!
  \class EllipticityThread qtbellipticitythread.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
EllipticityThread::EllipticityThread( QObject * parent )
    : CurvesThread(parent)
{
  TRACE;
  _nRayleigh=1;
  _signed=false;
}

/*!
  Description of destructor still missing
*/
EllipticityThread::~EllipticityThread()
{
  TRACE;
}

void EllipticityThread::initGraphs( GraphicSheet * sheet, LegendWidget * leg )
{
  TRACE;
  CurvesThread::initGraphs( sheet, leg );
  AxisWindow * w = _layer->graph();
  GraphicSheetMenu::setFrequencyTitles( w, tr("Ellitpticity (H/V)"), tr("Ellitpticity (V/H)"), Number::Fixed );
  if(!_signed) {
    w->yAxis()->setScaleType( Scale::Log );
    w->yAxis()->setAutoTicks( false );
    w->yAxis()->setMajorTicks( 2.0 );
    w->yAxis()->setMinorTicks( 0.5 );
  }
}

bool EllipticityThread::setParameters( int& argc, char ** argv )
{
  TRACE;
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-R") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _nRayleigh = atoi(argv[i]);
      } else if (arg=="-signed") {
          _signed=true;
      } else {
        argv[j++] = argv[i];
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  return CurvesThread::setParameters( argc, argv );
}

void EllipticityThread::setParameters( const EllipticityThread * o )
{
  TRACE;
  _nRayleigh = o->_nRayleigh;
  CurvesThread::setParameters( o );
}

void EllipticityThread::run( LayeredModel * m )
{
  if (_nRayleigh>0) {
    Rayleigh rayleigh( m );
    Dispersion dispersion (_nRayleigh, &_x);
    dispersion.setPrecision(1e-12); // Highest precision with double
    Ellipticity ell(_nRayleigh, &_x);
    if (!dispersion.calculate( &rayleigh, &ell, &_terminated )) return;
    if(!_signed) {
      ell.abs();
    }
    for(int i = 0;i<_nRayleigh;i++) {
      _curves.append( ell.curve(i) );
    }
  }
}
