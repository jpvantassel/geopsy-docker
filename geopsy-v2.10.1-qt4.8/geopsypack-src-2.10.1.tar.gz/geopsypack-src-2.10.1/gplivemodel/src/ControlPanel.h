/***************************************************************************
**
**  This file is part of gplivemodel.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-10-15
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef CONTROLPANEL_H
#define CONTROLPANEL_H

#include <QWidget>

#include <QGpCoreTools.h>
#include <QGpCoreWave.h>

#include "ui_ControlPanel.h"

class ModelSlider;

class ControlPanel : public QWidget, private Ui::ControlPanel, public XMLClass
{
  Q_OBJECT
public:
  ControlPanel( QWidget * parent=0 );
  ~ControlPanel();

  virtual const QString& xml_tagName() const {return xmlControlPanelTag;}
  static const QString xmlControlPanelTag;

  void setReferenceModel( LayeredModel * m );
  void clear();
  void load( QString fileName );
  ModelSlider * slider( QString sliderPattern );
private slots:
  void on_addSliderBut_clicked();
  void on_loadBut_clicked();
  void on_saveBut_clicked();
signals:
  void modelChanged( LayeredModel * m );
protected:
  virtual void xml_writeChildren(XML_WRITECHILDREN_ARGS) const;
  virtual XMLMember xml_member(XML_MEMBER_ARGS);
private:
  LayeredModel * _referenceModel;
};

#endif // CONTROLPANEL_H
