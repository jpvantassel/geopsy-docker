<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbControlPanel</name>
    <message>
        <location filename="../src/qtbcontrolpanel.cpp" line="108"/>
        <source>Unamed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcontrolpanel.cpp" line="156"/>
        <source>Open control panel description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcontrolpanel.cpp" line="157"/>
        <location filename="../src/qtbcontrolpanel.cpp" line="167"/>
        <source>Control panel file (*.cpanel)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcontrolpanel.cpp" line="166"/>
        <source>Save control panel description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcontrolpanel.ui" line="13"/>
        <source>Control panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcontrolpanel.ui" line="41"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcontrolpanel.ui" line="61"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbcontrolpanel.ui" line="68"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbCurvesThread</name>
    <message>
        <location filename="../src/qtbcurvesthread.cpp" line="122"/>
        <source>gpdclive: negative or null number of samples (option -n)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbDispersionGridThread</name>
    <message>
        <location filename="../src/qtbdispersiongridthread.cpp" line="80"/>
        <source>Slowness (s/m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdispersiongridthread.cpp" line="80"/>
        <source>Velocity (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbDispersionThread</name>
    <message>
        <location filename="../src/qtbdispersionthread.cpp" line="63"/>
        <source>Slowness (s/m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbdispersionthread.cpp" line="63"/>
        <source>Velocity (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbEllipticityThread</name>
    <message>
        <location filename="../src/qtbellipticitythread.cpp" line="63"/>
        <source>Ellitpticity (H/V)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbellipticitythread.cpp" line="63"/>
        <source>Ellitpticity (V/H)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbLiveModelReader</name>
    <message>
        <location filename="../src/qtblivemodelreader.cpp" line="104"/>
        <source>gplivemodel: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtblivemodelreader.cpp" line="117"/>
        <source>gplivemodel: option &apos;panel&apos; is required with option &apos;scan&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbMainWindow</name>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="64"/>
        <source>Background models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="77"/>
        <source>Reference model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="91"/>
        <source>Foreground model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="104"/>
        <source>Control Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="135"/>
        <source>Only curve types are accepted for scan: e.g. dispersion, ellipticity,...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="141"/>
        <source>Bad model generated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="145"/>
        <source># p = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="165"/>
        <source>Error parsing background models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="174"/>
        <source>%1 background model(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="185"/>
        <source>Error parsing foreground model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="228"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="231"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="239"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="246"/>
        <source>&amp;Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="253"/>
        <source>&amp;Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="256"/>
        <source>Automatic limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="257"/>
        <source>Switch on/off automatic adjustment of graph limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="275"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="308"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="311"/>
        <source>Online gplivemodel &amp;Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="312"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="313"/>
        <source>Access to online html documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="322"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="323"/>
        <source>Show gplivemodel&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="327"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmainwindow.cpp" line="328"/>
        <source>Show the Qt library&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbModelSlider</name>
    <message>
        <location filename="../src/qtbmodelslider.cpp" line="65"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmodelslider.cpp" line="144"/>
        <source>model slider: no code defined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmodelslider.cpp" line="146"/>
        <source>model slider: no layers in reference model</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbModelSliderEditor</name>
    <message>
        <location filename="../src/qtbmodelslidereditor.ui" line="13"/>
        <source>Slider editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmodelslidereditor.ui" line="21"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbResults</name>
    <message>
        <location filename="../src/qtbresults.cpp" line="58"/>
        <location filename="../src/qtbresults.cpp" line="73"/>
        <source>Depth (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbresults.cpp" line="59"/>
        <source>Vp (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbresults.cpp" line="74"/>
        <source>Vs (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbresults.cpp" line="88"/>
        <source>Background models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbresults.cpp" line="98"/>
        <source>Foreground models</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
