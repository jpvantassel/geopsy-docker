#ifndef GPSIGNAL_VERSION
#define GPSIGNAL_VERSION "1.0.1"
#define GPSIGNAL_VERSION_TIME "201103131947"
#define GPSIGNAL_VERSION_TYPE "testing"
#define GPSIGNAL_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)"
#endif // GPSIGNAL_VERSION
