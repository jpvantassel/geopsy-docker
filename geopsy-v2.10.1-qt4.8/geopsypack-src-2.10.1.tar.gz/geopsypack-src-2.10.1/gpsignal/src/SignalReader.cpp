/***************************************************************************
**
**  This file is part of gpsignal.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-16
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <math.h>

#include <QGpCoreTools.h>
#include "SignalReader.h"

/*!
  \class SignalReader qtbsignalreader.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
SignalReader::SignalReader()
    : ArgumentStdinReader()
{
  TRACE;
  _nSamples = 0;
  _samples = 0;
  //_commonFrequency = -1.0;
  _deltaT = 0.01;
  _timeLength = 600.0; // 10 minutes
  _velocity = 0.0;
  _azimuth = 90.0;
  //_uniqueFrequency=true;
}

SignalReader::~SignalReader()
{
  TRACE;
  delete [] _samples;
}

bool SignalReader::setOptions( int& argc, char ** argv )
{
  TRACE;
  // Check arguments
  int i, j = 1;
  for (i=1; i<argc; i++) {
    QByteArray arg = argv[i];
    if (arg[0]=='-') {
      if (arg=="-f") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _deltaT = 1.0 / atof( argv[i] );
      } else if (arg=="-t") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _timeLength = atof( argv[i] );
      } else if (arg=="-x") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _stationCoord.setX( atof( argv[i] ) );
      } else if (arg=="-y") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _stationCoord.setY(  atof( argv[i] ) );
      } else if (arg=="-a") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _azimuth = atof( argv[i] );
      } else if (arg=="-v") {
        CoreApplication::checkOptionArg(i, argc, argv);
        _velocity = atof( argv[i] );
      } else {
        App::stream() << tr("gpsignal: bad option %1, see -help").arg(argv[i]) << endl;
        return false;
      }
    } else {
      argv[j++] = argv[i];
    }
  }
  if(j < argc) {
    argv[j] = 0;
    argc = j;
  }
  if (_velocity>0.0) { // Add supplementary phase shift due to propagation
    // Math angle for station position relative to origin
    double angle=Point2D().azimuthTo(_stationCoord);
    angle-=Angle::geographicToMath(_azimuth);
    _propagationDelay = Point2D().distanceTo(_stationCoord)*cos(angle)/_velocity;
  } else {
    _propagationDelay = 0.0;
  }
  _nSamples = (int) floor( _timeLength/_deltaT +0.5 );
  _samples = new double [_nSamples];
  return true;
}

bool SignalReader::parse( QTextStream& s )
{
  TRACE;
  QString buf;
  buf = s.readLine();
  if (!buf.isEmpty() && buf[0]!='\n' && buf[0]!='#') {
    Wavelet w;
    StringSection fields(buf);
    StringSection field;
    const QChar * p = 0;
    field = fields.nextField( p );
    if (!field.isValid()) {
      App::stream() << tr("gpsignal: error reading amplitude, ").arg(buf) << endl;
      return false;
    }
    w.amplitude = field.toDouble();
    field = fields.nextField( p );
    if (!field.isValid()) {
      App::stream() << tr("gpsignal: error reading frequency, ").arg(buf) << endl;
      return false;
    }
    w.frequency = field.toDouble();
    field = fields.nextField( p );
    if (!field.isValid()) {
      App::stream() << tr("gpsignal: error reading phase, ").arg(buf) << endl;
      return false;
    }
    double phaseDegrees=field.toDouble();
    w.phase=Angle::degreesToRadians(phaseDegrees);
    w.phase+=2.0*M_PI*_propagationDelay*w.frequency;
    _wavelets.append(w);
    App::stream() << QString("%1   Amplitude = %2\n"
                      "       Frequency  = %3\n"
                      "       Phase      = %4\n")
                .arg(_wavelets.count(), 4, 10 )
                .arg(w.amplitude)
                .arg(w.frequency)
                .arg(phaseDegrees);
    //if ( _commonFrequency == -1) _commonFrequency = w.frequency;
    //else if ( _commonFrequency != w.frequency ) _uniqueFrequency=false;
  }
  return true;
}

void SignalReader::exec()
{
  int nWavelets = _wavelets.count();
  double t;
  for (int i=0;i<_nSamples;i++) {
    _samples[i]=0.0;
    t=(double)i*_deltaT;
    for ( int iw=0; iw<nWavelets; iw++) {
      Wavelet& w = _wavelets[iw];
      _samples[i]+=w.amplitude*cos(2.0*M_PI*w.frequency*t-w.phase);
    }
  }
  QTextStream sOut(stdout);
  for (int i=0;i<_nSamples;i++) sOut << _samples[i] << "\n";
  sOut << flush;
}

#if 0
  // Fit of a single cosine if fc[i] are all equals
  if (_uniqueFrequency && nWavelets>1) {
    double ** p=new double *[3];
    double * y=new double [3];
    p[0]=new double [2];
    p[0][0]=_wavelets[0].amplitude;
    p[0][1]=_wavelets[0].phase;
    y[0]=misfit(p[0]);
    p[1]=new double [2];
    p[1][0]=_wavelets[1].amplitude;
    p[1][1]=_wavelets[1].phase;
    y[1]=misfit(p[1]);
    p[2]=new double [2];
    p[2][0]=0;
    p[2][1]=0;
    y[2]=misfit(p[2]);
    int nfunk;
    amoeba(p, y, 2, 1e-5, misfit, &nfunk);
    for (int i=0;i<_nSamples;i++) {
      t=(double)i*_deltaT;
      printf("%lf\t%lf\n",_samples[i],p[0][0]*cos(2.0*M_PI*_commonFrequency*t-p[0][1]));
    }
    App::stream() << QString("Best fitting cosine:\n"
                      "  Amp=%1\tPhase=%2\tMisfit=%3\n"
                      "  Amp=%4\tPhase=%5\tMisfit=%6\n"
                      "  Amp=%7\tPhase=%8\tMisfit=%9\n")
              .arg(p[0][0]).arg(p[0][1]).arg(misfit(p[0]))
              .arg(p[1][0]).arg(p[1][1]).arg(misfit(p[1]))
              .arg(p[2][0]).arg(p[2][1]).arg(misfit(p[2]));
    /* It is always possible to express a sum of cosine into a single
       A*cos(wt+phi)
       For two cosines:
       A=A1*A1+A2*A2+2*A1*A2*cos(phi1-phi2)
       tan phi=(A1*sin phi1+A2*sin phi2)/(A1*cos phi1+A2*cos phi2)
    */
    delete [] p[0];
    delete [] p[1];
    delete [] p[2];
    delete [] p;
    delete [] y;
  } else {
}

double SignalReader::misfit(double ampPhi[])
{
  double tmp, misfitVal=0, t;
  for (int i=0;i<_nSamples;i++) {
    t=(double)i*_deltaT;
    tmp=_samples[i]-ampPhi[0]*cos(2.0*M_PI*_commonFrequency*t-ampPhi[1]);
    misfitVal+=tmp*tmp;
  }
  misfitVal=sqrt(misfitVal/_nSamples);
  fprintf(stderr,"%lf\t%lf\t%lf\n",ampPhi[0],ampPhi[1],misfitVal);
  return misfitVal;
}
#endif
