/***************************************************************************
**
**  This file is part of gpsignal.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-05-21
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <QGpCoreTools.h>
#include "SignalReader.h"
#include "gpsignalVersion.h"
#include "gpsignalInstallPath.h"

PACKAGE_INFO( gpsignal, GPSIGNAL );

double misfit(double ampPhi[]);
ApplicationHelp * help();

int main( int argc, char ** argv )
{
  CoreApplication a(argc, argv, help);
  // stdout is used for output of results, redirect main application log to stderr
  a.setStream(new StandardStream(stderr));

  SignalReader reader;
  if ( !reader.setOptions( argc, argv ) || !reader.read( argc, argv ) ) {
    return 2;
  }
  reader.exec();
  return 0;
}

ApplicationHelp * help()
{
  ApplicationHelp * h = new ApplicationHelp;
  h->setOptionSummary( "[OPTIONS]" );
  h->setComments( "Generate a signal defined by a sum of cosine signals. Each cosine is "
                 "defined by its amplitude, frequency and phase (in degrees) given through stdin.\n"
                 "If all cosines have the same frequency, the resulting cosine is computed." );
  h->addGroup("Gpsignal options", "gpsignal");
  h->addOption("-f <VAL>","Sampling frequency (default=100 Hz)");
  h->addOption("-t <VAL>","Time length in seconds (default=600 s.)");
  h->addOption("-x <VAL>","X coordinate of station, see option -v (default=0).");
  h->addOption("-y <VAL>","Y coordinate of station, see option -v (default=0).");
  h->addOption("-a <VAL>","Propagation azimuth in degrees counted clockwize from North (Y axis), see option -v (default=90).");
  h->addOption("-v <VAL>","Set medium velocity. Options -x and -y set the coordinate of the recording station. These options are "
                          "used to add a supplementary phase shift due to propagation from (0, 0) (default=0, no additional phase shift).");
  h->addExample("gpsignal << END > signal.txt\n3 1 0\n0.5 10 180\nEND",
                "Generate a signal with two frequencies 1 (amplitude 3, phase 0) and 10 Hz (amplitude 0.5, phase 180), ");
  return h;
}
