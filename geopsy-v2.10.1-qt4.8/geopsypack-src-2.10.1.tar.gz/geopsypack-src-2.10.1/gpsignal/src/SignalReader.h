/***************************************************************************
**
**  This file is part of gpsignal.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2008-12-16
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef SIGNALREADER_H
#define SIGNALREADER_H

#include <QVector>

#include <QGpCoreTools.h>

class Wavelet
{
public:
  Wavelet() { amplitude=1.0; frequency=1.0; phase=0.0; }

  double amplitude;
  double frequency;
  double phase;
};

class SignalReader : public ArgumentStdinReader
{
  TRANSLATIONS("SignalReader");
public:
  SignalReader();
  ~SignalReader();

  bool setOptions( int& argc, char ** argv );
  void exec();
protected:
  virtual bool parse( QTextStream& s );
private:
  static double misfit(double ampPhi[]);

  int _nSamples;
  //double _commonFrequency;
  double _deltaT;
  double * _samples;
  double _timeLength;
  double _velocity;
  double _azimuth;
  double _propagationDelay;
  Point2D _stationCoord;
  //bool _uniqueFrequency;
  QVector<Wavelet> _wavelets;
};

#endif // SIGNALREADER_H
