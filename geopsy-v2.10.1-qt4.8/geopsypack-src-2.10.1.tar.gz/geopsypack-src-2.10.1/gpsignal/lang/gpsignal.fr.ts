<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbSignalReader</name>
    <message>
        <location filename="../src/qtbsignalreader.cpp" line="87"/>
        <source>gpsignal: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbsignalreader.cpp" line="123"/>
        <source>gpsignal: error reading amplitude, </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbsignalreader.cpp" line="129"/>
        <source>gpsignal: error reading frequency, </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbsignalreader.cpp" line="135"/>
        <source>gpsignal: error reading phase, </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
