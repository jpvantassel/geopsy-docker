<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>DCReportBlock</name>
    <message>
        <location filename="../src/DCReportBlock.cpp" line="241"/>
        <source>Report has been produced by a more recent version of this library %1 (current = %2).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamGroundModel</name>
    <message>
        <location filename="../src/ParamGroundModel.cpp" line="61"/>
        <source>Compression-wave velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamGroundModel.cpp" line="64"/>
        <source>Poisson&apos;s Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamGroundModel.cpp" line="67"/>
        <source>Shear-wave velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamGroundModel.cpp" line="70"/>
        <source>Density</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamLayer</name>
    <message>
        <location filename="../src/ParamLayer.cpp" line="330"/>
        <source>Null or negative thickness for layer %1: top=%2, bottom=%3, very thin layer instead (1 mm).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamLayer.cpp" line="566"/>
        <source>Unknown value %1 for shape</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParamProfile</name>
    <message>
        <location filename="../src/ParamProfile.cpp" line="142"/>
        <source>Circular referecences for depth links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamProfile.cpp" line="145"/>
        <source>        %1 ---&gt; %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParamProfile.cpp" line="153"/>
        <source>Bad depth link %1 for parameter %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TargetList</name>
    <message>
        <location filename="../src/TargetList.cpp" line="267"/>
        <source> *** WARNING *** : bad physical model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="502"/>
        <source>Wrong type of modal curve target: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="506"/>
        <source>No type defined for modal curve target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="517"/>
        <source>Wrong type of value target: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="521"/>
        <source>No type defined for value target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="532"/>
        <source>Wrong type of refraction target: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="536"/>
        <source>No type defined for refraction target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="550"/>
        <source>Wrong type of modal curve %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="554"/>
        <source>No type defined for modal curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="571"/>
        <source>Wrong type of refraction curve %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TargetList.cpp" line="575"/>
        <source>No type defined for refraction curve</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
