#if defined __cplusplus
#include <QtCore>
#ifndef Q_WS_MAC
#include <QGpCoreTools.h>
#include <QGpCoreWave.h>
#include <QGpCompatibility.h>
#include <DinverCore.h>
#endif // Q_WS_MAC
#endif // __cplusplus
