/***************************************************************************
**
**  This file is part of DinverDCCore.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-10-18
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverCore.h>
#include <QGpCoreTools.h>
#include "ParamProfile.h"
#include "ParamLayer.h"

namespace DinverDCCore {

const QString ParamProfile::xmlParamProfileTag="ParamProfile";

ParamProfile::ParamProfile()
{
  TRACE;
  _defaultMinimum = 100;
  _defaultMaximum = 5000;
  _type = Param;
  _defaultCondition = SimpleCondition::LessThan;
}

/*!
  Copy constructor. Used only by copy constructor of ParamGroundModel.
*/
ParamProfile::ParamProfile( const ParamProfile& o )
  : XMLClass()
{
  TRACE;
  _longName = o._longName;
  _shortName = o._shortName;
  _unit = o._unit;
  _defaultMinimum = o._defaultMinimum;
  _defaultMaximum = o._defaultMaximum;
  _defaultCondition = o._defaultCondition;
  _type = o._type;

  LayerList::const_iterator it;
  for(it=o._layers.begin();it!=o._layers.end();++it) {
    ParamLayer * layer = new ParamLayer( **it );
    layer->setProfile(this);
    _layers.append( layer );
  }
}

ParamProfile::ParamProfile( QString shortName, QString longName, QString unit,
                                  double defaultMinimum, double defaultMaximum,
                                  Type type, SimpleCondition::Type defaultCondition )
{
  TRACE;
  _longName = longName;
  _shortName = shortName;
  _unit = unit;
  _defaultMinimum = defaultMinimum;
  _defaultMaximum = defaultMaximum;
  _type = type;
  _defaultCondition = defaultCondition;
}

ParamProfile::~ParamProfile()
{
  TRACE;
  LayerList::iterator it;
  for ( it = _layers.begin();it != _layers.end();++it ) delete *it;
}

/*!
  Inserts \a layer at index \a at. Never call this function directly,
  use ParamGroundModel::insertLayer() instead.
*/
void ParamProfile::insertLayer(int at, ParamLayer * layer)
{
  TRACE;
  _layers.insert(at, layer);
  int nLayers=_layers.size();
  for(int iLayer=at+1; iLayer<nLayers; iLayer++) {
    ParamLayer * layer=_layers.at(iLayer);
    layer->setIndex(iLayer);
  }
}

/*!
  Append all layers (except half spaces) to layer map \a links.
*/
void ParamProfile::collectDepthLinks(LayerMap& links)
{
  TRACE;
  int lastLayer = _layers.size() - 1; // half space index
  for (int iLayer=0; iLayer<lastLayer; iLayer++) {
    ParamLayer * layer=_layers.at(iLayer);
    links.insert(layer->name(), layer);
  }
}

/*!
  Set the link pointers from the link names and from the layer map \a links.
*/
void ParamProfile::setDepthLinks(const LayerMap& links)
{
  TRACE;
  int lastLayer = _layers.size() - 1; // half space index
  for (int iLayer=0; iLayer<lastLayer; iLayer++) {
    ParamLayer * layer=_layers.at(iLayer);
    if (!layer->linkedTo().isEmpty()) {
      layer->setPtrLink(links[layer->linkedTo()]);
    }
  }
}

/*!
  Set link names in each layer from the link pointers.
*/
void ParamProfile::setDepthLinkNames()
{
  TRACE;
  int lastLayer = _layers.size() - 1; // half space index
  for (int iLayer=0; iLayer<lastLayer; iLayer++) {
    ParamLayer * layer=_layers.at(iLayer);
    layer->setLinkedTo();
  }
}

/*!
  Append all value parameters that describe this profile to \a params.
*/
void ParamProfile::collectValueParameters( QList<Parameter *>& params ) const
{
  TRACE;
  int lastLayer = _layers.count() - 1;
  for ( int iLayer=0; iLayer<lastLayer; iLayer++ ) {
    ParamLayer * layer=_layers.at(iLayer);
    layer->collectValueParameters(params);
  }
  _layers.at(lastLayer)->collectValueParameters(params);
}

bool ParamProfile::toParam(RealSpace& ps, LayerMap& links)
{
  TRACE;
  int nLayers = _layers.size();
  int lastLayer = nLayers - 1; // half space index
  ParamLayer * layer;
  ParamLayer * prevLayer = 0;
  for ( int iLayer=0; iLayer<nLayers; iLayer++ ) {
    layer = _layers.at(iLayer);
    if ( layer->linkedTo() != "Not linked" && iLayer != lastLayer ) {
      // Links may be cascaded, look carefully for circular references
      LayerList browsedLinks;
      LayerList::iterator it;
      ParamLayer * link = layer;
      while ( link && link->linkedTo() != "Not linked" ) {
        if ( browsedLinks.contains(link) ) {
          App::stream() << tr( "Circular referecences for depth links" ) << endl;
          LayerList::iterator it;
          for ( it = browsedLinks.begin();it != browsedLinks.end();++it ) {
            App::stream() << tr( "        %1 ---> %2" ).arg( ( *it ) ->name() ).arg( ( *it ) ->linkedTo() ) << endl;
          }
          return false;
        } else browsedLinks.append( link );
        LayerMap::iterator itMap = links.find( link->linkedTo() );
        if ( itMap != links.end() ) link = itMap.value(); else link = 0;
      }
      if (!link) {
        App::stream() << tr( "Bad depth link %1 for parameter %2" ).arg( layer->linkedTo() ).arg( layer->name() ) << endl;
        return false;
      } else layer->setPtrLink( link );
    } else layer->setPtrLink( 0 );
    // Convert layer into parameters
    if (_type==Param) {
      if(!layer->valueToParam(ps)) {
        App::stream() << tr("Error initializing parameter %1").arg(layer->name()) << endl;
        return false;
      }
    } else {
      layer->setFinalProfileValuesCondition( _minRaw, _maxRaw );
    }
    if(!layer->depthToParam(iLayer==lastLayer, prevLayer, ps)) {
      App::stream() << tr("Error initializing parameter %1").arg(layer->name()) << endl;
      return false;
    }
    // Condition between neighbour layers
    if ( _type == Param ) {
      if (prevLayer && layer->isLastParamCondition()) {
        switch (_defaultCondition) {
        case SimpleCondition::LessThan:
          ps.addCondition( new SimpleCondition ( prevLayer->bottomParam(), SimpleCondition::LessThan, 1.0, layer->topParam(), 0.0 ) );
          break;
        case SimpleCondition::GreaterThan:
          ps.addCondition( new SimpleCondition ( prevLayer->bottomParam(), SimpleCondition::GreaterThan, 1.0, layer->topParam(), 0.0 ) );
          break;
        }
      }
    }
    prevLayer = layer;
  }
  return true;
}

/*!
  Delayed resolution of linked depths
  Needed by profiles for checking and adding condition for depth (across linked depths).
*/
void ParamProfile::setLinkedDepth( RealSpace& ps )
{
  TRACE;
  ParamLayer * prevLayer = 0;
  ParamLayer * layer;
  int lastLayer = _layers.size() - 1;
  int iLayer = 0;
  for ( LayerList::iterator it = _layers.begin();it != _layers.end();++it, iLayer++ ) {
    layer = *it;
    layer->setLinkedDepth( iLayer == lastLayer, prevLayer, ps);
    prevLayer = layer;
  }
}

/*!
  Initialize the final profiles with the correct number of sub layers and set the index of the top sub layer of each paramLayer.
*/
void ParamProfile::initFinalProfile()
{
  TRACE;
  int index = 0;
  int n = _layers.count();
  for ( int i = 0; i<n; i++ ) {
    _layers.at(i)->setTopDepthIndex(index);
  }
  switch (_type) {
  case Condition:
    _maxRaw.resize( index );
  case Param:
    _raw.resize( index );
    break;
  }
}

/*!
  Called routinely during inversion, it inits the depths from parameter values.
  Linked depth parameters are not considered.
*/
void ParamProfile::setFinalDepths(int fromLayer)
{
  TRACE;
  double z;
  if ( fromLayer == 0 )
    z = 0.0;
  else
    z = _layers.at(fromLayer)->topDepth();
  int n = _layers.count();
  for ( int i = fromLayer; i<n; i++ ) {
    _layers.at(i)->setFinalDepths( z );
  }
}

/*!
  Called routinely during inversion, it inits the depths from parameter values.
  Linked depth parameters are considered to build the final depth profile.
*/
void ParamProfile::setFinalProfileDepths(int fromLayer)
{
  TRACE;
  double z;
  if ( fromLayer == 0 )
    z = 0.0;
  else
    z = _layers.at(fromLayer)->topDepth();
  int n = _layers.count();
  switch (_type) {
  case Param:
    for ( int i = fromLayer; i<n; i++ ) {
      _layers.at(i)->setFinalProfileDepthsParam( _raw, z );
    }
    break;
  case Condition:
    for ( int i = fromLayer; i<n; i++ ) {
      _layers.at(i)->setFinalProfileDepthsCondition( _minRaw, _maxRaw, z );
    }
    break;
  }
}

void ParamProfile::setFinalProfileFrom(int layer)
{
  TRACE;
  int n = _layers.count();
  switch (_type) {
  case Param:
    for ( int i = layer; i<n; i++ ) {
      _layers.at(i)->setFinalProfileValuesParam( _raw );
    }
  case Condition:
    break;
  }
}

void ParamProfile::setFinalProfileAt(int layer)
{
  TRACE;
  switch (_type) {
  case Param:
    _layers.at(layer)->setFinalProfileValuesParam( _raw );
  case Condition:
    break;
  }
}

void ParamProfile::pRaw() const
{
  TRACE;
  _raw.print();
}

void ParamProfile::pResampled() const
{
  TRACE;
  _resampled.print();
}

void ParamProfile::pMaxRaw() const
{
  TRACE;
  _maxRaw.print();
}

void ParamProfile::pMaxResampled() const
{
  TRACE;
  _maxResampled.print();
}

void ParamProfile::xml_writeChildren( XML_WRITECHILDREN_ARGS ) const
{
  TRACE;
  LayerList::const_iterator it;
  static const QString key("name");
  XMLSaveAttributes att;
  att.add(key);
  QString& value = att.value(0);
  for ( it = _layers.begin();it != _layers.end();++it ) {
    value = ( *it ) ->name();
    ( *it ) ->xml_save(s, context, att);
  }
}

void ParamProfile::xml_writeProperties( XML_WRITEPROPERTIES_ARGS ) const
{
  TRACE;
  Q_UNUSED(context);
  writeProperty( s, "type", _type == Param ? "Param" : "Condition" );
  writeProperty( s, "longName", _longName );
  writeProperty( s, "shortName", _shortName );
  writeProperty( s, "unit", _unit );
  writeProperty( s, "defaultMinimum", _defaultMinimum );
  writeProperty( s, "defaultMaximum", _defaultMaximum );
  writeProperty( s, "defaultCondition",
                 _defaultCondition == SimpleCondition::LessThan ? "LessThan" : "GreaterThan");
}

XMLMember ParamProfile::xml_member( XML_MEMBER_ARGS )
{
  TRACE;
  Q_UNUSED(attributes)
  Q_UNUSED(context);
  if ( tag == "longName" ) return XMLMember( 0 );
  else if ( tag == "shortName" ) return XMLMember( 1 );
  else if ( tag == "unit" ) return XMLMember( 2 );
  else if ( tag == "type" ) return XMLMember( 6 );
  else if ( tag == "defaultMinimum" ) return XMLMember( 3 );
  else if ( tag == "defaultMaximum" ) return XMLMember( 4 );
  else if ( tag == "defaultCondition" ) return XMLMember( 5 );
  else if ( tag == "ParamLayer" ) {
    ParamLayer * l = new ParamLayer(this, nLayers());
    _layers.append( l );
    return XMLMember( l );
  } else if (tag == "minDefault") return XMLMember( 3 ); // Kept for compatibility
  else if (tag == "maxDefault") return XMLMember( 4 ); // Kept for compatibility
  else return XMLMember(XMLMember::Unknown);
}

bool ParamProfile::xml_setProperty( XML_SETPROPERTY_ARGS )
{
  TRACE;
  Q_UNUSED(context);
  Q_UNUSED(attributes)
  switch ( memberID ) {
  case 0: _longName = content.toString(); return true;
  case 1: _shortName = content.toString(); return true;
  case 2: _unit = content.toString(); return true;
  case 3: _defaultMinimum = content.toDouble(); return true;
  case 4: _defaultMaximum = content.toDouble(); return true;
  case 5:
    if ( content == "GreaterThan" )
      _defaultCondition = SimpleCondition::GreaterThan;
    else
      _defaultCondition = SimpleCondition::LessThan;
    return true;
  case 6:
    if ( content == "Condition" )
      _type = Condition;
    else
      _type = Param;
    return true;
  default: return false;
  }
}

} // namespace DinverDCCore
