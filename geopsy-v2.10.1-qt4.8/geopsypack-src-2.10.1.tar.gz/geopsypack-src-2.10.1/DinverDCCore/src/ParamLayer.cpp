/***************************************************************************
**
**  This file is part of DinverDCCore.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-10-18
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverCore.h>
#include <QGpCoreTools.h>
#include "ParamLayer.h"
#include "ParamProfile.h"
#include "GroundParameter.h"

namespace DinverDCCore {

const QString ParamLayer::xmlParamLayerTag = "ParamLayer";

/*!
  \class ParamLayer qtbabstractlayer.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Copy constructor. Profile ownership is left free. Used only by
  copy constructor of ParamProfile.
*/
ParamLayer::ParamLayer(const ParamLayer& o)
  : XMLClass()
{
  _profile = 0;
  _index = o._index;
  _shape = o._shape;
  _nSubLayers = o._nSubLayers;
  _topMin = o._topMin;
  _topMax = o._topMax;
  _bottomMin = o._bottomMin;
  _bottomMax = o._bottomMax;
  _lastParamCondition = o._lastParamCondition;

  _linkedTo = o._linkedTo;
  _isDepth = o._isDepth;
  _dhMin = o._dhMin;
  _dhMax = o._dhMax;

  _topDepthIndex = o._topDepthIndex;
  _finalTopDepth = o._finalTopDepth;
  _finalBottomDepth = o._finalBottomDepth;

  _ptrLink = 0;
  _topP = 0;
  _bottomP = 0;
  _dhP = 0;
}

/*!
  Constructs a default layer. Default options are acquired from \a profile.
*/
ParamLayer::ParamLayer(ParamProfile * profile, int index)
{
  TRACE;
  _profile = profile;
  _index = index;
  _shape = Uniform;
  _nSubLayers = 5;
  _topMin = profile->defaultMinimum();
  _topMax = profile->defaultMaximum();
  _bottomMin = _topMin;
  _bottomMax = _topMax;
  _lastParamCondition = true;

  _linkedTo = "Not linked";
  _isDepth = true;
  _dhMin = 1.0;
  _dhMax = 100.0;

  _topDepthIndex = 0;

  _ptrLink = 0;
  _topP = 0;
  _bottomP = 0;
  _dhP = 0;
}

/*!
  Create a new layer with a uniform value between \a minValue and \a maxValue. The detph is linked to profile \a linkedTo.
  Basically used to build a ground model from a LayeredModel.
*/
ParamLayer::ParamLayer( ParamProfile * profile, int index, double minValue, double maxValue, ParamProfile * linkedTo )
{
  TRACE;
  _profile = profile;
  _index = index;
  _ptrLink = 0;
  _topP = 0;
  _bottomP = 0;
  _dhP = 0;
  _topDepthIndex = 0;

  _shape = Uniform;
  _lastParamCondition = false;
  _nSubLayers = 1;
  _topMin = minValue;
  _topMax = maxValue;
  _bottomMin = minValue;
  _bottomMax = maxValue;
  _linkedTo = name(linkedTo->shortName(), index);
  _isDepth = true;
  _dhMin = 0.0;
  _dhMax = 0.0;
}

/*!
  Create a new layer with a uniform value betweem \a minValue and \a maxValue. The detph can vary from \a minDepth to \a maxDepth.
  Basically used to build a ground model from a LayeredModel.
*/
ParamLayer::ParamLayer( ParamProfile * profile, int index, double minValue, double maxValue, double minDepth, double maxDepth )
{
  TRACE;
  _profile = profile;
  _index = index;
  _ptrLink = 0;
  _topP = 0;
  _bottomP = 0;
  _dhP = 0;
  _topDepthIndex = 0;

  _shape = Uniform;
  _lastParamCondition = false;
  _nSubLayers = 1;
  _topMin = minValue;
  _topMax = maxValue;
  _bottomMin = minValue;
  _bottomMax = maxValue;
  _linkedTo = "Not linked";
  _isDepth = true;
  _dhMin = minDepth;
  _dhMax = maxDepth;
}

/*!
  Set link name from link pointer. Used after inserting a new layer
*/
void ParamLayer::setLinkedTo()
{
  TRACE;
  if(_ptrLink) {
    _linkedTo=_ptrLink->name();
  }
}

QString ParamLayer::name() const
{
  TRACE;
  return name( _profile->shortName(), _index );
}

QString ParamLayer::unit() const
{
  TRACE;
  return _profile->unit();
}

bool ParamLayer::valueToParam(RealSpace& ps)
{
  TRACE;
  _topP = ps.addParameter( new GroundParameter( this, GroundParameter::ValueTop, _topMin, _topMax ) );
  _topP->setScale( ParameterGrid::Log );
  _topP->setPrecision( 0.001 );
  if(!_topP->initGrid()) {
    return false;
  }
  switch ( _shape ) {
  case Uniform:
    _bottomP = _topP;
    break;
  case Linear:
    _bottomP = ps.addParameter( new GroundParameter( this, GroundParameter::ValueBottom, _bottomMin, _bottomMax ) );
    _bottomP->setScale( ParameterGrid::Log );
    _bottomP->setPrecision( 0.01 );
    if(!_bottomP->initGrid()) {
      return false;
    }
    break;
  case PowerLaw:
  case LinearIncrease:
    _bottomP = ps.addParameter( new GroundParameter( this, GroundParameter::ValueBottom, _bottomMin, _bottomMax ) );
    _bottomP->setScale( ParameterGrid::Log );
    _bottomP->setPrecision( 0.01 );
    if(!_bottomP->initGrid()) {
      return false;
    }
    ps.addCondition( new SimpleCondition ( _bottomP, SimpleCondition::GreaterThan, 1.0, _topP, 0.0 ) );
    break;
  case LinearDecrease:
    _bottomP = ps.addParameter( new GroundParameter( this, GroundParameter::ValueBottom, _bottomMin, _bottomMax ) );
    _bottomP->setScale( ParameterGrid::Log );
    _bottomP->setPrecision( 0.01 );
    if(!_bottomP->initGrid()) {
      return false;
    }
    ps.addCondition( new SimpleCondition ( _bottomP, SimpleCondition::LessThan, 1.0, _topP, 0.0 ) );
    break;
  }
  return true;
}

bool ParamLayer::depthToParam(bool last, ParamLayer * prev, RealSpace& ps)
{
  TRACE;
  if (!_ptrLink && !last) {
    _dhP = ps.addParameter( new GroundParameter( this,
               _isDepth ? GroundParameter::Depth : GroundParameter::Thickness, _dhMin, _dhMax ) );
    _dhP->setScale( ParameterGrid::Log );
    _dhP->setPrecision(0.01);
    if(!_dhP->initGrid()) {
      return false;
    }
    _dhP->setFussy(true);
    if (_isDepth && prev && prev->isDepth() && prev->dhParam()) {
      // Strict condition to avoid null thicknesses
      //ps.addCondition(new SimpleCondition (_dhP, SimpleCondition::GreaterThan, 1.0, prev->dhParam(), 0.0 ));
      // Condition to avoid thin layers: thickness cannot be less than 5% of average depth of layer
      ps.addCondition(new SimpleCondition (_dhP, SimpleCondition::GreaterThan, (2.0+0.05)/(2.0-0.05), prev->dhParam(), 0.0));
    }
  } else {
    _dhP = 0;
  }
  return true;
}

/*!
  Add top and bottom parameters if they are not fixed to \a params.
*/
void ParamLayer::collectValueParameters( QList<Parameter *>& params ) const
{
  TRACE;
  if (_topP) {
    if (!_topP->isFixed()) params.append(_topP);
    if (_bottomP!=_topP) {
      if (!_bottomP->isFixed()) params.append(_bottomP);
    }
  }
}

/*!
  Check and add condition for depth across linked depths.
*/
void ParamLayer::setLinkedDepth( bool last, ParamLayer * prev, RealSpace& ps )
{
  TRACE;
  if ( _ptrLink && !last ) {
    static_cast<GroundParameter *>(_ptrLink->_dhP)->addLayer(this);
    if ( _ptrLink->_isDepth ) {
      _isDepth = true;
      _dhP = _ptrLink->_dhP;
      if ( prev && prev->_isDepth && prev->_dhP )
        ps.addCondition( new SimpleCondition ( _dhP, SimpleCondition::GreaterThan, 1.0, prev->_dhP, 0.0 ) );
    }
  }
  // In case of thickness linked: _dhLeftP and _dhRightP pointers are set to 0
}

/*!
  Return the fixed thickness to the upper most layers with variable depth or thickness returned in \a ref (left)
*/
double ParamLayer::fixedThickness(ParamLayer *& ref)
{
  TRACE;
  if (_dhMin == _dhMax) {
    if (_isDepth || _index == 0) {
      ref = 0;
      return _dhMin;
    } else {
      return _dhMin+_profile->layer(_index-1)->fixedThickness(ref);
    }
  }
  ref = this;
  return 0.0;
}

/*!
  Check if the two layers have a common interface, even through fixed depths and thicknesses
*/
bool ParamLayer::isLinkedTo(ParamLayer * o)
{
  TRACE;
  // layers are linked together (this towards o)
  if (_ptrLink == o) return true;
  // layers are both linked to another layer (chained links have already been solved)
  if( _ptrLink == o->_ptrLink && _ptrLink != 0 ) return true;
  // layers are linked together (o towards this)
  if( this == o->_ptrLink) return true;
  // layers have fixed depths or thicknesses
  ParamLayer * lThis, *lo;
  double thickness = fixedThickness(lThis);
  if (thickness==o->fixedThickness(lo) && thickness>0.0) {
    if ( lThis && lo ) {
      if (!lThis->isLinkedTo(lo)) return false;
    } else if ( !lThis && !lo );
    else return false;
  } else return false;
  return true;
}

/*!
  Set the index of the top sub layer in the final profile, \a index is incremented by the number of sub layers for this layer.
*/
void ParamLayer::setTopDepthIndex( int& index )
{
  TRACE;
  _topDepthIndex = index;
  switch ( _shape ) {
  case Linear:
  case LinearIncrease:
  case LinearDecrease:
  case PowerLaw:
    index+=_nSubLayers;
    break;
  default:
    index++;
    break;
  }
}

/*!
  Called routinely during inversion, it inits the final bottom depth of the layer.

  If the top of the layer is below the bottom, a quasi null thickness is set. This may happen only during initialization phase.
  At any other time, the conditions on depths must effectively forbid this situation.

  Links are not taken into account.
*/
void ParamLayer::setFinalDepths( double & z )
{
  TRACE;
  if ( _dhP ) {
    _finalTopDepth = z;
    if ( _isDepth ) {
      _finalBottomDepth = _dhP->realValue();
      if ( _finalTopDepth >= _finalBottomDepth ) {
        App::stream() << tr("Null or negative thickness for layer %1: top=%2, bottom=%3, very thin layer instead (1 mm).")
                     .arg(name()).arg(_finalTopDepth).arg(_finalBottomDepth) << endl;
        _finalBottomDepth = _finalTopDepth + 0.001;
      }
      z = _finalBottomDepth;
    } else {
      _finalBottomDepth = z + _dhP->realValue();
      z = _finalBottomDepth;
    }
  }
}

/*!
  Called routinely during inversion, it sets the depths of final \a profile for parameter layers
*/
void ParamLayer::setFinalProfileDepthsParam( Profile& profile, double & z )
{
  TRACE;
  if ( !_dhP ) { // Set final depth for halfspace or layers linked to thickness param
    _finalTopDepth = z;
    if ( _ptrLink ) _finalBottomDepth = _ptrLink->_finalBottomDepth;
    else _finalBottomDepth = 1e99;
  }
  z = _finalBottomDepth;

  switch ( _shape ) {
  case Uniform:
    profile.setDepth( _topDepthIndex, _finalBottomDepth);
    break;
  case Linear:
  case LinearIncrease:
  case LinearDecrease: {
      double dz = ( _finalBottomDepth - _finalTopDepth ) / ( double ) _nSubLayers;
      int n = _nSubLayers-1;
      for ( int i = 0;i < n;i++ ) {
        profile.setDepth( _topDepthIndex+i, _finalTopDepth + ( double ) ( i + 1 ) * dz );
      }
      profile.setDepth(_topDepthIndex+n, _finalBottomDepth);
    }
    break;
  case PowerLaw: {
      double dz = ( _finalBottomDepth - _finalTopDepth ) / ( pow( 2.0, _nSubLayers ) - 1.0 );
      double z = _finalTopDepth;
      int n = _nSubLayers-1;
      for ( int i = 0;i < n;i++ ) {
        z += dz;
        profile.setDepth( _topDepthIndex+i, z );
        dz *= 2.0;
      }
      profile.setDepth(_topDepthIndex+n, _finalBottomDepth);
    }
    break;
  }
}

/*!
  Called routinely during inversion, it sets the depths of final profiles \a min and \a max for condition layers
*/
void ParamLayer::setFinalProfileDepthsCondition( Profile& min, Profile& max, double & z )
{
  TRACE;
  if ( !_dhP ) { // Set final depth for halfspace or layers linked to thickness param
    _finalTopDepth = z;
    if ( _ptrLink ) _finalBottomDepth = _ptrLink->_finalBottomDepth;
    else _finalBottomDepth = 1e99;
  }
  z = _finalBottomDepth;

  switch ( _shape ) {
  case Uniform:
    min.setDepth( _topDepthIndex, _finalBottomDepth);
    max.setDepth( _topDepthIndex, _finalBottomDepth);
    break;
  case Linear:
  case LinearIncrease:
  case LinearDecrease: {
      double dz = ( _finalBottomDepth - _finalTopDepth ) / ( double ) _nSubLayers;
      int n = _nSubLayers-1;
      for ( int i = 0;i < n;i++ ) {
        int di = _topDepthIndex+i;
        double z = _finalTopDepth + ( double ) ( i + 1 ) * dz;
        min.setDepth( di, z );
        max.setDepth( di, z );
      }
      min.setDepth(_topDepthIndex+n, _finalBottomDepth);
      max.setDepth(_topDepthIndex+n, _finalBottomDepth);
    }
    break;
  case PowerLaw: {
      double dz = ( _finalBottomDepth - _finalTopDepth ) / ( pow( 2.0, _nSubLayers ) - 1.0 );
      double z = _finalTopDepth;
      int n = _nSubLayers-1;
      for ( int i = 0;i < n;i++ ) {
        int di = _topDepthIndex+i;
        z += dz;
        min.setDepth( di, z );
        max.setDepth( di, z );
        dz *= 2.0;
      }
      min.setDepth(_topDepthIndex+n, _finalBottomDepth);
      max.setDepth(_topDepthIndex+n, _finalBottomDepth);
    }
    break;
  }
}

/*!
  Set intermediate depths according to shape
*/
void ParamLayer::setFinalProfileValues( Profile& profile, double topV, double bottomV )
{
  TRACE;
  // TODO : titled layers
  switch ( _shape ) {
  case Uniform:
    profile.setValue( _topDepthIndex, topV);
    break;
  case Linear:
  case LinearIncrease:
  case LinearDecrease: {
      double h = _finalBottomDepth - _finalTopDepth;
      double dz = h / ( double ) _nSubLayers;
      double halfdz = 0.5 * dz + _finalTopDepth;
      double slope = ( bottomV - topV ) / h;
      for ( int i = 0;i < _nSubLayers;i++ ) {
        int di = _topDepthIndex+i;
        profile.setValue( di, topV + slope * ( profile.depths().at(di) - halfdz ));
      }
    }
    break;
  case PowerLaw: {  // Simple power law: V=V0*(1.0+z-z0)^alpha
      double alpha = log( bottomV / topV ) / log( _finalBottomDepth - _finalTopDepth + 1.0 );
      double lastZ = _finalTopDepth;
      double z;
      for ( int i = 0;i < _nSubLayers;i++ ) {
        int di = _topDepthIndex+i;
        z = profile.depths().at(di);
        profile.setValue( di, topV * pow( 1.0 + 0.5 * ( z + lastZ ) - _finalTopDepth, alpha ) );
        lastZ = z;
      }
    }
    break;
  }
}

/*!
  \fn ParamLayer::topDepth() const
  Returns the current depth of the top
*/

/*!
  \fn ParamLayer::bottomDepth() const
  Returns the current depth of the bottom
*/

/*!
  Returns the current depth of next fixed depth. If the next layers have thickness parameters rather than depth, then the returned
  value is the bottom of the layer with a depth parameter below these thickness parameter layers, or 1e99 if the half space is reached.
  If the next layer has a depth parameter, the returned value is the same as bottomDepth().
*/
double ParamLayer::fixedBottomDepth() const
{
  TRACE;
  int nLayers = profile()->nLayers();
  for (int i = _index+1; i<nLayers; i++) {
    ParamLayer * layer = profile()->layer(i);
    if ( layer->isDepth() ) {
      return layer->bottomDepth();
    }
  }
  return 1e99; // No fixed bottom depth, half space reached
}

void ParamLayer::xml_writeProperties( XML_WRITEPROPERTIES_ARGS ) const
{
  TRACE;
  Q_UNUSED(context);
  switch ( _shape ) {
  case Linear: writeProperty( s, "shape", "Linear" ); break;
  case LinearIncrease: writeProperty( s, "shape", "LinearIncrease" ); break;
  case LinearDecrease: writeProperty( s, "shape", "LinearDecrease" ); break;
  case PowerLaw: writeProperty( s, "shape", "PowerLaw" ); break;
  case Uniform: writeProperty( s, "shape", "Uniform" ); break;
  }
  writeProperty( s, "lastParamCondition", _lastParamCondition );
  writeProperty( s, "nSubayers", _nSubLayers );
  writeProperty( s, "topMin", _topMin );
  writeProperty( s, "topMax", _topMax );
  if(_shape!=Uniform) {
    writeProperty( s, "bottomMin", _bottomMin );
    writeProperty( s, "bottomMax", _bottomMax );
  }
  writeProperty( s, "linkedTo", _linkedTo );
  writeProperty( s, "isDepth", _isDepth );
  writeProperty( s, "dhMin", _dhMin );
  writeProperty( s, "dhMax", _dhMax );
}

XMLMember ParamLayer::xml_member( XML_MEMBER_ARGS )
{
  TRACE;
  Q_UNUSED(attributes)
  Q_UNUSED(context);
  if ( tag == "shape" ) return XMLMember( 0 );
  else if ( tag == "lastParamCondition" ) return XMLMember( 1 );
  else if ( tag == "nSubayers" ) return XMLMember( 2 );
  else if ( tag == "topMin" ) return XMLMember( 3 );
  else if ( tag == "topMax" ) return XMLMember( 4 );
  else if ( tag == "bottomMin" ) return XMLMember( 5 );
  else if ( tag == "bottomMax" ) return XMLMember( 6 );
  else if ( tag == "linkedTo" ) return XMLMember( 7 );
  else if ( tag == "isDepth" ) return XMLMember( 8 );
  else if ( tag == "dhMin" ) return XMLMember( 9 );
  else if ( tag == "dhMax" ) return XMLMember( 10 );
  else if ( tag == "tilted" ) return XMLMember( 11 ); // Kept for compatibility
  else if ( tag == "dhMinLeft" ) return XMLMember( 9 ); // Kept for compatibility
  else if ( tag == "dhMaxLeft" ) return XMLMember( 10 ); // Kept for compatibility
  else if ( tag == "dhMinRight" ) return XMLMember( 11 ); // Kept for compatibility
  else if ( tag == "dhMaxRight" ) return XMLMember( 11 ); // Kept for compatibility
  else if ( tag == "greaterThanPrevious" ) return XMLMember( 1 ); // Kept for compatibility
  else return XMLMember(XMLMember::Unknown);
}

bool ParamLayer::xml_setProperty( XML_SETPROPERTY_ARGS )
{
  TRACE;
  Q_UNUSED(attributes)
  Q_UNUSED(context);
  switch ( memberID ) {
  case 0:
    if ( content == "Uniform" ) _shape = Uniform;
    else if ( content == "Linear" ) _shape = Linear;
    else if ( content == "LinearIncrease" ) _shape = LinearIncrease;
    else if ( content == "LinearDecrease" ) _shape = LinearDecrease;
    else if ( content == "PowerLaw" ) _shape = PowerLaw;
    else if ( content == "LinearIncr" ) _shape = LinearIncrease; // Kept for compatibility
    else if ( content == "LinearDecr" ) _shape = LinearDecrease; // Kept for compatibility
    else {
      App::stream() << tr( "Unknown value %1 for shape" ).arg( content.toString() ) << endl;
      return false;
    }
    return true;
  case 1:
    _lastParamCondition = content.toBool();
    return true;
  case 2:
    _nSubLayers = content.toInt();
    return true;
  case 3:
    _topMin = content.toDouble();
    return true;
  case 4:
    _topMax = content.toDouble();
    return true;
  case 5:
    _bottomMin = content.toDouble();
    return true;
  case 6:
    _bottomMax = content.toDouble();
    return true;
  case 7:
    _linkedTo = content.toString();
    return true;
  case 8:
    _isDepth = content.toBool();
    return true;
  case 9:
    _dhMin = content.toDouble();
    return true;
  case 10:
    _dhMax = content.toDouble();
    return true;
  case 11:
    return true;
  default:
    return false;
  }
}

} // namespace DinverDCCore
