#ifndef DINVERDCCOREDLLEXPORT_H
#define DINVERDCCOREDLLEXPORT_H

/* *_STATIC and MAKE_*_DLL are defined by the capitalization of
  the package name, included in the compiler options (only for Windows).
  Use directly WIN32 to allow transparent usage with or without Qt.
  DinverDCCoreInstallPath.h may contain DINVERDCCORE_STATIC macro definition.
  This define was introduced there to mark this library as static for
  all projects that link to this library.
*/

#include "DinverDCCoreInstallPath.h"

#if defined(WIN32) && !defined(DINVERDCCORE_STATIC)
#ifdef MAKE_DINVERDCCORE_DLL
# define DINVERDCCORE_EXPORT __declspec(dllexport)
#else
# define DINVERDCCORE_EXPORT __declspec(dllimport)
#endif
#else
# define DINVERDCCORE_EXPORT
#endif

#endif  // DINVERDCCOREDLLEXPORT_H

