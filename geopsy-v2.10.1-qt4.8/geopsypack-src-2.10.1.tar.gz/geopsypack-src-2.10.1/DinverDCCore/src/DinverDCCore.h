#ifndef DINVERDCCORE_HEADERS
#define DINVERDCCORE_HEADERS

// All headers of DinverDCCore library

#include "DinverDCCore/AutocorrTarget.h"
#include "DinverDCCore/DCModelInfo.h"
#include "DinverDCCore/DCReportBlock.h"
#include "DinverDCCore/DinverDCCoreDLLExport.h"
#include "DinverDCCore/GroundParameter.h"
#include "DinverDCCore/ModalCurveTarget.h"
#include "DinverDCCore/ModalStorageReader.h"
#include "DinverDCCore/ParamGroundModel.h"
#include "DinverDCCore/ParamLayer.h"
#include "DinverDCCore/ParamProfile.h"
#include "DinverDCCore/PoissonCondition.h"
#include "DinverDCCore/RefractionTarget.h"
#include "DinverDCCore/Target.h"
#include "DinverDCCore/TargetList.h"
#include "DinverDCCore/ValueTarget.h"
#include "DinverDCCore/XMLDinverDC.h"

#ifndef GP_EXPLICIT_LIBRARY_NAMESPACE
using namespace DinverDCCore;
#endif

#endif // DINVERDCCORE_HEADERS
