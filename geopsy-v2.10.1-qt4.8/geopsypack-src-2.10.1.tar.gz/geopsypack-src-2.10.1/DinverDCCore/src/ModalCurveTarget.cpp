/***************************************************************************
**
**  This file is part of DinverDCCore.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-07-27
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "ModalCurveTarget.h"

namespace DinverDCCore {

/*!
  \class ModalCurveTarget qtbmodalcurvetarget.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

const QString ModalCurveTarget::xmlModalCurveTargetTag = "ModalCurveTarget";

/*!
  Description of constructor still missing
*/
ModalCurveTarget::ModalCurveTarget()
    : Target()
{
  TRACE;
}

/*!
  Description of constructor still missing
*/
ModalCurveTarget::ModalCurveTarget(const ModalCurveTarget& o)
    : Target(o)
{
  TRACE;
  _curves=o._curves;
}

void ModalCurveTarget::setCurves(const QList<ModalCurve>& c)
{
  TRACE;
  _curves = c;
  for(QList<ModalCurve>::iterator it = _curves.begin(); it!=_curves.end(); it++) {
    it->sort();
  }
}

void ModalCurveTarget::xml_writeChildren( XML_WRITECHILDREN_ARGS ) const
{
  TRACE;
  for (QList<ModalCurve>::const_iterator it = _curves.begin(); it!=_curves.end(); ++it ) {
    it->xml_save(s, context);
  }
}

XMLMember ModalCurveTarget::xml_member( XML_MEMBER_ARGS )
{
  TRACE;
  Q_UNUSED(context);
  if(tag=="ModalCurve") {
    _curves.append(ModalCurve());
    return XMLMember(&_curves.last());
  } else return Target::xml_member(tag, attributes, context);
}

} // namespace DinverDCCore
