/***************************************************************************
**
**  This file is part of DinverDCCore.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-08-09
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "GroundParameter.h"
#include "ParamLayer.h"

namespace DinverDCCore {

/*!
  \class GroundParameter qtbgroundparameter.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

/*!
  Description of constructor still missing
*/
GroundParameter::GroundParameter( const ParamLayer * layer, Type type, double min, double max)
    : Parameter()
{
  TRACE;
  _layers << layer;
  _type = type;
  enum Type { ValueTop, ValueBottom, Depth, Thickness, LeftDepth, LeftThickness, RightDepth, RightThickness };
  switch(_type) {
  case ValueTop:
    setName( "Top"+layer->name() );
    setUnit(layer->unit());
    break;
  case ValueBottom:
    setName( "Bottom"+layer->name() );
    setUnit(layer->unit());
    break;
  case Depth:
    setName( "D"+layer->name() );
    setUnit("m");
    break;
  case Thickness:
    setName( "H"+layer->name() );
    setUnit("m");
    break;
  case LeftDepth:
    setName( "LD"+layer->name() );
    setUnit("m");
    break;
  case LeftThickness:
    setName( "LH"+layer->name() );
    setUnit("m");
    break;
  case RightDepth:
    setName( "RD"+layer->name() );
    setUnit("m");
    break;
  case RightThickness:
    setName( "RH"+layer->name() );
    setUnit("m");
    break;
  }
  setMinimum(min);
  setMaximum(max);
}

} // namespace DinverDCCore
