/***************************************************************************
**
**  This file is part of DinverDCCore.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-08-08
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <math.h>

#include "PoissonCondition.h"
#include "ParamProfile.h"
#include "ParamLayer.h"

namespace DinverDCCore {

/*!
  \class PoissonCondition qtbpoissoncondition.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

const QString PoissonCondition::xmlPoissonConditionTag = "PoissonCondition";

struct ProfileLimits
{
  const ParamLayer * layer;
  QVector<double> depths;
  QVector<double> minP;
  QVector<double> maxP;
  int topIndex;
  int bottomIndex;
  double topDepth;
  double bottomDepth;
  void pMinP();
  void pMaxP();
};

void ProfileLimits::pMinP()
{
  TRACE;
  printf("--min-profile--\n");
  for (int i = topIndex; i<=bottomIndex; i++) {
    printf("%20.15lg\t%20.15lg\n",depths[i],minP[i]);
  }
}

void ProfileLimits::pMaxP()
{
  TRACE;
  printf("--max-profile--\n");
  for (int i = topIndex; i<=bottomIndex; i++) {
    printf("%20.15lg\t%20.15lg\n",depths[i],maxP[i]);
  }
}

class LinearDepth
{
public:
  LinearDepth( double h, int nSubLayers ) {
    _h = h;
    _dz = h / ( double ) nSubLayers;
    _z = _dz;
    _iSubLayer = 1;
    _nSubLayers = nSubLayers;
  }
  double midDepth( double depth ) {
    if (_iSubLayer<_nSubLayers) {
      while(true) {
        if (depth<=_z) return _z-0.5*_dz;
        _iSubLayer++;
        if (_iSubLayer<_nSubLayers) {
          _z = ( double ) _iSubLayer * _dz;
        } else {
          _z = _h-0.5*_dz;
          return _z;
        }
      }
    } else return _z;
  }
private:
  double _dz, _z, _h;
  int _iSubLayer, _nSubLayers;
};

class PowerLawDepth
{
public:
  PowerLawDepth( double h, int nSubLayers ) {
    _h = h;
    _dz = h / ( pow( 2.0, nSubLayers ) - 1.0 );
    _z = _dz;
    _iSubLayer = 1;
    _nSubLayers = nSubLayers;
  }
  double midDepth( double depth ) {
    if (_iSubLayer<_nSubLayers) {
      while(true) {
        if (depth<=_z) return _z-0.5*_dz;
        _iSubLayer++;
        if (_iSubLayer<_nSubLayers) {
          _dz *= 2.0;
          _z += _dz;
        } else {
          _z = _h-_dz;
          return _z;
        }
      }
    } else return _z;
  }
private:
  double _dz, _z, _h;
  int _iSubLayer, _nSubLayers;
};

/*!
  Description of constructor still missing
*/
PoissonCondition::PoissonCondition(ParamProfile * vp, ParamProfile * vs, ParamProfile * nu)
{
  TRACE;
  _vp = vp;
  _vs = vs;
  _nu = nu;
  // Build the list of involved parameters (all value parameters from vp, vs and nu)
  _vp->collectValueParameters(parameterList());
  _vs->collectValueParameters(parameterList());
  _nu->collectValueParameters(parameterList());
}

bool PoissonCondition::operator==( const AbstractCondition& o ) const
{
  TRACE;
  if (xml_tagName() == o.xml_tagName()) {
    return AbstractCondition::operator==(o);
  } else return false;
}

void PoissonCondition::getLimits( int paramIndex, double& min, double& max) const
{
  TRACE;
  const GroundParameter& gParam = parameter(paramIndex);
  ProfileLimits pl;
  pl.layer = gParam.layer( 0 ); /* Only depth parameters may be linked to several layers from distinct profiles
                                   Depth parameters are never associated a poisson condition directly */
  const ParamProfile * profile = pl.layer->profile();
  pl.depths = profile->depths();
  const QVector<double>& minNu = _nu->minValues();
  const QVector<double>& maxNu = _nu->maxValues();
  int n = pl.depths.count();
  pl.minP.resize(n);
  pl.maxP.resize(n);
  pl.topDepth = pl.layer->topDepth();
  pl.bottomDepth = pl.layer->bottomDepth();
  pl.topIndex = -1;
  if (profile == _vp) { // Compute minP and maxP for Vp
    const QVector<double>& values = _vs->values();
    int i = 0;
    for ( ; i<n && pl.depths[i]<=pl.topDepth; i++ );
    pl.topIndex = i;
    for ( ; i<n && pl.depths[i]<=pl.bottomDepth; i++ ) {
      if (minNu[i]==0.5)
        pl.minP[i] = 1e99;
      else
        pl.minP[i]=values[i]*sqrt((minNu[i]-1.0)/(minNu[i]-0.5));
      if (maxNu[i]==0.5)
        pl.maxP[i] = 1e99;
      else
        pl.maxP[i]=values[i]*sqrt((maxNu[i]-1.0)/(maxNu[i]-0.5));
    }
    pl.bottomIndex = i-1;
  } else if (profile == _vs) { // Compute minP and maxP for Vs
    const QVector<double>& values = _vp->values();
    int i = 0;
    for ( ; i<n && pl.depths[i]<=pl.topDepth; i++ );
    pl.topIndex = i;
    for ( ; i<n && pl.depths[i]<=pl.bottomDepth; i++ ) {
      pl.minP[i]=values[i]*sqrt((maxNu[i]-0.5)/(maxNu[i]-1.0));
      pl.maxP[i]=values[i]*sqrt((minNu[i]-0.5)/(minNu[i]-1.0));
    }
    pl.bottomIndex = i-1;
  }
  // Find min and max for parameter gParam that belong to layer within minP and maxP profiles
  switch (gParam.type()) {
  case GroundParameter::ValueTop:
    getTopLimits( pl, min, max);
    break;
  case GroundParameter::ValueBottom:
    getBottomLimits( pl, min, max);
    break;
  default:
    // Never occur, depth parameters are directly handled by GroundParameter
    break;
  }
}

void PoissonCondition::getTopLimits( const ProfileLimits& pl, double& min, double& max ) const
{
  TRACE;
  switch (pl.layer->shape()) {
  case ParamLayer::Uniform:
    for(int i=pl.topIndex;i<=pl.bottomIndex;i++) {
      if (pl.minP[i]>min) min=pl.minP[i];
      if (pl.maxP[i]<max) max=pl.maxP[i];
    }
    break;
  case ParamLayer::Linear:
  case ParamLayer::LinearIncrease:
  case ParamLayer::LinearDecrease: {
      double h = pl.bottomDepth - pl.topDepth;
      double bottomV = pl.layer->bottomParam()->realValue();
      LinearDepth linDepth( h, pl.layer->nSubLayers() );
      double lastDepth=pl.topDepth;
      for( int i = pl.topIndex; i <= pl.bottomIndex; i++) {
        // Get the depth at the middle of the sublayer corresponding to pl.depths[i]
        // Depths of profile must match approximately theoretical depths of layer
        // To avoid precision errors while matching, look for the depth of the middle
        // limit layer.
        double midZ=linDepth.midDepth((pl.depths[i]+lastDepth)*0.5-pl.topDepth);
        lastDepth=pl.depths[i];
        double v, c = h / ( h - midZ );
        v = bottomV + ( pl.minP[i] - bottomV ) * c;
        if (v>min) min=v;
        v = bottomV + ( pl.maxP[i] - bottomV ) * c;
        if (v<max) max=v;
        if (min>max) break;
      }
      break;
    }
  case ParamLayer::PowerLaw: {
      double h = pl.bottomDepth - pl.topDepth;
      double bottomV = pl.layer->bottomParam()->realValue();
      PowerLawDepth powDepth( h, pl.layer->nSubLayers() );
      double lastDepth=pl.topDepth;
      for( int i = pl.topIndex; i <= pl.bottomIndex; i++) {
        // Get the depth at the middle of the sublayer corresponding to pl.depths[i]
        // Depths of profile must match approximately theoretical depths of layer
        // To avoid precision errors while matching, look for the depth of the middle
        // limit layer.
        double midZ=powDepth.midDepth((pl.depths[i]+lastDepth)*0.5-pl.topDepth);
        lastDepth=pl.depths[i];
        // Get the alpha exponent that gives a value of pl.minP[i] at z and bottomV at bottom
        double alpha, v;
        if (pl.minP[i]>0.0 && bottomV > pl.minP[i]) {
          alpha = log( bottomV / pl.minP[i] ) / log( (1.0+h)/(1.0+midZ) );
          v = bottomV / pow( 1.0 + h, alpha );
          if (v>min) min=v;
        }
        if (pl.maxP[i]>0.0 && bottomV > pl.maxP[i]) {
          alpha = log( bottomV / pl.maxP[i] ) / log( (1.0+h)/(1.0+midZ) );
          v = bottomV / pow( 1.0 + h, alpha );
          // Check precision
          //double alpha1 = log( bottomV/v ) / log( h + 1.0 );
          //double vlim = v * pow( 1.0 + midZ, alpha1 );
          //double vlimBottom = v * pow( 1.0 + h, alpha1 );
          if (v<max) max=v;
        }
        if (min>max) break;
      }
      break;
    }
  }
}

void PoissonCondition::getBottomLimits( const ProfileLimits& pl, double& min, double& max ) const
{
  TRACE;
  switch (pl.layer->shape()) {
  case ParamLayer::Uniform:
    for(int i=pl.topIndex;i<=pl.bottomIndex;i++) {
      if (pl.minP[i]>min) min=pl.minP[i];
      if (pl.maxP[i]<max) max=pl.maxP[i];
    }
    break;
  case ParamLayer::Linear:
  case ParamLayer::LinearIncrease:
  case ParamLayer::LinearDecrease: {
      double h = pl.bottomDepth - pl.topDepth;
      double topV = pl.layer->topParam()->realValue();
      LinearDepth linDepth( h, pl.layer->nSubLayers() );
      double lastDepth=pl.topDepth;
      for( int i = pl.topIndex; i <= pl.bottomIndex; i++) {
        // Get the depth at the middle of the sublayer corresponding to pl.depths[i]
        // Depths of profile must match approximately theoretical depths of layer
        // To avoid precision errors while matching, look for the depth of the middle
        // limit layer.
        double midZ=linDepth.midDepth((pl.depths[i]+lastDepth)*0.5-pl.topDepth);
        lastDepth=pl.depths[i];
        double v, c = h / midZ;
        v = topV + ( pl.minP[i] - topV ) * c;
        if (v>min) min=v;
        v = topV + ( pl.maxP[i] - topV ) * c;
        if (v<max) max=v;
        if (min>max) break;
      }
      break;
    }
  case ParamLayer::PowerLaw: {
      double h = pl.bottomDepth - pl.topDepth;
      double topV = pl.layer->topParam()->realValue();
      double inv_topV = 1.0 / topV;
      PowerLawDepth powDepth( h, pl.layer->nSubLayers() );
      double lastDepth=pl.topDepth;
      for( int i = pl.topIndex; i <= pl.bottomIndex; i++) {
        // Get the depth at the middle of the sublayer corresponding to pl.depths[i]
        // Depths of profile must match approximately theoretical depths of layer
        // To avoid precision errors while matching, look for the depth of the middle
        // limit layer.
        double midZ=powDepth.midDepth((pl.depths[i]+lastDepth)*0.5-pl.topDepth);
        lastDepth=pl.depths[i];
        // Get the alpha exponent that gives a value of pl.minP[i] at z and topV at top
        double alpha, v;
        if (pl.minP[i]>0.0 && topV < pl.minP[i]) {
          alpha = log( pl.minP[i]*inv_topV ) / log( 1.0+midZ );
          v = topV * pow( 1.0 + h, alpha );
          if (v>min) min=v;
        }
        if (pl.maxP[i]>0.0 && topV < pl.maxP[i]) {
          alpha = log( pl.maxP[i]*inv_topV ) / log( 1.0+midZ );
          v = topV * pow( 1.0 + h, alpha );
          // Check precision
          //double alpha1 = log( v*inv_topV ) / log( h + 1.0 );
          //double vlim = topV * pow( 1.0 + midZ, alpha1 );
          if (v<max) max=v;
        }
        if (min>max) break;
      }
      break;
    }
  }
}

/*!
  By design this function is called only for fussy parameters (depth and thickness only).
  All profiles are supposed to be correctly built, it return false if Poisson's ratio is not valid.
*/
bool PoissonCondition::isOk(const GroundParameter * from)
{
  TRACE;
  for( int iLayer = from->count()-1; iLayer>=0; iLayer-- ) {
    const ParamLayer * layer = from->layer(iLayer);
    const ParamProfile * profile = layer->profile();
    QVector<double> depths = profile->depths();
    int n = depths.count();
    double topDepth = layer->topDepth();
    double bottomDepth = layer->fixedBottomDepth();
    const QVector<double>& vs = _vs->values();
    const QVector<double>& vp = _vp->values();
    const QVector<double>& minNu = _nu->minValues();
    const QVector<double>& maxNu = _nu->maxValues();
    int i = 0;
    for ( ; i<n && depths[i]<=topDepth; i++ ) {}
    for ( ; i<n && depths[i]<=bottomDepth; i++ ) {
      if (vs[i]<vp[i]*sqrt((maxNu[i]-0.5)/(maxNu[i]-1.0))) return false;
      if (vs[i]>vp[i]*sqrt((minNu[i]-0.5)/(minNu[i]-1.0))) return false;
    }
  }
  return true;
}

/*!
  Return a number that uniquely identify this condition
*/
uint PoissonCondition::internalChecksum() const
{
  TRACE;
  uint cs = 0;
  return cs;
}
/*!
  Print human readable information about condition to stream.
*/
void PoissonCondition::humanInfo() const
{
  TRACE;
  App::stream() << "        Poisson's ratio checked\n";
}



} // namespace DinverDCCore
