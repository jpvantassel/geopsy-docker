/***************************************************************************
**
**  This file is part of DinverDCCore.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2004-10-21
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (ULg, Liège, Belgium)
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include <DinverCore.h>
#include <QGpCompatibility.h>
#include <QGpCoreWave.h>
#include "TargetList.h"
#include "ParamGroundModel.h"
#include "ParamProfile.h"
#include "PoissonCondition.h"

namespace DinverDCCore {

/*!
  \class TargetList qtbtargetlist.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

const QString TargetList::xmlTargetListTag = "TargetList";

/*!
  Description of constructor still missing
*/
TargetList::TargetList()
{
  TRACE;
  initFactories();
  initProfiles();
  // Ellipticity values are expressed on a log scale
  _ellipticityCurveTarget.setMisfitType(StatValue::L2_LogNormalized);
}

TargetList::TargetList(const TargetList& o)
   : XMLClass(),
     _dispersionTarget(o._dispersionTarget),
     _autocorrTarget(o._autocorrTarget),
     _ellipticityCurveTarget(o._ellipticityCurveTarget),
     _ellipticityPeakTarget(o._ellipticityPeakTarget),
     _refractionVpTarget(o._refractionVpTarget),
     _refractionVsTarget(o._refractionVsTarget)
{
  TRACE;
  initFactories();
  initProfiles();
  validateTargets();
}

TargetList::~TargetList()
{
  TRACE;
  deleteFactories();
}

void TargetList::initFactories()
{
  TRACE;
  _dispersionFactory=0;
  _autocorrFactory=0;
  _ellipticityFactory=0;
  _refractionVpFactory=0;
  _refractionVsFactory=0;
}

void TargetList::initProfiles()
{
  TRACE;
  _vp=0;
  _vs=0;
  _rho=0;
  _pitch=0;
  _poissonCondition=0;
}

void TargetList::deleteFactories()
{
  TRACE;
  delete _dispersionFactory;
  delete _autocorrFactory;
  delete _ellipticityFactory;
  delete _refractionVpFactory;
  delete _refractionVsFactory;
  initFactories();
}

void TargetList::setParamProfiles( ParamGroundModel * gm, RealSpace& ps )
{
  TRACE;
  _vp = gm->find( "Vp" );
  _vs = gm->find( "Vs" );
  _rho = gm->find( "Rho" );
  _pitch = gm->find( "Pitch" );
  if (_vp && _vs) {
    ParamProfile * nu = gm->find( "Nu" );
    ASSERT(nu && nu->type()==ParamProfile::Condition);
    _poissonCondition = new PoissonCondition( _vp, _vs, nu );
    ps.addCondition( _poissonCondition );
  }
}

void TargetList::setMisfitType(StatValue::MisfitType t)
{
  TRACE;
  _dispersionTarget.setMisfitType(t);
  _dispersionTarget.setMisfitType(t);
  _autocorrTarget.setMisfitType(t);
  _ellipticityCurveTarget.setMisfitType(t);
  _ellipticityPeakTarget.setMisfitType(t);
  _refractionVpTarget.setMisfitType(t);
  _refractionVsTarget.setMisfitType(t);
}
/*!
  Build the factories responsible for computing dispersion curves and misfits
*/
void TargetList::validateTargets()
{
  TRACE;
  // Init all factories instead of just dispersion (until 20110404)
  // Bug encountered in gpdcmisfit: load a target with various sub-targets, options
  //                                from command line do not select all of them.
  //                                Hence factories were still allocated but not validated
  //                                however still used by calculate().
  deleteFactories();
  initFactories();

  // Set X from curves
  if(_dispersionTarget.selected() && !_dispersionTarget.curves().isEmpty()) {
    _dispersionFactory=new DispersionFactory;
    _dispersionFactory->setX(_dispersionTarget.curves());
  }
  if(_ellipticityCurveTarget.selected() && !_ellipticityCurveTarget.curves().isEmpty()) {
    _ellipticityFactory=new EllipticityFactory;
    _ellipticityFactory->setX(_ellipticityCurveTarget.curves());
    if (!_dispersionFactory) {
      _dispersionFactory=new DispersionFactory;
    }
  }
  if(_autocorrTarget.selected() && !_autocorrTarget.curves().isEmpty()) {
    _autocorrFactory=new AutocorrFactory(_autocorrTarget.curves().rings());
    int nRings=_autocorrTarget.curves().ringCount();
    for (int iRing=0; iRing<nRings; iRing++) {
      _autocorrFactory->setX(_autocorrTarget.curves().ringCurves(iRing));
    }
    if (!_dispersionFactory) {
      _dispersionFactory=new DispersionFactory;
    }
  }
  if(_ellipticityPeakTarget.selected() && _ellipticityPeakTarget.value().isValid()) {
    if (!_ellipticityFactory) {
      _ellipticityFactory=new EllipticityFactory;
      if(!_dispersionFactory) {
        _dispersionFactory=new DispersionFactory;
        // No sampling defined elsewhere, use a default one from 0.2 to 20 with 100 samples on a log scale
        ModalCurve c;
        c.line( 0.2, 0.0, 20.0, 0.0 );
        c.resample( 100, 0.2, 20.0, LogScale | Function );
        _ellipticityFactory->setX(c);
      }
    }
  }
  // Set consistent X between factories
  if (_autocorrFactory) {
    _autocorrFactory->setX( *_dispersionFactory );
  }
  if (_ellipticityFactory) {
    _ellipticityFactory->setX( *_dispersionFactory );
    if (_autocorrFactory) { // Share again with autocorr if any
      _autocorrFactory->setX( *_dispersionFactory );
    }
  }
  // Set modes
  if (_dispersionFactory) {
    if(_dispersionTarget.selected() && !_dispersionTarget.curves().isEmpty()) {
      _dispersionFactory->linkX(_dispersionTarget.curves());
      _dispersionFactory->setModes(_dispersionTarget.curves());
    }
    _dispersionFactory->setAngularFrequency();
    if (_ellipticityFactory) {
      if(_ellipticityCurveTarget.selected() && !_ellipticityCurveTarget.curves().isEmpty()) {
        _ellipticityFactory->linkX(_ellipticityCurveTarget.curves());
        _ellipticityFactory->setModes(_ellipticityCurveTarget.curves());
      }
      _ellipticityFactory->setAngularFrequency();
      if(_ellipticityPeakTarget.selected() && _ellipticityPeakTarget.value().isValid()) {
        _ellipticityFactory->setMode(Mode( Mode::Phase, Mode::Rayleigh, 0));  // TODO Add mode selector in ellipticity peak
      }
    }
    if (_autocorrFactory) {
      _autocorrFactory->linkX(_autocorrTarget.curves().curves());
      _autocorrFactory->setModes(_autocorrTarget.curves().curves());
      _autocorrFactory->setAngularFrequency();
      _autocorrFactory->init();
    }
    _dispersionFactory->validate(_ellipticityFactory, _autocorrFactory);
  }

  if (_refractionVpTarget.selected() && !_refractionVpTarget.curves().isEmpty()) {
    _refractionVpFactory=new RefractionFactory();
    _refractionVpFactory->setX(_refractionVpTarget.curves());
    _refractionVpFactory->linkX(_refractionVpTarget.curves());
  }
  if (_refractionVsTarget.selected() && !_refractionVsTarget.curves().isEmpty()) {
    _refractionVsFactory=new RefractionFactory();
    _refractionVsFactory->setX(_refractionVsTarget.curves());
    _refractionVsFactory->linkX(_refractionVsTarget.curves());
  }
}

/*!
  Return the number of sample internally set to dispersion computation. Mainly used to inform the user.
*/
int TargetList::dispersionSampleCount() const
{
  TRACE;
  if (!_dispersionFactory) return 0;
  int nSamples = 0;
  Dispersion * d = _dispersionFactory->phaseRayleigh();
  if (d) {
    nSamples = d->xCount();
  } else {
    d = _dispersionFactory->groupRayleigh();
    if (d) {
      nSamples = d->xCount();
    }
  }
  return nSamples;
}

/*!
  \a nDimensions is number of free parameters. This is used only if Akaike misfit is computed.
*/
double TargetList::misfit( int nDimensions, bool& ok )
{
  TRACE;
  double totalMisfit = 0;
  double totalWeight = 0;
  LayeredModel * m = 0;
  if ( surfaceWave() ) {
    m = DCReportBlock::surfaceWaveModel(_vp->depths(), _vp->values(), _vs->values(), _rho->values());
    //fprintf(stdout,"%s\n",surfModel->toString().toAscii().data());
    surfaceMisfit(totalMisfit, totalWeight, m, nDimensions, ok);
    if((_refractionVpTarget.selected() && !_refractionVpTarget.curves().isEmpty()) ||
       (_refractionVsTarget.selected() && !_refractionVsTarget.curves().isEmpty())) {
      refractionMisfit( totalMisfit, totalWeight, m, _pitch->values(), nDimensions, ok );
    }
  } else { // No surface wave
    if (_refractionVpTarget.selected() && !_refractionVpTarget.curves().isEmpty()) {
      if (_refractionVsTarget.selected() && !_refractionVsTarget.curves().isEmpty()) {
        m = DCReportBlock::vspModel( _pitch->depths(), _vp->values(), _vs->values() );
      } else {
        m = DCReportBlock::vpModel( _pitch->depths(), _vp->values() );
      }
    } else if (_refractionVsTarget.selected() && !_refractionVsTarget.curves().isEmpty()) {
      m = DCReportBlock::vsModel( _pitch->depths(), _vs->values() );
    }
    if (m) refractionMisfit( totalMisfit, totalWeight, m, _pitch->values(), nDimensions, ok );
  }
  delete m;
  if ( totalWeight > 0 ) return totalMisfit / totalWeight;
  else return totalMisfit;
}

void TargetList::surfaceMisfit(double& totalMisfit, double& totalWeight,
                               LayeredModel * surfModel,
                               int nDimensions, bool& ok)
{
  TRACE;
  double individualMisfit;

  if (!surfModel->initCalculation()) {
    App::stream() << tr( " *** WARNING *** : bad physical model" ) << endl;
    App::stream() << surfModel->toString() << endl;
    ok=false;
    return;
  }
  // Rayleigh and/or Love modes, phase and/or group
  if (!_dispersionFactory->calculate(surfModel, _ellipticityFactory)) {
    ok=false;
    return;
  }

  if (_dispersionTarget.selected() && !_dispersionTarget.curves().isEmpty()) {
    individualMisfit=curveMisfit(_dispersionTarget.curves(), *_dispersionFactory, _dispersionTarget, nDimensions);
    if(individualMisfit==-1) {
      ok=false;
      return;
    }
    totalMisfit+=_dispersionTarget.misfitWeight()*individualMisfit;
    totalWeight+=_dispersionTarget.misfitWeight();
  }

  if (_autocorrTarget.selected() && !_autocorrTarget.curves().isEmpty()) {
    _autocorrFactory->calculate(_dispersionFactory);
    /*if ( _autocorrFactory->isRadial() || _autocorrFactory->isTransverse() ) {
      _autocorrFactory->setAlpha(_autocorrCurves.curves() );
      _autocorrFactory->setHorizontalAutocorr();
    }*/
    individualMisfit=curveMisfit(_autocorrTarget.curves().curves(), *_autocorrFactory, _autocorrTarget, nDimensions);
    if(individualMisfit==-1) {
      ok=false;
      return;
    }
    totalMisfit+=_autocorrTarget.misfitWeight()*individualMisfit;
    totalWeight+=_autocorrTarget.misfitWeight();
  }

  if (_ellipticityCurveTarget.selected() && !_ellipticityCurveTarget.curves().isEmpty()) {
    individualMisfit=curveMisfit(_ellipticityCurveTarget.curves(), *_ellipticityFactory, _ellipticityCurveTarget, nDimensions);
    if(individualMisfit==-1) {
      ok=false;
      return;
    }
    totalMisfit+=_ellipticityCurveTarget.misfitWeight()*individualMisfit;
    totalWeight+=_ellipticityCurveTarget.misfitWeight();
  }

  if (_ellipticityPeakTarget.selected() && _ellipticityPeakTarget.value().isValid()) {
    // TODO includes misfitType
    // Ellipticity peak misfit is not a L2 norm but just a L1...
    individualMisfit=_ellipticityFactory->peakMisfit(_ellipticityPeakTarget.value(), *_dispersionFactory, surfModel);
    if (individualMisfit<_ellipticityPeakTarget.minimumMisfit()) {
      individualMisfit=_ellipticityPeakTarget.minimumMisfit();
    }
    totalMisfit+=_ellipticityPeakTarget.misfitWeight()*individualMisfit;
    totalWeight+=_ellipticityPeakTarget.misfitWeight();
  }
}

void TargetList::refractionMisfit(double& totalMisfit, double& totalWeight,
                                  LayeredModel * surfModel, const QVector<double>& pitch,
                                  int nDimensions, bool& ok)
{
  TRACE;
  double individualMisfit;
  if (_refractionVpTarget.selected() && !_refractionVpTarget.curves().isEmpty()) {
    TiltLayeredModel m( surfModel->layerCount() );
    m.fromLayeredModel( *surfModel, pitch, LayeredModel::P );
    if ( !_refractionVpFactory->calculate( &m ) ) {
      ok = false;
      return;
    }
    individualMisfit=curveMisfit(_refractionVpTarget.curves(), *_refractionVpFactory, _refractionVpTarget, nDimensions);
    if(individualMisfit==-1) {
      ok=false;
      return;
    }
    totalMisfit+=_refractionVpTarget.misfitWeight()*individualMisfit;
    totalWeight+=_refractionVpTarget.misfitWeight();
  }
  if (_refractionVsTarget.selected() && !_refractionVsTarget.curves().isEmpty()) {
    TiltLayeredModel m( surfModel->layerCount() );
    m.fromLayeredModel( *surfModel, pitch, LayeredModel::S );
    if ( !_refractionVsFactory->calculate( &m ) ) {
      ok = false;
      return;
    }
    individualMisfit=curveMisfit(_refractionVsTarget.curves(), *_refractionVsFactory, _refractionVsTarget, nDimensions);
    if(individualMisfit==-1) {
      ok=false;
      return;
    }
    totalMisfit+=_refractionVsTarget.misfitWeight()*individualMisfit;
    totalWeight+=_refractionVsTarget.misfitWeight();
  }
}

void TargetList::refractionMisfit(double& totalMisfit, double& totalWeight,
                                  TiltLayeredModel * tiltModel,
                                  int nDimensions, bool& ok)
{
  TRACE;
  double individualMisfit;
  if (_refractionVpTarget.selected() && !_refractionVpTarget.curves().isEmpty()) {
    if ( !_refractionVpFactory->calculate( tiltModel ) ) {
      ok=false;
      return;
    }
    individualMisfit=curveMisfit(_refractionVpTarget.curves(), *_refractionVpFactory, _refractionVpTarget, nDimensions);
    if(individualMisfit==-1) {
      ok=false;
      return;
    }
    totalMisfit+=_refractionVpTarget.misfitWeight()*individualMisfit;
    totalWeight+=_refractionVpTarget.misfitWeight();
  }
  if (_refractionVsTarget.selected() && !_refractionVsTarget.curves().isEmpty()) {
    if ( !_refractionVsFactory->calculate( tiltModel ) ) {
      ok=false;
      return;
    }
    individualMisfit=curveMisfit(_refractionVsTarget.curves(), *_refractionVsFactory, _refractionVsTarget, nDimensions);
    if(individualMisfit==-1) {
      ok=false;
      return;
    }
    totalMisfit+=_refractionVpTarget.misfitWeight()*individualMisfit;
    totalWeight+=_refractionVsTarget.misfitWeight();
  }
}

/*!
  Return the global misfit for the curve list \a curveList, compared to values
  computed in factory \a f. It returns zero if the curve list contains no data points
  and -1 if no value are valid for a comparison. If \a normalize is true and if data points
  have no error estimates, the misfit is normalized by the mean observed data.
*/
double TargetList::curveMisfit(const QList<ModalCurve>& curveList, ModalFactory& f,
                               const Target& target, int nDimensions)
{
  TRACE;
  int nValues=0;
  int nData=0;
  double rms_val = 0.0;
  for (QList<ModalCurve>::ConstIterator it = curveList.begin(); it!=curveList.end(); ++it ) {
    rms_val += it->misfit(nValues, nData, f, target.misfitType(), target.minimumMisfit());
  }
  if (nValues>0) {
    switch(target.misfitType()) {
    case StatValue::L1:
    case StatValue::L1_Normalized:
    case StatValue::L1_LogNormalized:
    case StatValue::L1_NormalizedBySigmaOnly:
    case StatValue::L2:
    case StatValue::L2_Normalized:
    case StatValue::L2_LogNormalized:
    case StatValue::L2_NormalizedBySigmaOnly:
      rms_val = sqrt( rms_val/nValues );
      break;
    case StatValue::Akaike:
      rms_val=nValues*log(sqrt(rms_val/nValues))+2.0*nDimensions;
      break;
    case StatValue::AkaikeFewSamples:
      rms_val=nValues*log(sqrt(rms_val/nValues))
                +2.0*nDimensions+(2.0*nDimensions*(nDimensions+1.0))/(nValues-nDimensions-1.0);
      break;
    }
    // Penalty factor if the number of data is greater than number of values
    rms_val*=1.0+nData-nValues;
  } else if (nData==0) {
    rms_val=0.0; // Case where data curve contains only invalid values
  } else {
    rms_val=-1; // Invalid computed curve
  }
  return rms_val;
}

/*!
  Return the global misfit for the curve list \a curveList, compared to values
  computed in factory \a f. It returns zero if the curve list contains no data points
  and -1 if no value are valid for a comparison. If \a normalize is true and if data points
  have no error estimates, the misfit is normalized by the mean observed data.
*/
double TargetList::curveMisfit(const QList<RefractionCurve>& curveList, RefractionFactory& f,
                                  const Target& target, int nDimensions)
{
  TRACE;
  int nValues=0;
  int nData=0;
  double rms_val = 0.0;
  for (QList<RefractionCurve>::ConstIterator it = curveList.begin(); it!=curveList.end(); ++it ) {
    rms_val += it->misfit(nValues, nData, f, target.misfitType(), target.minimumMisfit());
  }
  if (nValues>0) {
    switch(target.misfitType()) {
      case StatValue::L1:
      case StatValue::L1_Normalized:
      case StatValue::L1_LogNormalized:
      case StatValue::L1_NormalizedBySigmaOnly:
      case StatValue::L2:
      case StatValue::L2_Normalized:
      case StatValue::L2_LogNormalized:
      case StatValue::L2_NormalizedBySigmaOnly:
        rms_val = sqrt( rms_val/nValues );
        break;
      case StatValue::Akaike:
        rms_val = nValues * log10( sqrt( rms_val/nValues ) ) + 2.0*nDimensions;
        break;
      case StatValue::AkaikeFewSamples:
        rms_val = nValues * log10( sqrt( rms_val/nValues ) )
                  +2.0*nDimensions+(2.0*nDimensions*(nDimensions+1.0))/(nValues-nDimensions-1.0);
        break;
    }
    // Penalty factor if the number of data is greater than number of values
    rms_val*=1.0+nData-nValues;
  } else if (nData==0) {
    rms_val=0.0; // Case where data curve contains only invalid values
  } else {
    rms_val=-1;
  }
  return rms_val;
}

void TargetList::xml_writeChildren( XML_WRITECHILDREN_ARGS ) const
{
  TRACE;
  static const QString key("type");
  XMLSaveAttributes att;
  att.add(key);
  QString& value = att.value(0);
  value = "dispersion";
  _dispersionTarget.xml_save(s, context, att);
  _autocorrTarget.xml_save(s, context);
  value = "ellipticity";
  _ellipticityCurveTarget.xml_save(s, context, att);
  value = "ellipticity peak";
  _ellipticityPeakTarget.xml_save(s, context, att);
  value = "Vp";
  _refractionVpTarget.xml_save(s, context, att);
  value = "Vs";
  _refractionVsTarget.xml_save(s, context, att);
}

XMLMember TargetList::xml_member( XML_MEMBER_ARGS )
{
  TRACE;
  Q_UNUSED(context);
  static const QString attName("type");
  if(tag=="ModalCurveTarget") {
    XMLRestoreAttributeIterator it=attributes.find(attName);
    if (it!=attributes.end()) {
      if (it.value() == "dispersion") {
        return XMLMember(&_dispersionTarget);
      } else if (it.value() == "ellipticity") {
        return XMLMember(&_ellipticityCurveTarget);
      } else {
        App::stream() << tr("Wrong type of modal curve target: %1").arg(it.value().toString()) << endl;
        return XMLMember(XMLMember::Unknown);
      }
    } else {
      App::stream() << tr("No type defined for modal curve target") << endl;
      return XMLMember(XMLMember::Unknown);
    }
  } else if(tag=="AutocorrTarget") {
    return XMLMember(&_autocorrTarget);
  } else if(tag=="ValueTarget") {
    XMLRestoreAttributeIterator it=attributes.find(attName);
    if (it!=attributes.end()) {
      if (it.value()=="ellipticity peak") {
        return XMLMember(&_ellipticityPeakTarget);
      } else {
        App::stream() << tr("Wrong type of value target: %1").arg(it.value().toString()) << endl;
        return XMLMember(XMLMember::Unknown);
      }
    }  else {
      App::stream() << tr("No type defined for value target") << endl;
      return XMLMember(XMLMember::Unknown);
    }
  } else if(tag=="RefractionTarget") {
    XMLRestoreAttributeIterator it=attributes.find(attName);
    if (it!=attributes.end()) {
      if (it.value()=="Vp") {
        return XMLMember(&_refractionVpTarget);
      } else if (it.value()=="Vs") {
        return XMLMember(&_refractionVsTarget);
      } else {
        App::stream() << tr("Wrong type of refraction target: %1").arg(it.value().toString()) << endl;
        return XMLMember(XMLMember::Unknown);
      }
    }  else {
      App::stream() << tr("No type defined for refraction target") << endl;
      return XMLMember(XMLMember::Unknown);
    }
  // Code below kept for compatibility with files generated before 20090727
  } else if ( tag == "ModalCurve" ) {
    XMLRestoreAttributeIterator it=attributes.find(attName);
    if (it!=attributes.end()) {
      if (it.value() == "disp") {
        _dispersionTarget.curves().append(ModalCurve());
        return XMLMember( &_dispersionTarget.curves().last() );
      } else if (it.value() == "ellCurve") {
        _ellipticityCurveTarget.curves().append(ModalCurve());
        return XMLMember( &_ellipticityCurveTarget.curves().last() );
      } else {
        App::stream() << tr("Wrong type of modal curve %1").arg(it.value().toString()) << endl;
        return XMLMember(XMLMember::Unknown);
      }
    } else {
      App::stream() << tr("No type defined for modal curve") << endl;
      return XMLMember(XMLMember::Unknown);
    }
  } else if (tag == "AutocorrCurves") {
    return XMLMember(&_autocorrTarget.curves());
  } else if ( tag == "StatValue" ) {
    return XMLMember(&_ellipticityPeakTarget.value());
  } else if ( tag == "RefractionCurve") {
    XMLRestoreAttributeIterator it=attributes.find(attName);
    if (it!=attributes.end()) {
      if (it.value() == "refraVp") {
        _refractionVpTarget.curves().append(RefractionCurve());
        return XMLMember( &_refractionVpTarget.curves().last() );
      } else if (it.value() == "refraVs") {
        _refractionVsTarget.curves().append(RefractionCurve());
        return XMLMember( &_refractionVsTarget.curves().last() );
      } else {
        App::stream() << tr("Wrong type of refraction curve %1").arg(it.value().toString()) << endl;
        return XMLMember(XMLMember::Unknown);
      }
    } else {
      App::stream() << tr("No type defined for refraction curve") << endl;
      return XMLMember(XMLMember::Unknown);
    }
  } else if ( tag == "dispWeight" ) return XMLMember( 1 );
  else if ( tag == "dispMinMisfit" ) return XMLMember( 7 );
  else if ( tag == "dispMisfitType" ) return XMLMember( 13 );
  else if ( tag == "autocorrWeight" ) return XMLMember( 2 );
  else if ( tag == "autocorrMinMisfit" ) return XMLMember( 8 );
  else if ( tag == "autocorrMisfitType" ) return XMLMember( 14 );
  else if ( tag == "ellCurveWeight" ) return XMLMember( 3 );
  else if ( tag == "ellCurveMinMisfit" ) return XMLMember( 9 );
  else if ( tag == "ellCurveMisfitType" ) return XMLMember( 15 );
  else if ( tag == "ellPeakWeight" ) return XMLMember( 4 );
  else if ( tag == "ellPeakMinMisfit" ) return XMLMember( 10 );
  else if ( tag == "ellPeakMisfitType" ) return XMLMember( 16 );
  else if ( tag == "refraVpWeight" ) return XMLMember( 5 );
  else if ( tag == "refraVpMinMisfit" ) return XMLMember( 11 );
  else if ( tag == "refraVpMisfitType" ) return XMLMember( 17 );
  else if ( tag == "refraVsWeight" ) return XMLMember( 6 );
  else if ( tag == "refraVsMinMisfit" ) return XMLMember( 12 );
  else if ( tag == "refraVsMisfitType" ) return XMLMember( 18 );
  else if ( tag == "ellWeight" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "modeGuess" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "modeGuessFreeJumping" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "modeGuessCount" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "modeGuessRayleighCount" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "hodoVpWeight" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "hodoVpMinMisfit" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "hodoVsWeight" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "hodoVsMinMisfit" ) return XMLMember( 0 ); // kept for compatibility
  else if ( tag == "ModalDispersion" ) { // kept for compatibility
    CompatModalDispersion * disp = new CompatModalDispersion;
    return XMLMember(disp, true);
  } else return XMLMember(XMLMember::Unknown);
}

bool TargetList::xml_setProperty( XML_SETPROPERTY_ARGS )
{
  // Function kept for compatibility only
  TRACE;
  Q_UNUSED(attributes)
  Q_UNUSED(context);
  switch ( memberID ) {
  case 0: return true;
  case 1: _dispersionTarget.setMisfitWeight(content.toDouble()); return true;
  case 2: _autocorrTarget.setMisfitWeight(content.toDouble()); return true;
  case 3: _ellipticityCurveTarget.setMisfitWeight(content.toDouble()); return true;
  case 4: _ellipticityPeakTarget.setMisfitWeight(content.toDouble()); return true;
  case 5: _refractionVpTarget.setMisfitWeight(content.toDouble()); return true;
  case 6: _refractionVsTarget.setMisfitWeight(content.toDouble()); return true;
  case 7: _dispersionTarget.setMinimumMisfit(content.toDouble()); return true;
  case 8: _autocorrTarget.setMinimumMisfit(content.toDouble()); return true;
  case 9: _ellipticityCurveTarget.setMinimumMisfit(content.toDouble()); return true;
  case 10: _ellipticityPeakTarget.setMinimumMisfit(content.toDouble()); return true;
  case 11: _refractionVpTarget.setMinimumMisfit(content.toDouble()); return true;
  case 12: _refractionVsTarget.setMinimumMisfit(content.toDouble()); return true;
  case 13: _dispersionTarget.setMisfitType(StatValue::misfitType(content.toString())); return true;
  case 14: _autocorrTarget.setMisfitType(StatValue::misfitType(content.toString())); return true;
  case 15: _ellipticityCurveTarget.setMisfitType(StatValue::misfitType(content.toString())); return true;
  case 16: _ellipticityPeakTarget.setMisfitType(StatValue::misfitType(content.toString())); return true;
  case 17: _refractionVpTarget.setMisfitType(StatValue::misfitType(content.toString())); return true;
  case 18: _refractionVsTarget.setMisfitType(StatValue::misfitType(content.toString())); return true;
  default: return false;
  }
}

void TargetList::xml_polishChild( XML_POLISHCHILD_ARGS )
{
  TRACE;
  Q_UNUSED(context);
  // Function kept for compatibility only
  if (child->xml_tagName()=="ModalDispersion") {
    CompatModalDispersion * disp = static_cast<CompatModalDispersion *>(child);
    for (int i=0;i<disp->nModes();i++) {
      _dispersionTarget.curves().append(ModalCurve());
      ModalCurve * c=&_dispersionTarget.curves().last();
      if (i<disp->nRayleighModes()) {
        c->addMode( Mode( Mode::Phase, Mode::Rayleigh, i ) );
      } else {
        c->addMode( Mode( Mode::Phase, Mode::Love, i-disp->nRayleighModes() ) );
      }
      CompatVDataPointVector& m=disp->mode(i);
      for (int i=0;i<m.size();i++) {
        FactoryPoint p;
        p.setX( 0.5 / M_PI * disp->omega(i) );
        p.setMean( m.at(i).mean() );
        p.setStddev( m.at(i).stddev() );
        p.setWeight( m.at(i).weight() );
        c->append( p );
      }
    }
  }
}

void TargetList::xml_polish(XML_POLISH_ARGS)
{
  TRACE;
  Q_UNUSED(context);
  // Ellipticity values are expressed on a log scale
  _ellipticityCurveTarget.setMisfitType(StatValue::L2_LogNormalized);

  validateTargets();
}

} // namespace DinverDCCore
