/***************************************************************************
**
**  This file is part of DinverDCCore.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2009-07-27
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#include "ValueTarget.h"

namespace DinverDCCore {

/*!
  \class ValueTarget qtbvaluetarget.h
  \brief Brief description of class still missing

  Full description of class still missing
*/

const QString ValueTarget::xmlValueTargetTag = "ValueTarget";

/*!
  Description of constructor still missing
*/
ValueTarget::ValueTarget()
    : Target()
{
  TRACE;
  _value.setWeight(1.0);
  _value.setValid(false);
}

/*!
  Description of constructor still missing
*/
ValueTarget::ValueTarget(const ValueTarget& o)
    : Target(o)
{
  TRACE;
  _value=o._value;
}

void ValueTarget::xml_writeChildren( XML_WRITECHILDREN_ARGS ) const
{
  TRACE;
  _value.xml_save(s, context);
}

XMLMember ValueTarget::xml_member( XML_MEMBER_ARGS )
{
  TRACE;
  Q_UNUSED(context);
  if(tag=="StatValue") {
    return XMLMember(&_value);
  } else return Target::xml_member(tag, attributes, context);
}

} // namespace DinverDCCore
