#ifndef DINVERDCCORE_VERSION
#define DINVERDCCORE_VERSION "1.7.3"
#define DINVERDCCORE_VERSION_TIME "201605121341"
#define DINVERDCCORE_VERSION_TYPE "testing"
#define DINVERDCCORE_AUTHORS "Marc Wathelet\nMarc Wathelet (LGIT, Grenoble, France)\nMarc Wathelet (ULg, Liège, Belgium)"
#endif // DINVERDCCORE_VERSION
