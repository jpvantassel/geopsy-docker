
// All headers of mseed library

namespace LibSLink {
#include "slink/libslink.h"
#include "slink/slplatform.h"
}

