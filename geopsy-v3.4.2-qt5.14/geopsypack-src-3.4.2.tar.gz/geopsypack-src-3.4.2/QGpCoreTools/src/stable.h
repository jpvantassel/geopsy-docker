#if defined __cplusplus
#include <QtQml>
#ifndef Q_OS_MAC
#endif // Q_OS_MAC
#endif // __cplusplus
