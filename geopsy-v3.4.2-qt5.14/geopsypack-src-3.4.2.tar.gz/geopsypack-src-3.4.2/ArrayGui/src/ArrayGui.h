#ifndef ARRAYGUI_HEADERS
#define ARRAYGUI_HEADERS

// All headers of ArrayGui library

#include "ArrayGuiDLLExport.h"
#include "ArrayResponse.h"
#include "BlockAveragingParameterWidget.h"
#include "RingEditor.h"
#include "ui_BlockAveragingParameterWidget.h"
#include "ui_RingEditor.h"
#include "ui_WaveNumAnimate.h"

#ifndef GP_EXPLICIT_LIBRARY_NAMESPACE
using namespace ArrayGui;
#endif

#endif // ARRAYGUI_HEADERS
