<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbHVTFALoopTask</name>
    <message>
        <location filename="../src/qtbhvtfaloop.cpp" line="94"/>
        <source>Station %1 : Morlet wavelet convolution at %2 Hz for component %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbHVTFAPlugin</name>
    <message>
        <location filename="../src/qtbhvtfaplugin.cpp" line="48"/>
        <source>H/V TFA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfaplugin.cpp" line="70"/>
        <source>H/V TFA (tag=%1, slot=0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfaplugin.h" line="39"/>
        <source>H/V Time Frequency Analysis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbHVTFAStationSignals</name>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="68"/>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="75"/>
        <source>Creating array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="69"/>
        <source>The samling rate must be the same for all components.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="76"/>
        <source>The differences between t0s must be a multiple of sampling period. Problem with signal ID %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="92"/>
        <source>Saving log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="93"/>
        <source>Unable to open file %1 for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="117"/>
        <source>No signal available for station %1 between times %2 and %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="133"/>
        <source>H/V Time Frequency Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvtfastationsignals.cpp" line="134"/>
        <source>Cannot open .max file %1 for writing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolHVTFA</name>
    <message>
        <location filename="../src/qtbtoolhvtfa.cpp" line="78"/>
        <source>Initializing stations...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfa.cpp" line="90"/>
        <source>Detected less than 3 components
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfa.cpp" line="92"/>
        <source>Checking stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfa.cpp" line="134"/>
        <source>Station %1 : computing fourier spectra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfa.cpp" line="141"/>
        <source>Cannot process an empty station</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfa.cpp" line="163"/>
        <source>Computation stopped</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolHVTFAd</name>
    <message>
        <location filename="../src/qtbtoolhvtfad.cpp" line="43"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.cpp" line="49"/>
        <source>This is just for computing the resolution in time and frequency. It has no influence on the computation of the Morlet transform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.cpp" line="56"/>
        <source>H/V Time frequency Analysis output file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.cpp" line="56"/>
        <source>Output max files (*.max)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="13"/>
        <source>H/V TFA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="31"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="43"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Modified Morlet Wavelet in spectral domain:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;M = 1/pow(pi,0.25)*exp( w0*f/fi - w0 )/ m&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;w0, m0 are the wavelet parameters. Theoretically w0&amp;gt;5.5. A typical value for w0 is 6. A typical value for m0 is 10.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;fi is the analysed frequency.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="56"/>
        <source>Wavelet parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="68"/>
        <source>Frequency range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="77"/>
        <source>Comments on frequency resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="89"/>
        <source>Output directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="99"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="126"/>
        <source>Load parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="149"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhvtfad.ui" line="159"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
