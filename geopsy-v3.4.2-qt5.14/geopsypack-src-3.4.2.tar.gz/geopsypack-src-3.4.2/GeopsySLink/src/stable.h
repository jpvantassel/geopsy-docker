#if defined __cplusplus
#include <QtNetwork>
#ifndef Q_OS_MAC
#include <QGpCoreTools.h>
#include <QGpCoreMath.h>
#include <GeopsyCore.h>
#include <slink.h>
#endif // Q_OS_MAC
#endif // __cplusplus
