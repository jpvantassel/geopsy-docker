/***************************************************************************
**
**  This file is part of ArrayCore.
**
**  ArrayCore is free software: you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  ArrayCore is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with Foobar.  If not, see <http://www.gnu.org/licenses/>
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2019-04-12
**  Copyright: 2019
**    Marc Wathelet (ISTerre, Grenoble, France)
**
***************************************************************************/

#include "FKSteeringTwoComponentRayleighRadial.h"
#include "FKSteeringOneComponent.h"

namespace ArrayCore {

  const int FKSteeringTwoComponentRayleighRadial::sizeFactor=2;

  /*!
    \class FKSteeringTwoComponentRayleighRadial FKSteeringTwoComponentRayleighRadial.h
    \brief Brief description of class still missing

    Full description of class still missing
  */

  void FKSteeringTwoComponentRayleighRadial::init(FKCache * cache, int index, const Point& kell)
  {
    FKSteeringTwoComponentRayleighRadial& s=FKSteeringTwoComponentRayleighRadial::cache(cache, index);
    s.resize();
    s.initValue(kell, ::tan(kell.z()));
  }

  void FKSteeringTwoComponentRayleighRadial::initValue(const Point2D& k, double ell)
  {
    int stationCount=_array->count();
    Complex q;
    Complex cell(0.0, -ell);
    for(int i=stationCount-1; i>=0; i--) {
      const Point2D& r=_array->relativePos(i);
      q.setUnitExp(-r.scalarProduct(k));
      _e.at(i+stationCount, 0)=q;
      _eh.at(0, i+stationCount)=conjugate(q);
      q*=cell;
      _e.at(i, 0)=q;
      _eh.at(0, i)=conjugate(q);
    }
  }

  void FKSteeringTwoComponentRayleighRadial::initValue(const FKSteeringOneComponent& s, double ell)
  {
    int stationCount=_array->count();
    Complex cell(0.0, -ell);
    Complex ccell(0.0, ell);
    for(int i=stationCount-1; i>=0; i--) {
      const Complex& e=s._e.at(i, 0);
      const Complex& eh=s._eh.at(0, i);
      _e.at(i+stationCount, 0)=e;
      _eh.at(0, i+stationCount)=eh;
      _e.at(i, 0)=e*cell;
      _eh.at(0, i)=eh*ccell;
    }
  }

} // namespace ArrayCore

