/***************************************************************************
**
**  This file is part of ArrayCore.
**
**  ArrayCore is free software: you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  ArrayCore is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with Foobar.  If not, see <http://www.gnu.org/licenses/>
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2018-01-04
**  Copyright: 2018-2019
**    Marc Wathelet (ISTerre, Grenoble, France)
**
***************************************************************************/

#include "PoggiFKVertical.h"
#include "HRFKRadial.h"

namespace ArrayCore {

  /*!
    \class PoggiFKVertical PoggiFKVertical.h
    \brief Vertical high resolution FK power with ellipticity

    Vertical high resolution FK power versus wavenumber (k) function.
    The cross-spectrum is already projected on the radial direction.
    Ellipticity is computed according Poggi et al. (2010) in GJI.
  */

  double PoggiFKVertical::ellipticity(const Point& k, bool& ok)
  {
    HRFKRadial radial(_gridCache);
    ok=true;
    return ::sqrt(radial.value(k)/value(k));
  }

} // namespace ArrayCore

