<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbHVPlugin</name>
    <message>
        <location filename="../src/qtbhvplugin.h" line="41"/>
        <source>H/V and Spectal ratios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="54"/>
        <source>H/V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="48"/>
        <source>Spectrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="60"/>
        <source>Spectrum Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="66"/>
        <source>H/V Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="131"/>
        <source>Spectrum (tag=%1, slot=0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="139"/>
        <source>Spectrum Rotate (tag=%1, slot=2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="141"/>
        <source>H/V Rotate (tag=%1, slot=3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="135"/>
        <source>H/V (tag=%1, slot=1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbHVRotateWinResults</name>
    <message>
        <location filename="../src/qtbhvrotatewinresults.cpp" line="44"/>
        <source>Azimuth from North (degrees)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvrotatewinresults.cpp" line="60"/>
        <source>H/V Rotate Results - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvrotatewinresults.cpp" line="72"/>
        <source>H/V amplitude</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbHVSummary</name>
    <message>
        <location filename="../src/qtbhvsummary.cpp" line="56"/>
        <source>H/V summary - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvsummary.cpp" line="63"/>
        <location filename="../src/qtbhvsummary.cpp" line="67"/>
        <source>H/V amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvsummary.cpp" line="65"/>
        <source>H/V peak frequency (Hz)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbHVWinResults</name>
    <message>
        <location filename="../src/qtbhvwinresults.cpp" line="41"/>
        <source>H/V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvwinresults.cpp" line="57"/>
        <source>H/V Results - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvwinresults.cpp" line="65"/>
        <source>Load H/V results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhvwinresults.cpp" line="65"/>
        <source>HV file (*.hv)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbSpectrumRotateWinResults</name>
    <message>
        <location filename="../src/qtbspectrumrotatewinresults.cpp" line="44"/>
        <source>Azimuth from North (degrees)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumrotatewinresults.cpp" line="60"/>
        <source>Horizontal Spectrum Rotate Results - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumrotatewinresults.cpp" line="72"/>
        <source>Spectrum amplitude</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbSpectrumStation</name>
    <message>
        <location filename="../src/qtbspectrumstation.cpp" line="54"/>
        <source>Cannot save results for an empty station</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbSpectrumSummary</name>
    <message>
        <location filename="../src/qtbspectrumsummary.cpp" line="44"/>
        <source>Spectrum summary - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumsummary.cpp" line="51"/>
        <location filename="../src/qtbspectrumsummary.cpp" line="54"/>
        <source>Spectrum amplitude</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbSpectrumWinResults</name>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="42"/>
        <source>Amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="55"/>
        <source>Spectrum Results - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="64"/>
        <source>&amp;Derivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="65"/>
        <source>Derivate the selected spectra.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="69"/>
        <source>&amp;Integrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="70"/>
        <source>Integrate the selected spectra.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="79"/>
        <source>Derivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="96"/>
        <source>Integrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="114"/>
        <source>Load spectrum results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspectrumwinresults.cpp" line="114"/>
        <source>Spectrum file (*.spec)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbStudentTest</name>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="16"/>
        <source>Statistical comparison</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="39"/>
        <source>Compare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="46"/>
        <source>this curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="65"/>
        <source>With the same curve in ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="90"/>
        <source>Test&apos;s significance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="87"/>
        <source>&lt;p&gt;The significance is a number between zero and one, and is the probability that abs(t) could be this large or larger just by chance, for distributions with equal means. Therefore, a small numerical value (0.05 or 0.01) means that the observed difference is &quot;very significant&quot;.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="97"/>
        <source>0.01</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="133"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstudenttest.ui" line="149"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbTabHVPreferences</name>
    <message>
        <location filename="../src/qtbtabhvpreferences.cpp" line="41"/>
        <source>Spectrum options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtabhvpreferences.cpp" line="43"/>
        <source>H/V options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtabhvpreferences.ui" line="13"/>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolExport</name>
    <message>
        <location filename="../src/qtbhvplugin.cpp" line="101"/>
        <source>HV</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolHV</name>
    <message>
        <location filename="../src/qtbtoolhv.cpp" line="40"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhv.cpp" line="41"/>
        <source>North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhv.cpp" line="42"/>
        <source>East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhv.cpp" line="66"/>
        <source>Initializing stations...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhv.cpp" line="78"/>
        <source>Detected less than 3 components
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhv.cpp" line="80"/>
        <source>Checking stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolhv.cpp" line="68"/>
        <source>H/V toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolHVRotate</name>
    <message>
        <location filename="../src/qtbtoolhvrotate.cpp" line="69"/>
        <source>H/V Rotate toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolSpectrum</name>
    <message>
        <location filename="../src/qtbtoolspectrum.cpp" line="51"/>
        <source>Any component</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspectrum.cpp" line="71"/>
        <source>Initializing stations...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtoolspectrum.cpp" line="80"/>
        <source>Checking stations</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolSpectrumRotate</name>
    <message>
        <location filename="../src/qtbtoolspectrumrotate.cpp" line="70"/>
        <source>Horizontal Spectrum Rotate toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
